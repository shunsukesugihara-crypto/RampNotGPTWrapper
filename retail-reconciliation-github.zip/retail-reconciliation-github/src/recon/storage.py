"""CSV-backed relational model. Only source business data is loaded, never labels."""
from __future__ import annotations
import csv
import sqlite3
from pathlib import Path

TABLES = {
    "products": "sku,description",
    "purchase_orders": "po_id,retailer,order_date",
    "invoices": "invoice_id,po_id,invoice_date",
    "invoice_lines": "invoice_line_id,invoice_id,sku,quantity,unit_price_cents",
    "shipments": "shipment_id,po_id,ship_date",
    "shipment_lines": "shipment_id,sku,shipped_qty",
    "receipts": "shipment_id,sku,received_qty,receipt_date",
    "deductions": "deduction_id,retailer,notice_date,amount_cents,short_qty,reason,description,sku_hint,po_hint,invoice_hint,shipment_hint",
}

DDL = """
PRAGMA foreign_keys=ON;
CREATE TABLE products(sku TEXT PRIMARY KEY, description TEXT NOT NULL);
CREATE TABLE purchase_orders(po_id TEXT PRIMARY KEY, retailer TEXT NOT NULL, order_date TEXT NOT NULL);
CREATE TABLE invoices(invoice_id TEXT PRIMARY KEY, po_id TEXT NOT NULL REFERENCES purchase_orders(po_id), invoice_date TEXT NOT NULL);
CREATE TABLE invoice_lines(invoice_line_id TEXT PRIMARY KEY, invoice_id TEXT NOT NULL REFERENCES invoices(invoice_id), sku TEXT NOT NULL REFERENCES products(sku), quantity INTEGER NOT NULL CHECK(quantity>0), unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents>0));
CREATE TABLE shipments(shipment_id TEXT PRIMARY KEY, po_id TEXT NOT NULL REFERENCES purchase_orders(po_id), ship_date TEXT NOT NULL);
CREATE TABLE shipment_lines(shipment_id TEXT NOT NULL REFERENCES shipments(shipment_id),sku TEXT NOT NULL REFERENCES products(sku),shipped_qty INTEGER NOT NULL CHECK(shipped_qty>0), PRIMARY KEY(shipment_id,sku));
CREATE TABLE receipts(shipment_id TEXT NOT NULL,sku TEXT NOT NULL,received_qty INTEGER NOT NULL CHECK(received_qty>=0),receipt_date TEXT NOT NULL,PRIMARY KEY(shipment_id,sku),FOREIGN KEY(shipment_id,sku) REFERENCES shipment_lines(shipment_id,sku));
CREATE TABLE deductions(deduction_id TEXT PRIMARY KEY,retailer TEXT NOT NULL,notice_date TEXT NOT NULL,amount_cents INTEGER NOT NULL CHECK(amount_cents>0),short_qty INTEGER NOT NULL CHECK(short_qty>0),reason TEXT NOT NULL,description TEXT NOT NULL,sku_hint TEXT,po_hint TEXT,invoice_hint TEXT,shipment_hint TEXT);
CREATE INDEX idx_po_retailer ON purchase_orders(retailer);
CREATE INDEX idx_shipment_date ON shipments(ship_date);
"""

def load_data(path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(DDL)
    path = Path(path)
    for table, columns_string in TABLES.items():
        columns = columns_string.split(",")
        with (path / f"{table}.csv").open(newline="",encoding="utf-8") as stream:
            reader = csv.DictReader(stream)
            if reader.fieldnames != columns:
                raise ValueError(f"Bad schema for {table}: expected {columns}; got {reader.fieldnames}")
            rows = []
            for record in reader:
                rows.append([record[c] if record[c] != "" else None for c in columns])
        placeholders = ",".join("?" for _ in columns)
        conn.executemany(f"INSERT INTO {table} ({columns_string}) VALUES ({placeholders})", rows)
    conn.commit()
    bad = conn.execute("SELECT COUNT(*) FROM receipts r JOIN shipment_lines s USING(shipment_id, sku) WHERE r.received_qty>s.shipped_qty").fetchone()[0]
    if bad:
        raise ValueError(f"Invalid data: {bad} receipt quantities exceed shipped quantity")
    return conn
