"""Evaluate frozen engines without teaching them hidden answers or raw sidecars.

Supported single-line accuracy, lossy-schema scope traps, and malformed inputs
are reported separately. An automatic link can have the right hidden identity
and still be inappropriate when the observable evidence is ambiguous.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
from time import perf_counter

from recon.engine import reconcile as baseline_reconcile
from recon.storage import TABLES, load_data as baseline_load_data
from recon.phase2.executor import RapidFuzzRanker
from recon.phase2.service import reconcile as phase2_reconcile
from recon.phase2.storage import load_data as phase2_load_data

ROOT = Path(__file__).resolve().parents[3]
ENGINES = ("baseline", "phase2_offline", "phase2_offline_text")


def _write_tables(path: Path, tables: dict) -> None:
    if set(tables) - set(TABLES):
        raise ValueError("Only business tables are allowed; labels must stay outside the engine")
    for table, records in tables.items():
        columns = TABLES[table].split(',')
        with (path / f"{table}.csv").open('w', newline='', encoding='utf-8') as stream:
            writer = csv.DictWriter(stream, fieldnames=columns)
            writer.writeheader()
            writer.writerows(records)


def _key(row: dict) -> tuple[str, str, str]:
    return row["invoice_line_id"], row["shipment_id"], row["sku"]


def evaluate_case(case: dict, label: dict, engine: str, *, rank_text: bool = False) -> dict:
    if engine not in ENGINES:
        raise ValueError(f"Unknown benchmark engine: {engine}")
    if label["case_id"] != case["case_id"]:
        raise ValueError("Case and label IDs differ")
    start = perf_counter()
    result = {"case_id": case["case_id"], "split": case["split"], "suite": case["suite"],
              "family": case["family"], "engine": engine, "input_supported": True,
              "error_type": None, "automatic_link_permitted": label["automatic_link_permitted"]}
    connection = None
    try:
        with tempfile.TemporaryDirectory(prefix="recon-stress-") as directory:
            folder = Path(directory)
            _write_tables(folder, case["tables"])
            # Phase 1 explicitly requires these notice fields; missing values
            # represent new input coverage, not an incorrect baseline decision.
            notices = case["tables"].get("deductions", [])
            notice = next((row for row in notices if row["deduction_id"] == case["deduction_id"]), None)
            missing = [] if notice is None else [field for field in ("amount_cents", "short_qty", "description")
                                                   if notice.get(field) in (None, '')]
            if engine == "baseline" and missing:
                output = {"status": "unsupported", "reason": "outside_phase1_required_input_schema",
                          "missing_required_fields": missing, "candidates": []}
                result["input_supported"] = False
            else:
                loader = baseline_load_data if engine == "baseline" else phase2_load_data
                connection = loader(folder)
                if engine == "baseline":
                    output = baseline_reconcile(connection, case["deduction_id"])
                else:
                    ranker = RapidFuzzRanker() if rank_text or engine == "phase2_offline_text" else None
                    output = phase2_reconcile(connection, case["deduction_id"], ranker=ranker)
    except (sqlite3.IntegrityError, FileNotFoundError, ValueError) as exc:
        result.update(input_supported=False, error_type=type(exc).__name__)
        output = {"status": "data_rejected", "reason": str(exc), "candidates": []}
    except ImportError as exc:
        result.update(input_supported=False, error_type=type(exc).__name__)
        output = {"status": "unavailable", "reason": "Optional text ranking dependency unavailable", "candidates": []}
    except Exception as exc:
        # Crashes are observations, never converted into safe-review successes.
        result.update(error_type=type(exc).__name__)
        output = {"status": "error", "reason": type(exc).__name__, "candidates": []}
    finally:
        if connection is not None:
            connection.close()
    matched = output["status"] == "matched"
    expected = {_key(item) for item in label["expected_links"]}
    chosen = {_key(item) for item in output.get("candidates", [])} if matched else set()
    identity_correct = chosen == expected if matched else None
    inappropriate = matched and (identity_correct is not True or not label["automatic_link_permitted"])
    behavior = output["status"] in label["expected_statuses"] and not inappropriate
    claim_expected = label.get("expected_claim_assessment")
    if claim_expected is not None and matched:
        behavior = behavior and output.get("claim_assessment") == claim_expected
    return {**result, "status": output["status"], "matched": matched,
            "identity_correct": identity_correct, "inappropriate_automatic_link": inappropriate,
            "expected_behavior_met": bool(behavior), "runtime_ms": (perf_counter() - start) * 1000,
            "expected_statuses": label["expected_statuses"], "expected_links": label["expected_links"],
            "label_explanation": label.get("explanation"), "result": output}


def summarize(results: list[dict]) -> dict:
    count = len(results)
    matched = [row for row in results if row["matched"]]
    correct = sum(row["identity_correct"] is True for row in matched)
    inappropriate = sum(row["inappropriate_automatic_link"] for row in matched)
    permitted = [row for row in results if row["automatic_link_permitted"]]
    justified = sum(row["matched"] and not row["inappropriate_automatic_link"] for row in results)
    return {
        "case_count": count, "status_counts": dict(Counter(row["status"] for row in results)),
        "automatic_links": len(matched), "identity_correct_automatic_links": correct,
        "identity_wrong_automatic_links": len(matched) - correct,
        "inappropriate_automatic_links": inappropriate,
        "right_identity_but_unjustified_links": sum(row["identity_correct"] is True and row["inappropriate_automatic_link"] for row in matched),
        "automatic_identity_precision": correct / len(matched) if matched else None,
        "justified_automatic_precision": (len(matched) - inappropriate) / len(matched) if matched else None,
        "automatic_coverage": len(matched) / count if count else None,
        "permitted_automatic_cases": len(permitted),
        "justified_automatic_coverage_of_permitted": justified / len(permitted) if permitted else None,
        "expected_behavior_met": sum(row["expected_behavior_met"] for row in results),
        "expected_behavior_rate": sum(row["expected_behavior_met"] for row in results) / count if count else None,
        "input_unsupported": sum(row["status"] == "unsupported" for row in results),
        "data_rejected": sum(row["status"] == "data_rejected" for row in results),
        "engine_errors": sum(row["status"] == "error" for row in results),
        "unavailable": sum(row["status"] == "unavailable" for row in results),
        "runtime_ms_total": sum(row["runtime_ms"] for row in results),
    }


def _read_jsonl(path: Path) -> dict[str, dict]:
    values = {}
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            item = json.loads(line)
            if item["case_id"] in values:
                raise ValueError(f"Duplicate case ID in {path.name}")
            values[item["case_id"]] = item
    return values


def check_engine_snapshot(path: Path | None = None) -> dict:
    path = path or ROOT / "evaluation" / "engine_snapshot.json"
    if not path.exists():
        return {"available": False, "unchanged": None}
    snapshot = json.loads(path.read_text())
    changed = [name for name, digest in snapshot["files"].items()
               if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest]
    return {"available": True, "unchanged": not changed, "changed_files": changed,
            "frozen_at_utc": snapshot["frozen_at_utc"]}


def run(corpus_dir: Path, output: Path | None = None, *, rank_text: bool = False) -> dict:
    corpus_dir = Path(corpus_dir)
    cases = _read_jsonl(corpus_dir / "cases.jsonl")
    labels = _read_jsonl(corpus_dir / "labels.jsonl")
    if set(cases) != set(labels):
        raise ValueError("Exactly one hidden label is required per case")
    before = check_engine_snapshot()
    if before["available"] and not before["unchanged"]:
        raise ValueError("Matching engine changed since freeze; do not silently report a frozen benchmark")
    engines = ENGINES if rank_text else ENGINES[:2]
    corpus_hashes = {name: hashlib.sha256((corpus_dir / name).read_bytes()).hexdigest()
                     for name in ("manifest.json", "cases.jsonl", "labels.jsonl", "raw_notices.jsonl")
                     if (corpus_dir / name).exists()}
    all_results = [evaluate_case(case, labels[key], engine)
                   for key, case in cases.items() for engine in engines]
    grouped = defaultdict(list)
    families = defaultdict(list)
    for row in all_results:
        grouped[(row["engine"], row["suite"], row["split"])].append(row)
        families[(row["engine"], row["family"])].append(row)
    report = {
        "dataset": "Authored synthetic challenge corpus; not representative real retail records",
        "corpus_manifest": json.loads((corpus_dir / "manifest.json").read_text()),
        "engine_snapshot_before": before, "engine_snapshot_after": check_engine_snapshot(),
        "live_ai_evaluated": False,
        "live_ai_not_run_reason": "This runner evaluates offline engines only; offline results are not AI quality evidence",
        "model_configuration": {"api_key_present": bool(os.environ.get("OPENAI_API_KEY")),
                                "model_present": bool(os.environ.get("OPENAI_MODEL"))},
        "corpus_sha256_before_execution": corpus_hashes,
        "corpus_unchanged_after_execution": all(hashlib.sha256((corpus_dir / name).read_bytes()).hexdigest() == digest
                                                for name, digest in corpus_hashes.items()),
        "engines": list(engines), "case_count_per_engine": len(cases),
        "summaries": {engine: {suite: summarize([row for row in all_results if row["engine"] == engine and row["suite"] == suite])
                              for suite in sorted({case["suite"] for case in cases.values()})} for engine in engines},
        "by_split": [{"engine": key[0], "suite": key[1], "split": key[2], **summarize(rows)} for key, rows in sorted(grouped.items())],
        "by_family": [{"engine": key[0], "family": key[1], **summarize(rows)} for key, rows in sorted(families.items())],
        "interpretation": [
            "Do not pool supported single-line precision with malformed input or lossy-schema scope traps.",
            "Scope traps deliberately retain units/currency/multi-line facts in raw_notices.jsonl; legacy engine tables cannot express them.",
            "An automatic result on an ambiguous or out-of-scope case is inappropriate even if it happens to equal the hidden identity.",
            "Baseline inputs missing required fields are unsupported, not assumed review decisions.",
            "Generated heldout-only combinations test this corpus; they do not establish external generalization.",
            "No matching code was tuned against the generated outputs.",
        ],
        "failures": [{key: row[key] for key in ("case_id", "family", "suite", "split", "engine", "status", "identity_correct", "inappropriate_automatic_link", "label_explanation")}
                     for row in all_results if not row["expected_behavior_met"]],
    }
    baseline_accepted = {row["case_id"] for row in all_results
                         if row["engine"] == "baseline" and row["suite"] == "supported"
                         and row["input_supported"] and row["error_type"] is None}
    report["common_schema_supported"] = {engine: summarize([row for row in all_results
        if row["engine"] == engine and row["case_id"] in baseline_accepted]) for engine in engines}
    if output is not None:
        output = Path(output)
        output.parent.mkdir(parents=True, exist_ok=True)
        detail = output.with_suffix('.cases.jsonl')
        with detail.open('w', encoding='utf-8') as stream:
            for row in all_results:
                stream.write(json.dumps(row, sort_keys=True) + '\n')
        report["case_results_file"] = str(detail)
        output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, default=Path("evaluation/stress"))
    parser.add_argument("--output", type=Path, default=Path("output/stress_evaluation.json"))
    parser.add_argument("--rank-text", action="store_true")
    args = parser.parse_args()
    report = run(args.corpus, args.output, rank_text=args.rank_text)
    print(json.dumps({"output": str(args.output), "cases_per_engine": report["case_count_per_engine"],
                      "live_ai_evaluated": False, "summaries": report["summaries"]}, indent=2))


if __name__ == "__main__":
    main()
