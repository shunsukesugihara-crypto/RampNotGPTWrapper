"""Audit genuine procurement observations without inventing deduction evidence.

BPI 2019 is an event log, not the engine's shortage-reconciliation input. This
module measures that coverage gap and observed complexity; it cannot score real
deduction matching because the source provides neither notices nor match labels.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import sqlite3

from recon.storage import TABLES, load_data as load_baseline
from recon.phase2.storage import load_data as load_phase2


ROOT = Path(__file__).resolve().parents[3]
ABSENT = {"", "NONE", "UNKNOWN"}
INVOICE_EVENT = "Record Invoice Receipt"
RECEIPT_EVENT = "Record Goods Receipt"
MONEY_FIELD = "Cumulative net worth (EUR)"
GAPS = (
    "retailer deduction notices and deduction amounts",
    "reported shortage case quantities",
    "shipment case quantities and shipment-line identities",
    "invoice case unit prices",
    "product SKU identifiers and catalog descriptions",
    "independent labeled shortage-to-transaction matches",
)


def _present(value: object) -> bool:
    return value is not None and str(value).strip().upper() not in ABSENT


def _presence(records: list[dict]) -> dict:
    fields = sorted({field for record in records for field in record})
    return {
        field: {
            "present": sum(_present(record.get(field)) for record in records),
            "missing_or_placeholder": sum(not _present(record.get(field)) for record in records),
        }
        for field in fields
    }


def _probe_loader(loader, directory: Path) -> dict:
    try:
        conn = loader(directory)
    except (OSError, ValueError, sqlite3.Error) as error:
        return {
            "accepted_raw_sample": False,
            "error_type": type(error).__name__,
            "error": str(error),
            "meaning": "Input schema is unsupported; no matching decision was executed.",
        }
    else:
        conn.close()
        return {
            "accepted_raw_sample": True,
            "meaning": "Loader acceptance alone does not establish real deduction coverage.",
        }


def audit(sample: str | Path) -> dict:
    directory = Path(sample)
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    path = directory / manifest.get("normalized_file", "traces.jsonl")
    # The filename must remain inside the selected public sample directory.
    if path.resolve().parent != directory.resolve():
        raise ValueError("Normalized trace file must be inside the sample directory")
    traces = []
    with path.open(encoding="utf-8") as stream:
        for number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            trace = json.loads(line)
            if (not isinstance(trace, dict) or not isinstance(trace.get("attributes"), dict)
                    or not isinstance(trace.get("events"), list)
                    or not all(isinstance(event, dict) for event in trace["events"])):
                raise ValueError(f"Invalid trace structure on line {number}")
            traces.append(trace)
    attributes = [trace["attributes"] for trace in traces]
    events = [event for trace in traces for event in trace["events"]]
    activities = Counter(event.get("concept:name", "<absent>") for event in events)
    category = Counter(record.get("Item Category", "<absent>") for record in attributes)
    per_trace = [Counter(event.get("concept:name") for event in trace["events"]) for trace in traces]
    timestamps, invalid_timestamps = [], 0
    for event in events:
        value = event.get("time:timestamp")
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                raise ValueError("Timezone missing")
            timestamps.append(parsed)
        except ValueError:
            invalid_timestamps += 1

    money, invalid_money, absent_money = [], 0, 0
    for event in events:
        value = event.get(MONEY_FIELD)
        if not _present(value):
            absent_money += 1
            continue
        try:
            number = Decimal(str(value))
            if not number.is_finite():
                raise InvalidOperation
            money.append(number)
        except InvalidOperation:
            invalid_money += 1

    prefix = directory / "source_prefix.xes.part"
    prefix_hash = hashlib.sha256(prefix.read_bytes()).hexdigest() if prefix.exists() else None
    expected_hash = manifest.get("downloaded_prefix_sha256")
    return {
        "dataset": manifest.get("title", "BPI Challenge 2019"),
        "source": {key: manifest.get(key) for key in (
            "citation", "license", "metadata_url", "download_url", "retrieved_at_utc")},
        "sample": {
            "method": manifest.get("sample_method"),
            "representative": False,
            "limitation": "Source-file prefix, not random; these counts describe only the downloaded sample.",
            "trace_count": len(traces),
            "manifest_trace_count": manifest.get("sample_trace_count"),
            "manifest_trace_count_matches": len(traces) == manifest.get("sample_trace_count"),
            "event_count": len(events),
            "unique_purchase_documents": len({record["Purchasing Document"] for record in attributes
                                               if _present(record.get("Purchasing Document"))}),
            "unique_vendors": len({record["Vendor"] for record in attributes if _present(record.get("Vendor"))}),
            "unique_companies": len({record["Company"] for record in attributes if _present(record.get("Company"))}),
            "normalized_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "downloaded_prefix_sha256": prefix_hash,
            "prefix_hash_matches_manifest": prefix_hash == expected_hash if prefix_hash and expected_hash else None,
        },
        "observed": {
            "activity_counts": dict(sorted(activities.items())),
            "item_category_counts": dict(sorted(category.items())),
            "traces_with_multiple_invoice_receipt_events": sum(row[INVOICE_EVENT] > 1 for row in per_trace),
            "traces_with_multiple_goods_receipt_events": sum(row[RECEIPT_EVENT] > 1 for row in per_trace),
            "traces_without_invoice_receipt_event": sum(row[INVOICE_EVENT] == 0 for row in per_trace),
            "traces_without_goods_receipt_event": sum(row[RECEIPT_EVENT] == 0 for row in per_trace),
            "absence_interpretation": "An absent event is an observation, not necessarily an error; item categories have different requirements.",
            "traces_with_price_change_event": sum(row["Change Price"] > 0 for row in per_trace),
            "traces_with_quantity_change_event": sum(row["Change Quantity"] > 0 for row in per_trace),
            "traces_with_invoice_cancellation_event": sum(row["Cancel Invoice Receipt"] > 0 for row in per_trace),
            "traces_with_goods_receipt_cancellation_event": sum(row["Cancel Goods Receipt"] > 0 for row in per_trace),
            "event_time_range": {
                "earliest": min(timestamps).isoformat() if timestamps else None,
                "latest": max(timestamps).isoformat() if timestamps else None,
                "invalid_or_missing_count": invalid_timestamps,
            },
            "trace_field_presence": _presence(attributes),
            "event_field_presence": _presence(events),
            "monetary_observations": {
                "source_field": MONEY_FIELD,
                "numeric_event_values": len(money),
                "missing_or_placeholder_values": absent_money,
                "invalid_values": invalid_money,
                "smallest_observed_value": str(min(money)) if money else None,
                "largest_observed_value": str(max(money)) if money else None,
                "interpretation": "Observed anonymized event values only. Publisher scales monetary values preserving addition approximately. Cumulative values, cancellations, and subsequent invoices require source-specific interpretation. No sums or verified reconciliation are claimed.",
            },
        },
        "existing_engine_coverage": {
            "phase1_raw_ingestion": _probe_loader(load_baseline, directory),
            "phase2_raw_ingestion": _probe_loader(load_phase2, directory),
            "missing_engine_csv_files": [f"{table}.csv" for table in TABLES if not (directory / f"{table}.csv").exists()],
            "missing_required_business_evidence": list(GAPS),
            "real_deduction_cases_available": 0,
            "supported_real_deduction_cases": 0,
            "real_deduction_accuracy": None,
            "evaluation_performed": False,
            "reason": "This public procurement log supplies no shortage deduction notices or labeled matches. Raw loader failures measure an input/coverage gap, not successful abstention or matching accuracy.",
        },
        "financial_facts_generated": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sample", type=Path, default=ROOT / "evaluation/public/bpi2019")
    parser.add_argument("--output", type=Path, default=ROOT / "output/real_data_audit.json")
    args = parser.parse_args()
    result = audit(args.sample)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "traces": result["sample"]["trace_count"],
                      "events": result["sample"]["event_count"],
                      "real_deduction_accuracy": None, "evaluation_performed": False}))


if __name__ == "__main__":
    main()
