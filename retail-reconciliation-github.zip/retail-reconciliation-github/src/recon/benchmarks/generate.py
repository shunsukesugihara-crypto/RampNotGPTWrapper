"""Seeded synthetic stress inputs; never consult either reconciliation engine.

This is an authored regression/stress corpus, not representative retail data.
Labels and raw semantic facts are separate from the exact-schema engine inputs.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import random

from recon.storage import TABLES

DEFAULT_SEED = 20261107
DEFAULT_REPLICAS = 12
SUPPORTED_FAMILIES = (
    "clean_reference", "missing_sku", "missing_qty_receipt", "missing_qty_no_receipt",
    "no_refs_unique_receipt", "no_refs_no_receipt", "exact_description_ambiguity",
    "generic_sameprice_ambiguity", "same_sku_multiple_shipments", "knownqty_disputed_receipt",
    "conflicting_refs", "amount_mismatch", "nonintegral_missingqty", "future_receipt_missingqty",
)
SCOPE_FAMILIES = ("multi_line_total", "units_case_vs_each", "discounted_price_decoy", "currency_collision")
MALFORMED_FAMILIES = ("invalid_date", "decimal_qty", "receipt_over_shipped", "broken_fk")
HELDOUT_COMBINATIONS = (
    "missing_qty_exact_description", "missing_sku_shared_po_price_ambiguity", "missing_qty_conflicting_refs",
)


def _rng(seed: int, family: str, replica: int) -> random.Random:
    value = hashlib.sha256(f"{seed}:{family}:{replica}".encode()).digest()
    return random.Random(int.from_bytes(value, "big"))


class _Case:
    def __init__(self, rng: random.Random, split: str):
        self.rng = rng
        self.tables = {name: [] for name in TABLES}
        self.case_id = self.identifier("C")
        self.deduction_id = self.identifier("D")
        self.retailer = "Retailer " + self.identifier("R")
        # Derived prices preserve nonzero cents in heldout cases. Development
        # prices are whole dollars, so heldout invoice prices never repeat them.
        self.price = rng.randrange(12, 80) * 100 if split == "development" else rng.randrange(90, 180) * 100 + 1
        self.qty = rng.randrange(2, 10) if split == "development" else rng.randrange(11, 19)
        self.base = date(2026, 3, 1) + timedelta(days=rng.randrange(100))
        self.notice_date = (self.base + timedelta(days=14)).isoformat()
        self._descriptions = iter(rng.sample([
            "Sparkling Water Variety Pack 12 x 355mL", "Citrus Tea Case 24 x 250mL",
            "Savory Rice Crackers 8 x 120g", "Cold Brew Coffee Case 12 x 200mL",
            "Oat Bar Variety Carton 16 x 40g", "Roasted Almonds Carton 10 x 150g",
        ], 6))

    def identifier(self, prefix: str) -> str:
        return f"{prefix}-{self.rng.getrandbits(80):020x}"

    def transaction(self, *, price: int | None = None, qty: int | None = None,
                    receipt: bool = True, po: str | None = None) -> dict:
        sku, invoice, line, shipment = [self.identifier(prefix) for prefix in ("K", "I", "L", "S")]
        if po is None:
            po = self.identifier("P")
            self.tables["purchase_orders"].append({"po_id": po, "retailer": self.retailer,
                                                  "order_date": self.base.isoformat()})
        quantity = self.qty if qty is None else qty
        shipped = quantity + self.rng.randrange(25, 75)
        description = next(self._descriptions)
        self.tables["products"].append({"sku": sku, "description": description})
        self.tables["invoices"].append({"invoice_id": invoice, "po_id": po,
                                        "invoice_date": (self.base + timedelta(days=1)).isoformat()})
        self.tables["invoice_lines"].append({"invoice_line_id": line, "invoice_id": invoice,
                                             "sku": sku, "quantity": shipped,
                                             "unit_price_cents": self.price if price is None else price})
        self.tables["shipments"].append({"shipment_id": shipment, "po_id": po,
                                         "ship_date": (self.base + timedelta(days=3)).isoformat()})
        self.tables["shipment_lines"].append({"shipment_id": shipment, "sku": sku, "shipped_qty": shipped})
        if receipt:
            self.tables["receipts"].append({"shipment_id": shipment, "sku": sku,
                                            "received_qty": shipped - quantity,
                                            "receipt_date": (self.base + timedelta(days=5)).isoformat()})
        return {"invoice_line_id": line, "invoice_id": invoice, "shipment_id": shipment,
                "sku": sku, "po_id": po, "description": description, "shipped": shipped}

    def notice(self, transaction: dict) -> dict:
        row = {"deduction_id": self.deduction_id, "retailer": self.retailer,
               "notice_date": self.notice_date, "amount_cents": self.qty * self.price,
               "short_qty": self.qty, "reason": "shortage", "description": "Short delivered merchandise",
               "sku_hint": None, "po_hint": transaction["po_id"], "invoice_hint": None, "shipment_hint": None}
        self.tables["deductions"].append(row)
        return row

    def remove_receipt(self, transaction: dict) -> None:
        self.tables["receipts"] = [r for r in self.tables["receipts"] if r["shipment_id"] != transaction["shipment_id"]]

    def receipt(self, transaction: dict) -> dict:
        return next(r for r in self.tables["receipts"] if r["shipment_id"] == transaction["shipment_id"])


def _link(transaction: dict) -> dict:
    return {key: transaction[key] for key in ("invoice_line_id", "shipment_id", "sku")}


def _make_case(seed: int, replica: int, family: str, split: str, suite: str) -> tuple[dict, dict, dict]:
    item = _Case(_rng(seed, family, replica), split)
    target = item.transaction()
    notice = item.notice(target)
    expected_links = [_link(target)]
    permitted = True
    statuses = ["matched"]
    explanation = "Unique single-line financial relationship with an explicit documentary reference."
    claim = None
    original = {"quantity_unit": "case", "currency": "USD", "line_count": 1,
                "price_basis": "invoice_unit_price", "adjustments": [],
                "short_qty": item.qty, "amount_cents": item.qty * item.price}
    dropped = []

    if family == "clean_reference":
        notice["po_hint"] = None
        reference = item.rng.choice(("po_hint", "invoice_hint", "shipment_hint"))
        notice[reference] = target[{"po_hint": "po_id", "invoice_hint": "invoice_id", "shipment_hint": "shipment_id"}[reference]]
        item.transaction(price=item.price + 300)
    elif family == "missing_sku":
        item.transaction(price=item.price + 300, po=target["po_id"])
        explanation = "SKU is absent; supplied purchase order and exact quantity-price arithmetic identify its line."
    elif family in {"missing_qty_receipt", "missing_qty_no_receipt", "future_receipt_missingqty"}:
        notice["short_qty"] = None
        original["short_qty"] = None
        if family == "missing_qty_no_receipt":
            item.remove_receipt(target)
            permitted, statuses = False, ["review"]
            explanation = "A derived quantity has no independent receipt corroboration."
        elif family == "future_receipt_missingqty":
            item.receipt(target)["receipt_date"] = (date.fromisoformat(item.notice_date) + timedelta(days=3)).isoformat()
            permitted, statuses = False, ["review"]
            explanation = "The receipt was unavailable at notice time and cannot corroborate a derived quantity."
        else:
            explanation = "Exact amount/price division derives a quantity corroborated by an independent receipt."
    elif family in {"no_refs_unique_receipt", "no_refs_no_receipt"}:
        notice["po_hint"] = None
        item.transaction(price=item.price + 300)
        if family == "no_refs_no_receipt":
            item.remove_receipt(target)
            permitted, statuses = False, ["review"]
            explanation = "A unique amount coincidence has neither a documentary anchor nor a receipt."
        else:
            explanation = "No notice reference; exactly one financial candidate has independent receipt corroboration."
    elif family in {"exact_description_ambiguity", "generic_sameprice_ambiguity", "missing_qty_exact_description"}:
        item.transaction(price=item.price)
        notice["po_hint"] = None
        if family == "generic_sameprice_ambiguity":
            notice["description"] = "Assorted merchandise"
            permitted, statuses = False, ["review"]
            explanation = "Two same-priced products have equal documentary and receiving support. Hidden truth cannot justify a guess."
        else:
            notice["description"] = "  " + target["description"].upper() + "!! "
            explanation = "Exact normalized catalog description plus a receipt resolves same-price product ambiguity."
            if family == "missing_qty_exact_description":
                notice["short_qty"] = None
                original["short_qty"] = None
                explanation = "Heldout combination: missing quantity, no references, same price, exact catalog text, and receipt corroboration."
    elif family == "same_sku_multiple_shipments":
        shipment = item.identifier("S")
        shipped = item.qty + item.rng.randrange(25, 75)
        item.tables["shipments"].append({"shipment_id": shipment, "po_id": target["po_id"],
                                          "ship_date": (item.base + timedelta(days=4)).isoformat()})
        item.tables["shipment_lines"].append({"shipment_id": shipment, "sku": target["sku"], "shipped_qty": shipped})
        item.tables["receipts"].append({"shipment_id": shipment, "sku": target["sku"],
                                         "received_qty": shipped - item.qty,
                                         "receipt_date": (item.base + timedelta(days=6)).isoformat()})
        item.tables["invoice_lines"][0]["quantity"] += shipped
        permitted, statuses = False, ["review"]
        explanation = "One product and invoice have two shipment records with indistinguishable shortage support."
    elif family == "knownqty_disputed_receipt":
        item.receipt(target)["received_qty"] = target["shipped"]
        claim = "receiving_records_do_not_support_claimed_quantity"
        explanation = "A documentary reference identifies the transaction; its receipt separately disputes the claimed shortage."
    elif family in {"conflicting_refs", "missing_qty_conflicting_refs"}:
        other = item.transaction(price=item.price)
        notice["invoice_hint"] = other["invoice_id"]
        permitted, statuses = False, ["no_match", "review"]
        explanation = "Notice purchase-order and invoice references point to different orders; neither can be silently discarded."
        if family == "missing_qty_conflicting_refs":
            notice["short_qty"] = None
            original["short_qty"] = None
            statuses = ["review"]
            explanation = "Heldout combination: quantity is missing and supplied purchase-order/invoice references conflict."
    elif family in {"amount_mismatch", "nonintegral_missingqty"}:
        notice["amount_cents"] += 1
        original["amount_cents"] = notice["amount_cents"]
        permitted, statuses = False, ["no_match", "review"]
        explanation = "Reported amount differs by one cent from quantity times invoice price."
        if family == "nonintegral_missingqty":
            notice["short_qty"] = None
            original["short_qty"] = None
            statuses = ["review"]
            explanation = "Missing quantity cannot be derived because amount/price is nonintegral."
    elif family == "missing_sku_shared_po_price_ambiguity":
        item.transaction(price=item.price, po=target["po_id"])
        permitted, statuses = False, ["review"]
        explanation = "Heldout combination: missing SKU, shared purchase order, same-price products, and generic text leave two candidates."
    elif family == "multi_line_total":
        other = item.transaction(price=item.price + 200, po=target["po_id"])
        item.transaction(price=item.price + 100, qty=2 * item.qty, po=target["po_id"])
        notice["short_qty"] = 2 * item.qty
        notice["amount_cents"] = 2 * item.qty * (item.price + 100)
        expected_links.append(_link(other))
        original.update(line_count=2, short_qty=2 * item.qty, amount_cents=notice["amount_cents"],
                        line_items=[{**_link(target), "short_qty": item.qty, "unit_price_cents": item.price},
                                    {**_link(other), "short_qty": item.qty, "unit_price_cents": item.price + 200}])
        dropped = ["line_count", "line_items"]
        explanation = "A two-line shortage total accidentally equals one decoy line's quantity-price equation; projecting away line items is lossy."
    elif family == "units_case_vs_each":
        item.tables["invoice_lines"][0]["unit_price_cents"] = 12 * item.price
        item.transaction(price=item.price, qty=12 * item.qty, po=target["po_id"])
        notice["short_qty"] = 12 * item.qty
        notice["amount_cents"] = 12 * item.qty * item.price
        original.update(quantity_unit="each", short_qty=12 * item.qty,
                        amount_cents=notice["amount_cents"], invoice_quantity_unit="case",
                        each_per_case=12, true_case_short_qty=item.qty)
        dropped = ["quantity_unit", "invoice_quantity_unit", "each_per_case"]
        explanation = "Twelve individual units per case require conversion; the projected each count accidentally fits another case-priced line."
    elif family == "discounted_price_decoy":
        item.tables["invoice_lines"][0]["unit_price_cents"] = 10 * item.price
        item.transaction(price=9 * item.price, po=target["po_id"])
        notice["amount_cents"] = item.qty * 9 * item.price
        original.update(amount_cents=notice["amount_cents"], price_basis="invoice_price_less_adjustment",
                        adjustments=[{"type": "discount", "basis_points": 1000}],
                        true_invoice_unit_price_cents=10 * item.price)
        dropped = ["price_basis", "adjustments"]
        explanation = "A ten-percent adjustment on the real line makes its net amount equal the gross amount of a decoy line."
    elif family == "currency_collision":
        item.transaction(price=2 * item.price, po=target["po_id"])
        notice["amount_cents"] = item.qty * 2 * item.price
        original.update(amount_cents=notice["amount_cents"], currency="USD", invoice_currency="EUR",
                        synthetic_usd_per_eur={"numerator": 2, "denominator": 1},
                        true_invoice_unit_price_eur_cents=item.price,
                        invoice_currency_by_line={row["invoice_line_id"]: ("EUR" if row["invoice_line_id"] == target["invoice_line_id"] else "USD")
                                                  for row in item.tables["invoice_lines"]})
        dropped = ["currency", "invoice_currency", "synthetic_usd_per_eur", "invoice_currency_by_line"]
        explanation = "An invented two-to-one currency conversion makes the real foreign-currency line collide with a domestic-currency decoy."
    elif family == "invalid_date":
        notice["notice_date"] = "2026-02-30"
        permitted, statuses = False, ["review", "data_rejected"]
        explanation = "The notice contains an impossible calendar date; do not use it for automatic matching."
    elif family == "decimal_qty":
        notice["short_qty"] = item.qty + 0.5
        permitted, statuses = False, ["review", "data_rejected"]
        explanation = "Fractional case quantity is outside the integer-quantity input contract."
    elif family == "receipt_over_shipped":
        item.receipt(target)["received_qty"] = target["shipped"] + 1
        permitted, statuses = False, ["review", "data_rejected"]
        explanation = "A receiving row records more units than were shipped; source validation must flag it."
    elif family == "broken_fk":
        item.tables["invoice_lines"][0]["invoice_id"] = item.identifier("I")
        permitted, statuses = False, ["review", "data_rejected"]
        explanation = "An invoice line references a missing invoice; ingestion must reject the broken relationship."
    else:
        raise ValueError(f"Unknown synthetic family: {family}")

    if suite == "scope_traps":
        permitted, statuses = False, ["review", "no_match", "data_rejected"]
    for rows in item.tables.values():
        item.rng.shuffle(rows)
    case = {"case_id": item.case_id, "split": split, "suite": suite, "family": family,
            "deduction_id": item.deduction_id, "tables": item.tables}
    label = {"case_id": item.case_id, "expected_links": expected_links,
             "automatic_link_permitted": permitted, "expected_statuses": statuses,
             "explanation": explanation}
    if claim is not None:
        label["expected_claim_assessment"] = claim
    raw = {"case_id": item.case_id, "source": "authored_synthetic_not_a_real_notice",
           "original_notice": original, "projected_notice": dict(notice),
           "projection": {"lossy": bool(dropped), "dropped_fields": dropped,
                          "purpose": "Explicit adapter-boundary stress test" if dropped else "Supported normalized facts"},
           "generation": {"replica": replica, "base_unit_price_cents": item.price, "base_short_qty": item.qty,
                          "heldout_combination": family in HELDOUT_COMBINATIONS}}
    return case, label, raw


def generate(output: Path, seed: int = DEFAULT_SEED, replicas: int = DEFAULT_REPLICAS) -> dict:
    """Write exact-schema inputs, independent labels and semantic-source sidecars."""
    if type(seed) is not int or type(replicas) is not int or replicas < 1:
        raise ValueError("seed must be an integer and replicas a positive integer")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    families = [(family, "supported") for family in SUPPORTED_FAMILIES]
    families += [(family, "scope_traps") for family in SCOPE_FAMILIES]
    families += [(family, "malformed") for family in MALFORMED_FAMILIES]
    rows = []
    development_replicas = (2 * replicas + 2) // 3
    for family, suite in families:
        for replica in range(replicas):
            split = "development" if replica < development_replicas else "heldout"
            rows.append(_make_case(seed, replica, family, split, suite))
    combination_replicas = max(1, replicas // 3)
    for family in HELDOUT_COMBINATIONS:
        for replica in range(combination_replicas):
            rows.append(_make_case(seed, replica, family, "heldout", "supported"))
    # The export order is independently randomized; identities contain no role,
    # family, split, or ground-truth markers.
    random.Random(seed).shuffle(rows)
    files = {}
    for index, filename in enumerate(("cases.jsonl", "labels.jsonl", "raw_notices.jsonl")):
        content = "".join(json.dumps(row[index], sort_keys=True) + "\n" for row in rows)
        (output / filename).write_text(content, encoding="utf-8")
        files[filename] = {"sha256": hashlib.sha256(content.encode()).hexdigest(), "records": len(rows)}
    cases = [row[0] for row in rows]
    manifest = {
        "version": 1, "seed": seed, "replicas_per_base_family": replicas,
        "replicas_per_heldout_combination": combination_replicas,
        "case_count": len(cases), "source": "Entirely authored seeded synthetic stress data",
        "real_retail_data": False, "engine_outputs_used_in_generation": False,
        "split_counts": dict(sorted(Counter(case["split"] for case in cases).items())),
        "suite_counts": dict(sorted(Counter(case["suite"] for case in cases).items())),
        "family_counts": dict(sorted(Counter(case["family"] for case in cases).items())),
        "engine_table_schemas": {name: columns.split(",") for name, columns in TABLES.items()},
        "heldout_design": {
            "numeric_draws": "Development base prices end in 00 cents and quantities are 2..9; heldout base prices end in 01 and quantities are 11..18. Derived invoice prices also remain disjoint.",
            "novel_combinations": list(HELDOUT_COMBINATIONS),
            "warning": "This authored split tests specified conditions, not unseen real-world distributions or model generalization.",
        },
        "label_semantics": {
            "expected_links": "Latent source relationships, not proof that visible facts permit automatic identification. Bundled cases can require more than one link.",
            "automatic_link_permitted": "False for ambiguous evidence, unsupported semantic scope, or malformed data even if a guess happens to equal latent truth.",
            "expected_statuses": "Permissible reconciliation statuses; data_rejected denotes a separate loader/data rejection, not an engine no_match.",
        },
        "scope_warning": "Scope traps deliberately use a lossy adapter. Units, currency, adjustments and multiple lines remain in raw_notices only; neither engine receives these missing semantics. Report separately from supported-scope accuracy.",
        "limitations": ["Not representative real retailer data", "No real-world performance estimates",
                        "No live model quality evaluation", "No parser/OCR evaluation",
                        "Each case is an isolated eight-table dataset to prevent malformed rows contaminating other cases"],
        "files": files,
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("evaluation/stress"))
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument("--replicas", type=int, default=DEFAULT_REPLICAS)
    args = parser.parse_args()
    print(json.dumps(generate(args.output, args.seed, args.replicas), indent=2))


if __name__ == "__main__":
    main()
