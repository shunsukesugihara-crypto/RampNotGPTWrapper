"""Read uploaded business files without guessing financial values or links.

Inspection retains original cells. Mapping is an explicit user-approved step;
the deterministic financial engines remain responsible for normalization and
matching. Column suggestions are vocabulary matches, never financial evidence.
"""
from __future__ import annotations

import base64
import binascii
from copy import deepcopy
import csv
from datetime import date, datetime, time
import hashlib
import importlib.util
import io
import json
from pathlib import PurePath
import posixpath
import re
import zipfile
from xml.etree import ElementTree as ET

from recon.demo.ingest import ALIASES as EXPORT_ALIASES
from recon.reconstruction.data import FIELDS, TABLES, KEYS

MAX_UPLOAD_BYTES = 10 * 1024 * 1024
MAX_FILES = 64
MAX_ROWS = 50_000
MAX_COLUMNS = 256
MAX_CELL_CHARS = 100_000
MAX_EXPANDED_XLSX_BYTES = 64 * 1024 * 1024
ROLES = ("notice", *TABLES)
OPTIONAL = {
    "notice": {"short_qty", "po_hint", "invoice_hint", "sku_hint", "description"},
    "products": {"description", "case_pack", "source_ref"},
}
GENERATED_IDENTITIES = {"invoice_lines": "invoice_line_id", "receipts": "receipt_id"}
DEFAULT_FIELDS = {role: FIELDS[role] & {"currency", "uom", "price_uom", "scope", "basis"} for role in ROLES}
FIELD_CATALOG = {
    role: {"fields": sorted(FIELDS[role]),
           "required": sorted(FIELDS[role] - OPTIONAL.get(role, set()) - {GENERATED_IDENTITIES.get(role)}),
           "generated_identity": GENERATED_IDENTITIES.get(role),
           "default_fields": sorted(DEFAULT_FIELDS[role])}
    for role in ROLES
}

EXTRA_ALIASES = {
    "deduction_id": ("claim id", "claim no", "claim number", "deduction number", "deduction no", "deduction #"),
    "retailer": ("customer", "customer name", "retailer name", "account name", "sold to"),
    "notice_date": ("deduction date", "claim date", "date of claim"),
    "amount": ("deduction amount", "claim amount", "amount deducted", "deducted amount", "shortage amount"),
    "currency": ("ccy", "currency code", "iso currency"),
    "short_qty": ("short qty", "shortage qty", "shortage quantity", "missing cases", "short cases"),
    "uom": ("uom", "unit of measure", "units", "unit", "qty unit", "quantity unit", "quantity uom"),
    "scope": ("claim scope", "line scope"),
    "basis": ("allocation basis", "financial basis", "claim basis"),
    "po_hint": ("po ref", "po reference", "purchase order reference", "po #", "po number", "purchase order"),
    "invoice_hint": ("invoice ref", "invoice reference", "invoice #", "invoice number", "inv no"),
    "sku_hint": ("product reference", "item ref", "sku", "item code", "product code"),
    "description": ("description", "item description", "product name", "item name", "deduction memo", "claim description", "memo"),
    "sku": ("product code", "product id", "item", "item #", "item number", "item id", "stock code", "material", "item code"),
    "case_pack": ("pack size", "units per case", "case pack", "pack qty", "each per case", "eaches per case"),
    "source_ref": ("source reference", "catalog reference", "catalog ref", "pack evidence", "master source reference", "source ref"),
    "po_id": ("po", "po #", "po no", "po number", "purchase order", "purchase order number", "order number", "order id"),
    "order_date": ("po date", "purchase order date", "order date", "ordered date"),
    "invoice_id": ("invoice", "invoice #", "invoice no", "invoice number", "inv no", "inv #", "billing document"),
    "invoice_date": ("invoice date", "billing date", "billed date", "inv date"),
    "invoice_line_id": ("line id", "line reference", "invoice line id", "invoice line number", "invoice line", "line number", "line no"),
    "quantity": ("qty", "quantity", "invoiced qty", "billed qty", "billed quantity", "shipped qty", "shipped quantity", "dispatched qty", "received qty", "received quantity", "receiving quantity"),
    "unit_price": ("price", "unit price", "price per unit", "case price", "price per case", "unit cost", "rate"),
    "price_uom": ("price unit", "price uom", "pricing unit", "pricing uom"),
    "shipment_id": ("shipment", "shipment #", "shipment no", "shipment number", "dispatch reference", "dispatch id", "delivery id", "delivery number", "asn", "asn number"),
    "ship_date": ("shipment date", "ship date", "shipping date", "dispatch date", "shipped date"),
    "receipt_id": ("receipt", "receipt #", "receipt no", "receipt number", "receiving reference", "receiving id", "grn", "goods receipt"),
    "receipt_date": ("receipt date", "received date", "receiving date", "warehouse date", "goods receipt date"),
}
FILE_HINTS = {
    "notice": ("deduction", "deductions", "notice", "claim", "claims"),
    "products": ("products", "product", "catalog", "master", "items"),
    "purchase_orders": ("purchaseorders", "purchaseorder", "poexport", "orders"),
    "invoices": ("invoiceheaders", "invoiceheader", "invoices", "billingheaders"),
    "invoice_lines": ("invoicelines", "invoicedetails", "invoicedetail", "billinglines"),
    "shipments": ("shipmentheaders", "shipmentheader", "shipments", "dispatchheaders"),
    "shipment_lines": ("shipmentlines", "shipmentdetails", "shipmentdetail", "dispatchlines"),
    "receipts": ("receiving", "receipts", "warehouse", "goodsreceipt"),
}
SIGNATURES = {
    "notice": {"deduction_id": 6, "notice_date": 4, "amount": 4},
    "products": {"case_pack": 5, "source_ref": 4, "sku": 1, "description": 1},
    "purchase_orders": {"order_date": 5, "po_id": 2, "retailer": 1},
    "invoices": {"invoice_date": 5, "invoice_id": 2, "po_id": 1},
    "invoice_lines": {"invoice_line_id": 5, "unit_price": 4, "invoice_id": 2, "sku": 1},
    "shipments": {"ship_date": 5, "shipment_id": 2, "po_id": 1},
    "shipment_lines": {"shipment_id": 2, "sku": 2, "quantity": 1},
    "receipts": {"receipt_id": 5, "receipt_date": 5, "shipment_id": 1},
}


def _norm(value):
    return re.sub(r"[^a-z0-9]", "", str(value).casefold())


def _issue(code, message, *, severity="error", **context):
    return {"code": code, "message": message, "severity": severity, **context}


def capabilities():
    return {"csv": True, "tsv": True, "json": True,
            "xlsx": importlib.util.find_spec("openpyxl") is not None,
            "pdf_text_preview": importlib.util.find_spec("pypdf") is not None,
            "pdf_automatic_financial_extraction": False,
            "max_upload_bytes": MAX_UPLOAD_BYTES, "max_rows_per_table": MAX_ROWS,
            "field_catalog": deepcopy(FIELD_CATALOG)}


def suggest_mapping(headers, role):
    """Return only unambiguous vocabulary mappings; unknown fields stay null."""
    role = "notice" if role == "deductions" else role
    if role not in ROLES:
        return {"columns": {}, "candidates": {}, "issues": []}
    columns, candidates, issues = {}, {}, []
    for field in FIELD_CATALOG[role]["fields"]:
        vocabulary = {_norm(x) for x in (field, *EXPORT_ALIASES.get(role, {}).get(field, ()), *EXTRA_ALIASES.get(field, ()))}
        exact = [h for h in headers if _norm(h) == _norm(field)]
        matching = exact if exact else [h for h in headers if _norm(h) in vocabulary]
        candidates[field] = matching
        columns[field] = matching[0] if len(matching) == 1 else None
        if len(matching) > 1:
            issues.append(_issue("ambiguous_column_mapping", f"Choose the source column for {field}.", severity="warning", field=field, candidates=matching))
    return {"columns": columns, "candidates": candidates, "issues": issues}


def _suggest_role(headers, name):
    scores = []
    normalized_name = _norm(name)
    for role in ROLES:
        mapped = suggest_mapping(headers, role)["columns"]
        score = sum(weight for field, weight in SIGNATURES[role].items() if mapped.get(field))
        score += sum(6 for hint in FILE_HINTS[role] if hint in normalized_name)
        scores.append((score, role))
    scores.sort(reverse=True)
    if not scores or scores[0][0] < 3 or len(scores) > 1 and scores[0][0] == scores[1][0]:
        return None
    return scores[0][1]


def _document(name, payload, fmt, headers, records, *, sheet=None, header_row=1, raw_rows=None, issues=None, row_numbers=None, cell_metadata=None, forced_role=None, suffix=""):
    sha = hashlib.sha256(payload).hexdigest()
    identity = hashlib.sha256((name + "\0" + str(sheet) + "\0" + sha + "\0" + suffix).encode()).hexdigest()[:24]
    role = forced_role or _suggest_role(headers, name + " " + str(sheet or ""))
    suggestion = suggest_mapping(headers, role)
    result = {"id": identity, "name": name, "format": fmt, "sheet": sheet, "sha256": sha,
              "columns": list(headers), "rows": records, "row_count": len(records), "header_row": header_row,
              "row_numbers": row_numbers or list(range(header_row + 1, header_row + 1 + len(records))),
              "role_suggestion": role, "mapping_suggestion": suggestion["columns"],
              "mapping_candidates": suggestion["candidates"], "issues": list(issues or []) + suggestion["issues"]}
    if raw_rows is not None:
        result["raw_rows"] = raw_rows
    if cell_metadata:
        result["cell_metadata"] = cell_metadata
    return result


def _table(name, payload, fmt, raw_rows, *, sheet=None, metadata=None, forced_role=None, suffix=""):
    issues = []
    nonempty = [(i, row) for i, row in enumerate(raw_rows) if any(value not in (None, "") for value in row)]
    if not nonempty:
        return _document(name, payload, fmt, [], [], sheet=sheet, issues=[_issue("empty_table", "This file or worksheet has no table rows.")], forced_role=forced_role, suffix=suffix)
    start, header_values = nonempty[0]
    vocabulary = {_norm(value) for role in ROLES for field in FIELDS[role]
                  for value in (field, *EXPORT_ALIASES.get(role, {}).get(field, ()), *EXTRA_ALIASES.get(field, ()))}
    candidates = [(sum(_norm(value) in vocabulary for value in row if value not in (None, "")), index, row)
                  for index, row in nonempty[:25]]
    best_score = max(score for score, _, _ in candidates)
    initial_score = candidates[0][0]
    if best_score >= 2 and best_score > initial_score:
        _, start, header_values = next(candidate for candidate in candidates if candidate[0] == best_score)
        issues.append(_issue("header_row_detected", "A table header was detected below a title or preamble. The preceding rows are retained for inspection.", severity="warning", header_row=start + 1))
    headers = [str(v) if v is not None else "" for v in header_values]
    if len(headers) > MAX_COLUMNS:
        issues.append(_issue("too_many_columns", f"A table may contain at most {MAX_COLUMNS} columns."))
    if any(not h.strip() for h in headers):
        issues.append(_issue("blank_header", "Every column needs a nonempty header. Rename blank source columns before importing."))
    if len(set(headers)) != len(headers):
        issues.append(_issue("duplicate_headers", "Duplicate source headers would overwrite cells. Rename the duplicated columns before importing."))
    if len({_norm(h) for h in headers}) != len(headers):
        issues.append(_issue("similar_headers", "Some headers differ only in punctuation or case; confirm their mappings.", severity="warning"))
    records, row_numbers = [], []
    for index, original_cells in nonempty:
        if index <= start:
            continue
        cells = original_cells
        if fmt == "xlsx" and len(cells) < len(headers):
            cells = [*cells, *([None] * (len(headers) - len(cells)))]
        if len(records) >= MAX_ROWS:
            issues.append(_issue("too_many_rows", f"A table may contain at most {MAX_ROWS:,} data rows."))
            break
        if len(cells) != len(headers):
            issues.append(_issue("row_width_mismatch", "This row has a different cell count from the header. No financial calculation can run until it is corrected.", row=index + 1, expected=len(headers), actual=len(cells)))
        if any(isinstance(c, str) and len(c) > MAX_CELL_CHARS for c in cells):
            issues.append(_issue("cell_too_large", "A source cell exceeds the supported text limit.", row=index + 1))
        # raw_rows retains every original cell, even when malformed table shape
        # prevents it from being safely represented as a keyed record.
        if len(set(headers)) == len(headers) and len(cells) == len(headers):
            records.append(dict(zip(headers, cells)))
            row_numbers.append(index + 1)
    result = _document(name, payload, fmt, headers, records, sheet=sheet, header_row=start + 1,
                       raw_rows=raw_rows, issues=issues, row_numbers=row_numbers, cell_metadata=metadata,
                       forced_role=forced_role, suffix=suffix)
    if start:
        result["preamble_rows"] = deepcopy(raw_rows[:start])
    return result


def _csv_documents(name, payload, extension):
    encoding = "utf-16" if payload.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"
    try:
        text = payload.decode(encoding)
    except UnicodeError:
        return [_document(name, payload, extension, [], [], issues=[_issue("unsupported_encoding", "Save this export as UTF-8 or UTF-16 CSV/TSV and upload again.")])]
    try:
        delimiter = "\t" if extension == "tsv" else csv.Sniffer().sniff(text[:32768], delimiters=",;\t|").delimiter
    except csv.Error:
        delimiter = "\t" if extension == "tsv" else ","
    try:
        reader = csv.reader(io.StringIO(text, newline=""), delimiter=delimiter, strict=True)
        rows, truncated = [], False
        for row in reader:
            rows.append(row)
            if len(rows) > MAX_ROWS + 25:
                truncated = True
                break
        document = _table(name, payload, extension, rows)
        if truncated:
            document["issues"].append(_issue("too_many_source_rows", "This file exceeds the inspection row limit. No calculation can use a truncated source; split the export into smaller files."))
        document["encoding"], document["delimiter"] = encoding, delimiter
        return [document]
    except (csv.Error, OverflowError):
        return [_document(name, payload, extension, [], [], issues=[_issue("malformed_delimited_file", "The quoted rows could not be read safely. Correct the export's quoting or delimiter.")])]


def _json_documents(name, payload):
    def unique(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ValueError("Duplicate JSON object key")
            out[key] = value
        return out
    def nonfinite(value):
        raise ValueError("Nonfinite JSON number")
    try:
        value = json.loads(payload.decode("utf-8-sig"), object_pairs_hook=unique, parse_constant=nonfinite,
                           parse_float=lambda token: token)
    except (ValueError, UnicodeError, RecursionError):
        return [_document(name, payload, "json", [], [], issues=[_issue("invalid_json", "The JSON file is invalid or contains duplicate keys/nonfinite numbers.")])]
    def table(rows, role=None, suffix=""):
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            return _document(name, payload, "json", [], [], issues=[_issue("json_table_required", "A JSON table must be an array of record objects.")], forced_role=role, suffix=suffix)
        headers = list(dict.fromkeys(key for row in rows for key in row))
        problems = []
        if len(rows) > MAX_ROWS or len(headers) > MAX_COLUMNS:
            problems.append(_issue("table_size_limit", "The JSON table exceeds the supported row/column limit."))
        if any(any(isinstance(v, (dict, list)) for v in row.values()) for row in rows):
            problems.append(_issue("nested_json_cells", "Nested cells need an explicit flattened export before column mapping."))
        return _document(name, payload, "json", headers, deepcopy(rows), sheet=role, header_row=0,
                         row_numbers=list(range(1, len(rows) + 1)), issues=problems, forced_role=role, suffix=suffix)
    if isinstance(value, dict) and value.get("version") == 1 and "notice" in value:
        result = [table([value["notice"]] if isinstance(value["notice"], dict) else value["notice"], "notice", "notice")]
        for role in TABLES:
            if role in value:
                result.append(table(value[role], role, role))
        unknown = sorted(set(value) - {"version", *ROLES})
        if unknown:
            result[0]["issues"].append(_issue("unmapped_json_sections", "Additional JSON sections are retained in the uploaded source but are not financial tables.", severity="warning", sections=unknown))
        return result
    if isinstance(value, dict):
        for key in ("rows", "records", "data", "items"):
            if isinstance(value.get(key), list):
                return [table(value[key])]
        return [table([value])]
    return [table(value)]


def _xlsx_documents(name, payload):
    try:
        import openpyxl
    except ImportError:
        return [_document(name, payload, "xlsx", [], [], issues=[_issue("parser_unavailable", "Excel import is unavailable on this server. Install openpyxl or export the worksheet as CSV.")])]
    try:
        archive = zipfile.ZipFile(io.BytesIO(payload))
        if sum(i.file_size for i in archive.infolist()) > MAX_EXPANDED_XLSX_BYTES:
            raise ValueError("Expanded workbook exceeds limit")
        ns = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
        relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        targets = {r.attrib["Id"]: r.attrib["Target"] for r in relationships if r.attrib.get("TargetMode") != "External"}
        workbook_xml = ET.fromstring(archive.read("xl/workbook.xml"))
        sheet_paths = {}
        for sheet in workbook_xml.findall("s:sheets/s:sheet", ns):
            rid = sheet.attrib.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
            target = targets.get(rid, "")
            normalized = target.lstrip("/") if target.startswith("/") else posixpath.normpath("xl/" + target)
            if normalized.startswith("xl/"):
                sheet_paths[sheet.attrib["name"]] = normalized
        workbook = openpyxl.load_workbook(io.BytesIO(payload), read_only=True, data_only=False, keep_links=False)
        output = []
        for sheet in workbook.worksheets:
            if (sheet.max_row or 0) > MAX_ROWS + 25 or (sheet.max_column or 0) > MAX_COLUMNS:
                output.append(_document(name, payload, "xlsx", [], [], sheet=sheet.title, issues=[_issue("table_size_limit", "This worksheet exceeds the supported row/column limit.")]))
                continue
            numbers = {}
            if sheet.title in sheet_paths:
                xml = ET.fromstring(archive.read(sheet_paths[sheet.title]))
                for cell in xml.findall(".//s:sheetData/s:row/s:c", ns):
                    value = cell.find("s:v", ns)
                    if cell.attrib.get("t", "n") == "n" and value is not None:
                        numbers[cell.attrib["r"]] = value.text
            rows, metadata = [], {}
            for row in sheet.iter_rows():
                if len(rows) > MAX_ROWS + 25:
                    raise ValueError("Workbook row limit")
                values = []
                for cell in row:
                    value = cell.value
                    rule = None
                    original = numbers.get(getattr(cell, "coordinate", ""))
                    if isinstance(value, datetime):
                        value = value.date().isoformat() if value.time() == time(0) else value.isoformat()
                        rule = "excel_typed_date_to_iso"
                    elif isinstance(value, (date, time)):
                        value, rule = value.isoformat(), "excel_typed_date_to_iso"
                    elif type(value) in (int, float) and original is not None:
                        # Preserve the XML decimal token, not a binary float's
                        # rounded approximation. Display-only zero padding is
                        # retained when the number format unambiguously asks it.
                        value, rule = original, "excel_numeric_xml_token"
                        if re.fullmatch(r"0+", cell.number_format or "") and re.fullmatch(r"\d+", original):
                            value, rule = original.zfill(len(cell.number_format)), "excel_explicit_zero_padding"
                    elif type(value) is float:
                        value, rule = repr(value), "excel_numeric_text"
                    if rule:
                        metadata[cell.coordinate] = {"rule": rule, "raw": original, "value": value, "number_format": cell.number_format}
                    values.append(value)
                # Excel's common rectangular used range supplies trailing None
                # cells; retain table width rather than changing header shape.
                rows.append(values)
            # Formatting can expand Excel's used range far beyond its actual
            # table. Empty trailing grid cells carry no financial value.
            last_column = max((i + 1 for row in rows for i, value in enumerate(row) if value not in (None, "")), default=0)
            rows = [row[:last_column] for row in rows]
            output.append(_table(name, payload, "xlsx", rows, sheet=sheet.title, metadata=metadata))
        workbook.close()
        archive.close()
        return output
    except Exception:
        return [_document(name, payload, "xlsx", [], [], issues=[_issue("invalid_workbook", "This workbook could not be read safely. Use an unencrypted XLSX file or export its tables as CSV.")])]


def _pdf_documents(name, payload):
    document = _document(name, payload, "pdf", [], [], issues=[])
    try:
        from pypdf import PdfReader
    except ImportError:
        document["issues"].append(_issue("parser_unavailable", "PDF text preview is unavailable. Upload structured CSV/XLSX records for reconciliation."))
        return [document]
    try:
        reader = PdfReader(io.BytesIO(payload))
        if reader.is_encrypted:
            raise ValueError("Encrypted PDF")
        if len(reader.pages) > 50:
            raise ValueError("PDF page limit")
        pages = [{"page": i + 1, "text": (page.extract_text() or "")[:MAX_CELL_CHARS]} for i, page in enumerate(reader.pages)]
        document["pages"], document["text_preview"] = pages, "\n\n".join(p["text"] for p in pages)[:MAX_CELL_CHARS]
        document["issues"].append(_issue("pdf_requires_structured_records", "PDF text is available for inspection, but automatic financial table extraction is not implemented. Upload the related structured export; no financial rows were invented.", severity="warning"))
        if not document["text_preview"].strip():
            document["issues"].append(_issue("scanned_pdf_requires_ocr", "This PDF has no extractable text. Supply a structured export or a searchable document."))
    except Exception:
        document["issues"].append(_issue("invalid_pdf", "The PDF could not be read, is encrypted, or exceeds the 50-page limit."))
    return [document]


def inspect_files(files):
    if not isinstance(files, list) or not 1 <= len(files) <= MAX_FILES:
        raise ValueError(f"Upload between one and {MAX_FILES} files.")
    documents, issues, total_bytes = [], [], 0
    for item in files:
        if not isinstance(item, dict) or not isinstance(item.get("name"), str) or not isinstance(item.get("content_base64"), str):
            raise ValueError("Each upload requires a filename and base64 file content.")
        name = item["name"].replace("\\", "/").rsplit("/", 1)[-1]
        if not name or len(name) > 240:
            raise ValueError("The upload filename is missing or too long.")
        if len(item["content_base64"]) > (MAX_UPLOAD_BYTES * 4 // 3 + 8):
            raise ValueError("Uploaded content exceeds the 10 MB limit.")
        try:
            payload = base64.b64decode(item["content_base64"], validate=True)
        except (ValueError, binascii.Error):
            raise ValueError("Uploaded file content is not valid base64.") from None
        total_bytes += len(payload)
        if total_bytes > MAX_UPLOAD_BYTES:
            raise ValueError("Uploaded files exceed the 10 MB total limit.")
        extension = PurePath(name).suffix.lower().lstrip(".")
        if extension in ("csv", "tsv", "txt"):
            parsed = _csv_documents(name, payload, "tsv" if extension == "tsv" else "csv")
        elif extension == "json":
            parsed = _json_documents(name, payload)
        elif extension == "xlsx":
            parsed = _xlsx_documents(name, payload)
        elif extension == "pdf":
            parsed = _pdf_documents(name, payload)
        else:
            parsed = [_document(name, payload, extension or "unknown", [], [], issues=[_issue("unsupported_format", "Use CSV, TSV, XLSX, JSON, or a PDF for text inspection. Legacy XLS and executable files are not imported.")])]
        known = {d["id"] for d in documents}
        for document in parsed:
            if document["id"] in known:
                issues.append(_issue("duplicate_upload", "An identical named file or sheet was uploaded twice. Keep one copy.", document_id=document["id"]))
            documents.append(document)
            known.add(document["id"])
    return {"documents": documents, "issues": issues, "total_bytes": total_bytes,
            "field_catalog": deepcopy(FIELD_CATALOG), "capabilities": capabilities()}


def _present(value):
    return value is not None and value != "" and (not isinstance(value, str) or bool(value.strip()))


def build_pack(documents, mappings, notice_row_id=None):
    """Apply confirmed mappings, retaining source cells and declared defaults.

    Repeated identical header records can collapse by identity; every contributing
    source row retains provenance. Financial line and receiving duplicates never
    disappear. Only internal row identifiers can be generated, never business
    invoice/order/shipment relationships or financial facts.
    """
    if not isinstance(documents, list) or not isinstance(mappings, list):
        raise ValueError("Documents and confirmed mappings must be arrays.")
    by_id = {d.get("id"): d for d in documents if isinstance(d, dict)}
    if len(by_id) != len(documents):
        raise ValueError("Uploaded document identities must be unique.")
    tables = {role: [] for role in ROLES}
    issues, provenance, seen, used_documents = [], [], {r: {} for r in ROLES}, set()
    header_roles = {"products", "purchase_orders", "invoices", "shipments"}
    for mapping in mappings:
        if not isinstance(mapping, dict):
            raise ValueError("Each mapping must be an object.")
        doc_id, role = mapping.get("document_id"), mapping.get("role")
        if role in (None, "", "ignore"):
            continue
        role = "notice" if role == "deductions" else role
        if role not in ROLES or doc_id not in by_id:
            raise ValueError("Mappings must reference an uploaded table and approved financial role.")
        doc = by_id[doc_id]
        used_documents.add(doc_id)
        selected, defaults = mapping.get("columns", {}), mapping.get("defaults", {})
        if not isinstance(selected, dict) or not isinstance(defaults, dict):
            raise ValueError("Column mappings and declared defaults must be objects.")
        if set(selected) - FIELDS[role] or set(defaults) - FIELDS[role]:
            raise ValueError("Mapping fields must belong to the selected financial role.")
        if set(defaults) - DEFAULT_FIELDS[role]:
            raise ValueError("Defaults may declare currency, units, scope, or financial basis only; business identifiers and financial amounts require source columns.")
        if any(value is not None and (not isinstance(value, str) or value not in doc.get("columns", [])) for value in selected.values()):
            raise ValueError("Each mapped column must exist in its uploaded table.")
        if any(isinstance(v, (dict, list, bool)) or type(v) not in (str, int, float, type(None)) for v in defaults.values()):
            raise ValueError("Declared defaults must be scalar source values.")
        issues.extend({**problem, "document_id": doc_id} for problem in doc.get("issues", []) if problem.get("severity") == "error")
        if not doc.get("rows"):
            issues.append(_issue("no_mappable_rows", "This document contains no structured table rows.", document_id=doc_id))
            continue
        referenced_columns = {v for v in selected.values() if v is not None}
        unmapped = [c for c in doc["columns"] if c not in referenced_columns]
        if unmapped:
            issues.append(_issue("unmapped_source_columns", "These source columns are preserved in the upload but not interpreted by this table mapping.", severity="warning", document_id=doc_id, role=role, columns=unmapped))
        for row_index, raw in enumerate(doc["rows"]):
            if not isinstance(raw, dict):
                raise ValueError("Inspected source rows must be objects.")
            source_row = doc.get("row_numbers", [])[row_index] if row_index < len(doc.get("row_numbers", [])) else row_index + 2
            record, cells = {}, []
            for field in FIELD_CATALOG[role]["fields"]:
                column = selected.get(field)
                original = raw.get(column) if column is not None else None
                value, operation = original, "map_source_column"
                if not _present(value):
                    value = None
                    operation = "blank_to_null" if column is not None else "missing_source_field"
                    if field in defaults and _present(defaults[field]):
                        value, operation = defaults[field], "user_declared_default"
                if field == GENERATED_IDENTITIES.get(role) and not _present(value):
                    value = "source-row:" + doc_id + ":" + str(source_row)
                    operation = "generated_internal_row_identity"
                if field == "case_pack" and _present(value):
                    if type(value) is int and value > 0:
                        pass
                    elif isinstance(value, str) and re.fullmatch(r"[1-9]\d*", value.strip()):
                        value, operation = int(value), "parse_declared_integer_metadata"
                    else:
                        issues.append(_issue("invalid_case_pack", "A case-pack factor must be a positive recorded integer; it was not rounded or guessed.", document_id=doc_id, row=source_row, field=field))
                if field in FIELD_CATALOG[role]["required"] and not _present(value):
                    issues.append(_issue("missing_required_field", f"Map or explicitly supply {field} for this source row.", document_id=doc_id, role=role, row=source_row, field=field))
                if isinstance(value, (dict, list, bool)):
                    issues.append(_issue("unsupported_cell_type", "This mapped cell is not a supported scalar source value.", document_id=doc_id, row=source_row, field=field))
                if isinstance(value, str) and value.startswith("="):
                    issues.append(_issue("formula_requires_values", "Formula cells are not executed. Export their verified values before reconciliation.", document_id=doc_id, row=source_row, field=field))
                record[field] = value
                cell = {"document_id": doc_id, "file": doc["name"], "sheet": doc.get("sheet"),
                              "source_sha256": doc["sha256"], "source_row": source_row, "source_column": column,
                              "table": role, "field": field, "raw": original, "value": value, "operation": operation}
                if doc.get("format") == "xlsx" and column in doc["columns"]:
                    index, letters = doc["columns"].index(column) + 1, ""
                    while index:
                        index, remainder = divmod(index - 1, 26)
                        letters = chr(65 + remainder) + letters
                    coordinate = letters + str(source_row)
                    cell["source_cell"] = coordinate
                    if coordinate in doc.get("cell_metadata", {}):
                        cell["cell_conversion"] = deepcopy(doc["cell_metadata"][coordinate])
                cells.append(cell)
            keys = KEYS[role]
            key = tuple(record.get(field) for field in keys)
            valid_key = all(_present(value) and not isinstance(value, (dict, list, bool)) for value in key)
            existing = seen[role].get(key) if valid_key else None
            if existing is not None and role in header_roles:
                canonical_row = existing
                if tables[role][existing] != record:
                    issues.append(_issue("conflicting_source_identity", "Rows with the same business identifier disagree. Resolve the source conflict before running.", document_id=doc_id, role=role, row=source_row, key=dict(zip(keys, key))))
                else:
                    issues.append(_issue("repeated_header_projection", "An identical repeated header record was projected once; all contributing cells retain provenance.", severity="info", document_id=doc_id, role=role, row=source_row, canonical_row=canonical_row))
            else:
                canonical_row = len(tables[role])
                tables[role].append(record)
                if valid_key:
                    if existing is not None:
                        issues.append(_issue("duplicate_financial_identity", "A duplicate financial line, notice, or receiving identifier was retained and blocks automatic processing.", document_id=doc_id, role=role, row=source_row, key=dict(zip(keys, key))))
                    else:
                        seen[role][key] = canonical_row
            for cell in cells:
                cell["canonical_row"] = canonical_row
                provenance.append(cell)
    for doc_id, doc in by_id.items():
        if doc_id not in used_documents:
            issues.append(_issue("document_not_mapped", "This uploaded document is preserved but has no confirmed financial table mapping.", severity="warning", document_id=doc_id, file=doc.get("name")))
    notices = tables.pop("notice")
    if not notices:
        issues.append(_issue("missing_notices", "Map at least one deduction notice before running."))
    if not tables["invoice_lines"]:
        issues.append(_issue("missing_invoice_lines", "Map invoice lines before running reconciliation."))
    for role in ("purchase_orders", "invoices", "shipments", "shipment_lines", "receipts"):
        if not tables[role]:
            issues.append(_issue("missing_evidence_table", f"No {role.replace('_', ' ')} records were supplied. A supported match may be impossible.", severity="warning", role=role))
    selected_notice = 0
    if notice_row_id is not None:
        matches = [i for i, n in enumerate(notices) if n.get("deduction_id") == notice_row_id]
        if len(matches) != 1:
            issues.append(_issue("notice_selection_not_unique", "The requested deduction identifier is absent or duplicated."))
        else:
            selected_notice = matches[0]
    pack = {"version": 1, "notice": deepcopy(notices[selected_notice]) if notices else {}, **deepcopy(tables)}
    return {"pack": pack, "notices": notices, "issues": issues, "provenance": provenance,
            "ready": not any(issue.get("severity") == "error" for issue in issues),
            "counts": {"notices": len(notices), **{role: len(rows) for role, rows in tables.items()}},
            "source_documents": [{"id": d["id"], "name": d["name"], "sheet": d.get("sheet"), "sha256": d["sha256"]} for d in documents]}
