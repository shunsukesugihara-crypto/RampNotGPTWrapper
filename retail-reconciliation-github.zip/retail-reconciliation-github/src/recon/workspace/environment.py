"""Load only this application's server settings, without executing shell code."""
import os
from pathlib import Path

ALLOWED = {"RECON_PROVIDER", "OPENAI_API_KEY", "OPENAI_MODEL", "CODEX_MODEL"}


def load_environment(path, environ=None):
    env = os.environ if environ is None else environ
    path = Path(path)
    if not path.is_file():
        return {"loaded": False, "variables": []}
    seen, loaded = set(), []
    for number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        if text.startswith("export "):
            text = text[7:].lstrip()
        if "=" not in text:
            raise ValueError(f"Invalid environment setting at line {number}")
        name, value = text.split("=", 1)
        name, value = name.strip(), value.strip()
        if name not in ALLOWED or name in seen:
            raise ValueError(f"Unsupported or repeated environment setting at line {number}")
        seen.add(name)
        if value.startswith(("'", '"')):
            if len(value) < 2 or value[-1] != value[0]:
                raise ValueError(f"Unclosed environment value at line {number}")
            value = value[1:-1]
        else:
            value = value.split(" #", 1)[0].rstrip()
        if any(c in value for c in ("\x00", "\r", "\n")):
            raise ValueError(f"Invalid environment value at line {number}")
        if name not in env:
            env[name] = value
            loaded.append(name)
    return {"loaded": True, "variables": loaded}
