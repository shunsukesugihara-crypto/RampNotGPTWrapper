"""Readable descriptions of executed operations, not generated model thoughts."""
from copy import deepcopy


def action_text(action):
    action = action if isinstance(action, dict) else {"operation": str(action)}
    operation, source = action.get("operation", action.get("op")), action.get("source")
    if operation == "read_evidence":
        return "Read " + str(source or "source").replace("_", " ") + " using " + str(action.get("relation") or "recorded references").replace("_", " ")
    return {
        "normalize_source_records": "Normalize original values and validate recorded units",
        "join_financial_records": "Connect invoice, order and shipment records through their identifiers",
        "check_shortfalls": "Calculate shipped-minus-received shortages and exact amounts",
        "check_single_line_constraints": "Check the amount and quantity against individual invoice relationships",
        "solve_receipt_shortfall_allocation": "Run OR-Tools to search supported combinations of invoice lines",
        "verify_evidence": "Independently verify source records, calculations and competing relationships",
        "verify_reconstruction": "Independently verify the reconstructed allocation against raw records",
        "request_review": "Keep this deduction unresolved for human review",
    }.get(operation, str(operation or "processing step").replace("_", " "))


def observation_summary(value):
    fields = ("candidate_count", "invoice_candidate_count", "relationship_count", "source_row_counts", "calculation_state",
              "evidence_gaps", "normalization_issue_count", "transformation_count", "solution_count", "search_complete",
              "search_tool", "product_conversion_required")
    return {key: deepcopy(value[key]) for key in fields if key in value}
