"""Prevent multiple deductions from independently consuming one whole shortage.

This check uses already verified relationships, not a model or evaluation label.
It returns a deep copy. It never selects a first winner or removes the source
evidence: every deduction sharing a physical shortage must be reviewed together.
"""
from copy import deepcopy
from collections import defaultdict


REASON = "shared_shortfall_across_deductions"
MESSAGE = "These deductions reuse the same recorded receiving shortage; review together."


def _whole_shortfall(row, result):
    for notice in (row.get("notice"), result.get("notice"), result.get("notice_normalized")):
        if isinstance(notice, dict) and notice.get("basis") is not None:
            return notice["basis"] == "whole_receipt_shortfalls"
    return False


def _pairs(result):
    pairs = set()
    candidates = result.get("candidates", [])
    if not isinstance(candidates, list):
        return pairs
    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        lines = candidate.get("lines")
        if not isinstance(lines, list):
            lines = [candidate]
        for line in lines:
            if not isinstance(line, dict):
                continue
            shipment, sku = line.get("shipment_id"), line.get("sku")
            if isinstance(shipment, str) and shipment.strip() and isinstance(sku, str) and sku.strip():
                pairs.add((shipment.strip(), sku.strip()))
    return pairs


def enforce_batch_consistency(rows):
    """Return rows with every cross-deduction whole-shortage reuse reviewed.

    The physical identity is (shipment_id, sku), even when the invoice or invoice
    line differs. Arithmetic verification remains recorded separately. Repeated
    calls are stable; previously flagged reviews participate when later rows are
    added, so a third claim cannot evade the original conflict.
    """
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError("Batch results must be a list of result objects.")
    output = deepcopy(rows)
    eligible = {}
    uses = defaultdict(dict)
    for index, row in enumerate(output):
        result = row.get("result")
        deduction_id = row.get("deduction_id")
        if not isinstance(result, dict) or not isinstance(deduction_id, str) or not deduction_id:
            continue
        verification = result.get("verification", {})
        if not isinstance(verification, dict) or verification.get("passed") is not True or not _whole_shortfall(row, result):
            continue
        matched = row.get("status") == "matched" and result.get("status") == "matched"
        previous_conflict = (row.get("status") == "review" and result.get("status") == "review"
                             and row.get("reason") == REASON and result.get("reason") == REASON
                             and verification.get("batch_consistency_passed") is False)
        if not matched and not previous_conflict:
            continue
        pairs = _pairs(result)
        eligible[index] = pairs
        for pair in pairs:
            uses[pair].setdefault(deduction_id, []).append(index)
    conflicts = {pair: sorted(deductions) for pair, deductions in uses.items() if len(deductions) > 1}
    for index, pairs in eligible.items():
        details = [{"shipment_id": shipment, "sku": sku, "deduction_ids": conflicts[(shipment, sku)], "message": MESSAGE}
                   for shipment, sku in sorted(pairs) if (shipment, sku) in conflicts]
        if not details:
            continue
        row, result = output[index], output[index]["result"]
        row.update(status="review", reason=REASON, batch_conflicts=deepcopy(details))
        result.update(status="review", reason=REASON, batch_conflicts=deepcopy(details))
        result["verification"].update(batch_consistency_passed=False, batch_conflicts=deepcopy(details),
                                      batch_consistency_message=MESSAGE)
    return output
