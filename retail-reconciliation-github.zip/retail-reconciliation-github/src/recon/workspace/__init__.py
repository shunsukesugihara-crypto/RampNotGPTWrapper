"""User-file workspaces, explicit model settings and persistent batch jobs."""
