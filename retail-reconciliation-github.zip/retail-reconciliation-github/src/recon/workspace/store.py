"""Local persistent workspace data; identifiers never become arbitrary paths."""
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
from threading import RLock
import uuid


def now():
    return datetime.now(timezone.utc).isoformat()


def identity(value):
    if not isinstance(value, str):
        raise ValueError("A valid workspace or job identifier is required")
    try:
        if str(uuid.UUID(value)) != value:
            raise ValueError()
    except (ValueError, AttributeError):
        raise ValueError("Invalid workspace or job identifier") from None
    return value


class Store:
    def __init__(self, root):
        self.root = Path(root)
        self.lock = RLock()
        self.root.mkdir(parents=True, exist_ok=True)
        for name in ("workspaces", "jobs"):
            (self.root / name).mkdir(exist_ok=True)

    def _path(self, kind, item_id):
        if kind not in {"workspaces", "jobs"}:
            raise ValueError("Unsupported saved object")
        return self.root / kind / (identity(item_id) + ".json")

    def save(self, kind, value):
        data = deepcopy(value)
        data["updated_at"] = now()
        path = self._path(kind, data["id"])
        with self.lock:
            temporary = path.with_suffix(".json.tmp")
            temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
            temporary.replace(path)
        return data

    def get(self, kind, item_id):
        with self.lock:
            try:
                return json.loads(self._path(kind, item_id).read_text())
            except FileNotFoundError:
                raise ValueError("This workspace or job was not found") from None

    def list(self, kind):
        if kind not in {"workspaces", "jobs"}:
            raise ValueError("Unsupported saved object")
        with self.lock:
            rows = [json.loads(p.read_text()) for p in (self.root / kind).glob("*.json")]
        return sorted(rows, key=lambda x: x.get("created_at", ""), reverse=True)

    def recover(self):
        """An interrupted process is not a completed or quietly retried job."""
        for job in self.list("jobs"):
            if job.get("status") in {"queued", "running", "cancelling"}:
                job.update(status="interrupted", error="The application restarted before this job finished. Completed rows are preserved. Start a new run to process it again.")
                self.save("jobs", job)
