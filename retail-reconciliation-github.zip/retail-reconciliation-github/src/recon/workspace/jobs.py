"""Actual asynchronous per-notice execution against imported user records."""
from copy import deepcopy
import csv
import io
import json
from pathlib import Path
from threading import Event, Lock, Thread
import uuid

from recon.reconstruction.data import load_pack
from .store import now
from .events import action_text, observation_summary
from .scoping import scope_pack


class Cancelled(Exception):
    pass


class ObservedProvider:
    def __init__(self, provider, callback, cancel):
        self.provider, self.callback, self.cancel = provider, callback, cancel
        self.observed_steps = 0
        self.previous_observation = {}

    def record_observation(self, observation):
        actions = observation.get("executed_actions", observation.get("executed_operations", []))
        for value in actions[self.observed_steps:]:
            action = value if isinstance(value, dict) else {"operation": value}
            self.callback({"type": "tool_observation", "level": "info", "status": "completed",
                           "message": action_text(action), "action": deepcopy(action), "operation": action.get("operation"),
                           "source": action.get("source"), "tool": observation.get("search_tool") or "approved code operation",
                           "before_count": self.previous_observation.get("candidate_count"), "after_count": observation.get("candidate_count"),
                           "observation": observation_summary(observation)})
            self.observed_steps += 1
        self.previous_observation = deepcopy(observation)

    def complete(self, instructions, context, schema):
        if self.cancel.is_set():
            raise Cancelled("Run cancelled before the next model request")
        self.record_observation(context.get("observation", {}))
        self.callback({"type": "model_request", "level": "info", "status": "running", "message": "AI is selecting the next processing step.",
                       "observation": observation_summary(context.get("observation", {}))})
        try:
            completion = self.provider.complete(instructions, context, schema)
        except Exception as error:
            self.callback({"type": "model_error", "level": "error", "status": "failed", "message": "The model request failed. No fallback answer was accepted.", "error_type": type(error).__name__})
            raise
        if self.cancel.is_set():
            self.callback({"type": "model_completion_discarded", "message": "The model request finished after cancellation. Its result was discarded.",
                           "audit": deepcopy(completion.audit)})
            raise Cancelled("Run cancelled after the current model request completed")
        self.callback({"type": "model_action", "level": "info", "status": "selected", "message": "AI selected: " + action_text(completion.value),
                       "action": deepcopy(completion.value), "audit": deepcopy(completion.audit)})
        return completion


class JobManager:
    def __init__(self, store, models):
        self.store, self.models = store, models
        self.lock = Lock()
        self.cancellations = {}
        self.active = None
        self.store.recover()

    def start(self, workspace, mode):
        if not isinstance(mode, str) or mode not in {"ai", "fixed"}:
            raise ValueError("Choose AI planning or fixed tools")
        built = workspace.get("built", {})
        if not built.get("ready") or not built.get("notices"):
            raise ValueError("Resolve the import and mapping issues, then confirm the mappings before running")
        if len(built["notices"]) > 100:
            raise ValueError("This local version supports at most 100 deductions in one run. Import a smaller batch.")
        if mode == "ai":
            provider, config = self.models.selection()
        else:
            provider, config = None, self.models.view()
        job_id = str(uuid.uuid4())
        with self.lock:
            if self.active is not None:
                raise ValueError("Another batch is running. Finish or cancel it before starting a new batch.")
            self.active = job_id
            cancel = Event()
            self.cancellations[job_id] = cancel
        job = {"id": job_id, "job_id": job_id, "workspace_id": workspace["id"], "name": workspace.get("name", "Imported records"),
               "created_at": now(), "status": "queued", "completed": 0, "total": len(built["notices"]), "current": None,
               "mode": mode, "provider": config.get("provider") if mode == "ai" else "none", "model": config.get("model") if mode == "ai" else "Fixed tools",
               "model_configuration": config, "results": [], "progress": deepcopy(workspace.get("activity", [])), "error": None}
        self.store.save("jobs", job)
        Thread(target=self._run, args=(deepcopy(workspace), job, provider, cancel), daemon=True).start()
        return job

    def cancel(self, job_id):
        job = self.store.get("jobs", job_id)
        with self.lock:
            event = self.cancellations.get(job_id)
            if event:
                event.set()
                job.update(status="cancelling", cancellation_note="The current model request may finish; no next deduction will start.")
                self.store.save("jobs", job)
        return job

    def _run(self, workspace, job, provider, cancel):
        folder = self.store.root / "job_sources" / job["id"]
        folder.mkdir(parents=True, exist_ok=True)
        job["status"] = "running"

        def progress(value):
            if cancel.is_set() and job["status"] not in {"cancelled", "complete", "failed", "interrupted"}:
                job["status"] = "cancelling"
            job["progress"].append({"at": now(), "deduction_id": job.get("current"), **value})
            self.store.save("jobs", job)

        try:
            built = workspace["built"]
            progress({"type": "batch_started", "level": "info", "message": f"Started {len(built['notices'])} deductions using " + (f"{job['provider']} / {job['model']}" if provider is not None else "fixed tools; no model requests"),
                      "rows": deepcopy(built.get("counts", {}))})
            for index, notice in enumerate(built["notices"]):
                if cancel.is_set():
                    break
                deduction_id = notice.get("deduction_id") or f"Source row {index + 1}"
                job["current"] = deduction_id
                progress({"type": "deduction_started", "message": "Processing this deduction against the imported records."})
                pack = deepcopy(built["pack"])
                pack["notice"] = deepcopy(notice)
                selection = scope_pack(pack)
                pack = selection["pack"]
                progress({"type": "source_selection", "level": "info", "message": "Selected records using the notice's supplied business references; no answer-based filtering.",
                          "filters": selection["recorded_reference_filters"], "rows": selection["counts"]})
                source = folder / f"{index:04d}.json"
                source.write_text(json.dumps(pack, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
                try:
                    observed = ObservedProvider(provider, progress, cancel) if provider is not None else None
                    raw = load_pack(source)
                    use_investigation = (notice.get("scope") == "single_line" and notice.get("basis") == "whole_receipt_shortfalls"
                                         and notice.get("uom") == "CS" and notice.get("currency") == "USD"
                                         and all(line.get("price_uom") == "CS" and line.get("uom") == "CS" for line in pack["invoice_lines"]))
                    if use_investigation:
                        from recon.investigation.service import run_case
                        result = run_case(raw, provider=observed, mode=job["mode"])
                    elif job["mode"] == "fixed":
                        from recon.reconstruction.evaluate import all_tools
                        result = all_tools(raw)
                    else:
                        from recon.reconstruction.service import reconcile
                        result = reconcile(raw, provider=observed)
                    result["data_kind"] = "user_uploaded"
                    if result.get("reason") in {"planner_unavailable", "invalid_model_action", "model_step_limit", "operation_failed"}:
                        result["status"] = "failed"
                except Exception as error:
                    result = {"status": "failed", "reason": "record_execution_failed", "error_type": type(error).__name__,
                              "candidates": [], "verification": {"passed": False}, "model_calls": 0}
                if cancel.is_set():
                    progress({"type": "cancelled_current", "message": "The in-progress deduction was cancelled. No result was accepted."})
                    break
                seen = observed.observed_steps if observed is not None else 0
                for trace in result.get("trace", [])[seen:]:
                    progress({"type": "tool_observation", "level": "info", "status": "completed", "message": trace.get("summary") or action_text(trace),
                              "action": {k: trace.get(k) for k in ("operation", "source", "relation")}, "operation": trace.get("operation"),
                              "source": trace.get("source"), "tool": trace.get("tool") or "approved code operation",
                              "before_count": trace.get("before_count", trace.get("input_count")), "after_count": trace.get("after_count", trace.get("output_count")),
                              "equations": deepcopy(trace.get("equations", []))})
                refs = {("notice", index)}
                def evidence_refs(value):
                    if isinstance(value, dict):
                        if isinstance(value.get("table"), str) and type(value.get("row")) is int:
                            table, selected_row = value["table"], value["row"]
                            original_rows = selection["source_rows"].get(table, [])
                            if 0 <= selected_row < len(original_rows):
                                refs.add((table, original_rows[selected_row]))
                        for child in value.values():
                            evidence_refs(child)
                    elif isinstance(value, (list, tuple)):
                        for child in value:
                            evidence_refs(child)
                evidence_refs(result.get("candidates", []))
                evidence_refs(result.get("verification", {}).get("evidence", []))
                relevant = [p for p in built.get("provenance", []) if (p.get("table"), p.get("canonical_row")) in refs]
                job["results"].append({"deduction_id": deduction_id, "status": result.get("status", "failed"),
                                       "notice": deepcopy(notice),
                                       "amount": notice.get("amount"), "currency": notice.get("currency"), "reason": result.get("reason"),
                                       "result": result, "source_pack": str(source), "source_provenance": deepcopy(relevant[:1500]),
                                       "source_provenance_total": len(relevant), "source_provenance_truncated": len(relevant) > 1500,
                                       "source_selection": {k: deepcopy(v) for k, v in selection.items() if k != "pack"},
                                       "import_provenance_ref": {"workspace_id": workspace["id"], "section": "built.provenance"}})
                from .consistency import enforce_batch_consistency
                previous_statuses = {row["deduction_id"]: row["status"] for row in job["results"]}
                job["results"] = enforce_batch_consistency(job["results"])
                for row in job["results"]:
                    if row["status"] != previous_statuses[row["deduction_id"]]:
                        progress({"type": "batch_conflict", "level": "warning", "deduction_id": row["deduction_id"],
                                  "status": row["status"], "previous_status": previous_statuses[row["deduction_id"]],
                                  "message": "Changed to review: another deduction claims the same whole receiving shortage. Review the linked claims together.",
                                  "conflicts": deepcopy(row.get("batch_conflicts", []))})
                job["completed"] = len(job["results"])
                progress({"type": "deduction_finished", "message": "The result, source evidence and cross-deduction checks were saved.", "status": job["results"][-1]["status"]})
            job.update(status="cancelled" if cancel.is_set() else "complete", current=None, finished_at=now())
            progress({"type": "batch_finished", "level": "warning" if cancel.is_set() else "info", "status": job["status"],
                      "message": f"{job['completed']} of {job['total']} deductions saved. " + ("Cancellation completed." if cancel.is_set() else "Results and evidence are ready to export.")})
        except Exception as error:
            job.update(status="failed", error="The batch stopped unexpectedly; completed rows remain saved.", error_type=type(error).__name__, finished_at=now())
        finally:
            # Successful/cancelled terminal state was saved by batch_finished.
            # Do not write again after readers can observe the terminal status.
            if job["status"] == "failed":
                self.store.save("jobs", job)
            with self.lock:
                self.cancellations.pop(job["id"], None)
                if self.active == job["id"]:
                    self.active = None


def results_csv(job):
    out = io.StringIO(newline="")
    writer = csv.writer(out)
    writer.writerow(["deduction_id", "status", "amount", "currency", "reason", "invoice_lines", "verified", "provider", "model"])
    def safe(value):
        text = "" if value is None else str(value)
        return "'" + text if text.startswith(("=", "+", "-", "@", "\t", "\r")) else text
    for row in job["results"]:
        result = row.get("result", {})
        ids = []
        for candidate in result.get("candidates", []):
            if candidate.get("invoice_line_id"):
                ids.append(candidate["invoice_line_id"])
            ids.extend(line.get("invoice_line_id", "") for line in candidate.get("lines", []))
        writer.writerow([safe(v) for v in (row["deduction_id"], row["status"], row.get("amount"), row.get("currency"), row.get("reason"), "; ".join(ids), result.get("verification", {}).get("passed", False), job.get("provider"), job.get("model"))])
    return out.getvalue().encode("utf-8-sig")
