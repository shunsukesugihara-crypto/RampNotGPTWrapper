"""User-file workspace API on the existing localhost application boundary."""
import base64
from copy import deepcopy
import json
from pathlib import Path
import re
import uuid
import io
import zipfile

from .ingestion import FIELD_CATALOG, ROLES, build_pack, capabilities, inspect_files
from .jobs import JobManager, results_csv
from .model import ModelSettings, suggest_mappings
from .store import Store, now
from .scoping import scope_pack


class WorkspaceApp:
    def __init__(self, root, *, store=None, models=None):
        self.root = Path(root)
        self.store = store or Store(self.root / "output/workspace")
        self.models = models or ModelSettings(self.store.root / "model_settings.json")
        self.jobs = JobManager(self.store, self.models)

    def config(self):
        cap = capabilities()
        formats = ["CSV", "TSV", "JSON"]
        if cap["xlsx"]:
            formats.append("XLSX")
        if cap["pdf_text_preview"]:
            formats.append("PDF text preview only")
        return {**self.models.view(), "field_catalog": deepcopy(FIELD_CATALOG), "capabilities": cap,
                "supported_formats": formats,
                "engine_limits": {"max_source_rows": 2000, "max_pack_bytes": 1048576, "max_deductions": 100},
                "storage": "Files and runs are saved locally in this project. AI requests send selected records to your configured model."}

    def _workspace(self, workspace):
        out = deepcopy(workspace)
        built = out.pop("built", {})
        out.update(workspace_id=out["id"], field_catalog=deepcopy(FIELD_CATALOG),
                   ready=built.get("ready", False), notices=deepcopy(built.get("notices", [])),
                   notice_count=len(built.get("notices", [])), counts=built.get("counts", {}),
                   provenance=deepcopy(built.get("provenance", [])))
        if built:
            out["issues"] = built.get("issues", [])
        return out

    def get(self, handler):
        path = handler.path
        if not path.startswith("/api/workspace"):
            return False
        try:
            if path == "/api/workspace/config":
                handler._json(200, self.config())
            elif path in {"/api/workspace/example.zip", "/api/workspace/example-expected.json"}:
                folder = self.root / "examples/retail_reconciliation"
                if path.endswith(".json"):
                    handler._json(200, json.loads((folder / "expected_results.json").read_text()))
                else:
                    stream = io.BytesIO()
                    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                        for file in sorted(folder.rglob("*")):
                            if file.is_file():
                                archive.write(file, str(file.relative_to(folder)))
                    handler._send(200, stream.getvalue(), "application/zip")
            elif path == "/api/workspace/history":
                fields = ("id", "job_id", "workspace_id", "name", "status", "created_at", "updated_at", "completed", "total", "mode", "provider", "model", "error")
                handler._json(200, {"jobs": [{k: job.get(k) for k in fields} for job in self.store.list("jobs")]})
            elif path.startswith("/api/workspace/jobs/"):
                parts = path[len("/api/workspace/jobs/"):].split("/")
                job = self.store.get("jobs", parts[0])
                if len(parts) == 1:
                    handler._json(200, job)
                elif len(parts) == 2 and parts[1] == "export.csv":
                    handler._send(200, results_csv(job), "text/csv; charset=utf-8")
                elif len(parts) == 2 and parts[1] == "export.json":
                    workspace = self.store.get("workspaces", job["workspace_id"])
                    handler._json(200, {"job": job, "mapping": workspace.get("mappings"), "settings": workspace.get("settings"),
                                        "source_documents": workspace.get("built", {}).get("source_documents"),
                                        "import_provenance": workspace.get("built", {}).get("provenance", [])})
                else:
                    handler._error(404, "not_found", "This workspace route does not exist.")
            elif path.startswith("/api/workspace/"):
                handler._json(200, self._workspace(self.store.get("workspaces", path[len("/api/workspace/"):])))
            else:
                handler._error(404, "not_found", "This workspace route does not exist.")
        except (ValueError, KeyError) as error:
            handler._error(400, "workspace_request", str(error))
        except Exception as error:
            handler._error(500, "workspace_unavailable", f"Workspace operation failed ({type(error).__name__}). Saved records were not replaced.")
        return True

    def post(self, handler, request):
        path = handler.path
        if not path.startswith("/api/workspace/"):
            return False
        try:
            if not isinstance(request, dict):
                raise ValueError("Send a JSON object for this workspace operation.")
            if path == "/api/workspace/config":
                self.models.update(request)
                handler._json(200, self.config())
            elif path == "/api/workspace/test":
                handler._json(200, self.models.test_connection())
            elif path == "/api/workspace/import":
                inspected = inspect_files(request.get("files"))
                item_id = str(uuid.uuid4())
                folder = self.store.root / "uploads" / item_id
                folder.mkdir(parents=True, exist_ok=False)
                files = []
                for index, upload in enumerate(request["files"]):
                    # User filenames are display metadata, never filesystem paths.
                    path_out = folder / f"{index:03d}.source"
                    content = base64.b64decode(upload["content_base64"], validate=True)
                    path_out.write_bytes(content)
                    files.append({"name": upload["name"], "bytes": len(content), "path": str(path_out)})
                workspace = {"id": item_id, "created_at": now(), "name": request.get("name") or request["files"][0]["name"],
                             "documents": inspected["documents"], "issues": inspected["issues"], "files": files,
                             "total_bytes": inspected["total_bytes"], "mappings": [], "settings": {}, "built": {},
                             "activity": [{"at": now(), "type": "import_complete", "level": "info", "message": f"Read {len(files)} uploaded files into {len(inspected['documents'])} tables. Original values and file hashes were retained.",
                                           "files": [{"name": f["name"], "bytes": f["bytes"]} for f in files]}]}
                self.store.save("workspaces", workspace)
                handler._json(201, self._workspace(workspace))
            elif path == "/api/workspace/suggest":
                workspace = self.store.get("workspaces", request.get("workspace_id"))
                docs = [doc for doc in workspace["documents"] if doc.get("columns") and doc.get("rows")]
                if not docs:
                    raise ValueError("No structured tables are available for column mapping. PDF text previews are not financial tables.")
                provider, config = self.models.selection()
                proposal = suggest_mappings(docs, provider)
                workspace["mapping_proposal"] = {**proposal, "model_configuration": config}
                workspace.setdefault("activity", []).append({"at": now(), "type": "mapping_proposed", "level": "info", "message": f"{config['model']} proposed {len(proposal['mappings'])} record-type mappings. No financial values were filled; user review is required."})
                self.store.save("workspaces", workspace)
                handler._json(200, {**proposal, "model_configuration": config})
            elif path == "/api/workspace/map":
                workspace = self.store.get("workspaces", request.get("workspace_id"))
                settings = self._settings(request.get("settings", {}))
                mappings = self._with_defaults(request.get("mappings"), settings)
                built = build_pack(workspace["documents"], mappings)
                for notice in built["notices"]:
                    selected = scope_pack({**built["pack"], "notice": notice})["pack"]
                    count = sum(len(selected[role]) for role in ROLES if role != "notice")
                    if count > 2000:
                        built["issues"].append({"code": "execution_row_limit", "severity": "error", "deduction_id": notice.get("deduction_id"), "message": "This deduction has more than 2,000 relevant source rows. Add a recorded invoice/order reference or filter the export. Records have not been silently discarded."})
                    if len(json.dumps(selected, ensure_ascii=False).encode()) > 1048576:
                        built["issues"].append({"code": "execution_size_limit", "severity": "error", "deduction_id": notice.get("deduction_id"), "message": "This deduction's mapped evidence exceeds the 1 MB engine limit. Split the export into smaller business scopes."})
                if len(built["notices"]) > 100:
                    built["issues"].append({"code": "deduction_batch_limit", "severity": "error", "message": "Split this deduction export into batches of at most 100 rows."})
                built["ready"] = built["ready"] and not any(x.get("severity") == "error" for x in built["issues"])
                workspace.update(mappings=deepcopy(request["mappings"]), settings=settings, built=built)
                workspace.setdefault("activity", []).append({"at": now(), "type": "mapping_confirmed", "level": "info" if built["ready"] else "error", "status": "ready" if built["ready"] else "blocked",
                    "message": f"Confirmed source mappings for {len(built['notices'])} deductions. " + ("Required fields and execution limits passed." if built["ready"] else "Mapping issues must be resolved before execution."), "rows": built["counts"]})
                self.store.save("workspaces", workspace)
                handler._json(200, self._workspace(workspace))
            elif path == "/api/workspace/run":
                workspace = self.store.get("workspaces", request.get("workspace_id"))
                handler._json(202, self.jobs.start(workspace, request.get("mode", "ai")))
            elif path.startswith("/api/workspace/jobs/") and path.endswith("/cancel"):
                job_id = path[len("/api/workspace/jobs/"):-len("/cancel")]
                handler._json(200, self.jobs.cancel(job_id))
            else:
                handler._error(404, "not_found", "This workspace route does not exist.")
        except (ValueError, KeyError) as error:
            handler._error(400, "workspace_request", str(error))
        except Exception as error:
            handler._error(502, "model_or_workspace_failed", f"The requested operation failed ({type(error).__name__}). No alternative model or fixed workflow was substituted.")
        return True

    @staticmethod
    def _settings(value):
        if not isinstance(value, dict) or set(value) - {"currency", "uom", "scope", "basis"}:
            raise ValueError("Only explicit currency, unit, claim-scope and financial-basis defaults are accepted.")
        if any(not isinstance(val, str) for val in value.values()):
            raise ValueError("Declared default settings must be text, not numbers or executable expressions.")
        out = {key: val.strip() for key, val in value.items() if isinstance(val, str) and val.strip()}
        if "currency" in out:
            out["currency"] = out["currency"].upper()
            if not re.fullmatch("[A-Z]{3}", out["currency"]):
                raise ValueError("Currency must use a three-letter code such as USD.")
        if "uom" in out:
            out["uom"] = out["uom"].upper()
            if out["uom"] not in {"CS", "EA"}:
                raise ValueError("Choose CS (cases) or EA (individual units).")
        if out.get("scope", "unknown") not in {"single_line", "multi_line", "unknown"}:
            raise ValueError("Choose single_line, multi_line or unknown for claim scope.")
        if out.get("basis") not in {None, "whole_receipt_shortfalls", "invoice_unit_price"}:
            raise ValueError("Choose a supported, explicit financial basis.")
        return out

    @staticmethod
    def _with_defaults(mappings, settings):
        if not isinstance(mappings, list):
            raise ValueError("Confirm the column mappings before continuing.")
        result = deepcopy(mappings)
        for mapping in result:
            if not isinstance(mapping, dict):
                raise ValueError("Each table mapping must be an object.")
            role = mapping.get("role")
            if role == "deductions":
                role = "notice"
            if role is not None and not isinstance(role, str):
                raise ValueError("Choose a supported table role for each mapping.")
            if role not in FIELD_CATALOG:
                continue
            defaults = mapping.setdefault("defaults", {})
            if not isinstance(defaults, dict):
                raise ValueError("Declared mapping defaults must be an object.")
            for field, value in settings.items():
                if field in FIELD_CATALOG[role]["fields"] and (field not in {"scope", "basis"} or role == "notice"):
                    defaults.setdefault(field, value)
        return result
