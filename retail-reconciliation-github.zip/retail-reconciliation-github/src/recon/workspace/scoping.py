"""Narrow source pools by recorded business references, never by guessed matches."""
from copy import deepcopy

TABLES = ("products", "purchase_orders", "invoices", "invoice_lines", "shipments", "shipment_lines", "receipts")


def _id(value):
    return value.strip() if isinstance(value, str) else ""


def scope_pack(pack):
    """Keep every relationship inside the notice's explicit invoice/PO/SKU scope.

    No price ranking, quantity guess, semantic threshold or top-k truncation is
    used. Without an explicit reference the complete supplied pool is retained.
    Source-row indices link each derived row back to the imported cell ledger.
    """
    notice = pack["notice"]
    invoice_ref, po_ref, sku_ref = (_id(notice.get(key)) for key in ("invoice_hint", "po_hint", "sku_hint"))
    rows = {name: list(enumerate(pack[name])) for name in TABLES}
    filters = {key: value for key, value in (("invoice_hint", invoice_ref), ("po_hint", po_ref), ("sku_hint", sku_ref)) if value}
    if filters:
        all_invoice_ids = {_id(row.get("invoice_id")) for row in pack["invoices"]}
        if invoice_ref:
            rows["invoices"] = [(i, r) for i, r in rows["invoices"] if _id(r.get("invoice_id")) == invoice_ref]
            rows["invoice_lines"] = [(i, r) for i, r in rows["invoice_lines"] if _id(r.get("invoice_id")) == invoice_ref]
        elif po_ref:
            rows["invoices"] = [(i, r) for i, r in rows["invoices"] if _id(r.get("po_id")) == po_ref]
            ids = {_id(r.get("invoice_id")) for _, r in rows["invoices"]}
            # Orphan lines have unknown order membership. Retain them so the
            # financial validator cannot silently assume they are irrelevant.
            rows["invoice_lines"] = [(i, r) for i, r in rows["invoice_lines"]
                                     if _id(r.get("invoice_id")) in ids or _id(r.get("invoice_id")) not in all_invoice_ids]
        if sku_ref:
            rows["invoice_lines"] = [(i, r) for i, r in rows["invoice_lines"] if _id(r.get("sku")) == sku_ref]
        if not invoice_ref and not po_ref:
            ids = {_id(r.get("invoice_id")) for _, r in rows["invoice_lines"]}
            rows["invoices"] = [(i, r) for i, r in rows["invoices"] if _id(r.get("invoice_id")) in ids]
        orders = {_id(r.get("po_id")) for _, r in rows["invoices"]}
        if po_ref:
            orders.add(po_ref)
        rows["purchase_orders"] = [(i, r) for i, r in rows["purchase_orders"] if _id(r.get("po_id")) in orders]
        rows["shipments"] = [(i, r) for i, r in rows["shipments"] if _id(r.get("po_id")) in orders]
        shipments = {_id(r.get("shipment_id")) for _, r in rows["shipments"]}
        skus = {_id(r.get("sku")) for _, r in rows["invoice_lines"]}
        if sku_ref:
            skus.add(sku_ref)
        rows["shipment_lines"] = [(i, r) for i, r in rows["shipment_lines"]
                                  if _id(r.get("shipment_id")) in shipments and _id(r.get("sku")) in skus]
        rows["receipts"] = [(i, r) for i, r in rows["receipts"]
                            if _id(r.get("shipment_id")) in shipments and _id(r.get("sku")) in skus]
        rows["products"] = [(i, r) for i, r in rows["products"] if _id(r.get("sku")) in skus]
    selected = {"version": pack["version"], "notice": deepcopy(notice),
                **{table: [deepcopy(row) for _, row in values] for table, values in rows.items()}}
    return {"pack": selected, "source_rows": {table: [index for index, _ in values] for table, values in rows.items()},
            "recorded_reference_filters": filters,
            "counts": {table: {"available": len(pack[table]), "selected": len(values)} for table, values in rows.items()},
            "selection_rule": "Exact recorded invoice, purchase-order and product references only; no answer ranking or invented relationship."}
