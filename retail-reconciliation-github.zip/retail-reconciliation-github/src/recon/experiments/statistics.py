"""Paired case-level analysis of already-scored, frozen experiment results.

Repeated model runs are observations of the same case, not new independent
financial problems. We average paired repeats within each case, then resample
whole cases. Dataset names define separate analyses; no pooled winner is inferred.
This module cannot establish label quality, untouched test data, or independence.
"""
from collections import defaultdict
from collections.abc import Mapping
import hashlib
import math
import random


ENGINES = ("no_ai", "direct_ai", "procedure_ai")
COMPARATORS = ("direct_ai", "no_ai")
FLAGS = ("success", "incorrect_auto", "auto", "review", "failed", "verified")
DEFAULT_SEED = 20261109
REFERENCES = {
    "paired_percentile_bootstrap": "https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.bootstrap.html",
    "exact_mcnemar": "https://www.statsmodels.org/stable/generated/statsmodels.stats.contingency_tables.mcnemar.html",
    "holm_adjustment": "https://www.statsmodels.org/stable/generated/statsmodels.stats.multitest.multipletests.html",
    "finite_sample_proportion_uncertainty": "https://www.itl.nist.gov/div898/handbook/prc/section2/prc241.htm",
}


def _mean(values):
    return math.fsum(values) / len(values) if values else None


def _rate(numerator, denominator):
    return numerator / denominator if denominator else None


def _validate(records):
    required = {"dataset", "case_id", "repeat", "engine", "runtime_ms", "model_calls", "input_tokens", "output_tokens", *FLAGS}
    seen = set()
    clean = []
    for position, record in enumerate(records):
        if not isinstance(record, Mapping):
            raise ValueError(f"Record {position} must be an object")
        missing = required - record.keys()
        if missing:
            raise ValueError(f"Record {position} missing fields: {', '.join(sorted(missing))}")
        for field in ("dataset", "case_id"):
            if not isinstance(record[field], str) or not record[field].strip():
                raise ValueError(f"Record {position} {field} must be a nonempty string")
        if record["engine"] not in ENGINES:
            raise ValueError(f"Record {position} has unknown engine")
        for field in ("repeat", "model_calls"):
            if type(record[field]) is not int or record[field] < 0:
                raise ValueError(f"Record {position} {field} must be a nonnegative integer")
        for field in FLAGS:
            if type(record[field]) is not bool:
                raise ValueError(f"Record {position} {field} must be boolean")
        runtime = record["runtime_ms"]
        if type(runtime) not in (int, float) or not math.isfinite(runtime) or runtime < 0:
            raise ValueError(f"Record {position} runtime_ms must be finite and nonnegative")
        for field in ("input_tokens", "output_tokens"):
            if record[field] is not None and (type(record[field]) is not int or record[field] < 0):
                raise ValueError(f"Record {position} {field} must be a nonnegative integer or null")
        if record["failed"] and record["success"]:
            raise ValueError(f"Record {position} failed attempts cannot be credited as success")
        if record["incorrect_auto"] and (not record["auto"] or record["success"]):
            raise ValueError(f"Record {position} incorrect_auto requires auto and unsuccessful outcome")
        if record["auto"] and record["review"]:
            raise ValueError(f"Record {position} auto and review are mutually exclusive")
        if record["failed"] and record["auto"]:
            raise ValueError(f"Record {position} failed attempts cannot be automatic conclusions")
        key = (record["dataset"], record["case_id"], record["repeat"], record["engine"])
        if key in seen:
            raise ValueError(f"Duplicate dataset/case/repeat/engine: {key!r}")
        seen.add(key)
        clean.append(dict(record))
    return clean


def _token_usage(records, field):
    observed = [row[field] for row in records if row[field] is not None]
    unknown = len(records) - len(observed)
    return {
        "total": sum(observed) if records and not unknown else None,
        "observed_total": sum(observed),
        "observed_records": len(observed),
        "unknown_records": unknown,
        "complete": bool(records) and not unknown,
        "mean_per_observed_record": _mean(observed),
    }


def _engine_summary(records):
    by_case = defaultdict(list)
    for row in records:
        by_case[row["case_id"]].append(row)
    cases = []
    for case_id, rows in sorted(by_case.items()):
        cases.append({
            "case_id": case_id,
            "repeat_ids": sorted(row["repeat"] for row in rows),
            "n_repeats": len(rows),
            "mean_success": _mean([int(row["success"]) for row in rows]),
            "mean_incorrect_auto": _mean([int(row["incorrect_auto"]) for row in rows]),
            "mean_failed": _mean([int(row["failed"]) for row in rows]),
        })
    counts = {flag: sum(row[flag] for row in records) for flag in FLAGS}
    # Some clients shape an API failure as a review result. Keep that flag visible,
    # but do not count it as a completed human-review decision.
    counts["completed_review"] = sum(row["review"] and not row["failed"] for row in records)
    counts["completed"] = len(records) - counts["failed"]
    rates = {name: _rate(count, len(records)) for name, count in counts.items()}
    rates["incorrect_given_auto"] = _rate(counts["incorrect_auto"], counts["auto"])
    rates["success_case_weighted"] = _mean([case["mean_success"] for case in cases])
    rates["incorrect_auto_case_weighted"] = _mean([case["mean_incorrect_auto"] for case in cases])
    return {
        "n_records": len(records),
        "n_cases": len(cases),
        "counts": counts,
        "rates": rates,
        "rate_denominator": "all recorded attempts, including failures; conditional and case-weighted rates are named separately",
        "per_case": cases,
        "resources": {
            "runtime_ms": {"total": math.fsum(row["runtime_ms"] for row in records), "mean_per_record": _mean([row["runtime_ms"] for row in records])},
            "model_calls": {"total": sum(row["model_calls"] for row in records), "mean_per_record": _mean([row["model_calls"] for row in records])},
            "input_tokens": _token_usage(records, "input_tokens"),
            "output_tokens": _token_usage(records, "output_tokens"),
            "cost": None,
            "cost_unavailable_reason": "No prices or monetary cost were supplied; unknown tokens are not imputed as zero.",
        },
    }


def _quantile(sorted_values, probability):
    position = (len(sorted_values) - 1) * probability
    lo = math.floor(position)
    hi = math.ceil(position)
    fraction = position - lo
    return sorted_values[lo] * (1 - fraction) + sorted_values[hi] * fraction


def _bootstrap(differences, rng, resamples):
    count = len(differences)
    estimate = _mean(differences)
    result = {
        "estimate": estimate,
        "ci95": None,
        "n_cases": count,
        "method": "paired case-cluster percentile bootstrap",
        "confidence_level": 0.95,
        "resamples": resamples if count >= 2 else 0,
        "interval_is_simultaneous_across_comparisons": False,
    }
    if count < 2:
        result.update(status="insufficient_cases", reason="At least two paired independent case clusters are required; repeated runs do not increase this count.")
        return result
    constant = all(value == differences[0] for value in differences)
    if constant:
        distribution = [differences[0]] * resamples
    else:
        distribution = sorted(math.fsum(differences[rng.randrange(count)] for _ in range(count)) / count for _ in range(resamples))
    result["ci95"] = {"low": _quantile(distribution, 0.025), "high": _quantile(distribution, 0.975)}
    if constant:
        result.update(status="all_case_differences_tied" if differences[0] == 0 else "constant_case_difference", reason="The observed bootstrap distribution is degenerate; this does not establish absence of unobserved errors or population certainty.")
    else:
        result.update(status="estimated", reason=None)
    return result


def _exact_mcnemar(case_pairs):
    repeat_zero = [pair for pair in case_pairs if pair["repeat"] == 0]
    b = sum(pair["procedure"]["success"] and not pair["comparator"]["success"] for pair in repeat_zero)
    c = sum(not pair["procedure"]["success"] and pair["comparator"]["success"] for pair in repeat_zero)
    n_discordant = b + c
    p_value = None
    if repeat_zero:
        # Integer arithmetic avoids an overflowing float 2**n intermediate.
        p_value = min(1.0, (2 * sum(math.comb(n_discordant, k) for k in range(min(b, c) + 1))) / (1 << n_discordant))
    return {
        "endpoint": "success",
        "repeat": 0,
        "n_cases": len(repeat_zero),
        "case_ids": sorted(pair["case_id"] for pair in repeat_zero),
        "b": b,
        "c": c,
        "b_definition": "procedure succeeds and comparator fails",
        "c_definition": "procedure fails and comparator succeeds",
        "concordant_success": sum(pair["procedure"]["success"] and pair["comparator"]["success"] for pair in repeat_zero),
        "concordant_failure": sum(not pair["procedure"]["success"] and not pair["comparator"]["success"] for pair in repeat_zero),
        "discordant_cases": n_discordant,
        "statistic": min(b, c) if repeat_zero else None,
        "p_two_sided_exact": p_value,
        "status": "no_discordance" if repeat_zero and not n_discordant else "calculated" if repeat_zero else "no_repeat_zero_pairs",
        "assumption": "One independent binary paired outcome per case, restricted to repeat 0; independence is required but cannot be verified from these records.",
    }


def _comparison(records, comparator, seed, resamples):
    indexed = {(row["case_id"], row["repeat"], row["engine"]): row for row in records}
    slots = sorted({(row["case_id"], row["repeat"]) for row in records})
    pairs = []
    excluded = []
    for case_id, repeat in slots:
        procedure = indexed.get((case_id, repeat, "procedure_ai"))
        control = indexed.get((case_id, repeat, comparator))
        if procedure is None or control is None:
            excluded.append({"case_id": case_id, "repeat": repeat, "missing_engines": [engine for engine, row in (("procedure_ai", procedure), (comparator, control)) if row is None]})
        else:
            pairs.append({"case_id": case_id, "repeat": repeat, "procedure": procedure, "comparator": control})
    by_case = defaultdict(list)
    for pair in pairs:
        by_case[pair["case_id"]].append(pair)
    case_differences = []
    for case_id, rows in sorted(by_case.items()):
        case_differences.append({
            "case_id": case_id,
            "paired_repeat_ids": sorted(row["repeat"] for row in rows),
            "n_paired_repeats": len(rows),
            "procedure_mean_success": _mean([int(row["procedure"]["success"]) for row in rows]),
            "comparator_mean_success": _mean([int(row["comparator"]["success"]) for row in rows]),
            "success_difference": _mean([int(row["procedure"]["success"]) - int(row["comparator"]["success"]) for row in rows]),
            "incorrect_auto_difference": _mean([int(row["procedure"]["incorrect_auto"]) - int(row["comparator"]["incorrect_auto"]) for row in rows]),
        })
    success = [row["success_difference"] for row in case_differences]
    incorrect = [row["incorrect_auto_difference"] for row in case_differences]
    return {
        "procedure": "procedure_ai",
        "comparator": comparator,
        "difference_direction": "procedure_ai minus comparator; positive success is favorable, positive incorrect_auto is unfavorable",
        "n_cases": len(case_differences),
        "n_paired_case_repeats": len(pairs),
        "per_case": case_differences,
        "pairing": {
            "policy": "Intersect repeat IDs within each case; average paired repeat differences, then weight each included case equally. Failures stay paired observations with success false.",
            "complete": not excluded,
            "excluded_case_repeats": excluded,
            "excluded_count": len(excluded),
            "cases_with_no_paired_repeats": sorted({slot[0] for slot in slots} - set(by_case)),
            "repeat_zero_missing_case_ids": sorted({slot[0] for slot in slots} - {pair["case_id"] for pair in pairs if pair["repeat"] == 0}),
        },
        "success_difference": _bootstrap(success, random.Random(seed), resamples),
        "incorrect_auto_difference": _bootstrap(incorrect, random.Random(seed), resamples),
        "mcnemar": _exact_mcnemar(pairs),
    }


def _holm_and_claim_scope(comparisons, dataset):
    # The two success comparisons are predeclared. An unavailable test consumes
    # its family slot conservatively (p=1), rather than shrinking the family.
    ordered = sorted(comparisons, key=lambda key: (comparisons[key]["mcnemar"]["p_two_sided_exact"] if comparisons[key]["mcnemar"]["p_two_sided_exact"] is not None else 1.0, key))
    previous = 0.0
    for rank, key in enumerate(ordered):
        item = comparisons[key]
        test = item["mcnemar"]
        raw_p = test["p_two_sided_exact"]
        adjusted = max(previous, min(1.0, (len(COMPARATORS) - rank) * (raw_p if raw_p is not None else 1.0)))
        previous = adjusted
        test["p_holm"] = adjusted if raw_p is not None else None
        test["holm_family_size"] = len(COMPARATORS)
        test["reject_equal_success_holm_0_05"] = raw_p is not None and adjusted <= 0.05
        success_ci = item["success_difference"]["ci95"]
        safety_ci = item["incorrect_auto_difference"]["ci95"]
        success_supported = bool(success_ci is not None and success_ci["low"] > 0 and test["reject_equal_success_holm_0_05"])
        # An all-zero observed error contrast bootstraps to [0,0]. That is not
        # evidence of a zero true error rate or a proven no-harm difference.
        safety_informative = any(row["incorrect_auto_difference"] != 0 for row in item["per_case"])
        safety_supported = bool(safety_ci is not None and safety_ci["high"] <= 0 and safety_informative)
        item["claim_checks"] = {
            "success_ci_positive_and_repeat_zero_holm_significant": success_supported,
            "incorrect_auto_upper_ci_nonpositive_with_informative_contrast": safety_supported,
            "all_required_numerical_criteria_met": success_supported and safety_supported and item["pairing"]["complete"],
            "safety_status": "numerical_criterion_met" if safety_supported else "no_informative_error_contrast" if not safety_informative else "criterion_not_met_or_insufficient_cases",
            "complete_pairs_required": True,
            "superiority_claim": None,
            "external_superiority_established": False,
            "proof_scope": f"Only the supplied paired case clusters in dataset {dataset!r}. This function does not verify case independence, labels, predeclaration, sampling, a held-out split, identical model settings, or dataset provenance. No population, causal AI-value, or overall-best claim is established.",
        }


def paired_case_analysis(records, seed=DEFAULT_SEED, bootstrap_resamples=10000):
    """Return JSON-compatible descriptive statistics and bounded paired inference.

    Missing engine runs are disclosed, never silently scored as failures. Recorded
    failed runs *are* included as failures. Repeats share one case resampling unit;
    the success McNemar test deliberately uses only repeat 0. Intervals are
    unadjusted two-sided 95% percentile intervals; Holm adjusts the two success
    McNemar p-values within each dataset. No external superiority is inferred.
    """
    if type(seed) is not int:
        raise ValueError("seed must be an integer")
    if type(bootstrap_resamples) is not int or bootstrap_resamples < 1:
        raise ValueError("bootstrap_resamples must be a positive integer")
    clean = _validate(records)
    grouped = defaultdict(list)
    for record in clean:
        grouped[record["dataset"]].append(record)
    datasets = {}
    for dataset, rows in sorted(grouped.items()):
        comparisons = {}
        for comparator in COMPARATORS:
            derived_seed = int.from_bytes(hashlib.sha256(f"{seed}:{dataset}:{comparator}".encode()).digest()[:8], "big")
            comparisons[f"procedure_ai_vs_{comparator}"] = _comparison(rows, comparator, derived_seed, bootstrap_resamples)
        _holm_and_claim_scope(comparisons, dataset)
        datasets[dataset] = {
            "n_cases": len({row["case_id"] for row in rows}),
            "n_records": len(rows),
            "engines": {engine: _engine_summary([row for row in rows if row["engine"] == engine]) for engine in ENGINES},
            "comparisons": comparisons,
            "multiplicity": {"method": "Holm", "family": [f"procedure_ai_vs_{engine}:repeat_0_success" for engine in COMPARATORS], "alpha": 0.05, "scope": "within this dataset only; bootstrap intervals are not simultaneous"},
        }
    return {
        "version": 1,
        "method": {
            "seed": seed,
            "bootstrap_resamples": bootstrap_resamples,
            "resampling_unit": "case, retaining all its paired repeated runs",
            "case_weighting": "equal case weight within each dataset; repeats averaged within a case",
            "primary_endpoint": "supplied independently scored success flag; label validity is not verified here",
            "datasets_pooled": False,
            "references": dict(REFERENCES),
        },
        "datasets": datasets,
        "overall": {"pooled_analysis_performed": False, "superiority_claim": None, "reason": "Datasets may describe different tasks; they are analyzed separately."},
        "limitations": [
            "A missing record is distinct from a recorded failed attempt. Missing pairs are excluded and explicitly listed; completeness is required for numerical claim checks.",
            "More repeats do not create more independent cases. Case independence, representative sampling, fixed test data, and scoring quality require external evidence.",
            "Percentile bootstrap intervals can be unreliable with few cases or degenerate outcomes. A tied zero-error contrast does not prove noninferiority or absence of errors.",
            "The two success tests are Holm-adjusted within each dataset. Intervals and error contrasts are not simultaneous family-wise bounds; inspecting more datasets or endpoints requires additional predeclared control.",
            "Verification flags measure reported evidence checks, not independent correctness. Costs and missing token usage are not inferred.",
        ],
    }
