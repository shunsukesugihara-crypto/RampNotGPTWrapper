"""Freeze controlled single-field masks of genuine published CEAP records.

The hidden oracle is the unchanged published CSV amount, converted exactly to
integer cents. This is an expense-arithmetic experiment, not a retail-shortage
or independently settled bank-payment benchmark. No model is called here.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
import csv
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, localcontext
from hashlib import sha256
import io
import json
from pathlib import Path
import re
from zipfile import ZipFile


FIELDS = ("vlrDocumento", "vlrGlosa", "vlrLiquido")
SOURCE_URL = "https://www.camara.leg.br/cotas/Ano-2024.csv.zip"
DICTIONARY_URL = "https://dadosabertos.camara.leg.br/howtouse/2023-12-26-dados-ceap.html"
POLICY_URL = "https://dadosabertos.camara.leg.br/howtouse/sobre-dados-abertos.html"
MASK_REASON = "controlled one-field missingness in real published expense records"
SCHEMA_FIELDS = (
    "txNomeParlamentar", "cpf", "ideCadastro", "nuCarteiraParlamentar", "nuLegislatura",
    "sgUF", "sgPartido", "codLegislatura", "numSubCota", "txtDescricao",
    "numEspecificacaoSubCota", "txtDescricaoEspecificacao", "txtFornecedor", "txtCNPJCPF",
    "txtNumero", "indTipoDocumento", "datEmissao", "vlrDocumento", "vlrGlosa",
    "vlrLiquido", "numMes", "numAno", "numParcela", "txtPassageiro", "txtTrecho",
    "numLote", "numRessarcimento", "datPagamentoRestituicao", "vlrRestituicao",
    "nuDeputadoId", "ideDocumento", "urlDocumento",
)


def amount_cents(value: str) -> int:
    """Parse the publisher's decimal-point cell syntax without rounding."""
    if type(value) is not str or not re.fullmatch(r"[+-]?[0-9]+(?:\.[0-9]+)?", value):
        raise ValueError("CEAP amount must be an original decimal-point string")
    try:
        with localcontext() as context:
            context.prec = max(28, len(value) + 4)
            amount = Decimal(value) * 100
    except InvalidOperation as exc:
        raise ValueError("Malformed source amount") from exc
    if not amount.is_finite() or amount != amount.to_integral_value():
        raise ValueError("Source amount cannot be represented as exact cents")
    return int(amount)


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def _read_json(path):
    def bad_constant(value):
        raise ValueError(f"Nonfinite JSON value: {value}")
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_object, parse_constant=bad_constant)


def _read_jsonl(path):
    if path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Bounded pilot JSONL is too large")
    return [json.loads(line, object_pairs_hook=_object) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _digest(path):
    return sha256(path.read_bytes()).hexdigest()


def _frozen_sources(source_dir):
    source_dir = Path(source_dir).resolve()
    freeze = _read_json(source_dir / "source_freeze.json")
    if not isinstance(freeze.get("files"), dict) or not freeze["files"]:
        raise ValueError("Missing CEAP source freeze")
    for relative, expected in freeze["files"].items():
        path = source_dir / relative
        if not isinstance(relative, str) or path.is_symlink() or not path.resolve().is_relative_to(source_dir):
            raise ValueError("Source freeze path escape")
        if not path.is_file() or _digest(path) != expected:
            raise ValueError(f"Frozen source changed: {relative}")
    audit = _read_json(source_dir / "sample_audit.json")
    if audit.get("passed") is not True:
        raise ValueError("Independent source-cell audit has not passed")
    prefix = (source_dir / "source_prefix_300.csv").read_bytes()
    rows = list(csv.DictReader(io.StringIO(prefix.decode("utf-8-sig"), newline=""), delimiter=";", strict=True))
    archive = source_dir / "Ano-2024.csv.zip"
    with ZipFile(archive) as z:
        with z.open("Ano-2024.csv") as stream:
            if stream.read(len(prefix)) != prefix:
                raise ValueError("Sample is not an exact annual-source prefix")
    saved = _read_jsonl(source_dir / "sample_records.jsonl")
    if rows != saved or len(rows) != 300:
        raise ValueError("Source record extraction disagreement")
    for row in rows:
        if tuple(row) != SCHEMA_FIELDS or any(type(value) is not str for value in row.values()):
            raise ValueError("Unexpected original 32-field source schema")
        gross, glosa, net = (amount_cents(row[field]) for field in FIELDS)
        if gross - glosa != net:
            raise ValueError("Published financial relation does not hold; do not repair the source")
    return rows, {"directory": str(source_dir), "dataset_url": SOURCE_URL,
                  "archive_sha256": _digest(archive), "prefix_sha256": sha256(prefix).hexdigest(),
                  "source_freeze_sha256": _digest(source_dir / "source_freeze.json"),
                  "sample_records_sha256": _digest(source_dir / "sample_records.jsonl")}


def _select(rows):
    """Predeclared source-order strata, disjoint by original document identity."""
    selected, used = [], set()
    for target, positive_only in (("vlrDocumento", True), ("vlrLiquido", True), ("vlrGlosa", False)):
        group = []
        for index, row in enumerate(rows):
            identity = row["ideDocumento"]
            if not identity or identity in used:
                continue
            if positive_only and amount_cents(row["vlrGlosa"]) <= 0:
                continue
            group.append((index, row, target))
            used.add(identity)
            if len(group) == 4:
                break
        if len(group) != 4:
            raise ValueError("Not enough genuine source records for the predeclared strata")
        selected.extend(group)
    return selected


def _dump_jsonl(path, rows):
    path.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def build_corpus(source_dir: Path, destination: Path) -> dict:
    """Build exactly 12 predeclared masks once, before observing model outputs."""
    rows, source = _frozen_sources(source_dir)
    destination = Path(destination)
    if destination.exists():
        raise FileExistsError("Do not overwrite a frozen CEAP experiment corpus")
    cases, labels, selection = [], [], []
    for ordinal, (index, row, target) in enumerate(_select(rows), 1):
        case_id = f"CEAP-{ordinal:03d}"
        observed = deepcopy(row)
        observed[target] = None
        cases.append({"version": 1, "case_id": case_id, "dataset": "ceap",
                      "task": {"kind": "document_adjustment", "target_path": [target]},
                      "observed": observed,
                      "source": {"dataset_url": SOURCE_URL, "record_id": row["ideDocumento"],
                                 "sha256": source["archive_sha256"],
                                 "citation": "Câmara dos Deputados, CEAP 2024, original annual expense CSV; documented amount relation in official field dictionary"},
                      "masking": {"removed_paths": [[target]], "reason": MASK_REASON}})
        labels.append({"case_id": case_id, "expected_value": amount_cents(row[target]),
                       "expected_status": "recovered",
                       "observability_reason": "Official dictionary defines vlrLiquido = vlrDocumento - vlrGlosa. Exactly one amount is hidden; the other two original amounts uniquely establish it in integer cents. Oracle is the unchanged published hidden value."})
        selection.append({"case_id": case_id, "source_record_index": index,
                          "source_document_id": row["ideDocumento"], "target_path": [target]})
    destination.mkdir(parents=True)
    _dump_jsonl(destination / "cases.jsonl", cases)
    _dump_jsonl(destination / "labels.jsonl", labels)
    manifest = {
        "version": 1, "dataset": "ceap", "task_kind": "document_adjustment", "case_count": 12,
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "files": {name: _digest(destination / name) for name in ("cases.jsonl", "labels.jsonl")},
        "source": source, "field_dictionary_url": DICTIONARY_URL, "source_policy_url": POLICY_URL,
        "sampling": "Stratified nonrandom pilot from a single-office 300-record publisher-order prefix: first 4 positive-glosa document IDs hide gross; next 4 positive-glosa IDs hide net; first 4 remaining IDs hide glosa. All 12 document IDs are distinct.",
        "selection": selection, "source_column_count": len(SCHEMA_FIELDS),
        "target_counts": dict(Counter(case["task"]["target_path"][0] for case in cases)),
        "observed_cell_convention": "Original CSV strings unchanged, including blanks; only the one declared target becomes JSON null. Source amounts use decimal points with variable precision.",
        "oracle_unit": "integer cents, exact Decimal conversion of original hidden published value; no rounding",
        "original_financial_values_generated": False, "missingness_is_controlled": True,
        "pdf_text_or_oracle_copy_supplied_to_models": False, "model_network_tools_required": False,
        "model_calls_before_freeze": 0,
        "limitations": ["Expense amount arithmetic only; no retail shipment-shortage accuracy claim", "Controlled masking does not establish performance on naturally missing information", "All selected records come from one parliamentary leadership office and are not representative", "Published net allowance charges are not independent bank settlement proof", "The inspected PDFs are not experiment inputs; original PDF contradictions and inaccessible invoice details remain documented in source audit", "No evidence of an AI accuracy advantage is supplied by creating this corpus"],
    }
    (destination / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    load_corpus(destination)
    return manifest


def load_corpus(folder: Path):
    """Validate frozen bytes and masks; return cases, separate oracle labels, manifest."""
    folder = Path(folder).resolve()
    manifest = _read_json(folder / "manifest.json")
    if manifest.get("version") != 1 or manifest.get("dataset") != "ceap" or manifest.get("case_count") != 12:
        raise ValueError("Unsupported CEAP corpus manifest")
    files = manifest.get("files")
    if not isinstance(files, dict) or set(files) != {"cases.jsonl", "labels.jsonl"}:
        raise ValueError("Unexpected corpus files")
    for name, expected in files.items():
        path = folder / name
        if path.is_symlink() or not path.is_file() or _digest(path) != expected:
            raise ValueError("Frozen corpus file changed")
    cases = _read_jsonl(folder / "cases.jsonl")
    label_rows = _read_jsonl(folder / "labels.jsonl")
    if len(cases) != 12 or len(label_rows) != 12:
        raise ValueError("CEAP corpus must contain 12 cases and labels")
    labels = {row.get("case_id"): row for row in label_rows}
    if len(labels) != 12:
        raise ValueError("Duplicate label identity")
    identities, case_ids = set(), set()
    for case in cases:
        if set(case) != {"version", "case_id", "dataset", "task", "observed", "source", "masking"} or case["version"] != 1 or case["dataset"] != "ceap":
            raise ValueError("Unexpected CEAP case fields")
        case_id = case["case_id"]
        if case_id in case_ids or case_id not in labels:
            raise ValueError("Duplicate/missing case identity")
        case_ids.add(case_id)
        task = case["task"]
        if set(task) != {"kind", "target_path"} or task["kind"] != "document_adjustment" or not isinstance(task["target_path"], list) or len(task["target_path"]) != 1 or task["target_path"][0] not in FIELDS:
            raise ValueError("Unexpected typed task")
        target = task["target_path"][0]
        observed = case["observed"]
        if set(observed) != set(SCHEMA_FIELDS) or observed[target] is not None or any(type(value) is not str for field, value in observed.items() if field != target):
            raise ValueError("The one declared target must be the only masked source cell")
        if case["masking"] != {"removed_paths": [[target]], "reason": MASK_REASON}:
            raise ValueError("Mask declaration disagreement")
        source = case["source"]
        if set(source) != {"dataset_url", "record_id", "sha256", "citation"} or source["dataset_url"] != SOURCE_URL or source["record_id"] != observed["ideDocumento"] or source["sha256"] != manifest["source"]["archive_sha256"]:
            raise ValueError("Case source provenance disagreement")
        if not source["record_id"] or source["record_id"] in identities:
            raise ValueError("Source document identities must be distinct")
        identities.add(source["record_id"])
        label = labels[case_id]
        if set(label) != {"case_id", "expected_value", "expected_status", "observability_reason"} or type(label["expected_value"]) is not int or label["expected_status"] != "recovered":
            raise ValueError("Unexpected separate oracle label")
        values = {field: amount_cents(observed[field]) for field in FIELDS if field != target}
        values[target] = label["expected_value"]
        if values["vlrDocumento"] - values["vlrGlosa"] != values["vlrLiquido"]:
            raise ValueError("Oracle disagrees with documented source relation")
    if Counter(case["task"]["target_path"][0] for case in cases) != Counter({field: 4 for field in FIELDS}):
        raise ValueError("Predeclared target strata changed")
    return cases, labels, manifest
