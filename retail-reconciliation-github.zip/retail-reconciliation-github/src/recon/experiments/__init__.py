"""Evaluation utilities; these do not run reconciliation or model inference."""
