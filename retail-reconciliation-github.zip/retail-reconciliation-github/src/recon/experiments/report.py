"""Standalone, escaped experiment reports showing evidence rather than thoughts."""
from collections import defaultdict
from html import escape
import json
from pathlib import Path
from urllib.parse import urlparse


ENGINE_NAMES = {"no_ai": "No AI: deterministic tools", "direct_ai": "Direct AI: final answer", "procedure_ai": "Procedure AI: tool selection"}
DATASET_NAMES = {"cord": "CORD — primary receipt reconstruction", "cord_extra_redaction": "CORD — additional redaction checks", "ceap": "CEAP — expense-field reconstruction"}
FILES = {"cord": "cord.html", "cord_extra_redaction": "cord_extra_redaction.html", "ceap": "ceap.html"}


def _text(value):
    return escape(str(value), quote=True)


def _json(value):
    return '<pre>' + _text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)) + '</pre>'


def _link(value, label=None):
    if not isinstance(value, str):
        return _text(value)
    parsed = urlparse(value)
    if parsed.scheme in ("https", "http") and parsed.netloc:
        return '<a href="' + _text(value) + '" rel="noreferrer">' + _text(label or value) + '</a>'
    return _text(label or value)


def _percentage(value):
    return "unavailable" if value is None else f"{value * 100:.1f}%"


def _number(value):
    return "unknown" if value is None else f"{value:,}" if isinstance(value, int) else f"{value:,.1f}"


def _path(path):
    if not isinstance(path, (tuple, list)):
        return str(path)
    text = ""
    for part in path:
        text += f"[{part}]" if type(part) is int else ("." if text else "") + str(part)
    return text


REASONS = {
    "printed_integer_grouping": "Removed documented thousands separators from a printed integer amount.",
    "equal_repeated_printed_integer_grouping": "Decoded repeated printed amounts and confirmed that every copy agrees.",
    "documented_count_decoration": "Removed documented count decorations such as X or an unmatched opening parenthesis.",
    "publisher_decimal_to_integer_cents": "Converted the original decimal-point money string to exact integer cents without rounding.",
    "explicit_percentage_to_exact_ratio": "Converted an explicitly printed percentage into an exact fraction.",
    "independently_reconstructed_from_observed_evidence": "A separate code path reconstructed the same value from retained source fields and checked the executed equations.",
    "conflicting_observed_relations": "The retained source relations disagree. The case requires human review.",
    "insufficient_observed_evidence": "The retained fields do not determine one reliable value. The case requires human review.",
    "no_complete_selected_calculation": "The selected operations did not produce a complete supported calculation.",
    "unverified_direct_model_answer": "The model supplied a final answer. This baseline performs no independent computational verification.",
    "model_requested_review": "The model explicitly requested human review instead of asserting a value.",
    "fixed_policy_requested_review": "The deterministic policy returned the unresolved case for human review.",
    "direct_model_failed": "The direct-answer model request failed. No answer is credited.",
    "method_execution_failed": "A model request or operation failed. No answer is credited.",
    "method_step_limit": "The method did not finish within the frozen operation budget. This is counted as a failed attempt.",
    "provider_unavailable": "The configured model provider was unavailable. No offline replacement was used.",
    "zero_effective_price_does_not_identify_quantity": "A zero effective price cannot identify quantity; for example, a full discount makes every quantity produce the same zero amount.",
    "aggregate_quantity_not_observed": "No aggregate item quantity was recorded, so subtraction cannot recover this count.",
    "unclassified_other_tender": "Another payment amount is present, but its printed meaning has not been established.",
    "missing_other_tender": "Another declared payment component is missing; it cannot be assumed to be zero.",
    "missing_unit_or_line_amount": "The unit price or extended line amount needed for the quantity equation is missing.",
    "multiple_tenders_require_full_balance": "Several payment types are recorded, so cash minus change alone is incomplete.",
}


def _reason(value):
    if not value:
        return "No further reason was recorded."
    return REASONS.get(value, str(value).replace("_", " "))


def _observed_conclusion(report, dataset):
    engines = report.get("statistics", {}).get("datasets", {}).get(dataset, {}).get("engines", {})
    active = [(engine, item) for engine, item in engines.items() if item.get("n_records")]
    scores = [item["rates"]["success"] for _, item in active]
    sentences = [f'{ENGINE_NAMES[engine]}: {item["counts"]["success"]}/{item["n_records"]} correct outcomes, {item["counts"]["incorrect_auto"]} wrong or unjustified automatic answers, {item["counts"]["failed"]} failures.' for engine, item in active]
    interpretation = "All observed success rates are tied; this pilot supplies no observed accuracy advantage for AI method selection." if len(scores) == 3 and len(set(scores)) == 1 else "These are observed scores on selected pilot cases. They do not establish a population winner or that AI selection caused a difference."
    return '<p><strong>' + _text(DATASET_NAMES.get(dataset, dataset)) + '.</strong> ' + _text(' '.join(sentences)) + ' ' + _text(interpretation) + '</p>'


def _outcome_table(attempts):
    repeats = sorted({row["repeat"] for row in attempts})
    indexed = {(row["engine"], row["repeat"]): row for row in attempts}
    body = []
    for engine, name in ENGINE_NAMES.items():
        cells = ['<th>' + _text(name) + '</th>']
        for repeat in repeats:
            row = indexed.get((engine, repeat))
            if row is None:
                cells.append('<td>Not run</td>')
                continue
            result, score = row["result"], row["evaluation"]
            outcome = "Correct outcome" if score["success"] else "Failed" if score["failed"] else "Wrong / unjustified auto" if score["incorrect_auto"] else "Review of recoverable field"
            cells.append('<td><strong>' + _text(outcome) + '</strong><br>' + _text(result["status"]) + '; value ' + _text(result.get("value")) + '<br>' + _number(row["runtime_ms"]) + ' ms; ' + _text(row["provider_audit"]["provider_attempts"]) + ' provider calls</td>')
        body.append('<tr>' + ''.join(cells) + '</tr>')
    return '<div class="scroll"><table><thead><tr><th>Method</th>' + ''.join('<th>Repeat ' + _text(repeat) + '</th>' for repeat in repeats) + '</tr></thead><tbody>' + ''.join(body) + '</tbody></table></div>'


def _normalization_table(normalizations):
    if not normalizations:
        return '<p>No code-based source normalization was executed by this method.</p>'
    rows = []
    for item in normalizations:
        values = (_path(item.get("path")), json.dumps(item.get("raw"), ensure_ascii=False), item.get("value"), _reason(item.get("rule")))
        rows.append('<tr>' + ''.join('<td>' + _text(value) + '</td>' for value in values) + '</tr>')
    return '<div class="scroll"><table><thead><tr><th>Source field</th><th>Original text</th><th>Exact value</th><th>Conversion rule</th></tr></thead><tbody>' + ''.join(rows) + '</tbody></table></div>'


def _equations(equations):
    rows = []
    for equation in equations:
        expression = equation.get("expression", "")
        if equation.get("complete") and "=" not in expression:
            expression += ' = ' + str(equation.get("value"))
        description = '<code>' + _text(expression) + '</code>' if expression else _text(_reason(equation.get("reason")))
        evidence = ', '.join(_path(path) for path in equation.get("evidence", [])) or "No supporting field recorded"
        rows.append('<li>' + description + '<br><span class="muted">Source fields: ' + _text(evidence) + '. ' + ("Complete equation." if equation.get("complete") else "Incomplete: " + _text(_reason(equation.get("reason")))) + '</span></li>')
    return '<ul class="equations">' + ''.join(rows) + '</ul>' if rows else '<p>No executed arithmetic equation was recorded.</p>'


def _executed_steps(row):
    result = row["result"]
    descriptions = {
        "normalize_observed_fields": "Converted original printed amounts and counts into exact integers using the declared dataset format. Original tokens are retained in the table below.",
        "sum_item_amounts": "Added the recorded extended line amounts and any nested add-ons. CORD menu.price already includes quantity; multiplying it by quantity again would double count.",
        "solve_cash_change": "Tried cash received minus change. Other recorded payment types must also be accounted for before this can establish a total.",
        "solve_tender_balance": "Combined the observed payment components and subtracted change, using only established meanings for each component.",
        "derive_total_from_document": "Combined the recorded subtotal with explicit tax, service and discount fields. Missing components were not assigned invented zero values.",
        "derive_quantity_from_price": "Tried an exact quantity equation from unit price, extended amount and any explicit percentage discount.",
        "derive_quantity_from_count": "Used the printed aggregate item count minus all other recorded item counts as an alternative quantity equation.",
        "apply_document_adjustment_identity": "Applied the documented CEAP identity: gross amount minus disallowance equals the net allowance charge, using exact cents.",
        "verify_reconstruction": "A separate checker reparsed the retained observations and compared all supported relations with the selected calculations. It did not read the hidden publisher answer.",
    }
    if row["engine"] == "direct_ai":
        return '<ol><li>Sent the same masked observed record to the shared model and accepted its structured final answer or review decision. This baseline ran no calculator, financial executor, verifier or repair step.</li></ol>'
    steps = []
    for trace in result.get("trace", []):
        operation = trace.get("operation")
        observation = trace.get("observation", {})
        if operation == "classify_tender_labels":
            labels = row["observed_input"].get("field_labels", {}).get("total.total_etc", [])
            description = "Checked the actual printed payment key " + repr(', '.join(labels)) + ". " + ("Its Coupon/Voucher meaning was recognized as another tender." if observation.get("coupon_label_classified") else "No supported Coupon/Voucher meaning was established.")
        else:
            description = descriptions.get(operation, str(operation).replace("_", " "))
        issues = observation.get("equation_issue_codes", [])
        if operation == "derive_quantity_from_price" and "zero_effective_price_does_not_identify_quantity" in issues:
            description += " The observed effective price was zero, so this equation could not identify quantity."
        elif operation == "derive_quantity_from_count" and "zero_effective_price_does_not_identify_quantity" in issues:
            description += " This supplies a different method after the price equation could not identify quantity."
        checked = trace.get("verification")
        if checked:
            description += ' ' + _reason(checked.get("reason"))
        steps.append('<li>' + _text(description) + '</li>')
    if any(decision.get("action") == "request_review" for decision in result.get("planning_decisions", [])):
        steps.append('<li>Requested human review without asserting a missing numeric value.</li>')
    return '<ol>' + ''.join(steps) + '</ol>' if steps else '<p>No completed computational operation was recorded.</p>'


def _source_study(report):
    audits = {audit["path"]: audit["data"] for audit in report.get("source_audits", [])}
    uci = next((value for path, value in audits.items() if path.endswith("uci_online_retail/quality_audit.json")), None)
    ceap = next((value for path, value in audits.items() if path.endswith("ceap/data_source_profile.json")), None)
    ceap_arithmetic = next((value for path, value in audits.items() if path.endswith("ceap/arithmetic_audit.json")), {})
    result = '<ul>'
    if uci:
        result += '<li><strong>UCI Online Retail:</strong> ' + _link(uci.get("source_url"), "authentic retail invoice data") + ' contains ' + _number(uci.get("row_count")) + ' rows. The audit found ' + _number(uci.get("missing_values", {}).get("CustomerID")) + ' missing customer identifiers, ' + _number(uci.get("exact_duplicate_excess_rows")) + ' excess exact duplicate rows and ' + _number(uci.get("stock_codes_with_multiple_description_strings")) + ' stock codes with multiple description strings. These are observed flags, not automatically declared errors. The data lacks receiving records and deduction-allocation truth, so it is a source-quality study, not part of reconstruction accuracy.</li>'
    if ceap:
        result += '<li><strong>CEAP:</strong> ' + _link(ceap.get("source_url"), "official published expense records") + ' supplied a publisher-order prefix of ' + _number(ceap.get("sample_count")) + ' real records from one office. ' + _number(ceap.get("positive_disallowance_count")) + ' contain positive disallowances; the documented gross-minus-disallowance identity holds in all ' + _number(ceap_arithmetic.get("holds")) + ' audited records. Twelve distinct document records are used for controlled one-field masking. Net allowance charges are not independent bank-settlement proof.</li>'
    cord = next((corpus.get("manifest", {}) for corpus in report["protocol"].get("corpora", []) if corpus.get("manifest", {}).get("dataset") == "cord"), None)
    if cord:
        result += '<li><strong>CORD:</strong> ' + _link("https://huggingface.co/datasets/naver-clova-ix/cord-v2", "publisher receipt annotations") + ' were acquired for 20 actual publisher test records. The frozen pilot has ' + _number(cord.get("genuine_single_target_masks", 12)) + ' tasks on distinct receipts and ' + _number(cord.get("controlled_additional_redactions", 2)) + ' additional redaction checks. The hidden answers come from original annotations. This supplies real values with artificial missingness; it does not measure raw optical character recognition or natural missing-data frequency.</li>'
    return result + '</ul>'


def _summary(report, dataset):
    analysis = report.get("statistics", {}).get("datasets", {}).get(dataset, {})
    rows = []
    for engine, name in ENGINE_NAMES.items():
        item = analysis.get("engines", {}).get(engine, {})
        counts, rates, resources = item.get("counts", {}), item.get("rates", {}), item.get("resources", {})
        row = [name, item.get("n_cases", 0), item.get("n_records", 0), f'{counts.get("success", 0)} ({_percentage(rates.get("success"))})',
               counts.get("incorrect_auto", 0), counts.get("auto", 0), counts.get("completed_review", 0), counts.get("failed", 0),
               counts.get("verified", 0), _number(resources.get("runtime_ms", {}).get("total")), resources.get("model_calls", {}).get("total", 0),
               _number(resources.get("input_tokens", {}).get("total")), _number(resources.get("output_tokens", {}).get("total"))]
        rows.append('<tr>' + ''.join('<td>' + _text(value) + '</td>' for value in row) + '</tr>')
    headers = ("Method", "Cases", "Attempts", "Correct outcomes", "Wrong/unjustified auto", "Automatic", "Completed reviews", "Failed", "Evidence checked", "Runtime ms", "Provider attempts", "Input tokens", "Output tokens")
    return '<div class="scroll"><table><thead><tr>' + ''.join('<th>' + _text(header) + '</th>' for header in headers) + '</tr></thead><tbody>' + ''.join(rows) + '</tbody></table></div>'


def _comparisons(report, dataset):
    comparisons = report.get("statistics", {}).get("datasets", {}).get(dataset, {}).get("comparisons", {})
    rows = []
    for item in comparisons.values():
        success, safety, test = item["success_difference"], item["incorrect_auto_difference"], item["mcnemar"]
        def interval(metric):
            ci = metric.get("ci95")
            return "insufficient cases" if ci is None else f'{ci["low"] * 100:.1f} to {ci["high"] * 100:.1f} pp'
        values = [ENGINE_NAMES[item["comparator"]], item["n_cases"], item["n_paired_case_repeats"],
                  "unavailable" if success["estimate"] is None else f'{success["estimate"] * 100:.1f} pp', interval(success), interval(safety),
                  f'{test["b"]}/{test["c"]}', "unavailable" if test["p_two_sided_exact"] is None else f'{test["p_two_sided_exact"]:.6g}',
                  "unavailable" if test["p_holm"] is None else f'{test["p_holm"]:.6g}',
                  item["pairing"]["excluded_count"]]
        rows.append('<tr>' + ''.join('<td>' + _text(value) + '</td>' for value in values) + '</tr>')
    headers = ("Procedure AI versus", "Paired cases", "Paired repeats", "Success difference", "95% interval", "Error difference 95% interval", "McNemar b/c", "Exact p", "Holm p", "Excluded pairs")
    return '<div class="scroll"><table><thead><tr>' + ''.join('<th>' + _text(header) + '</th>' for header in headers) + '</tr></thead><tbody>' + ''.join(rows) + '</tbody></table></div><p>pp = percentage points. Differences are procedure AI minus the comparator. Repeats are averaged inside each case; the bootstrap resamples whole cases. McNemar uses only repeat 0. Intervals are two-sided percentile intervals, not simultaneous bounds. A tied zero-error interval does not prove safety. No overall winner is inferred.</p>'


def _case_audits(report, dataset):
    cases = defaultdict(list)
    for row in report["results"]:
        if row["dataset"] == dataset:
            cases[row["case_id"]].append(row)
    content = []
    for case_id, attempts in sorted(cases.items()):
        original = attempts[0]
        source = original.get("source", {})
        case = '<details class="case"><summary>' + _text(case_id) + ' · source ' + _text(source.get("record_id")) + '</summary>'
        case += '<p>Publisher: ' + _link(source.get("dataset_url")) + '. Source digest: <code>' + _text(source.get("sha256")) + '</code>.</p>'
        task = original["observed_input"].get("task", {})
        case += '<p><strong>Missing field:</strong> <code>' + _text(_path(task.get("target_path", []))) + '</code>. Only the retained observations below are available to each method. The original hidden value is revealed only in the scoring section.</p>'
        case += _outcome_table(attempts)
        case += '<details><summary>Observed input shared by every method</summary>' + _json(original["observed_input"]) + '</details>'
        for row in sorted(attempts, key=lambda value: (value["repeat"], tuple(ENGINE_NAMES).index(value["engine"]))):
            result, score = row["result"], row["evaluation"]
            outcome = "correct outcome" if score["success"] else "failed attempt" if score["failed"] else "wrong or unjustified automatic answer" if score["incorrect_auto"] else "unresolved recoverable field"
            case += '<article><h4>Repeat ' + _text(row["repeat"]) + ' · ' + _text(ENGINE_NAMES[row["engine"]]) + '</h4>'
            case += '<p><strong>' + _text(result["status"]) + '</strong> · value ' + _text(result.get("value")) + ' · ' + _text(outcome) + ' · ' + _number(row["runtime_ms"]) + ' ms</p>'
            case += '<p>' + _text(_reason(result.get("reason"))) + '</p>'
            case += '<h5>Numbered operations actually executed</h5>' + _executed_steps(row)
            equations = result.get("equations", [])
            if equations:
                case += '<h5>Executed equations and supporting fields</h5>' + _equations(equations)
            case += '<h5>Source normalization: before → after</h5>' + _normalization_table(result.get("normalizations", []))
            case += '<details><summary>Operations actually executed</summary>' + _json(result.get("trace", [])) + '</details>'
            case += '<details><summary>Normalizations of source values</summary>' + _json(result.get("normalizations", [])) + '</details>'
            decisions = [{key: decision.get(key) for key in ("step", "action", "audit", "observation_before", "observation")} for decision in result.get("planning_decisions", [])]
            case += '<details><summary>Structured action decisions and tool observations</summary>' + _json(decisions) + '</details>'
            case += '<details><summary>Verification, provider usage, and output audit</summary>' + _json({"verification": result.get("verification"), "provider_audit": row.get("provider_audit"), "provider_attempts": row.get("provider_attempts"), "resource_usage": row.get("resource_usage"), "model_call_audit_agrees": row.get("model_call_audit_agrees")}) + '</details>'
            case += '<details><summary>Hidden-label evaluation revealed after execution</summary>' + _json(score) + '</details></article>'
        content.append(case + '</details>')
    return ''.join(content)


def render_html(report, dataset=None):
    """Render one dataset or a master report; no scripts or external assets."""
    available = report.get("statistics", {}).get("datasets", {})
    if dataset is not None and dataset not in available:
        raise ValueError("Dataset does not occur in this report")
    selected = [dataset] if dataset is not None else list(available)
    title = DATASET_NAMES.get(dataset, "Public financial-field reconstruction pilot")
    protocol, metadata = report["protocol"], report["run_metadata"]
    content = '<header><p class="eyebrow">Exploratory experiment · authentic source values · controlled missingness</p><h1>' + _text(title) + '</h1><p>Run <code>' + _text(metadata["run_id"]) + '</code> · ' + _text(metadata.get("started_at")) + '</p></header>'
    content += '<section><h2>Observed result</h2>' + ''.join(_observed_conclusion(report, name) for name in selected) + '</section>'
    content += '<section><h2>Scope and data</h2><p>This experiment reconstructs deliberately hidden numeric fields in published CORD receipt annotations and CEAP expense records. It does not test retail shipment-shortage reconciliation, raw document parsing, or independently confirmed payment transactions. Correct outcomes require both the right value and sufficient retained evidence; a lucky answer on an evidence-insufficient case is an unjustified automatic result.</p>'
    if dataset is None:
        content += '<ul>' + ''.join('<li><a href="' + FILES[name] + '">' + _text(DATASET_NAMES[name]) + '</a> · ' + _text(protocol["selection_counts"].get(name, 0)) + ' distinct source cases</li>' for name in selected) + '</ul>'
    else:
        content += '<p><a href="report.html">Master report and all source audits</a></p>'
    content += '<p>CORD integers preserve printed monetary units or item counts. CEAP monetary values are exact integer cents. The two additional CORD redaction cases share source receipts with the primary set and are kept in a separate analysis.</p></section>'
    content += '<section><h2>Methods and frozen protocol</h2><ol><li><strong>No AI:</strong> ordinary code runs the approved operations deterministically.</li><li><strong>Direct AI:</strong> the shared model returns a final value or review decision from the same observed facts.</li><li><strong>Procedure AI:</strong> the shared model selects typed approved operations; ordinary code computes and verifies any recovered value.</li></ol><p>The selection, randomized AI-method order, labels’ digests, source digests, prompts, schemas and engine files were frozen before requests. Every selected case has ' + _text(protocol["repeats"]) + ' scheduled repeats. Failed attempts remain in denominators. No selective retries or replacement cases are used. Repeats do not increase the independent case count.</p>'
    content += '<details><summary>Protocol and provider configuration</summary>' + _json({"protocol": protocol, "provider_configuration": report.get("provider_configuration")}) + '</details></section>'
    for name in selected:
        content += '<section><h2>' + _text(DATASET_NAMES.get(name, name)) + '</h2>' + _summary(report, name)
        content += '<p>“Correct outcomes” includes appropriate review of evidence-insufficient cases. “Wrong/unjustified auto” counts incorrect values and unsupported guesses. “Evidence checked” reports the method’s independent arithmetic check flag; it is not independent bank or warehouse evidence. All failure and usage counts are retained; unknown token totals are not zero. Runtime includes provider waiting time.</p><h3>Paired analysis</h3>' + _comparisons(report, name)
        content += '<h3>Case audit: inputs → operations → equations → verification → scoring</h3>' + _case_audits(report, name) + '</section>'
    content += '<section><h2>Source authenticity and audit evidence</h2><p>These acquisition and quality audits describe actual published source artifacts. Their row counts and arithmetic checks are not reconciliation-accuracy observations and are not pooled into the experiment’s case scores.</p>'
    content += _source_study(report)
    for corpus in protocol.get("corpora", []):
        content += '<details><summary>Frozen corpus: ' + _text(corpus["path"]) + '</summary>' + _json(corpus.get("manifest")) + '</details>'
    for audit in report.get("source_audits", []):
        content += '<details><summary>' + _text(audit["path"]) + ' · SHA-256 ' + _text(audit["sha256"]) + '</summary>' + _json(audit["data"]) + '</details>'
    content += '</section><section><h2>Integrity, limitations, and interpretation</h2>' + _json({"freeze_checks": report.get("freeze_checks"), "provider_audit": report.get("provider_audit")})
    content += '<ul>' + ''.join('<li>' + _text(value) + '</li>' for value in report.get("limitations", [])) + '</ul>'
    content += '<p>A better score on these inspected pilot cases would describe these cases only. It would not establish that AI is generally better, that model-selected methods caused a gain, or that the original retail application works on real deductions. An all-tools tie is meaningful evidence that operator coverage, rather than AI selection, may explain recovery.</p>'
    references = report.get("statistics", {}).get("method", {}).get("references", {})
    content += '<h3>Statistical method references</h3><ul>' + ''.join('<li>' + _link(url, name.replace("_", " ")) + '</li>' for name, url in references.items()) + '</ul></section>'
    css = 'body{margin:0;color:#17202a;background:#fff;font:16px/1.55 Georgia,serif}main{max-width:1160px;margin:48px auto;padding:0 26px}h1{font-size:38px;line-height:1.15}h2{font-size:25px;margin-top:38px}h3{font-size:20px}h4{font:600 16px system-ui;margin-bottom:8px}h5{font-size:16px;margin-bottom:5px}header{border-bottom:3px solid #17202a;padding-bottom:20px}.eyebrow{font:12px system-ui;text-transform:uppercase;letter-spacing:.1em;color:#586474}p{max-width:100ch}a{color:#075a90}code,pre{font:12px/1.5 ui-monospace,monospace}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f5f6f8;padding:14px;border:1px solid #e0e3e7}summary{cursor:pointer;font:14px/1.5 system-ui;padding:8px 0}details{margin:8px 0}details.case{border-top:1px solid #bac2cb;padding:7px 0}article{border-left:3px solid #d5dce4;margin:14px 0;padding:0 16px}.scroll{overflow-x:auto}table{border-collapse:collapse;font:12px/1.45 system-ui;width:100%}th,td{border-bottom:1px solid #d5dce4;text-align:left;padding:9px;vertical-align:top}th{background:#f0f3f6}li{margin:6px 0}@media print{main{margin:0;max-width:none}details{display:block}summary{font-weight:bold}pre{font-size:9px}a{color:inherit}}'
    return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'"><title>' + _text(title) + '</title><style>' + css + '</style></head><body><main>' + content + '</main></body></html>'


def write_reports(report, folder):
    folder = Path(folder)
    (folder / "report.html").write_text(render_html(report))
    datasets = {}
    for dataset in report.get("statistics", {}).get("datasets", {}):
        if dataset not in FILES:
            raise ValueError("Unexpected dataset name")
        name = FILES[dataset]
        (folder / name).write_text(render_html(report, dataset))
        datasets[dataset] = name
    return {"master": "report.html", "datasets": datasets}
