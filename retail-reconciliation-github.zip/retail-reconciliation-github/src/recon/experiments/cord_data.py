"""Audited acquisition and predeclared controlled masking of public CORD labels.

This is a financial-field reconstruction pilot, not retail-shortage matching,
OCR evaluation, or independently verified bank/warehouse reconciliation. Source
annotations and evaluation answers never enter a model case pack.
"""
from __future__ import annotations

import argparse
from collections import Counter
from collections.abc import Callable
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import urllib.request


DATASET_URL = "https://huggingface.co/datasets/naver-clova-ix/cord-v2"
PUBLISHER_URL = "https://github.com/clovaai/cord"
ROWS_URL = "https://datasets-server.huggingface.co/rows?dataset=naver-clova-ix%2Fcord-v2&config=default&split=test&offset=0&length=20"
METADATA_URL = "https://huggingface.co/api/datasets/naver-clova-ix/cord-v2"
LICENSE_URL = "https://raw.githubusercontent.com/clovaai/cord/master/LICENSE-CC-BY"
SCHEMA_URL = "https://raw.githubusercontent.com/clovaai/cord/master/README.md"
CITATION = "Park et al., CORD: A Consolidated Receipt Dataset for Post-OCR Parsing, Document Intelligence Workshop at NeurIPS 2019; NAVER CLOVA CORD v2."
SOURCES = (
    ("hf_rows.json", ROWS_URL),
    ("dataset_metadata.json", METADATA_URL),
    ("LICENSE_CC_BY_4_0.txt", LICENSE_URL),
    ("publisher_readme.txt", SCHEMA_URL),
)

# Frozen before inference. Row numbers are publisher test-split row_idx values.
# The two additional-redaction variants are clustered with their original receipt.
PREDECLARED_TASKS = (
    (0, "subtotal", ("sub_total", "subtotal_price"), False),
    (2, "subtotal", ("sub_total", "subtotal_price"), False),
    (7, "subtotal", ("sub_total", "subtotal_price"), False),
    (8, "subtotal", ("sub_total", "subtotal_price"), False),
    (6, "payment_total", ("total", "total_price"), False),
    (11, "payment_total", ("total", "total_price"), False),
    (14, "payment_total", ("total", "total_price"), False),
    (15, "payment_total", ("total", "total_price"), False),
    (3, "item_quantity", ("menu", "cnt"), False),
    (10, "item_quantity", ("menu", "cnt"), False),
    (12, "item_quantity", ("menu", 1, "cnt"), False),
    (13, "item_quantity", ("menu", 0, "cnt"), False),
    (12, "item_quantity", ("menu", 1, "cnt"), True),
    (14, "payment_total", ("total", "total_price"), True),
)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _json_bytes(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _write_json(path: Path, value) -> None:
    path.write_bytes(_json_bytes(value))


def _get(value, path):
    for segment in path:
        value = value[segment]
    return value


def _set(value, path, replacement) -> None:
    _get(value, path[:-1])[path[-1]] = replacement


def _records(response: dict) -> dict[int, dict]:
    if response.get("partial") is not False or len(response.get("rows", [])) != 20:
        raise ValueError("Expected the complete bounded 20-row CORD test response")
    records = {}
    for entry in response["rows"]:
        index = entry.get("row_idx")
        ground_truth = entry.get("row", {}).get("ground_truth")
        if type(index) is not int or index in records or not isinstance(ground_truth, str):
            raise ValueError("Invalid or duplicate CORD source record")
        annotation = json.loads(ground_truth)
        if not isinstance(annotation.get("gt_parse"), dict) or not isinstance(annotation.get("valid_line"), list):
            raise ValueError("Missing publisher structured annotations")
        if annotation.get("meta", {}).get("image_id") != index:
            raise ValueError("Source row and image identity disagree")
        records[index] = {"annotation": annotation, "raw": ground_truth}
    if set(records) != set(range(20)):
        raise ValueError("Expected CORD test row indices 0 through 19")
    return records


def _publisher_integer(value, *, quantity=False) -> int:
    """Independent label decoding; no engine/normalizer imports or arithmetic labels."""
    if isinstance(value, list):
        if not value:
            raise ValueError("Empty repeated publisher label")
        decoded = [_publisher_integer(item, quantity=quantity) for item in value]
        if len(set(decoded)) != 1:
            raise ValueError("Repeated publisher labels disagree")
        return decoded[0]
    if not isinstance(value, str):
        raise ValueError("Expected source label text")
    token = value.strip()
    if quantity:
        # An unmatched opening parenthesis occurs in the publisher's '(2' count.
        match = re.fullmatch(r"\(?(\d+)(?:\.0+)?\s*(?:x(?:items)?)?\)?", token, re.I)
        if not match:
            raise ValueError("Unsupported publisher count label")
        return int(match.group(1))
    token = re.sub(r"^(?:Rp\.?\s*|IDR\s*|@\s*)", "", token, flags=re.I)
    if re.fullmatch(r"-?\d+", token):
        return int(token)
    if re.fullmatch(r"-?\d{1,3}(?:\.\d{3})+", token):
        return int(token.replace(".", ""))
    if re.fullmatch(r"-?\d{1,3}(?:,\d{3})+", token):
        return int(token.replace(",", ""))
    raise ValueError("Unsupported publisher monetary label; no locale guessed")


def _field_labels(annotation: dict, excluded: set[str]) -> dict[str, list[str]]:
    result = {}
    for line in annotation["valid_line"]:
        category = line.get("category")
        if not isinstance(category, str) or category in excluded:
            continue
        # Source words designated as keys only: never raw OCR value words.
        text = " ".join(word["text"] for word in line.get("words", [])
                        if word.get("is_key") == 1 and isinstance(word.get("text"), str)).strip()
        if text and text not in result.setdefault(category, []):
            result[category].append(text)
    return result


def _category(path) -> str:
    return ".".join(segment for segment in path if isinstance(segment, str))


def _flatten(value, prefix=()):
    if isinstance(value, dict):
        for key, item in value.items():
            yield from _flatten(item, (*prefix, key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from _flatten(item, (*prefix, index))
    else:
        yield list(prefix), value


def _observations(records) -> dict:
    """Describe all 20 records without filtering to equation-agreeing cases."""
    present = Counter()
    observations = []
    for index, record in sorted(records.items()):
        parsed = record["annotation"]["gt_parse"]
        paths = [path for path, _ in _flatten(parsed)]
        for category in {_category(path) for path in paths}:
            present[category] += 1
        monetary = []
        counts = []
        for path, raw in _flatten(parsed):
            leaf = next(segment for segment in reversed(path) if isinstance(segment, str))
            if leaf in {"cnt", "menuqty_cnt"}:
                destination, quantity = counts, True
            elif isinstance(leaf, str) and ("price" in leaf or leaf == "etc"):
                destination, quantity = monetary, False
            else:
                continue
            try:
                value = _publisher_integer(raw, quantity=quantity)
            except ValueError:
                value = None
            destination.append({"path": path, "raw": raw, "decoded_integer": value})
        total = parsed.get("total", {})
        checks = []
        if all(field in total for field in ("total_price", "cashprice", "changeprice")):
            expected = _publisher_integer(total["total_price"])
            calculated = _publisher_integer(total["cashprice"]) - _publisher_integer(total["changeprice"])
            checks.append({"procedure": "cash_minus_change", "computed": calculated,
                           "publisher_total": expected, "agrees": calculated == expected,
                           "scope": "Diagnostic only; may omit an observed non-cash tender."})
        observations.append({"record_id": f"test:{index}", "row_idx": index,
                             "menu_container": type(parsed.get("menu")).__name__,
                             "monetary_tokens": monetary, "quantity_tokens": counts,
                             "field_labels": _field_labels(record["annotation"], set()),
                             "diagnostics": checks})
    return {"record_count": len(records), "field_presence_record_counts": dict(sorted(present.items())),
            "records": observations,
            "limits": ["These are publisher annotations, not raw OCR results or independent payment records.",
                       "menu.price is a line total, not a unit price.",
                       "Absent amounts remain absent; no zero fees, currency, or counterpart records are invented.",
                       "Diagnostic arithmetic is not a label-generation procedure."]}


def _download(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "reconciliation-public-data-audit/1.0"})
    with urllib.request.urlopen(request, timeout=30) as response:
        raw = response.read(8_000_001)
    if len(raw) > 8_000_000:
        raise ValueError("Public response exceeds the bounded acquisition limit")
    return raw


def acquire(output_dir: Path, *, transport: Callable[[str], bytes] | None = None) -> dict:
    """Download only 20 structured annotations and provenance; never fetch images."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    transport = transport or _download
    fetched = {}
    audits = []
    for filename, url in SOURCES:
        raw = transport(url)
        if not isinstance(raw, bytes) or not raw:
            raise ValueError("Public source transport must return nonempty bytes")
        fetched[filename] = raw
        audits.append({"file": filename, "url": url, "sha256": _sha(raw), "bytes": len(raw),
                       "retrieved_at": datetime.now(timezone.utc).isoformat()})
    records = _records(json.loads(fetched["hf_rows.json"]))
    metadata = json.loads(fetched["dataset_metadata.json"])
    if metadata.get("id") != "naver-clova-ix/cord-v2" or metadata.get("cardData", {}).get("license") != "cc-by-4.0":
        raise ValueError("Unexpected dataset identity or declared license")
    if b"Attribution 4.0 International" not in fetched["LICENSE_CC_BY_4_0.txt"]:
        raise ValueError("Official license snapshot is not CC BY 4.0")
    for filename, raw in fetched.items():
        (output_dir / filename).write_bytes(raw)
    observations = _observations(records)
    _write_json(output_dir / "financial_observations.json", observations)
    manifest = {
        "version": 1, "dataset": "cord", "publisher": "NAVER CLOVA", "dataset_url": DATASET_URL,
        "publisher_url": PUBLISHER_URL, "citation": CITATION,
        "license": {"id": "CC-BY-4.0", "url": LICENSE_URL, "snapshot": "LICENSE_CC_BY_4_0.txt",
                    "attribution_required": True},
        "sources": audits, "metadata_revision": metadata.get("sha"),
        "revision_binding": "The metadata revision was observed separately. The rows API request was not revision-pinned; exact response bytes are preserved and hashed.",
        "split": "test", "offset": 0, "record_count": 20, "publisher_split_size": 100,
        "images_downloaded": False, "image_url_metadata_retained_in_original_response": True,
        "financial_observations": {"file": "financial_observations.json", "sha256": _sha(_json_bytes(observations))},
        "profile": {"field_presence_record_counts": observations["field_presence_record_counts"],
                    "record_ids": [f"test:{index}" for index in sorted(records)]},
        "limits": observations["limits"],
    }
    _write_json(output_dir / "manifest.json", manifest)
    return manifest


def _label_reason(index, kind, damaged):
    if damaged and index == 12:
        return "Additional controlled redaction removes the aggregate count. A 100% discounted zero-value item does not establish its quantity from price arithmetic; review is required even if a guess equals the publisher label."
    if damaged and index == 14:
        return "Additional controlled redaction removes the coupon amount/key, all menu lines, and the subtotal/fees section. Cash and change remain, but an unobserved additional tender cannot be established as zero or invented; review is required."
    if kind == "subtotal":
        return "Observed line totals (using itemsubtotal where present) plus observed nested addon totals determine the hidden subtotal. Line totals must not be multiplied by quantity."
    if kind == "payment_total" and index == 14:
        return "The printed Coupon key identifies the observed other tender: cash + coupon - change agrees with observed subtotal + service + tax."
    if kind == "payment_total":
        return "Observed cash minus observed change determines the hidden total; the observed menu line totals agree."
    if index == 12:
        return "The preserved printed aggregate '(2' indicates two items, and the other line has count 1. The hidden free-bag quantity is 1; its 100% discount alone would not determine quantity."
    return "Observed unit price and line total determine an integral item quantity; no absent quantity is invented."


def _build_case(index, kind, path, damaged, records):
    record = records[index]
    annotation = record["annotation"]
    original = annotation["gt_parse"]
    label_raw = deepcopy(_get(original, path))
    label_value = _publisher_integer(label_raw, quantity=kind == "item_quantity")
    observed = deepcopy(original)
    removed = [list(path)]
    excluded = {_category(path)}
    if damaged:
        additional_paths = (("total", "menuqty_cnt"),) if index == 12 else (
            ("total", "total_etc"), ("menu",), ("sub_total",))
        for additional in additional_paths:
            _get(original, additional)  # Fail if a declared source fact is absent.
            removed.append(list(additional))
            excluded.add(_category(additional))
        if index == 14:
            excluded.update(line["category"] for line in annotation["valid_line"]
                            if line.get("category", "").startswith(("menu.", "sub_total.")))
    for removed_path in removed:
        _set(observed, removed_path, None)
    case_id = f"CORD-test-{index:05d}-{kind}" + ("-co-missing" if damaged else "")
    case = {
        "version": 1, "case_id": case_id, "dataset": "cord",
        "task": {"kind": kind, "target_path": list(path)},
        "observed": observed, "field_labels": _field_labels(annotation, excluded),
        "source": {"dataset_url": DATASET_URL, "record_id": f"test:{index}",
                   "sha256": _sha(record["raw"].encode("utf-8")), "citation": CITATION},
        "masking": {"removed_paths": removed, "removed_label_categories": sorted(excluded),
                    "reason": "Controlled target redaction" + (" plus predeclared additional evidence redaction." if damaged else "."),
                    "raw_ocr_withheld": True},
    }
    label = {"case_id": case_id, "expected_value": label_value,
             "expected_status": "review" if damaged else "recovered",
             "observability_reason": _label_reason(index, kind, damaged),
             "cluster_id": f"CORD-test-{index:05d}", "publisher_target_raw": label_raw,
             "target_source_ref": {"record_id": f"test:{index}", "path": ["gt_parse", *path]},
             "controlled_additional_redaction": damaged}
    return case, label


def build_cases(source_dir: Path, output_dir: Path) -> dict:
    """Freeze 12 genuine-value tasks and two explicitly co-missing variants."""
    source_dir, output_dir = Path(source_dir), Path(output_dir)
    source_manifest = json.loads((source_dir / "manifest.json").read_text())
    raw = (source_dir / "hf_rows.json").read_bytes()
    expected = next(item["sha256"] for item in source_manifest["sources"] if item["file"] == "hf_rows.json")
    if _sha(raw) != expected:
        raise ValueError("CORD response no longer matches the acquisition manifest")
    records = _records(json.loads(raw))
    cases, labels = [], []
    for index, kind, path, damaged in PREDECLARED_TASKS:
        case, label = _build_case(index, kind, path, damaged, records)
        cases.append(case)
        labels.append(label)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "cases").mkdir(exist_ok=True)
    case_rows = []
    for case in cases:
        path = f"cases/{case['case_id']}.json"
        _write_json(output_dir / path, case)
        case_rows.append({"case_id": case["case_id"], "path": path, "sha256": _sha(_json_bytes(case)),
                          "record_id": case["source"]["record_id"], "task": case["task"]})
    cases_raw = b"".join(json.dumps(case, ensure_ascii=False, sort_keys=True).encode("utf-8") + b"\n" for case in cases)
    labels_raw = b"".join(json.dumps(label, ensure_ascii=False, sort_keys=True).encode("utf-8") + b"\n" for label in labels)
    (output_dir / "cases.jsonl").write_bytes(cases_raw)
    (output_dir / "labels.jsonl").write_bytes(labels_raw)
    selection = [{"row_idx": index, "kind": kind, "target_path": list(path), "additional_redaction": damaged}
                 for index, kind, path, damaged in PREDECLARED_TASKS]
    selected_rows = {entry[0] for entry in PREDECLARED_TASKS}
    excluded_rows = [{"record_id": f"test:{index}", "reason": "Not in the small predeclared pilot; not excluded based on model outcomes.",
                      "publisher_field_paths": [path for path, _ in _flatten(records[index]["annotation"]["gt_parse"])]}
                     for index in sorted(set(records) - selected_rows)]
    manifest = {
        "version": 1, "dataset": "cord", "experiment": "controlled financial-field reconstruction",
        "created_at": datetime.now(timezone.utc).isoformat(), "frozen_before_model_outputs": True,
        "source_dir": str(source_dir.resolve()), "source_response_sha256": _sha(raw),
        "source_manifest_sha256": _sha((source_dir / "manifest.json").read_bytes()),
        "license": source_manifest["license"], "citation": CITATION,
        "case_count": len(cases), "distinct_receipt_count": len(selected_rows),
        "genuine_single_target_masks": 12, "controlled_additional_redactions": 2,
        "status_counts": dict(Counter(label["expected_status"] for label in labels)),
        "task_counts": dict(Counter(case["task"]["kind"] for case in cases)),
        "cases": case_rows, "selection": selection, "selection_sha256": _sha(_json_bytes(selection)),
        "labels": {"file": "labels.jsonl", "sha256": _sha(labels_raw), "hidden_from_engines": True,
                   "method": "Exact publisher gt_parse target values decoded to integers by an independent stdlib label decoder; no engine outputs used."},
        "casepacks": {"file": "cases.jsonl", "sha256": _sha(cases_raw)},
        "excluded_records": excluded_rows,
        "analysis_unit": "Receipt cluster; additional-redaction variants are not independent receipts.",
        "currency_policy": "Integer printed monetary units, not cents; no currency or exchange rate is invented.",
        "scope": "Frozen examples from the first 20 publisher test records; exploratory pilot selected after annotation inspection, not an untouched representative benchmark.",
        "masking_policy": "Only masked gt_parse and printed key labels enter casepacks. Entire target fields, including repeated lists, become null. Raw valid_line values, source images, and labels are withheld.",
        "limits": ["Controlled missingness is artificial; underlying annotation values are authentic.",
                   "No OCR/parser quality claim: publisher structured annotations are supplied.",
                   "No independent third-party bank, invoice, or warehouse verification is available.",
                   "A correct numeric guess is not success when the retained evidence requires review.",
                   "Same-case ties or a small selected sample do not establish an AI advantage.",
                   "Printed aggregate '(2' is explicitly accepted as the quantity count 2 in this bounded task."],
    }
    _write_json(output_dir / "manifest.json", manifest)
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("acquire", "build"))
    parser.add_argument("--source", type=Path, default=Path("evaluation/public/cord"))
    parser.add_argument("--output", type=Path, default=Path("evaluation/cord_reconstruction"))
    args = parser.parse_args(argv)
    result = acquire(args.source) if args.mode == "acquire" else build_cases(args.source, args.output)
    print(json.dumps({key: result[key] for key in ("dataset", "record_count", "case_count") if key in result}))


if __name__ == "__main__":
    main()
