"""Frozen, checkpointed comparison on authentic fields with controlled missingness.

This runner executes no model calls on import. Labels are scoring data only and
are never passed to a method or provider. It does not retry unsuccessful runs.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib
import json
import math
from pathlib import Path
import random
import time
import uuid

from recon.ai.provider import create_provider
from recon.experiments.statistics import paired_case_analysis


PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_CORPORA = (PROJECT_ROOT / "evaluation/cord_reconstruction", PROJECT_ROOT / "evaluation/ceap_reconstruction")
DEFAULT_OUTPUT = PROJECT_ROOT / "output/experiments"
ENGINES = ("no_ai", "direct_ai", "procedure_ai")
SEED = 20261109


def _now():
    return datetime.now(timezone.utc).isoformat()


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def _file_hash(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1_048_576), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write(path, value):
    """Atomic replacement leaves the previous completed checkpoint readable."""
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def _tree_snapshot(folder):
    return {str(path.relative_to(folder)): _file_hash(path) for path in sorted(folder.rglob("*")) if path.is_file()}


def _inside(folder, relative):
    if not isinstance(relative, str):
        raise ValueError("Frozen artifact paths must be strings")
    path = (folder / relative).resolve()
    if path == folder or not path.is_relative_to(folder) or not path.is_file():
        raise ValueError("Frozen artifact is missing or outside its corpus")
    return path


def _jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def _load_corpus(folder):
    folder = Path(folder).resolve()
    manifest = json.loads((folder / "manifest.json").read_text())
    declared = {}
    for field in ("casepacks", "labels"):
        item = manifest.get(field, {})
        if isinstance(item, dict) and isinstance(item.get("file"), str) and isinstance(item.get("sha256"), str):
            declared[item["file"]] = item["sha256"]
    for item in manifest.get("cases", []):
        if isinstance(item, dict) and item.get("path") and item.get("sha256"):
            declared[item["path"]] = item["sha256"]
    files = manifest.get("files", {})
    if isinstance(files, dict):
        for name, value in files.items():
            declared[name] = value.get("sha256") if isinstance(value, dict) else value
    elif isinstance(files, list):
        for item in files:
            declared[item.get("file", item.get("path"))] = item.get("sha256")
    for name, expected in declared.items():
        if not isinstance(expected, str) or _file_hash(_inside(folder, name)) != expected:
            raise ValueError(f"Frozen corpus artifact hash mismatch: {name}")
    cases = _jsonl(folder / "cases.jsonl")
    labels = _jsonl(folder / "labels.jsonl")
    by_id = {label["case_id"]: label for label in labels}
    if len(by_id) != len(labels) or len({case["case_id"] for case in cases}) != len(cases):
        raise ValueError("Duplicate case or label identity")
    if {case["case_id"] for case in cases} != set(by_id):
        raise ValueError("Case and label identities must agree exactly")
    if "cases.jsonl" not in declared or "labels.jsonl" not in declared:
        raise ValueError("Both cases.jsonl and labels.jsonl require frozen manifest hashes")
    entries = []
    for case in cases:
        label = by_id[case["case_id"]]
        if case.get("dataset") not in ("cord", "ceap"):
            raise ValueError("Only native CORD and CEAP reconstruction corpora are supported")
        if label.get("expected_status") not in ("recovered", "review") or type(label.get("expected_value")) is not int:
            raise ValueError("Labels require a recovery/review outcome and an exact integer publisher value")
        if any(field in case for field in ("expected_value", "expected_status", "publisher_target_raw", "label")):
            raise ValueError("Evaluation labels must not occur in engine inputs")
        target = case.get("observed")
        try:
            for part in case["task"]["target_path"]:
                target = target[part]
        except (KeyError, IndexError, TypeError):
            raise ValueError("Case target path is invalid") from None
        if target is not None:
            raise ValueError("The target must be masked in the observed input")
        dataset = "cord_extra_redaction" if case["dataset"] == "cord" and label.get("controlled_additional_redaction") is True else case["dataset"]
        entries.append({"case": case, "label": label, "dataset": dataset, "corpus_dir": folder,
                        "cluster_id": label.get("cluster_id", case.get("source", {}).get("record_id", case["case_id"]))})
    return entries, manifest, _tree_snapshot(folder)


def _engine_snapshot():
    paths = sorted(Path(__file__).parent.glob("*.py"))
    paths.extend((PROJECT_ROOT / "src/recon/ai/provider.py", PROJECT_ROOT / "src/recon/phase2/contracts.py"))
    return {str(path.relative_to(PROJECT_ROOT)): _file_hash(path) for path in paths if path.is_file()}


def _protocol_metadata():
    return importlib.import_module("recon.experiments.methods").protocol_metadata()


def _run_case(pack, *, mode, provider, max_steps):
    return importlib.import_module("recon.experiments.methods").run_case(pack, mode=mode, provider=provider, max_steps=max_steps)


def _safe_provider_config(provider, kind, model, timeout):
    # Never inspect __dict__, authentication, environment, or transport closures.
    result = {"requested_kind": kind, "requested_model": model, "timeout_seconds": timeout,
              "same_provider_instance_for_both_ai_methods": True, "selective_retries": False}
    if provider is not None:
        result["provider_class"] = type(provider).__name__
        public_model = getattr(provider, "model", None)
        result["configured_model"] = public_model if isinstance(public_model, str) else None
        result["model_identity_requested_explicitly"] = isinstance(public_model, str) and bool(public_model)
        result["exact_model_identity_verified"] = False
    else:
        result["exact_model_identity_verified"] = False
    return result


class _RecordingProvider:
    """Preserve attempted completions even if a method raises before returning."""
    def __init__(self, provider, on_update=None):
        self.provider = provider
        self.attempts = []
        self.on_update = on_update

    def complete(self, instructions, context, schema):
        attempt = {"attempt": len(self.attempts) + 1, "started_at": _now(),
                   "instructions_hash": _digest(instructions), "context_hash": _digest(context), "schema_hash": _digest(schema)}
        self.attempts.append(attempt)
        if self.on_update is not None:
            self.on_update()
        started = time.perf_counter()
        try:
            completion = self.provider.complete(instructions, context, schema)
            attempt.update(completed=True, audit=deepcopy(completion.audit), value=deepcopy(completion.value))
            return completion
        except Exception as error:
            attempt.update(completed=False, audit={"error_type": type(error).__name__, "live": None})
            raise
        finally:
            attempt.update(finished_at=_now(), runtime_ms=(time.perf_counter() - started) * 1000)
            if self.on_update is not None:
                self.on_update()


def _failure(reason, error_type):
    return {"status": "failed", "value": None, "reason": reason, "error_type": error_type,
            "model_calls": 0, "planning_decisions": [], "trace": [], "normalizations": [], "equations": [],
            "verification": {"passed": False, "independent": False}, "live_ai": False}


def _validate_result(result):
    if not isinstance(result, dict) or result.get("status") not in ("recovered", "review", "failed"):
        raise ValueError("Method returned an invalid status")
    if result["status"] == "recovered" and type(result.get("value")) is not int:
        raise ValueError("Recovered values must be exact integers")
    if result["status"] != "recovered" and result.get("value") is not None:
        raise ValueError("Unresolved or failed outputs must not assert a value")
    _canonical(result)
    return result


def _assess(result, label):
    recovered = result["status"] == "recovered"
    value_correct = recovered and result["value"] == label["expected_value"]
    permitted = label["expected_status"] == "recovered"
    failed = result["status"] == "failed"
    return {"expected_status": label["expected_status"], "expected_value": label["expected_value"],
            "observability_reason": label.get("observability_reason"),
            "success": not failed and ((recovered and permitted and value_correct) or (result["status"] == "review" and not permitted)),
            "value_correct_when_recovered": value_correct if recovered else None,
            "incorrect_auto": recovered and (not permitted or not value_correct),
            "auto": recovered, "review": result["status"] == "review", "failed": failed,
            "scored_after_execution": True,
            "rule": "A numeric guess on an evidence-insufficient case is an unjustified automatic result, even if it equals the hidden publisher value."}


def _usage(attempts, field, *, deterministic=False):
    if deterministic:
        return 0
    if not attempts:
        return None
    values = [attempt.get("audit", {}).get("usage", {}).get(field) for attempt in attempts]
    return sum(values) if all(type(value) is int and value >= 0 for value in values) else None


def _audit_counts(attempts):
    completed = [attempt for attempt in attempts if attempt.get("completed") is True and not attempt.get("audit", {}).get("error_type")]
    return {"provider_attempts": len(attempts), "completed": len(completed),
            "live_completed": sum(attempt.get("audit", {}).get("live") is True for attempt in completed),
            "injected_completed": sum(attempt.get("audit", {}).get("live") is False for attempt in completed),
            "unverified_completed": sum(attempt.get("audit", {}).get("live") not in (True, False) for attempt in completed),
            "failed_attempts": sum(attempt.get("completed") is not True or bool(attempt.get("audit", {}).get("error_type")) for attempt in attempts)}


def _metric_record(row):
    score, result = row["evaluation"], row["result"]
    verification = result.get("verification", {})
    return {"dataset": row["dataset"], "case_id": row["case_id"], "repeat": row["repeat"], "engine": row["engine"],
            **{name: score[name] for name in ("success", "incorrect_auto", "auto", "review", "failed")},
            "verified": verification.get("passed") is True and verification.get("independent") is True,
            "runtime_ms": row["runtime_ms"], "model_calls": row["provider_audit"]["provider_attempts"],
            "input_tokens": row["resource_usage"]["input_tokens"], "output_tokens": row["resource_usage"]["output_tokens"]}


def _emit(progress, value):
    print(json.dumps(value, sort_keys=True), flush=True)
    if progress is not None:
        progress(deepcopy(value))


def _source_audits():
    """Descriptive source checks are linked separately from accuracy outcomes."""
    audits = []
    public = PROJECT_ROOT / "evaluation/public"
    for path in sorted(public.glob("*/*.json")):
        if any(word in path.stem for word in ("audit", "profile", "provenance", "observations")):
            audits.append({"path": str(path.relative_to(PROJECT_ROOT)), "sha256": _file_hash(path),
                           "data": json.loads(path.read_text()), "used_as_accuracy_ground_truth": False})
    return audits


def run_experiment(corpus_dirs=None, output_dir=DEFAULT_OUTPUT, *, provider=None, provider_kind="auto", model=None,
                   case_ids=None, repeats=2, seed=SEED, max_steps=8, model_runs=True, timeout=60,
                   bootstrap_resamples=10000, progress=None):
    """Run every preselected attempt once and save protocol before model requests.

    All cases and two repeats are the defaults. ``model_runs=False`` executes the
    deterministic control only. A supplied provider is an explicit injection;
    its own completion audits determine whether calls were live or simulated.
    """
    if type(repeats) is not int or repeats < 1 or type(seed) is not int:
        raise ValueError("repeats must be positive and seed must be an integer")
    if type(max_steps) is not int or not 1 <= max_steps <= 8:
        raise ValueError("max_steps must be between 1 and 8")
    if type(timeout) not in (int, float) or not math.isfinite(timeout) or not 0 < timeout <= 60:
        raise ValueError("timeout must be positive and at most 60 seconds")
    if type(bootstrap_resamples) is not int or bootstrap_resamples < 1:
        raise ValueError("bootstrap_resamples must be positive")
    entries, corpora = [], []
    for folder in corpus_dirs or DEFAULT_CORPORA:
        loaded, manifest, snapshot = _load_corpus(folder)
        entries.extend(loaded)
        source_name = manifest.get("source_dir", manifest.get("source", {}).get("directory"))
        source_dir = Path(source_name).resolve() if isinstance(source_name, str) else None
        corpora.append({"path": str(Path(folder).resolve()), "manifest": manifest, "files_before": snapshot,
                        "source_path": str(source_dir) if source_dir and source_dir.is_dir() else None,
                        "source_files_before": _tree_snapshot(source_dir) if source_dir and source_dir.is_dir() else None})
    lookup = {entry["case"]["case_id"]: entry for entry in entries}
    if len(lookup) != len(entries):
        raise ValueError("Case identities must be unique across corpora")
    if case_ids is not None:
        if not case_ids or len(set(case_ids)) != len(case_ids) or set(case_ids) - lookup.keys():
            raise ValueError("Selected case IDs must be nonempty, unique, and present in the frozen corpora")
        entries = [lookup[case_id] for case_id in sorted(case_ids)]
    else:
        entries.sort(key=lambda entry: (entry["dataset"], entry["case"]["case_id"]))
    if not entries:
        raise ValueError("No cases selected")
    clusters = defaultdict(list)
    for entry in entries:
        clusters[(entry["dataset"], entry["cluster_id"])].append(entry["case"]["case_id"])
    duplicate_clusters = [ids for ids in clusters.values() if len(ids) > 1]
    if duplicate_clusters:
        raise ValueError("Multiple cases from one source cluster cannot be treated as independent in the same dataset analysis")
    metadata = _protocol_metadata()
    rng = random.Random(seed)
    blocks = [(entry["case"]["case_id"], repeat) for entry in entries for repeat in range(repeats)]
    rng.shuffle(blocks)
    schedule = []
    for case_id, repeat in blocks:
        ai_order = ["direct_ai", "procedure_ai"] if model_runs else []
        rng.shuffle(ai_order)
        for engine in ["no_ai", *ai_order]:
            schedule.append({"sequence": len(schedule) + 1, "case_id": case_id, "repeat": repeat,
                             "dataset": lookup[case_id]["dataset"], "engine": engine})
    run_id = str(uuid.uuid4())
    folder = Path(output_dir).resolve() / run_id
    folder.mkdir(parents=True, exist_ok=False)
    protocol = {
        "version": 1, "run_id": run_id, "frozen_at": _now(), "seed": seed, "repeats": repeats,
        "model_runs": model_runs, "max_steps": max_steps, "timeout_seconds_per_model_call": timeout,
        "maximum_model_requests": len(entries) * repeats * (1 + max_steps) if model_runs else 0,
        "selection": [{"dataset": entry["dataset"], "case_id": entry["case"]["case_id"], "cluster_id": entry["cluster_id"],
                       "input_sha256": _digest(entry["case"]), "label_sha256": _digest(entry["label"]), "source": entry["case"].get("source", {})} for entry in entries],
        "selection_counts": dict(Counter(entry["dataset"] for entry in entries)),
        "schedule": schedule, "schedule_sha256": _digest(schedule), "engine_files_before": _engine_snapshot(),
        "method_contracts": metadata, "corpora": corpora,
        "provider": _safe_provider_config(provider, provider_kind, model, timeout),
        "analysis": {"primary_dataset": "cord", "separate_analyses": ["cord", "cord_extra_redaction", "ceap"],
                     "bootstrap_resamples": bootstrap_resamples, "resampling_unit": "independent source case within dataset, all repeats retained",
                     "mcnemar_repeat": 0, "success_comparisons": ["procedure_ai_vs_direct_ai", "procedure_ai_vs_no_ai"],
                     "no_population_or_causal_best_claim": True},
        "conditions": ["The three methods receive identical masked observed facts and task metadata; only the AI methods access the shared model provider.",
                       "Direct AI returns a final answer; procedure AI selects allowlisted operations; no AI invokes the same operators deterministically.",
                       "Every scheduled attempt runs once. No selective retries, prompt changes, replacement cases, or answer repair in this runner.",
                       "Labels are kept separate and revealed for scoring only after each method has returned.",
                       "The source values are authentic; target removal is a controlled intervention, not observed natural missingness.",
                       "CORD additional-redaction cases overlap primary source receipts and are analyzed separately.",
                       "This is financial-field reconstruction, not validation of the original retail-deduction reconciliation task."],
    }
    _write(folder / "protocol.json", protocol)
    report = {"version": 1, "run_metadata": {"run_id": run_id, "started_at": _now(), "status": "running",
              "output_dir": str(folder), "artifacts": {"protocol": "protocol.json", "checkpoint": "checkpoint.json", "report": "report.json", "html": "report.html"}},
              "protocol": protocol, "results": [], "metrics_records": [], "provider_configuration": None}
    _write(folder / "checkpoint.json", report)
    selected_provider, provider_error = provider, None
    if model_runs and selected_provider is None:
        try:
            selected_provider = create_provider(provider_kind, model=model, timeout=timeout)
        except Exception as error:
            provider_error = type(error).__name__
    report["provider_initialization_error"] = provider_error
    recorder = None
    def save_attempt_journal():
        report["in_progress"]["provider_attempts"] = deepcopy(recorder.attempts)
        _write(folder / "checkpoint.json", report)
    recorder = _RecordingProvider(selected_provider, save_attempt_journal) if selected_provider is not None and model_runs else None
    report["provider_configuration"] = _safe_provider_config(selected_provider, provider_kind, model, timeout)
    started_run = time.perf_counter()
    for slot in schedule:
        entry = lookup[slot["case_id"]]
        engine = slot["engine"]
        event = {"event": "engine_started", "completed_engine_runs": len(report["results"]), "total_engine_runs": len(schedule), **slot}
        _emit(progress, event)
        if recorder is not None:
            recorder.attempts = []
        started, started_at = time.perf_counter(), _now()
        report["in_progress"] = {**slot, "started_at": started_at, "provider_attempts": [],
                                 "censoring_policy": "An interrupted in-progress attempt is preserved here, not scored as review or success."}
        _write(folder / "checkpoint.json", report)
        try:
            if engine != "no_ai" and provider_error:
                result = _failure("Provider initialization failed; no fallback or retry was attempted.", provider_error)
            else:
                result = _validate_result(_run_case(deepcopy(entry["case"]), mode=engine,
                                                   provider=recorder if engine != "no_ai" else None, max_steps=max_steps))
        except Exception as error:
            result = _failure("Method execution failed; no fallback or retry was attempted.", type(error).__name__)
        attempts = deepcopy(recorder.attempts) if recorder is not None and engine != "no_ai" else []
        row = {**slot, "started_at": started_at, "finished_at": _now(), "runtime_ms": (time.perf_counter() - started) * 1000,
               "observed_input": deepcopy(entry["case"]), "observed_input_sha256": _digest(entry["case"]),
               "cluster_id": entry["cluster_id"], "source": deepcopy(entry["case"].get("source", {})),
               "result": result, "provider_attempts": attempts, "provider_audit": _audit_counts(attempts),
               "resource_usage": {field: _usage(attempts, field, deterministic=engine == "no_ai") for field in ("input_tokens", "output_tokens")},
               "evaluation": _assess(result, entry["label"])}
        row["reported_model_calls"] = result.get("model_calls")
        row["model_call_audit_agrees"] = result.get("model_calls") == len(attempts)
        report["results"].append(row)
        report["metrics_records"].append(_metric_record(row))
        report["in_progress"] = None
        report["run_metadata"]["completed_engine_runs"] = len(report["results"])
        report["run_metadata"]["total_engine_runs"] = len(schedule)
        _write(folder / "checkpoint.json", report)
        _emit(progress, {**event, "event": "engine_finished", "completed_engine_runs": len(report["results"]),
                         "status": result["status"], "success": row["evaluation"]["success"], "runtime_ms": row["runtime_ms"],
                         "provider_attempts": len(attempts)})
    report["run_metadata"].update(finished_at=_now(), runtime_ms=(time.perf_counter() - started_run) * 1000,
        runtime_scope="Scheduled engine loop, including audit checkpoints; excludes corpus loading, provider initialization and report rendering.", status="complete")
    report["freeze_checks"] = {"engine_files_after": _engine_snapshot(), "corpora": []}
    report["freeze_checks"]["engine_files_unchanged"] = protocol["engine_files_before"] == report["freeze_checks"]["engine_files_after"]
    for corpus in corpora:
        files_after = _tree_snapshot(Path(corpus["path"]))
        source_after = _tree_snapshot(Path(corpus["source_path"])) if corpus["source_path"] else None
        report["freeze_checks"]["corpora"].append({"path": corpus["path"], "files_after": files_after,
            "corpus_unchanged": corpus["files_before"] == files_after, "source_files_after": source_after,
            "source_unchanged": corpus["source_files_before"] == source_after if corpus["source_path"] else None})
    report["freeze_checks"]["all_declared_artifacts_unchanged"] = report["freeze_checks"]["engine_files_unchanged"] and all(corpus["corpus_unchanged"] and corpus["source_unchanged"] is not False for corpus in report["freeze_checks"]["corpora"])
    report["statistics"] = paired_case_analysis(report["metrics_records"], seed=seed, bootstrap_resamples=bootstrap_resamples)
    report["provider_audit"] = _audit_counts([attempt for row in report["results"] for attempt in row["provider_attempts"]])
    report["source_audits"] = _source_audits()
    report["limitations"] = ["Small selected pilot; cases were inspected when methods were engineered. This is not an untouched or representative benchmark.",
        "CORD uses publisher structured receipt annotations, not raw optical character recognition. CEAP uses published expense fields, not invoice PDFs.",
        "Arithmetic checks use retained source fields; independent bank/warehouse confirmation and original retail-deduction labels are unavailable.",
        "Controlled masking is artificial. Correct field recovery on these cases does not establish accuracy on naturally missing records.",
        "Additional CORD redactions share receipts with the primary set; cross-dataset results must not be pooled as independent observations.",
        "A shared provider configuration is recorded. If a CLI default does not report its exact model, identical model identity cannot be independently confirmed.",
        "CLI tool disabling is audited but is not hard operating-system isolation from local source or label files.",
        "Unknown token usage and failed requests are retained. Monetary cost cannot be calculated without known prices and complete usage."]
    _write(folder / "report.json", report)
    _write(folder / "checkpoint.json", report)
    try:
        from recon.experiments.report import write_reports
        report["run_metadata"]["artifacts"]["html_reports"] = write_reports(report, folder)
    except Exception as error:
        report["run_metadata"]["html_report_unavailable"] = type(error).__name__
        _write(folder / "report.json", report)
        _write(folder / "checkpoint.json", report)
    _write(folder / "report.json", report)
    _write(folder / "checkpoint.json", report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, action="append", help="Frozen corpus directory; repeat for CORD and CEAP")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--case", action="append", dest="case_ids")
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--provider", choices=("auto", "openai", "codex"), default="auto")
    parser.add_argument("--model")
    parser.add_argument("--max-steps", type=int, default=8)
    parser.add_argument("--timeout", type=float, default=60)
    parser.add_argument("--bootstrap-resamples", type=int, default=10000)
    parser.add_argument("--controls-only", action="store_true")
    options = parser.parse_args(argv)
    report = run_experiment(options.corpus, options.output, provider_kind=options.provider, model=options.model,
        case_ids=options.case_ids, repeats=options.repeats, seed=options.seed, max_steps=options.max_steps,
        model_runs=not options.controls_only, timeout=options.timeout, bootstrap_resamples=options.bootstrap_resamples)
    print(json.dumps({"run_id": report["run_metadata"]["run_id"], "output_dir": report["run_metadata"]["output_dir"],
                      "provider_audit": report["provider_audit"], "freeze_checks_passed": report["freeze_checks"]["all_declared_artifacts_unchanged"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
