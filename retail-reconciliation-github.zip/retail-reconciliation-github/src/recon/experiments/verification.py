"""Independent observed-input verification for bounded real-record experiments.

No executor, financial parser, hidden label, PDF, source file, or model is used.
The selected equations are checked against every supported relation available in
the masked record, rather than allowing a selected method to hide a rival.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, localcontext
from fractions import Fraction
import hashlib
import json
import re


LIMIT = 10**12
MONEY = {"price", "unitprice", "itemsubtotal", "subtotal_price", "discount_price", "tax_price",
         "service_price", "othersvc_price", "total_price", "cashprice", "changeprice",
         "creditcardprice", "emoneyprice", "total_etc", "etc"}
COUNTS = {"cnt", "menuqty_cnt"}
CEAP_MONEY = {"vlrDocumento", "vlrGlosa", "vlrLiquido", "vlrRestituicao"}
OPS = {
    "subtotal": {"sum_item_amounts"},
    "payment_total": {"solve_cash_change", "solve_tender_balance", "derive_total_from_document"},
    "item_quantity": {"derive_quantity_from_price", "derive_quantity_from_count"},
    "document_adjustment": {"apply_document_adjustment_identity"},
}


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _hash(value):
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def _get(value, path):
    for segment in path:
        value = value[segment]
    return value


def _path(value):
    if (not isinstance(value, list) or not 1 <= len(value) <= 12
            or any(not ((type(part) is str and 0 < len(part) <= 100)
                       or (type(part) is int and 0 <= part < 1000)) for part in value)):
        raise ValueError("invalid_field_path")
    return tuple(value)


def _bounded(value):
    if type(value) is not int or abs(value) > LIMIT:
        raise ValueError("number_outside_bounded_scope")
    return value


def _money(raw):
    if type(raw) is int:
        return _bounded(raw)
    if not isinstance(raw, str) or len(raw) > 100:
        raise ValueError("invalid_printed_money")
    text = raw.strip()
    prefix = re.match(r"^(?:[Rr][Pp]\.?)\s*|^@\s*", text)
    if prefix:
        text = text[prefix.end():]
    if text == "(0)":
        return 0
    if re.fullmatch(r"-?[0-9]+", text):
        return _bounded(int(text))
    separator = "." if "." in text else ","
    groups = text.removeprefix("-").split(separator)
    if (len(groups) < 2 or not 1 <= len(groups[0]) <= 3
            or any(not re.fullmatch(r"[0-9]{3}", group) for group in groups[1:])
            or not re.fullmatch(r"[0-9]+", groups[0])):
        raise ValueError("invalid_printed_money_grouping")
    return _bounded(int(("-" if text.startswith("-") else "") + "".join(groups)))


def _count(raw):
    if type(raw) is int:
        value = raw
    elif isinstance(raw, str) and len(raw) <= 100:
        token = raw.strip()
        match = re.fullmatch(r"\(?([0-9]+)(?:[.]0+)?\)?\s*(?:[xX]\s*(?:ITEM[sS])?)?", token)
        if not match:
            raise ValueError("invalid_printed_count")
        value = int(match.group(1))
    else:
        raise ValueError("invalid_printed_count")
    if value < 0:
        raise ValueError("negative_count")
    return _bounded(value)


def _decimal(raw, *, percentage=False):
    if not isinstance(raw, str) or len(raw) > 100:
        raise ValueError("invalid_decimal_source_token")
    token = raw[:-1] if percentage and raw.endswith("%") else raw
    if percentage and not raw.endswith("%"):
        raise ValueError("discount_is_not_an_explicit_percentage")
    if not re.fullmatch(r"[+-]?[0-9]+(?:[.][0-9]+)?", token):
        raise ValueError("invalid_decimal_source_token")
    try:
        with localcontext() as context:
            context.prec = max(40, len(token) + 8)
            value = Decimal(token)
            if percentage:
                if not 0 <= value <= 100:
                    raise ValueError("discount_out_of_range")
                return Fraction(value) / 100
            cents = value * 100
            if cents != cents.to_integral_value():
                raise ValueError("fractional_cent_source_amount")
            return _bounded(int(cents))
    except InvalidOperation as exc:
        raise ValueError("invalid_decimal_source_token") from exc


def _independent_normalize(pack):
    numbers, rates, ledger = {}, {}, []
    nodes = 0
    def visit(value, path=()):
        nonlocal nodes
        nodes += 1
        if nodes > 5000 or len(path) > 12:
            raise ValueError("observed_record_exceeds_bounded_scope")
        key = path[-1] if path else None
        rule = None
        if value is not None and value != "":
            if pack["dataset"] == "ceap" and key in CEAP_MONEY:
                number = _decimal(value)
                numbers[path], rule = number, "publisher_decimal_to_integer_cents"
            elif pack["dataset"] == "cord" and key in MONEY:
                if isinstance(value, list):
                    if path != ("sub_total", "subtotal_price") or not 1 <= len(value) <= 20:
                        raise ValueError("unsupported_repeated_financial_field")
                    decoded = [_money(item) for item in value]
                    if len(set(decoded)) != 1:
                        raise ValueError("conflicting_repeated_subtotal_values")
                    number, rule = decoded[0], "equal_repeated_printed_integer_grouping"
                else:
                    number, rule = _money(value), "printed_integer_grouping"
                numbers[path] = number
            elif pack["dataset"] == "cord" and key in COUNTS:
                number, rule = _count(value), "documented_count_decoration"
                numbers[path] = number
            elif pack["dataset"] == "cord" and key == "discountprice":
                rate = _decimal(value, percentage=True)
                rates[path], number, rule = rate, str(rate), "explicit_percentage_to_exact_ratio"
        if rule:
            ledger.append({"path": list(path), "raw": value, "value": number, "rule": rule})
            return
        if isinstance(value, dict):
            if len(value) > 200 or any(type(key) is not str for key in value):
                raise ValueError("invalid_observed_object")
            for field, child in value.items():
                visit(child, (*path, field))
        elif isinstance(value, list):
            if len(value) > 1000:
                raise ValueError("observed_array_exceeds_bounded_scope")
            for index, child in enumerate(value):
                visit(child, (*path, index))
        elif isinstance(value, str) and len(value) > 10000:
            raise ValueError("observed_text_exceeds_bounded_scope")
        elif value is not None and type(value) not in (str, int, bool):
            raise ValueError("unsupported_observed_scalar")
    visit(pack["observed"])
    return numbers, rates, ledger


def _items(observed):
    menu = observed.get("menu")
    if menu is None:
        return []
    if isinstance(menu, dict):
        return [(("menu",), menu)]
    if isinstance(menu, list) and all(isinstance(item, dict) for item in menu):
        return [(("menu", index), item) for index, item in enumerate(menu)]
    raise ValueError("invalid_menu_structure")


def _eq(kind, value=None, expression="", evidence=(), reason=None):
    if value is not None:
        _bounded(value)
    return {"kind": kind, "value": value, "expression": expression,
            "evidence": [list(path) for path in evidence], "complete": value is not None, "reason": reason}


def _independent_equations(pack, numbers, rates):
    observed, target, kind = pack["observed"], tuple(pack["task"]["target_path"]), pack["task"]["kind"]
    equations, contradictions = [], []
    if kind == "document_adjustment":
        gross, glosa, net = ((field,) for field in ("vlrDocumento", "vlrGlosa", "vlrLiquido"))
        known = [path for path in (gross, glosa, net) if path != target]
        if not all(path in numbers for path in known):
            return [_eq("apply_document_adjustment_identity", reason="missing_adjustment_component")], []
        if target == gross:
            value, expression = numbers[glosa] + numbers[net], f"{numbers[glosa]} + {numbers[net]}"
        else:
            subtract = net if target == glosa else glosa
            value, expression = numbers[gross] - numbers[subtract], f"{numbers[gross]} - {numbers[subtract]}"
        return [_eq("apply_document_adjustment_identity", value, f"{expression} = {value}", known)], []
    if kind == "subtotal":
        parts = []
        def add(path, row):
            if not isinstance(row, dict):
                raise ValueError("missing_line_amount")
            field = "itemsubtotal" if "itemsubtotal" in row else "price"
            amount_path = (*path, field)
            if amount_path not in numbers:
                raise ValueError("missing_line_amount")
            parts.append((amount_path, numbers[amount_path]))
            sub = row.get("sub", [])
            if isinstance(sub, dict):
                add((*path, "sub"), sub)
            elif isinstance(sub, list):
                for index, child in enumerate(sub):
                    add((*path, "sub", index), child)
            elif sub is not None:
                raise ValueError("invalid_submenu_structure")
        try:
            for path, item in _items(observed):
                add(path, item)
        except ValueError as exc:
            return [_eq("sum_item_amounts", reason=str(exc))], []
        if not parts:
            return [_eq("sum_item_amounts", reason="no_observed_item_amounts")], []
        return [_eq("sum_item_amounts", sum(value for _, value in parts),
                    " + ".join(str(value) for _, value in parts), [path for path, _ in parts])], []
    if kind == "payment_total":
        total = observed.get("total")
        if not isinstance(total, dict):
            raise ValueError("missing_payment_section")
        cash, change, extra = ("total", "cashprice"), ("total", "changeprice"), ("total", "total_etc")
        labels = pack.get("field_labels", {})
        if not isinstance(labels, dict) or any(not isinstance(value, list) or any(type(text) is not str or len(text) > 500 for text in value) for value in labels.values()):
            raise ValueError("invalid_printed_field_labels")
        classified = any(re.fullmatch(r"coupon|voucher", label.strip(), re.I)
                         for label in labels.get("total.total_etc", []))
        if extra in numbers and numbers[extra] != 0 and not classified:
            contradictions.append("unclassified_nonzero_other_tender")
        for operation in ("solve_cash_change", "solve_tender_balance"):
            reason = None
            parts = []
            if cash not in numbers or change not in numbers:
                reason = "cash_and_change_both_required"
            else:
                parts = [(cash, numbers[cash]), (change, -numbers[change])]
                if "total_etc" in total and total["total_etc"] in (None, ""):
                    reason = "missing_other_tender"
                elif extra in numbers and numbers[extra] != 0:
                    if operation == "solve_cash_change" or not classified:
                        reason = "unclassified_other_tender"
                    else:
                        parts.append((extra, numbers[extra]))
                for field in ("creditcardprice", "emoneyprice"):
                    path = ("total", field)
                    if field in total and total[field] in (None, ""):
                        reason = "missing_other_tender"
                    elif path in numbers and numbers[path] != 0:
                        if operation == "solve_cash_change":
                            reason = "multiple_tenders_require_full_balance"
                        else:
                            parts.append((path, numbers[path]))
            equations.append(_eq(operation, reason=reason) if reason else _eq(operation,
                sum(value for _, value in parts), " + ".join(str(value) for _, value in parts), [path for path, _ in parts]))
        subtotal = observed.get("sub_total")
        subtotal_path = ("sub_total", "subtotal_price")
        if not isinstance(subtotal, dict) or subtotal_path not in numbers:
            equations.append(_eq("derive_total_from_document", reason="missing_document_subtotal"))
        else:
            parts = [(subtotal_path, numbers[subtotal_path])]
            missing = False
            for field in ("service_price", "othersvc_price", "tax_price", "discount_price"):
                path = ("sub_total", field)
                if field in subtotal and subtotal[field] in (None, ""):
                    missing = True
                elif path in numbers:
                    parts.append((path, -abs(numbers[path]) if field == "discount_price" else numbers[path]))
            if ("etc" in subtotal and subtotal["etc"] in (None, "")) or numbers.get(("sub_total", "etc"), 0) != 0:
                missing = True
                if numbers.get(("sub_total", "etc"), 0) != 0:
                    contradictions.append("unclassified_nonzero_document_adjustment")
            equations.append(_eq("derive_total_from_document", reason="missing_or_unclassified_adjustment") if missing else _eq(
                "derive_total_from_document", sum(value for _, value in parts),
                " + ".join(str(value) for _, value in parts), [path for path, _ in parts]))
        return equations, contradictions
    row_path = target[:-1]
    row = _get(observed, row_path)
    unit = (*row_path, "unitprice")
    amount = (*row_path, "itemsubtotal" if "itemsubtotal" in row else "price")
    discount_path = (*row_path, "discountprice")
    reason = None
    if unit not in numbers or amount not in numbers:
        reason = "missing_unit_or_line_amount"
    elif "itemsubtotal" in row and discount_path not in rates:
        reason = "discount_for_after_discount_amount_not_observed"
    else:
        discount = rates[discount_path] if "itemsubtotal" in row else Fraction(0)
        coefficient = numbers[unit] * (1 - discount)
        if coefficient == 0:
            reason = "zero_effective_price_does_not_identify_quantity"
            if numbers[amount] != 0:
                contradictions.append("nonzero_amount_at_zero_effective_price")
        elif coefficient < 0 or numbers[amount] <= 0:
            reason = "nonpositive_quantity_equation"
            contradictions.append(reason)
        else:
            value = Fraction(numbers[amount]) / coefficient
            if value.denominator != 1 or value <= 0:
                reason = "nonintegral_or_nonpositive_quantity"
                contradictions.append(reason)
            else:
                evidence = [unit, amount] + ([discount_path] if "itemsubtotal" in row else [])
                equations.append(_eq("derive_quantity_from_price", int(value),
                    f"{numbers[amount]} / ({numbers[unit]} * (1 - {discount})) = {int(value)}", evidence))
    if reason:
        equations.append(_eq("derive_quantity_from_price", reason=reason))
    aggregate, others = ("total", "menuqty_cnt"), []
    reason = "aggregate_quantity_not_observed" if aggregate not in numbers else None
    if reason is None:
        for path, item in _items(observed):
            if item.get("sub"):
                reason = "nested_quantity_scope_ambiguous"
                break
            if path != row_path:
                count_path = (*path, "cnt")
                if count_path not in numbers:
                    reason = "another_item_quantity_missing"
                    break
                others.append((count_path, numbers[count_path]))
        if reason is None:
            value = numbers[aggregate] - sum(value for _, value in others)
            if value <= 0:
                reason = "nonpositive_remaining_quantity"
                contradictions.append(reason)
            else:
                equations.append(_eq("derive_quantity_from_count", value,
                    f"{numbers[aggregate]} - ({' + '.join(str(value) for _, value in others) or '0'}) = {value}",
                    [aggregate, *[path for path, _ in others]]))
    if reason:
        equations.append(_eq("derive_quantity_from_count", reason=reason))
    return equations, contradictions


def _validate_pack(pack):
    if (not isinstance(pack, dict) or type(pack.get("version")) is not int
            or pack.get("version") != 1 or not isinstance(pack.get("observed"), dict)):
        raise ValueError("invalid_masked_casepack")
    task = pack.get("task")
    if not isinstance(task, dict) or set(task) != {"kind", "target_path"}:
        raise ValueError("invalid_task_contract")
    target, kind = _path(task["target_path"]), task["kind"]
    if pack.get("dataset") == "ceap":
        if kind != "document_adjustment" or len(target) != 1 or target[0] not in {"vlrDocumento", "vlrGlosa", "vlrLiquido"}:
            raise ValueError("dataset_task_target_mismatch")
    elif pack.get("dataset") == "cord":
        if kind == "subtotal":
            valid = target == ("sub_total", "subtotal_price")
        elif kind == "payment_total":
            valid = target == ("total", "total_price")
        elif kind == "item_quantity":
            valid = (target == ("menu", "cnt") or (len(target) == 3 and target[0] == "menu" and type(target[1]) is int and target[2] == "cnt"))
            valid = valid and isinstance(_get(pack["observed"], target[:-1]), dict)
        else:
            valid = False
        if not valid:
            raise ValueError("dataset_task_target_mismatch")
    else:
        raise ValueError("unsupported_dataset")
    if _get(pack["observed"], target) is not None:
        raise ValueError("target_is_not_masked")
    _canonical(pack["observed"])


def verify(pack, normalizations: list, equations: list) -> dict:
    """Check raw conversions, selected calculations, and all independent rivals."""
    result = {"passed": False, "value": None, "independent": True,
              "reason": "verification_not_completed", "hidden_labels_loaded": False,
              "normalizations_verified": False, "independent_equations": []}
    try:
        _validate_pack(pack)
        if not isinstance(normalizations, list) or len(normalizations) > 5000:
            raise ValueError("invalid_normalization_ledger")
        if not isinstance(equations, list) or len(equations) > 10:
            raise ValueError("invalid_selected_equations")
        numbers, rates, expected_ledger = _independent_normalize(pack)
        expected = {tuple(entry["path"]): entry for entry in expected_ledger}
        seen = set()
        for entry in normalizations:
            if not isinstance(entry, dict) or set(entry) != {"path", "raw", "value", "rule"}:
                raise ValueError("invalid_normalization_entry")
            path = _path(entry["path"])
            if path in seen or path not in expected:
                raise ValueError("duplicate_or_unobserved_normalization")
            if _canonical(entry) != _canonical(expected[path]):
                raise ValueError("normalization_does_not_match_original_observed_field")
            seen.add(path)
        if seen != set(expected):
            raise ValueError("incomplete_normalization_ledger")
        result.update(normalizations_verified=True, normalization_count=len(expected_ledger),
                      normalized_observed_digest=_hash(expected_ledger))
        independent, contradictions = _independent_equations(pack, numbers, rates)
        result["independent_equations"] = independent
        result["contradictions"] = contradictions
        lookup = {entry["kind"]: entry for entry in independent}
        selected_complete = 0
        selected = set()
        for equation in equations:
            if (not isinstance(equation, dict) or set(equation) != {"kind", "value", "expression", "evidence", "complete", "reason"}
                    or type(equation["complete"]) is not bool or not isinstance(equation["expression"], str)
                    or len(equation["expression"]) > 2000 or not isinstance(equation["evidence"], list)
                    or len(equation["evidence"]) > 1000
                    or (equation["reason"] is not None and (not isinstance(equation["reason"], str) or len(equation["reason"]) > 500))):
                raise ValueError("invalid_selected_equation")
            operation = equation["kind"]
            if operation not in OPS[pack["task"]["kind"]] or operation in selected:
                raise ValueError("equation_operation_not_valid_for_target")
            selected.add(operation)
            reference = lookup[operation]
            for path in equation["evidence"]:
                _path(path)
            if not equation["complete"]:
                if equation["value"] is not None or equation["expression"] or equation["evidence"]:
                    raise ValueError("incomplete_equation_contains_unsupported_result")
                continue
            _bounded(equation["value"])
            if (not reference["complete"] or equation["value"] != reference["value"]
                    or equation["expression"] != reference["expression"]
                    or _canonical(equation["evidence"]) != _canonical(reference["evidence"])):
                raise ValueError("selected_equation_not_independently_reproduced")
            selected_complete += 1
        values = {entry["value"] for entry in independent if entry["complete"]}
        result.update(selected_complete_equations=selected_complete, independent_values=sorted(values),
                      all_supported_relations_considered=True)
        if any(code.startswith("unclassified_nonzero_") for code in contradictions):
            result["reason"] = "unsupported_observed_financial_component"
        elif contradictions or len(values) > 1:
            result["reason"] = "conflicting_observed_relations"
        elif not values:
            result["reason"] = "insufficient_observed_evidence"
        elif selected_complete == 0:
            result["reason"] = "no_complete_selected_calculation"
        else:
            result.update(passed=True, value=next(iter(values)), reason="independently_reconstructed_from_observed_evidence")
    except (ValueError, TypeError, KeyError, IndexError, OverflowError, ZeroDivisionError, RecursionError) as exc:
        result["reason"] = str(exc) if isinstance(exc, ValueError) else "invalid_observed_or_execution_contract"
    return result
