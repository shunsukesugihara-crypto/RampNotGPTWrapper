"""Deterministic retail deduction matching MVP (phase 1)."""
__version__ = "0.1.0"
