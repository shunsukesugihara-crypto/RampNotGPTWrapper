"""Lossless CSV-export demonstration adapters and their separate audit reports."""
