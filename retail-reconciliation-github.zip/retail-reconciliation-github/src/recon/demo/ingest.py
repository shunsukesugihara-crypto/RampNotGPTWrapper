"""Known CSV column mappings only; financial normalization remains a model tool."""
from __future__ import annotations

import csv
import hashlib
import io
from pathlib import Path
import re

MAX_BUNDLE_BYTES = 1024 * 1024
MAX_SOURCE_ROWS = 2000
FILES = {
    "notice": "deduction_notice.csv", "products": "product_master.csv",
    "purchase_orders": "purchase_order_export.csv", "invoices": "invoice_header_export.csv",
    "invoice_lines": "invoice_detail_export.csv", "shipments": "shipment_header_export.csv",
    "shipment_lines": "shipment_detail_export.csv", "receipts": "receiving_export.csv",
}
ALIASES = {
    "notice": {
        "deduction_id": ("Deduction ID", "Claim Number"), "retailer": ("Retailer", "Customer Name"),
        "notice_date": ("Notice Date", "Claim Date"), "amount": ("Deduction Amount", "Claim Amount"),
        "currency": ("Currency", "Currency Code"), "short_qty": ("Short Quantity", "Missing Qty"),
        "uom": ("Quantity UOM", "Claim Unit"), "scope": ("Claim Scope", "Line Scope"),
        "basis": ("Allocation Basis", "Financial Basis"), "po_hint": ("PO Reference", "Purchase Order Ref"),
        "invoice_hint": ("Invoice Reference", "Invoice Ref"), "sku_hint": ("Product Reference", "Item Ref"),
        "description": ("Claim Description", "Deduction Memo"),
    },
    "products": {"sku": ("SKU", "Item Code"), "description": ("Product Description", "Item Name"),
                 "case_pack": ("Units Per Case", "Case Pack"), "source_ref": ("Master Source Reference", "Pack Evidence Ref")},
    "purchase_orders": {"po_id": ("PO Number", "Purchase Order"), "retailer": ("Retailer", "Customer Name"),
                        "order_date": ("Order Date", "PO Date")},
    "invoices": {"invoice_id": ("Invoice Number", "Invoice ID"), "po_id": ("PO Number", "Purchase Order"),
                 "invoice_date": ("Invoice Date", "Billing Date"), "currency": ("Currency", "Currency Code")},
    "invoice_lines": {"invoice_line_id": ("Invoice Line ID", "Line Reference"), "invoice_id": ("Invoice Number", "Invoice ID"),
                      "sku": ("SKU", "Item Code"), "quantity": ("Invoiced Qty", "Billed Quantity"), "uom": ("Qty UOM", "Quantity Unit"),
                      "unit_price": ("Unit Price", "Price Per Unit"), "price_uom": ("Price UOM", "Price Unit"),
                      "currency": ("Currency", "Currency Code")},
    "shipments": {"shipment_id": ("Shipment ID", "Dispatch Reference"), "po_id": ("PO Number", "Purchase Order"),
                  "ship_date": ("Ship Date", "Dispatch Date")},
    "shipment_lines": {"shipment_id": ("Shipment ID", "Dispatch Reference"), "sku": ("SKU", "Item Code"),
                       "quantity": ("Shipped Qty", "Dispatched Quantity"), "uom": ("Qty UOM", "Quantity Unit")},
    "receipts": {"receipt_id": ("Receipt ID", "Receiving Reference"), "shipment_id": ("Shipment ID", "Dispatch Reference"),
                 "sku": ("SKU", "Item Code"), "quantity": ("Received Qty", "Receiving Quantity"),
                 "uom": ("Qty UOM", "Quantity Unit"), "receipt_date": ("Receipt Date", "Received Date")},
}
KEYS = {"notice": ("deduction_id",), "products": ("sku",), "purchase_orders": ("po_id",),
        "invoices": ("invoice_id",), "invoice_lines": ("invoice_line_id",), "shipments": ("shipment_id",),
        "shipment_lines": ("shipment_id", "sku"), "receipts": ("receipt_id",)}
NULLABLE = {("notice", key) for key in ("amount", "short_qty", "po_hint", "invoice_hint", "sku_hint", "description", "basis")}
NULLABLE |= {("products", "case_pack"), ("products", "source_ref"), ("products", "description")}
CONVENTIONS = {
    "encoding": "UTF-8; an optional leading BOM belongs to the header, not a cell",
    "blank_cells": "Empty cells are null only in explicitly nullable fields; empty strings are not a second missing-value convention",
    "text_cells": "Money, quantities, dates, units, currencies and identifiers stay exact text; no trimming or repairs",
    "declared_integer": "Only products.case_pack is an integer metadata field; canonical base-10 syntax is required",
    "csv_rows": "row counts logical records with the header at row 1; physical line ranges are also retained",
}


def _files(folder: Path) -> dict[str, bytes]:
    if not folder.is_dir():
        raise ValueError("CSV source bundle must be a directory")
    if {path.name for path in folder.iterdir()} != set(FILES.values()):
        raise ValueError("CSV source bundle must contain exactly the eight approved exports")
    files, size = {}, 0
    for table, filename in FILES.items():
        path = folder / filename
        if not path.resolve().is_relative_to(folder.resolve()) or not path.is_file():
            raise ValueError("CSV source paths must remain inside their bundle")
        with path.open("rb") as stream:
            content = stream.read(MAX_BUNDLE_BYTES + 1)
        size += len(content)
        if size > MAX_BUNDLE_BYTES:
            raise ValueError("CSV source bundle exceeds one MiB")
        files[table] = content
    return files


def _headers(table, header):
    if not header or len(header) != len(set(header)):
        raise ValueError("Missing or duplicate CSV column")
    lookup = {name: field for field, names in ALIASES[table].items() for name in (field, *names)}
    if any(name not in lookup for name in header):
        raise ValueError("Unknown CSV column; unmodeled facts cannot be silently discarded")
    mapped = [lookup[name] for name in header]
    if len(set(mapped)) != len(mapped) or set(mapped) != set(ALIASES[table]):
        raise ValueError("CSV columns must map exactly once to every declared source field")
    return mapped


def import_bundle(bundle_dir: str | Path) -> dict:
    """Map known columns without solving, normalizing, joining or reading labels."""
    folder = Path(bundle_dir)
    content = _files(folder)
    data, mapping, sources, total_rows = {"version": 1}, [], [], 0
    for table, body in content.items():
        try:
            reader = csv.reader(io.StringIO(body.decode("utf-8-sig"), newline=""), strict=True)
            header = next(reader)
            fields = _headers(table, header)
            records, seen = [], set()
            while True:
                start = reader.line_num + 1
                try:
                    cells = next(reader)
                except StopIteration:
                    break
                if len(cells) != len(header):
                    raise ValueError("CSV row length differs from its header")
                record = {}
                for column, field, cell in zip(header, fields, cells):
                    operation, value = "map_csv_column", cell
                    if cell == "":
                        if (table, field) not in NULLABLE:
                            raise ValueError("Required CSV field is blank")
                        value, operation = None, "blank_to_null"
                    elif (table, field) == ("products", "case_pack"):
                        if not re.fullmatch(r"-?(?:0|[1-9][0-9]*)", cell) or len(cell) > 20 or str(int(cell)) != cell:
                            raise ValueError("Case pack must use its declared integer format")
                        value, operation = int(cell), "parse_declared_integer"
                    record[field] = value
                    mapping.append({"file": FILES[table], "sha256": hashlib.sha256(body).hexdigest(),
                                    "row": len(records) + 2, "physical_line_start": start, "physical_line_end": reader.line_num,
                                    "column": column, "field": field, "table": table, "canonical_row": len(records),
                                    "json_path": f"$.notice.{field}" if table == "notice" else f"$.{table}[{len(records)}].{field}",
                                    "raw": cell, "value": value, "operation": operation})
                key = tuple(record[field] for field in KEYS[table])
                if key in seen:
                    raise ValueError("Duplicate source identity in CSV export")
                seen.add(key)
                for cell_mapping in mapping[-len(fields):]:
                    cell_mapping["record_key"] = {field: record[field] for field in KEYS[table]}
                records.append(record)
                if table != "notice":
                    total_rows += 1
                if total_rows > MAX_SOURCE_ROWS:
                    raise ValueError("CSV source bundle exceeds the row limit")
            if table == "notice" and len(records) != 1:
                raise ValueError("Exactly one notice is required per CSV bundle")
            data[table] = records[0] if table == "notice" else records
            sources.append({"file": FILES[table], "table": table, "sha256": hashlib.sha256(body).hexdigest(),
                            "bytes": len(body), "rows": len(records)})
        except (UnicodeError, csv.Error, StopIteration):
            raise ValueError("Malformed UTF-8 CSV source export") from None
    return {"data": data, "mapping": mapping, "sources": sources, "issues": [],
            "importer_checks": {"approved_files_only": True, "approved_columns_only": True,
                                "one_to_one_columns": True, "unique_source_identities": True,
                                "source_paths_contained": True, "known_null_and_type_conventions": True},
            "conventions": dict(CONVENTIONS)}


def audit_bundle(bundle_dir: str | Path, data: dict) -> dict:
    """Independent cell iteration and inverse serialization, not a second import.

    This reads with DictReader and compares every raw cell to the representation
    required by its proposed JSON value. It never calls the importer or its cell
    conversion logic, and checks independently that no columns/rows/facts vanish.
    """
    folder, issues, cell_count, file_hashes = Path(bundle_dir), [], 0, {}
    try:
        if set(data) != {"version", *FILES} or type(data["version"]) is not int or data["version"] != 1:
            raise ValueError("Derived source has an unexpected schema")
        if {path.name for path in folder.iterdir()} != set(FILES.values()):
            raise ValueError("Source export file set differs")
        total_bytes = total_rows = 0
        for table, filename in FILES.items():
            path = folder / filename
            if not path.is_file() or not path.resolve().is_relative_to(folder.resolve()):
                raise ValueError("Audit source path leaves bundle")
            with path.open("rb") as stream:
                body = stream.read(MAX_BUNDLE_BYTES + 1)
            total_bytes += len(body)
            if total_bytes > MAX_BUNDLE_BYTES:
                raise ValueError("Audit source size limit exceeded")
            file_hashes[filename] = hashlib.sha256(body).hexdigest()
            reader = csv.DictReader(io.StringIO(body.decode("utf-8-sig"), newline=""), strict=True)
            headers = reader.fieldnames or []
            if len(set(headers)) != len(headers):
                raise ValueError("Audit found duplicate source columns")
            # Reverse mapping is built from the declared export vocabulary,
            # independently of the importer's header/cell conversion helpers.
            by_field = {}
            for field, alternatives in ALIASES[table].items():
                matching = [name for name in headers if name == field or name in alternatives]
                if len(matching) != 1:
                    raise ValueError("Audit requires exactly one column per field")
                by_field[field] = matching[0]
            if set(headers) != set(by_field.values()):
                raise ValueError("Audit found an unaccounted source column")
            proposed = [data["notice"]] if table == "notice" else data[table]
            if not isinstance(proposed, list) or table == "notice" and not isinstance(data["notice"], dict):
                raise ValueError("Derived table has wrong shape")
            seen, count = set(), 0
            for index, cells in enumerate(reader):
                if None in cells or any(value is None for value in cells.values()) or index >= len(proposed):
                    raise ValueError("Source and derived row counts or widths differ")
                record = proposed[index]
                if not isinstance(record, dict) or set(record) != set(by_field):
                    raise ValueError("Derived row loses or invents fields")
                key = tuple(record[field] for field in KEYS[table])
                if key in seen:
                    raise ValueError("Audit found duplicate derived source identity")
                seen.add(key)
                for field, column in by_field.items():
                    value = record[field]
                    if value is None:
                        if (table, field) not in NULLABLE:
                            raise ValueError("Audit found invented null in required field")
                        expected_cell = ""
                    elif (table, field) == ("products", "case_pack"):
                        if type(value) is not int:
                            raise ValueError("Audit found a changed declared integer type")
                        expected_cell = str(value)
                    else:
                        if not isinstance(value, str) or value == "":
                            raise ValueError("Audit found a changed raw text type")
                        expected_cell = value
                    cell_count += 1
                    if cells[column] != expected_cell:
                        issues.append({"code": "cell_disagreement", "file": filename, "row": index + 2,
                                       "column": column, "field": field})
                count += 1
            if count != len(proposed) or table == "notice" and count != 1:
                raise ValueError("Audit found lost or invented source rows")
            if table != "notice":
                total_rows += count
        if total_rows > MAX_SOURCE_ROWS:
            raise ValueError("Audit source row limit exceeded")
    except (ValueError, TypeError, KeyError, UnicodeError, csv.Error, OSError) as exc:
        issues.append({"code": "audit_failed", "error_type": type(exc).__name__})
    return {"passed": not issues, "method": "independent_csv_cell_iteration_and_inverse_serialization",
            "checks": {"all_cells_accounted_for": not issues, "no_lost_rows_or_fields": not issues,
                       "no_financial_normalization": not issues, "paths_and_source_limits_checked": not issues},
            "cell_count": cell_count, "source_hashes": file_hashes, "issues": issues}
