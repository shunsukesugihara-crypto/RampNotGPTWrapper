"""Freeze CSV views of existing authored facts; never manufacture new answers."""
from __future__ import annotations

from copy import deepcopy
import csv
import hashlib
import json
from pathlib import Path
import random

from recon.reconstruction.data import load_pack
from recon.reconstruction.evaluate import load_corpus
from .ingest import ALIASES, CONVENTIONS, FILES, KEYS, NULLABLE, audit_bundle, import_bundle


def _digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _inside(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Corpus source paths must remain inside the selected root")
    return path


def _cell(table, field, value):
    if value is None and (table, field) in NULLABLE:
        return ""
    if (table, field) == ("products", "case_pack") and type(value) is int:
        return str(value)
    if not isinstance(value, str) or value == "":
        raise ValueError("Original source value cannot be represented losslessly by this CSV contract")
    return value


def _business_equal(original, derived):
    if set(original) != set(derived) or original["version"] != derived["version"] or original["notice"] != derived["notice"]:
        return False
    for table in FILES:
        if table == "notice":
            continue
        key = lambda row: tuple(row[field] for field in KEYS[table])
        # Canonical JSON serialization also distinguishes numeric types, whereas
        # Python equality alone would conflate True/1 and 12/12.0.
        left = [json.dumps(row, sort_keys=True, allow_nan=False) for row in sorted(original[table], key=key)]
        right = [json.dumps(row, sort_keys=True, allow_nan=False) for row in sorted(derived[table], key=key)]
        if left != right:
            return False
    return True


def build_demo_corpus(source_dir: str | Path, destination: str | Path) -> dict:
    source_dir, destination = Path(source_dir), Path(destination)
    original_manifest, index, _, freeze = load_corpus(source_dir)
    if destination.exists():
        raise ValueError("Demo corpus destination already exists; frozen exports are never overwritten")
    destination.mkdir(parents=True)
    for name in ("bundles", "cases", "imports"):
        (destination / name).mkdir()
    output_index, cell_count = [], 0
    for case_id, metadata in index.items():
        if not case_id or Path(case_id).name != case_id or case_id in {".", ".."}:
            raise ValueError("Case IDs cannot contain paths")
        source_path = _inside(source_dir, metadata["raw_path"])
        raw = load_pack(source_path)
        bundle_relative = f"bundles/{case_id}"
        bundle = destination / bundle_relative
        bundle.mkdir()
        for table, filename in FILES.items():
            seed = int.from_bytes(hashlib.sha256(f"demo-csv-v1:{case_id}:{table}".encode()).digest(), "big")
            rng = random.Random(seed)
            fields = list(ALIASES[table])
            rng.shuffle(fields)
            headers = [rng.choice(ALIASES[table][field]) for field in fields]
            records = [deepcopy(raw.data["notice"])] if table == "notice" else deepcopy(raw.data[table])
            rng.shuffle(records)
            with (bundle / filename).open("w", newline="", encoding="utf-8-sig") as stream:
                writer = csv.writer(stream, lineterminator="\r\n")
                writer.writerow(headers)
                for record in records:
                    if set(record) != set(fields):
                        raise ValueError("Original source schema contains unsupported fields")
                    writer.writerow([_cell(table, field, record[field]) for field in fields])
        imported = import_bundle(bundle)
        audit = audit_bundle(bundle, imported["data"])
        equal = _business_equal(raw.data, imported["data"])
        if not audit["passed"] or not equal:
            raise ValueError("CSV export/import audit changed original business facts")
        case_relative, audit_relative = f"cases/{case_id}.json", f"imports/{case_id}.json"
        (destination / case_relative).write_text(json.dumps(imported["data"], sort_keys=True, indent=2) + "\n", encoding="utf-8")
        sidecar = {"case_id": case_id, "source_bundle_path": bundle_relative,
                   "original_source": {"path": metadata["raw_path"], "sha256": raw.source_digest},
                   **{key: imported[key] for key in ("mapping", "sources", "issues", "importer_checks", "conventions")},
                   "audit": audit, "business_facts_preserved": equal,
                   "business_comparison": "Exact field values/types by source identity; only CSV row/column order changes"}
        (destination / audit_relative).write_text(json.dumps(sidecar, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        output_index.append({**metadata, "original_raw_path": metadata["raw_path"],
                             "original_raw_sha256": metadata["raw_sha256"], "raw_path": case_relative,
                             "raw_sha256": _digest(destination / case_relative),
                             "source_bundle_path": bundle_relative, "import_audit_path": audit_relative})
        cell_count += audit["cell_count"]
    (destination / "index.jsonl").write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in output_index), encoding="utf-8")
    (destination / "labels.jsonl").write_bytes((source_dir / "labels.jsonl").read_bytes())
    files = {str(path.relative_to(destination)): _digest(path) for path in sorted(destination.rglob("*")) if path.is_file()}
    manifest = {**{key: deepcopy(value) for key, value in original_manifest.items() if key not in {"files", "raw_facts", "source"}},
                "files": files, "source": "CSV exports derived losslessly from the frozen authored reconstruction corpus",
                "raw_facts": "Eight separate CSV exports with allowlisted aliases, shuffled rows/columns, quoted comma text, blank nulls and unchanged money/date/unit text",
                "original_frozen_corpus": {"manifest_sha256": freeze["manifest_sha256"], "files": freeze["files"]},
                "original_labels_sha256": _digest(source_dir / "labels.jsonl"),
                "source_bundle_count": len(output_index), "csv_file_count": len(output_index) * len(FILES),
                "audited_cell_count": cell_count, "all_import_audits_passed": True,
                "business_facts_preserved": True, "financial_normalization_performed": False,
                "csv_conventions": dict(CONVENTIONS),
                "derivation": "CSV export/import changes storage layout only; no changed financial facts, labels or expected answers"}
    (destination / "manifest.json").write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    if load_corpus(source_dir)[3] != freeze:
        raise ValueError("Original source corpus changed during derivation")
    load_corpus(destination)
    return manifest
