"""Local demo UI backed by fresh evidence-reconstruction and comparison runs.

Run ``PYTHONPATH=src python -m recon.web`` and open the printed localhost URL.
AI constructs the method in the default mode. An explicitly selected offline
mode remains available as a control. Model output never contains executable code.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import hashlib
import re
from pathlib import Path
from time import perf_counter
from threading import Lock
from uuid import uuid4

from .ai.provider import create_provider
from .ai.service import reconcile as ai_reconcile
from .phase2.executor import RapidFuzzRanker
from .phase2.planner import OfflinePlanner
from .phase2.service import reconcile
from .phase2.storage import load_data
from .reconstruction.data import load_pack
from .reconstruction.service import reconcile as reconstruct

ROOT = Path(__file__).resolve().parents[2]
MAX_BODY_BYTES = 4096
CASES = (
    {"deduction_id": "D-DEMO-PO", "title": "Known purchase order",
     "description": "Run the synthetic shortage notice with an explicit purchase-order reference."},
    {"deduction_id": "D-DEMO-AMBIG", "title": "Same-price ambiguity",
     "description": "Run a synthetic notice whose amount fits more than one product."},
)
ALLOWED_IDS = frozenset(case["deduction_id"] for case in CASES)


def reconstruction_catalog(folder: Path) -> tuple[list[dict], dict]:
    """Expose a small source-only catalog; evaluation labels are never read."""
    index = folder / "index.jsonl"
    if not index.is_file():
        return [], {}
    titles = {
        "unique_two_line": ("Combined invoice lines", "Reconstruct a deduction spread across multiple invoice lines."),
        "heldout_missing_quantity_mixed_units": ("Missing quantity + mixed units", "Use source conversion records and receiving evidence."),
        "mixed_units": ("Receiving units differ", "Receipts and invoices record quantities in different units."),
        "ambiguous_two_line": ("Competing combinations", "Check all supported combinations before deciding."),
        "missing_conversion": ("Missing conversion record", "A required product conversion factor is absent."),
    }
    rows = [json.loads(line) for line in index.read_text().splitlines() if line.strip()]
    cases, sources = [], {}
    for family, (title, description) in titles.items():
        row = next((r for r in rows if r.get("family") == family and r.get("split") == "heldout"), None)
        if row is None:
            continue
        path = (folder / row["raw_path"]).resolve()
        if not path.is_relative_to(folder.resolve()) or hashlib.sha256(path.read_bytes()).hexdigest() != row["raw_sha256"]:
            raise ValueError("Reconstruction source catalog failed its integrity check")
        raw = load_pack(path)
        key = raw.data["notice"]["deduction_id"]
        if key in ALLOWED_IDS or key in sources:
            raise ValueError("Duplicate reconstruction notice")
        cases.append({"deduction_id": key, "title": title, "description": description,
                      "source_kind": "reconstruction_pack"})
        sources[key] = {"path": path, "sha256": row["raw_sha256"]}
    return cases, sources


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("Duplicate JSON field")
        value[key] = item
    return value


def _invalid_constant(value):
    raise ValueError("Nonstandard JSON constant")


class LocalServer(ThreadingHTTPServer):
    """Factory-created loopback server; paths are server configuration only."""

    daemon_threads = True

    def __init__(self, *, port: int, data_dir: Path, index_path: Path,
                 planner_mode: str = "ai", provider=None, provider_kind: str = "auto"):
        self.data_dir = data_dir
        self.index_path = index_path
        self.planner_mode = planner_mode
        self.provider = provider
        self._workspace_application = None
        self._workspace_lock = Lock()
        extra_cases, self.reconstruction_sources = reconstruction_catalog(ROOT / "evaluation/reconstruction") if planner_mode == "ai" else ([], {})
        self.cases = [*extra_cases, *CASES]
        self.allowed_ids = frozenset(case["deduction_id"] for case in self.cases)
        if planner_mode == "ai" and self.provider is None:
            try:
                self.provider = create_provider(provider_kind)
            except Exception:
                # Configuration failure stays visible; never substitute rules.
                self.provider = None
        try:
            self.ranker = RapidFuzzRanker()
        except ImportError:
            self.ranker = None
        self.text_ranking = {
            "available": self.ranker is not None,
            "enabled": self.ranker is not None,
            "name": self.ranker.name if self.ranker is not None else None,
            "advisory_only": True,
        }
        super().__init__(("127.0.0.1", port), LocalHandler)


class LocalHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, format, *args):
        # Keep raw request text and financial records out of server logs.
        pass

    def _send(self, status: int, body: bytes, content_type: str):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        self.wfile.write(body)

    def _json(self, status: int, value: dict):
        self._send(status, json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _error(self, status: int, code: str, message: str):
        self._json(status, {"error": {"code": code, "message": message}})

    def _valid_host(self) -> bool:
        hosts = self.headers.get_all("Host", [])
        port = self.server.server_port
        return len(hosts) == 1 and hosts[0].lower() in {f"127.0.0.1:{port}", f"localhost:{port}"}

    def _workspace(self):
        with self.server._workspace_lock:
            if self.server._workspace_application is None:
                from .workspace.http import WorkspaceApp
                self.server._workspace_application = WorkspaceApp(ROOT)
            return self.server._workspace_application

    def do_GET(self):
        if not self._valid_host():
            self._error(403, "invalid_host", "Use this app through its localhost URL.")
            return
        if self.path.startswith("/api/workspace"):
            self._workspace().get(self)
            return
        if self.path == "/":
            try:
                content = self.server.index_path.read_bytes()
            except OSError:
                self._error(503, "ui_unavailable", "The local app page is unavailable.")
                return
            self._send(200, content, "text/html; charset=utf-8")
        elif self.path in {"/investigate", "/investigate/", "/workspace", "/workspace/"}:
            try:
                content = (ROOT / "web/workspace.html").read_bytes()
            except OSError:
                self._error(503, "ui_unavailable", "The investigation page is unavailable.")
                return
            self._send(200, content, "text/html; charset=utf-8")
        elif self.path in {"/map/", "/demo-investigation/"}:
            filename = "index.html" if self.path == "/map/" else "investigation.html"
            try:
                self._send(200, (ROOT / "web" / filename).read_bytes(), "text/html; charset=utf-8")
            except OSError:
                self._error(503, "ui_unavailable", "The legacy demonstration page is unavailable.")
        elif self.path == "/api/investigation/cases":
            from .investigation.fixtures import catalog
            self._json(200, {"cases": catalog(), "ai_available": self.server.provider is not None,
                             "data_kind": "authored_synthetic", "live_ai": None})
        elif self.path in {"/research/", "/research/overview.html", "/research/report.html", "/research/cord.html", "/research/ceap.html", "/research/cord_extra_redaction.html", "/research/report.json", "/research/protocol.json", "/research/study_history.json"}:
            try:
                pointer = json.loads((ROOT / "output/experiments/latest_run.json").read_text())
                run_id = pointer["run_id"]
                if not isinstance(run_id, str) or not re.fullmatch(r"[0-9a-f-]{36}", run_id):
                    raise ValueError("Invalid saved study identity")
                filename = "overview.html" if self.path == "/research/" else self.path.rsplit("/", 1)[1]
                folder = (ROOT / "output/experiments" / run_id).resolve()
                path = (folder / filename).resolve()
                if not folder.is_relative_to((ROOT / "output/experiments").resolve()) or not path.is_relative_to(folder):
                    raise ValueError("Invalid saved study path")
                content_type = "application/json; charset=utf-8" if filename.endswith(".json") else "text/html; charset=utf-8"
                self._send(200, path.read_bytes(), content_type)
            except (OSError, ValueError, KeyError):
                self._error(503, "study_unavailable", "The public-data study has not completed yet.")
        elif self.path == "/api/cases":
            self._json(200, {"cases": self.server.cases,
                             "planner": "model_controller" if self.server.planner_mode == "ai" else "offline_policy",
                             "planner_mode": self.server.planner_mode,
                             "ai_available": self.server.provider is not None,
                             "provider": type(self.server.provider).__name__ if self.server.provider is not None else None,
                             "live_ai": None, "data_kind": "synthetic_fixture",
                             "text_ranking": self.server.text_ranking})
        else:
            self._error(404, "not_found", "This route does not exist.")

    def do_POST(self):
        if not self._valid_host():
            self._error(403, "invalid_host", "Use this app through its localhost URL.")
            return
        origins = self.headers.get_all("Origin", [])
        host = self.headers["Host"].lower()
        if ((origins and (len(origins) != 1 or origins[0] != f"http://{host}"))
                or self.headers.get("Sec-Fetch-Site", "").lower() == "cross-site"):
            self._error(403, "invalid_origin", "Runs must originate from this local app.")
            return
        if self.path not in {"/api/run", "/api/investigation/run"} and not self.path.startswith("/api/workspace/"):
            self._error(404, "not_found", "This route does not exist.")
            return
        if self.headers.get("Transfer-Encoding") is not None:
            self._error(400, "unsupported_transfer_encoding", "Send a JSON body with Content-Length.")
            return
        types = self.headers.get_all("Content-Type", [])
        if (len(types) != 1 or self.headers.get_content_type() != "application/json"
                or self.headers.get_content_charset("utf-8").lower() != "utf-8"):
            self._error(415, "unsupported_content_type", "Send UTF-8 application/json.")
            return
        lengths = self.headers.get_all("Content-Length", [])
        if not lengths:
            self._error(411, "length_required", "Content-Length is required.")
            return
        if len(lengths) != 1 or not lengths[0].isascii() or not lengths[0].isdecimal():
            self._error(400, "invalid_content_length", "Content-Length must be a single byte count.")
            return
        if len(lengths[0]) > 10:
            self._error(413, "body_too_large", "The run request is too large.")
            return
        length = int(lengths[0])
        limit = 16 * 1024 * 1024 if self.path.startswith("/api/workspace/") else MAX_BODY_BYTES
        if length > limit:
            self._error(413, "body_too_large", "The run request is too large.")
            return
        try:
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise ValueError("Incomplete request body")
            request = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object,
                                 parse_constant=_invalid_constant)
        except (UnicodeError, ValueError, RecursionError, TimeoutError, OSError):
            self._error(400, "invalid_json", "Send one valid JSON object.")
            return
        if self.path.startswith("/api/workspace/"):
            self._workspace().post(self, request)
            return
        if self.path == "/api/investigation/run":
            self._run_investigation(request)
            return
        if (not isinstance(request, dict) or set(request) != {"deduction_id"}
                or not isinstance(request["deduction_id"], str)):
            self._error(400, "invalid_request", "The request must contain only a deduction_id string.")
            return
        if request["deduction_id"] not in self.server.allowed_ids:
            self._error(400, "unknown_case", "Choose an available demo case.")
            return
        run_id, started_at, start = str(uuid4()), _utc_now(), perf_counter()
        if self.server.planner_mode == "ai" and self.server.provider is None:
            self._error(503, "planner_unavailable", "Configure a model provider. Rules are not substituted for AI.")
            return
        conn = None
        try:
            # Re-read the CSVs on every click; never return a saved fixture result.
            source = self.server.reconstruction_sources.get(request["deduction_id"])
            if source is not None:
                raw = load_pack(source["path"])
                if raw.source_digest != source["sha256"]:
                    raise ValueError("Raw source changed after catalog publication")
                result = reconstruct(raw, provider=self.server.provider)
            elif self.server.planner_mode == "ai":
                conn = load_data(self.server.data_dir)
                result = ai_reconcile(conn, request["deduction_id"], provider=self.server.provider,
                                      ranker=self.server.ranker)
            else:
                conn = load_data(self.server.data_dir)
                result = reconcile(conn, request["deduction_id"], planner=OfflinePlanner(), ranker=self.server.ranker)
        except Exception:
            self._error(500, "run_failed", "The local run failed. Check the source files and try again.")
            return
        finally:
            if conn is not None:
                conn.close()
        self._json(200, {"run_id": run_id, "started_at": started_at, "completed_at": _utc_now(),
                         "elapsed_ms": round((perf_counter() - start) * 1000, 3),
                         "planner": result["planner"], "planner_mode": self.server.planner_mode,
                         "live_ai": result.get("live_ai", False),
                         "text_ranking": self.server.text_ranking, "result": result})

    def _run_investigation(self, request):
        from .investigation.fixtures import catalog, load_case
        from .investigation.service import run_case

        if (not isinstance(request, dict) or set(request) != {"case_id", "mode"}
                or not isinstance(request["case_id"], str)
                or not isinstance(request["mode"], str)
                or request["mode"] not in {"ai", "fixed", "direct"}):
            self._error(400, "invalid_request", "Choose one case and one investigation method.")
            return
        if request["case_id"] not in {case["id"] for case in catalog()}:
            self._error(400, "unknown_case", "Choose an available investigation case.")
            return
        if request["mode"] != "fixed" and self.server.provider is None:
            self._error(503, "planner_unavailable", "The model connection is unavailable. No fixed policy was substituted.")
            return
        run_id, started_at, start = str(uuid4()), _utc_now(), perf_counter()
        try:
            raw = load_case(request["case_id"])
            result = run_case(raw, provider=self.server.provider, mode=request["mode"])
            response = {"run_id": run_id, "started_at": started_at, "completed_at": _utc_now(),
                        "elapsed_ms": round((perf_counter() - start) * 1000, 3),
                        "case_id": request["case_id"], "mode": request["mode"],
                        "data_kind": "authored_synthetic", "result": result}
            folder = ROOT / "output/investigation_runs"
            folder.mkdir(parents=True, exist_ok=True)
            path = folder / f"{run_id}.json"
            temporary = path.with_suffix(".json.tmp")
            temporary.write_text(json.dumps(response, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
            temporary.replace(path)
        except Exception:
            self._error(500, "investigation_failed", "The investigation failed. No financial answer was accepted.")
            return
        self._json(200, response)

    def do_OPTIONS(self):
        self._error(405, "method_not_allowed", "Use the app's GET and POST routes.")


def create_server(*, port: int = 8765, data_dir: str | Path | None = None,
                  index_path: str | Path | None = None, planner_mode: str = "ai",
                  provider=None, provider_kind: str = "auto") -> LocalServer:
    """Create an unstarted localhost server; port zero chooses an ephemeral port."""
    if type(port) is not int or not 0 <= port <= 65535:
        raise ValueError("port must be an integer from 0 to 65535")
    if planner_mode not in {"ai", "offline"}:
        raise ValueError("planner_mode must be ai or offline")
    return LocalServer(port=port, data_dir=Path(data_dir) if data_dir is not None else ROOT / "data",
                       index_path=Path(index_path) if index_path is not None else ROOT / "web" / "workspace.html",
                       planner_mode=planner_mode, provider=provider, provider_kind=provider_kind)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--mode", choices=("ai", "offline"), default="ai")
    parser.add_argument("--provider", choices=("auto", "openai", "codex"), default="auto")
    args = parser.parse_args()
    from .workspace.environment import load_environment
    try:
        load_environment(ROOT / ".env")
        server = create_server(port=args.port, planner_mode=args.mode, provider_kind=args.provider)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    print(f"Open http://127.0.0.1:{server.server_port}/ (local upload workspace; explicit model settings in the app)", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
