"""Command line entry point. No LLM call and no dependency on external services."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from .storage import load_data
from .engine import reconcile, reconcile_all


def main() -> None:
    parser = argparse.ArgumentParser(description="Evidence-based retail deduction matching MVP")
    parser.add_argument("--data", default="data", help="Directory of CSV tables")
    parser.add_argument("--deduction", help="Analyze one deduction ID (otherwise all)")
    parser.add_argument("--output", help="Write JSON result to file")
    args = parser.parse_args()
    conn = load_data(args.data)
    result = reconcile(conn, args.deduction) if args.deduction else reconcile_all(conn)
    content = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output).write_text(content + "\n", encoding="utf-8")
        print(f"Saved {args.output}")
    else:
        print(content)

if __name__ == "__main__":
    main()
