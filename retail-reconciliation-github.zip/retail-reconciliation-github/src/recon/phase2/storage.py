"""Phase 2 ingestion permits absent notice facts, without changing Phase 1."""
from __future__ import annotations

import csv
from datetime import date
import hashlib
import json
from pathlib import Path
import sqlite3

from recon.storage import DDL, TABLES


def load_data(path: str | Path) -> sqlite3.Connection:
    ddl = DDL.replace("amount_cents INTEGER NOT NULL", "amount_cents INTEGER")
    ddl = ddl.replace("short_qty INTEGER NOT NULL", "short_qty INTEGER")
    ddl = ddl.replace("reason TEXT NOT NULL,description TEXT NOT NULL", "reason TEXT NOT NULL,description TEXT")
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(ddl)
    try:
        for table, columns_string in TABLES.items():
            columns = columns_string.split(",")
            with (Path(path) / f"{table}.csv").open(newline="", encoding="utf-8") as stream:
                reader = csv.DictReader(stream)
                if reader.fieldnames != columns:
                    raise ValueError(f"Bad schema for {table}: expected {columns}; got {reader.fieldnames}")
                rows = [[record[column] if record[column] != "" else None for column in columns]
                        for record in reader]
            conn.executemany(f"INSERT INTO {table} ({columns_string}) VALUES ({','.join('?' for _ in columns)})", rows)
        conn.commit()
        return conn
    except Exception:
        conn.close()
        raise


def source_digest(conn: sqlite3.Connection) -> str:
    """Hash business records only. Labels are never read or stored here."""
    rows = {table: [list(row) for row in conn.execute(f"SELECT {columns} FROM {table} ORDER BY {columns}")]
            for table, columns in TABLES.items()}
    return hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest()


def is_iso_date(value: object) -> bool:
    if not isinstance(value, str) or len(value) != 10:
        return False
    try:
        return date.fromisoformat(value).isoformat() == value
    except ValueError:
        return False


def source_issues(conn: sqlite3.Connection) -> list[str]:
    """SQLite uses flexible types; don't assume INTEGER declarations ensure ints."""
    numeric = {"quantity", "unit_price_cents", "shipped_qty", "received_qty", "amount_cents", "short_qty"}
    issues = []
    for table, columns in TABLES.items():
        for row in conn.execute(f"SELECT {columns} FROM {table}"):
            for field in row.keys():
                value = row[field]
                if table == "deductions" and field in {"amount_cents", "short_qty", "description"} and value is None:
                    continue
                if field in numeric and (type(value) is not int or value < (0 if field == "received_qty" else 1)):
                    issues.append(f"{table}.{field}: invalid integer quantity or cents")
                if field.endswith("_date") and not is_iso_date(value):
                    issues.append(f"{table}.{field}: invalid ISO date")
    over_received = conn.execute("""
        SELECT COUNT(*) FROM receipts r JOIN shipment_lines s USING(shipment_id, sku)
        WHERE r.received_qty > s.shipped_qty
    """).fetchone()[0]
    if over_received:
        issues.append("receipts.received_qty: exceeds recorded shipped quantity")
    return sorted(set(issues))
