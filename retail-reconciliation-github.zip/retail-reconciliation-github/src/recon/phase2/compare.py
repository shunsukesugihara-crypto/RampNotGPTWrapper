"""Compare the unchanged rules baseline with the offline Phase 2 procedure planner.

Labels stay in this module: neither matcher nor planner receives expected answers.
The additional challenges are deliberately small synthetic regression scenarios,
not independent retail evidence or a benchmark of a live language model.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from dataclasses import dataclass
import json
from pathlib import Path
import sqlite3

from ..engine import reconcile as baseline_reconcile
from ..storage import load_data as baseline_load_data
from .service import reconcile
from .storage import load_data


@dataclass(frozen=True)
class ChallengeExpectation:
    deduction_id: str
    scenario: str
    true_invoice_line_id: str
    true_shipment_id: str
    baseline_status: str
    phase2_status: str
    derived_short_qty: int | None = None
    claim_assessment: str | None = None


# Explicit expected transaction IDs are authored separately from source records.
# These values are used only after both engines finish their work.
CHALLENGE_EXPECTATIONS = (
    ChallengeExpectation("D-P2-MISSING-QTY", "missing_quantity_with_po_and_receipt",
                         "LINE-P2-MISSING-QTY-A", "SHP-P2-MISSING-QTY-A", "unsupported", "matched", 15),
    ChallengeExpectation("D-P2-EXACT-TEXT", "exact_description_resolves_same_price",
                         "LINE-P2-EXACT-TEXT-A", "SHP-P2-EXACT-TEXT-A", "review", "matched"),
    ChallengeExpectation("D-P2-GENERIC", "generic_description_same_price_ambiguity",
                         "LINE-P2-GENERIC-A", "SHP-P2-GENERIC-A", "review", "review"),
    ChallengeExpectation("D-P2-NO-RECEIPT", "missing_quantity_and_receipt",
                         "LINE-P2-NO-RECEIPT-A", "SHP-P2-NO-RECEIPT-A", "unsupported", "review"),
    ChallengeExpectation("D-P2-NO-AMOUNT", "missing_amount",
                         "LINE-P2-NO-AMOUNT-A", "SHP-P2-NO-AMOUNT-A", "unsupported", "review"),
    ChallengeExpectation("D-P2-FUZZY", "fuzzy_description_collision",
                         "LINE-P2-FUZZY-A", "SHP-P2-FUZZY-A", "review", "review"),
    ChallengeExpectation("D-P2-UNIQUE", "no_reference_unique_financial_and_receipt_evidence",
                         "LINE-P2-UNIQUE-A", "SHP-P2-UNIQUE-A", "matched", "matched"),
    ChallengeExpectation("D-P2-CONFLICT", "known_quantity_with_contradictory_receipt",
                         "LINE-P2-CONFLICT-A", "SHP-P2-CONFLICT-A", "matched", "matched",
                         claim_assessment="receiving_records_do_not_support_claimed_quantity"),
)


def build_challenges(conn: sqlite3.Connection) -> tuple[ChallengeExpectation, ...]:
    """Append isolated business records to a disposable Phase 2 connection.

    New retailers isolate each scenario from the unchanged original fixture and
    from other scenarios. No expected-answer table is created in the database.
    """
    conn.executemany(
        "INSERT INTO products (sku, description) VALUES (?, ?)",
        [("SKU-P2-WATER", "Sparkling Water Variety Pack 12 x 355mL"),
         ("SKU-P2-SODA", "Soda Assortment 12 x 355mL"),
         ("SKU-P2-WATER-ALT", "Sparkling Water Variety Pack 24 x 355mL"),
         ("SKU-P2-TEA", "Citrus Tea Case")],
    )
    # Source records: suffix, SKU, unit price in cents, shipped and received cases.
    transactions = (
        ("MISSING-QTY-A", "SKU-P2-WATER", 6000, 100, 85),
        ("EXACT-TEXT-A", "SKU-P2-WATER", 6000, 100, 85),
        ("EXACT-TEXT-B", "SKU-P2-SODA", 6000, 90, 75),
        ("GENERIC-A", "SKU-P2-WATER", 6000, 100, 85),
        ("GENERIC-B", "SKU-P2-SODA", 6000, 90, 75),
        ("NO-RECEIPT-A", "SKU-P2-WATER", 6000, 100, None),
        ("NO-AMOUNT-A", "SKU-P2-WATER", 6000, 100, 85),
        ("FUZZY-A", "SKU-P2-WATER", 6000, 100, 85),
        ("FUZZY-B", "SKU-P2-WATER-ALT", 6000, 90, 75),
        ("UNIQUE-A", "SKU-P2-WATER", 6000, 100, 85),
        ("UNIQUE-B", "SKU-P2-TEA", 4500, 90, 75),
        ("CONFLICT-A", "SKU-P2-WATER", 6000, 100, 100),
    )
    for suffix, sku, price, shipped, received in transactions:
        retailer = "Challenge " + suffix.rsplit("-", 1)[0]
        po, invoice, shipment = f"PO-P2-{suffix}", f"INV-P2-{suffix}", f"SHP-P2-{suffix}"
        conn.execute("INSERT INTO purchase_orders VALUES (?, ?, ?)", (po, retailer, "2026-08-01"))
        conn.execute("INSERT INTO invoices VALUES (?, ?, ?)", (invoice, po, "2026-08-02"))
        conn.execute("INSERT INTO invoice_lines VALUES (?, ?, ?, ?, ?)",
                     (f"LINE-P2-{suffix}", invoice, sku, shipped, price))
        conn.execute("INSERT INTO shipments VALUES (?, ?, ?)", (shipment, po, "2026-08-03"))
        conn.execute("INSERT INTO shipment_lines VALUES (?, ?, ?)", (shipment, sku, shipped))
        if received is not None:
            conn.execute("INSERT INTO receipts VALUES (?, ?, ?, ?)",
                         (shipment, sku, received, "2026-08-05"))

    # Notices contain reported facts only. Missing values remain SQL NULL.
    notices = (
        ("MISSING-QTY", 90000, None, "Short shipment", "PO-P2-MISSING-QTY-A"),
        ("EXACT-TEXT", 90000, 15, "Sparkling Water Variety Pack 12 x 355mL", None),
        ("GENERIC", 90000, 15, "Assorted beverages", None),
        ("NO-RECEIPT", 90000, None, "Short shipment", "PO-P2-NO-RECEIPT-A"),
        ("NO-AMOUNT", None, 15, "Short shipment", "PO-P2-NO-AMOUNT-A"),
        ("FUZZY", 90000, 15, "Sparkling Water Variety Pack", None),
        ("UNIQUE", 90000, 15, "Short shipment", None),
        ("CONFLICT", 90000, 15, "Short shipment", "PO-P2-CONFLICT-A"),
    )
    for suffix, amount, quantity, description, po_hint in notices:
        conn.execute(
            "INSERT INTO deductions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (f"D-P2-{suffix}", f"Challenge {suffix}", "2026-08-15", amount, quantity,
             "shortage", description, None, po_hint, None, None),
        )
    conn.commit()
    return CHALLENGE_EXPECTATIONS


def _baseline_result(conn: sqlite3.Connection, deduction_id: str) -> dict:
    notice = conn.execute("SELECT * FROM deductions WHERE deduction_id=?", (deduction_id,)).fetchone()
    missing = [field for field in ("amount_cents", "short_qty", "description") if notice[field] is None]
    if missing:
        # The Phase 1 loader requires these fields; do not change its schema or
        # fabricate a baseline result for inputs outside that engine's domain.
        return {"deduction_id": deduction_id, "status": "unsupported", "candidates": [],
                "reason": "outside_phase1_required_input_schema", "missing_required_fields": missing}
    return baseline_reconcile(conn, deduction_id)


def _link_correct(result: dict, label: dict) -> bool | None:
    if result["status"] != "matched":
        return None
    if len(result.get("candidates", [])) != 1:
        raise ValueError("A matched result must contain exactly one chosen candidate")
    candidate = result["candidates"][0]
    return (candidate["invoice_line_id"] == label["true_invoice_line_id"] and
            candidate["shipment_id"] == label["true_shipment_id"])


def _summarize(results: list[dict], labels: dict[str, dict]) -> dict:
    counts = Counter(result["status"] for result in results)
    unknown = set(counts) - {"matched", "review", "no_match", "unsupported"}
    if unknown:
        raise ValueError(f"Unknown result statuses: {sorted(unknown)}")
    correct = wrong = 0
    for result in results:
        is_correct = _link_correct(result, labels[result["deduction_id"]])
        correct += is_correct is True
        wrong += is_correct is False
    total = len(results)
    supported = total - counts["unsupported"]
    automatic = correct + wrong
    abstentions = counts["review"] + counts["no_match"]
    return {
        "total_cases": total,
        "supported_cases": supported,
        "unsupported_cases": counts["unsupported"],
        "status_counts": dict(counts),
        "correct_automatic_links": correct,
        "incorrect_automatic_links": wrong,
        "automatic_link_precision": correct / automatic if automatic else None,
        "automatic_link_coverage": automatic / total if total else 0,
        "automatic_link_coverage_supported_cases": automatic / supported if supported else None,
        "abstention_count": abstentions,
        "abstention_rate_supported_cases": abstentions / supported if supported else None,
    }


def _reported_result(result: dict, label: dict) -> dict:
    fields = ("status", "reason", "notice", "claim_assessment", "candidates", "plan", "planner",
              "profile", "trace", "verification", "missing_required_fields")
    return {**{key: result[key] for key in fields if key in result},
            "automatic_link_correct": _link_correct(result, label)}


def _read_labels(path: str | Path) -> dict[str, dict]:
    with Path(path).open(newline="", encoding="utf-8") as stream:
        labels = {}
        reader = csv.DictReader(stream)
        required = {"deduction_id", "true_invoice_line_id", "true_shipment_id"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("Evaluation labels require deduction and expected transaction IDs")
        for row in reader:
            if row["deduction_id"] in labels:
                raise ValueError(f"Duplicate evaluation label: {row['deduction_id']}")
            labels[row["deduction_id"]] = row
    return labels


def compare(data_dir: str | Path, labels_path: str | Path) -> dict:
    """Run two separate comparisons; never pool unlike baseline applicability."""
    labels = _read_labels(labels_path)
    baseline_conn = baseline_load_data(data_dir)
    phase2_conn = load_data(data_dir)
    try:
        ids = [row[0] for row in baseline_conn.execute("SELECT deduction_id FROM deductions ORDER BY deduction_id")]
        if set(ids) != set(labels):
            raise ValueError("Evaluation labels must cover exactly the source deduction IDs")
        baseline_results = [baseline_reconcile(baseline_conn, key) for key in ids]
        phase2_results = [reconcile(phase2_conn, key) for key in ids]
        original_rows = [
            {"deduction_id": key, "scenario": labels[key].get("scenario"),
             "baseline": _reported_result(before, labels[key]),
             "phase2": _reported_result(after, labels[key])}
            for key, before, after in zip(ids, baseline_results, phase2_results)
        ]
        expectations = build_challenges(phase2_conn)
        challenge_labels = {
            case.deduction_id: {"true_invoice_line_id": case.true_invoice_line_id,
                                "true_shipment_id": case.true_shipment_id}
            for case in expectations
        }
        challenge_baseline, challenge_phase2, challenge_rows = [], [], []
        for case in expectations:
            before = _baseline_result(phase2_conn, case.deduction_id)
            after = reconcile(phase2_conn, case.deduction_id)
            label = challenge_labels[case.deduction_id]
            challenge_baseline.append(before)
            challenge_phase2.append(after)
            expectation_met = before["status"] == case.baseline_status and after["status"] == case.phase2_status
            if before["status"] == "matched":
                expectation_met = expectation_met and _link_correct(before, label) is True
            if after["status"] == "matched":
                expectation_met = expectation_met and _link_correct(after, label) is True
            if case.derived_short_qty is not None:
                expectation_met = expectation_met and bool(after.get("candidates")) and (
                    after["candidates"][0].get("derived_short_qty") == case.derived_short_qty)
            if case.claim_assessment is not None:
                expectation_met = expectation_met and after.get("claim_assessment") == case.claim_assessment
            challenge_rows.append({
                "deduction_id": case.deduction_id,
                "scenario": case.scenario,
                "baseline_supported": before["status"] != "unsupported",
                "expected_baseline_status": case.baseline_status,
                "expected_phase2_status": case.phase2_status,
                "expected_transaction": label,
                "expectation_met": bool(expectation_met),
                "baseline": _reported_result(before, label),
                "phase2": _reported_result(after, label),
            })
        return {
            "dataset": "Synthetic fixture and authored synthetic challenges; not real retail transactions",
            "planner": "offline_policy",
            "live_ai_evaluated": False,
            "scope_notes": [
                f"The original fixture is shared by both engines without changing its {len(ids)} source notices or labels.",
                "Additional challenges are regression examples, not evidence of real-world generalization.",
                "Unsupported baseline inputs are counted separately from review and no_match.",
                "Coverage uses all cases; coverage on supported inputs is also reported explicitly.",
                "Precision measures transaction linking, not claim validity or recovered dollars.",
                "No live language-model planning or semantic-model performance is measured here.",
            ],
            "original_fixture": {
                "case_count": len(ids),
                "baseline": _summarize(baseline_results, labels),
                "phase2": _summarize(phase2_results, labels),
                "cases": original_rows,
            },
            "synthetic_challenges": {
                "case_count": len(expectations),
                "unsupported_baseline": sum(r["status"] == "unsupported" for r in challenge_baseline),
                "baseline": _summarize(challenge_baseline, challenge_labels),
                "phase2": _summarize(challenge_phase2, challenge_labels),
                "all_expectations_met": all(row["expectation_met"] for row in challenge_rows),
                "applicability": challenge_rows,
            },
        }
    finally:
        baseline_conn.close()
        phase2_conn.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default="data")
    parser.add_argument("--truth", default="evaluation/ground_truth.csv")
    parser.add_argument("--output", help="Write the complete comparison and candidate evidence as JSON")
    args = parser.parse_args()
    report = compare(args.data, args.truth)
    serialized = json.dumps(report, indent=2)
    if args.output:
        target = Path(args.output)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(serialized + "\n", encoding="utf-8")
        summary = {"output": str(target), "planner": report["planner"],
                   "original_fixture": {key: value for key, value in report["original_fixture"].items() if key != "cases"},
                   "synthetic_challenges": {key: value for key, value in report["synthetic_challenges"].items() if key != "applicability"}}
        print(json.dumps(summary, indent=2))
    else:
        print(serialized)


if __name__ == "__main__":
    main()
