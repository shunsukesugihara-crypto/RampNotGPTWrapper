"""Only these Python implementations execute. Plans contain no executable text."""
from __future__ import annotations

from dataclasses import dataclass
import math

from recon.engine import Candidate, generate_candidates
from .analysis import analyze, quantity_for, respects_references
from .contracts import MethodPlan, Op, TextRanker, normalize_description


@dataclass(frozen=True)
class Hypothesis:
    candidate: Candidate
    quantity: int | None = None
    quantity_source: str = "not_computed"
    text_score: float | None = None

    @property
    def key(self) -> tuple[str, str, str]:
        return self.candidate.invoice_line_id, self.candidate.shipment_id, self.candidate.sku


@dataclass(frozen=True)
class Execution:
    hypotheses: tuple[Hypothesis, ...]
    trace: tuple[dict, ...]


class RapidFuzzRanker:
    """Lexical similarity, NOT semantic understanding or financial evidence."""
    name = "rapidfuzz.WRatio"

    def __init__(self):
        from rapidfuzz.fuzz import WRatio
        self._score = WRatio

    def score(self, query: str, description: str) -> float:
        return float(self._score(normalize_description(query), normalize_description(description)))


def execute(conn, notice: dict, plan: MethodPlan, *, ranker: TextRanker | None = None) -> Execution:
    plan.validate(analyze(conn, notice, text_ranking_available=ranker is not None))
    hypotheses: list[Hypothesis] = []
    trace = []
    for op in plan.operations:
        before = len(hypotheses)
        rejected = []
        if op == Op.JOIN:
            hypotheses = [Hypothesis(candidate) for candidate in generate_candidates(conn, notice)]
        elif op == Op.REFERENCES:
            rejected = [item.key for item in hypotheses if not respects_references(notice, item.candidate)]
            hypotheses = [item for item in hypotheses if respects_references(notice, item.candidate)]
        elif op in {Op.AMOUNT, Op.DERIVE_QUANTITY}:
            result = []
            for item in hypotheses:
                qty = quantity_for(notice, item.candidate)
                if qty is None:
                    rejected.append(item.key)
                else:
                    result.append(Hypothesis(item.candidate, qty, "reported" if op == Op.AMOUNT else "amount_divided_by_invoice_price"))
            hypotheses = result
        elif op == Op.EXACT_DESCRIPTION:
            description = normalize_description(notice["description"])
            rejected = [item.key for item in hypotheses if normalize_description(item.candidate.product_description) != description]
            hypotheses = [item for item in hypotheses if normalize_description(item.candidate.product_description) == description]
        elif op == Op.RANK_TEXT:
            result = []
            for item in hypotheses:
                try:
                    score = ranker.score(notice["description"], item.candidate.product_description)
                except Exception:
                    raise ValueError("Text ranking adapter failed") from None
                if type(score) not in (float, int) or not math.isfinite(score) or not 0 <= score <= 100:
                    raise ValueError("Text ranker must return a finite score in [0, 100]")
                result.append(Hypothesis(item.candidate, item.quantity, item.quantity_source, score))
            hypotheses = sorted(result, key=lambda item: (-item.text_score, item.key))
        elif op == Op.VERIFY:
            # Marker only: the service ALWAYS calls the independent verifier below.
            # It is deliberately outside this executor and cannot be skipped by it.
            continue
        trace.append({"operation": op.value, "input_count": before, "output_count": len(hypotheses),
                      "rejected_keys": rejected,
                      "advisory_only": op == Op.RANK_TEXT,
                      "tool": ranker.name if op == Op.RANK_TEXT else "sqlite" if op == Op.JOIN else "python_integer_arithmetic" if op in {Op.AMOUNT, Op.DERIVE_QUANTITY} else "python"})
    return Execution(tuple(hypotheses), tuple(trace))
