"""Method planners choose trusted operations, never financial record matches.

The offline planner is a deterministic policy for demos and comparisons. The
OpenAI planner makes a real structured-output request only when explicitly
configured; an unavailable model never silently becomes the offline policy.
"""
from __future__ import annotations

import json
import os
from typing import Callable
import urllib.error
import urllib.request

from .contracts import DataProfile, MethodPlan, Op, PLAN_SCHEMA, PlanError, PlannerUnavailable


class OfflinePlanner:
    """Transparent data-dependent policy; this is not an LLM implementation."""

    name = "offline_policy"

    def plan(self, profile: DataProfile) -> MethodPlan:
        operations = [Op.JOIN]
        if profile.reference_fields:
            operations.append(Op.REFERENCES)
        operations.append(Op.DERIVE_QUANTITY if "short_qty" in profile.missing_fields else Op.AMOUNT)
        if profile.financially_consistent_count > 1:
            if profile.exact_description_sku_count > 0:
                operations.append(Op.EXACT_DESCRIPTION)
            elif "description" in profile.present_fields and profile.text_ranking_available:
                operations.append(Op.RANK_TEXT)
        operations.append(Op.VERIFY)
        plan = MethodPlan(tuple(operations))
        plan.validate(profile)
        return plan


_INSTRUCTIONS = """You construct a method for reconciling one retail shortage deduction.
Return only a version-1 recipe matching the supplied JSON schema. You receive
aggregate field availability and relationship statistics, not financial rows.
Never return matches, record identifiers, financial values, SQL, Python, or
invented facts. Select operations according to this profile:
- join_records must be first: execute a fixed retailer/order/invoice/shipment join.
- filter_references must follow if and only if reference_fields is nonempty:
  check every supplied PO, invoice, shipment, and SKU reference for equality.
- Use exactly one arithmetic operation: check_amount when short_qty is present;
  derive_quantity when short_qty is missing. The executor derives an integer
  candidate quantity from the recorded amount and invoice price; it does not
  fill in a reported fact. Missing amount_cents is unsupported.
- If financially_consistent_count exceeds one and exact_description_sku_count
  exceeds zero, match_exact_description may compare normalized catalog text.
  Otherwise rank_description may rank ambiguous records only if a description
  is available and text_ranking_available is true. Ranking is advisory evidence
  and can never establish an automatic financial match. Do not use both text
  operations. Do not add text operations for an unambiguous case.
- verify_records must be last: ordinary code independently reads original
  financial records, enforces hard constraints and requires documentary or
  receiving corroboration. It decides matched/review/no_match; you do not.
Operations are unique and follow join, references, arithmetic, optional text,
verification order. No operation accepts parameters or executable code.
"""


class OpenAIPlanner:
    """Optional Responses API adapter using only the Python standard library.

    Configure a model explicitly or with OPENAI_MODEL. OPENAI_API_KEY is read
    when planning, unless api_key was provided. An injected transport accepts a
    request payload and returns a Responses-shaped dictionary; it is intended
    for tests and needs neither credentials nor network access.
    """

    def __init__(
        self,
        model: str | None = None,
        api_key: str | None = None,
        transport: Callable[[dict], dict] | None = None,
        timeout: float = 30,
    ) -> None:
        selected_model = model if model is not None else os.environ.get("OPENAI_MODEL")
        if not isinstance(selected_model, str) or not selected_model.strip():
            raise PlannerUnavailable("Configure a planner model with model or OPENAI_MODEL")
        if timeout <= 0 or timeout > 60:
            raise ValueError("Planner timeout must be greater than zero and at most 60 seconds")
        self.model = selected_model.strip()
        self.name = f"openai:{self.model}"
        self._api_key = api_key
        self._transport = transport
        self._timeout = timeout

    def plan(self, profile: DataProfile) -> MethodPlan:
        if "amount_cents" in profile.missing_fields:
            raise PlanError("Missing deduction amount; cannot construct this method")
        payload = {
            "model": self.model,
            "store": False,
            "max_output_tokens": 2048,
            "input": [
                {"role": "system", "content": [{"type": "input_text", "text": _INSTRUCTIONS}]},
                {"role": "user", "content": [{"type": "input_text", "text": json.dumps(profile.to_dict())}]},
            ],
            "text": {"format": {
                "type": "json_schema", "name": "reconciliation_method",
                "strict": True, "schema": PLAN_SCHEMA,
            }},
        }
        try:
            response = self._transport(payload) if self._transport is not None else self._request(payload)
        except PlannerUnavailable:
            raise
        except Exception:
            # Provider/network exception strings may contain credentials or raw
            # response content. Neither belongs in a case's evidence report.
            raise PlannerUnavailable("Planner request failed") from None
        plan = MethodPlan.from_dict(self._extract_recipe(response))
        plan.validate(profile)
        return plan

    def _request(self, payload: dict) -> dict:
        api_key = self._api_key if self._api_key is not None else os.environ.get("OPENAI_API_KEY")
        if not isinstance(api_key, str) or not api_key.strip():
            raise PlannerUnavailable("Configure OPENAI_API_KEY to use the model planner")
        request = urllib.request.Request(
            "https://api.openai.com/v1/responses",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self._timeout) as response:
                return json.load(response)
        except (urllib.error.URLError, OSError, UnicodeError, ValueError):
            raise PlannerUnavailable("Planner API request failed") from None

    @staticmethod
    def _extract_recipe(response: object) -> object:
        if not isinstance(response, dict):
            raise PlanError("Planner response must be an object")
        if response.get("status") != "completed" or response.get("error"):
            raise PlannerUnavailable("Planner did not complete a method")
        output = response.get("output")
        if not isinstance(output, list):
            raise PlanError("Planner response is missing output messages")
        texts = []
        for item in output:
            if not isinstance(item, dict):
                raise PlanError("Invalid planner output item")
            if item.get("type") == "reasoning":
                continue
            if item.get("type") != "message" or item.get("role") != "assistant":
                raise PlanError("Only structured assistant messages are supported")
            if item.get("status", "completed") != "completed":
                raise PlannerUnavailable("Planner message was incomplete")
            content = item.get("content")
            if not isinstance(content, list):
                raise PlanError("Planner message is missing content")
            for part in content:
                if not isinstance(part, dict):
                    raise PlanError("Invalid planner message content")
                if part.get("type") == "refusal":
                    raise PlannerUnavailable("Planner declined to construct a method")
                if part.get("type") != "output_text" or not isinstance(part.get("text"), str):
                    raise PlanError("Only JSON recipe text is supported")
                texts.append(part["text"])
        if len(texts) != 1:
            raise PlanError("Planner must return exactly one recipe")
        try:
            return json.loads(texts[0], object_pairs_hook=_unique_keys)
        except (ValueError, TypeError):
            raise PlanError("Planner returned invalid or ambiguous recipe JSON") from None


def _unique_keys(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result
