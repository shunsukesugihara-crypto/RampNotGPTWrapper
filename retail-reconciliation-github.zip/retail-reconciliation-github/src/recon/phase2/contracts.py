"""Small, versioned recipe language. No code, SQL, IDs, or invented facts."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
import re
from typing import Protocol


class PlanError(ValueError):
    pass


class PlannerUnavailable(RuntimeError):
    pass


class Op(str, Enum):
    JOIN = "join_records"
    REFERENCES = "filter_references"
    AMOUNT = "check_amount"
    DERIVE_QUANTITY = "derive_quantity"
    EXACT_DESCRIPTION = "match_exact_description"
    RANK_TEXT = "rank_description"
    VERIFY = "verify_records"


def normalize_description(value: str | None) -> str:
    # Deliberately only equality after case/spacing/punctuation normalization.
    return " ".join(re.findall(r"\w+", (value or "").casefold()))


@dataclass(frozen=True)
class DataProfile:
    present_fields: tuple[str, ...]
    missing_fields: tuple[str, ...]
    reference_fields: tuple[str, ...]
    candidate_count: int
    financially_consistent_count: int
    distinct_skus: int
    exact_description_sku_count: int
    receipt_count: int
    text_ranking_available: bool
    available_fields: dict[str, tuple[str, ...]]
    relationships: tuple[str, ...] = (
        "purchase_orders -> invoices -> invoice_lines -> products",
        "purchase_orders -> shipments -> shipment_lines",
        "shipment_lines -> receipts (optional)",
    )

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class MethodPlan:
    operations: tuple[Op, ...]
    version: int = 1

    def __post_init__(self) -> None:
        if not isinstance(self.operations, tuple) or not all(isinstance(op, Op) for op in self.operations):
            raise PlanError("Operations must be a tuple of typed allowlisted operators")

    @classmethod
    def from_dict(cls, value: object) -> MethodPlan:
        if not isinstance(value, dict) or set(value) != {"version", "operations"}:
            raise PlanError("Recipe must contain only version and operations")
        if type(value["version"]) is not int or value["version"] != 1:
            raise PlanError("Unsupported recipe version")
        steps = value["operations"]
        if not isinstance(steps, list) or not 3 <= len(steps) <= 6:
            raise PlanError("Recipe must contain 3..6 operations")
        ops = []
        for step in steps:
            if not isinstance(step, dict) or set(step) != {"op"}:
                raise PlanError("Each operation contains only an allowlisted op name")
            try:
                ops.append(Op(step["op"]))
            except (TypeError, ValueError) as exc:
                raise PlanError("Unsupported operation") from exc
        return cls(tuple(ops))

    def to_dict(self) -> dict:
        return {"version": self.version, "operations": [{"op": op.value} for op in self.operations]}

    def validate(self, profile: DataProfile) -> None:
        # Roundtrip validates even objects supplied by an in-process planner.
        MethodPlan.from_dict(self.to_dict())
        ops = self.operations
        if ops[0] != Op.JOIN or ops[-1] != Op.VERIFY or len(set(ops)) != len(ops):
            raise PlanError("Join first, verification last, and no duplicate operations")
        ranks = {Op.JOIN: 0, Op.REFERENCES: 1, Op.AMOUNT: 2, Op.DERIVE_QUANTITY: 2,
                 Op.EXACT_DESCRIPTION: 3, Op.RANK_TEXT: 3, Op.VERIFY: 4}
        if [ranks[op] for op in ops] != sorted(ranks[op] for op in ops):
            raise PlanError("Operations violate data dependencies")
        arithmetic = Op.DERIVE_QUANTITY if "short_qty" in profile.missing_fields else Op.AMOUNT
        if arithmetic not in ops or (Op.AMOUNT in ops and Op.DERIVE_QUANTITY in ops):
            raise PlanError("Use exactly the arithmetic operation appropriate to the available quantity")
        if "amount_cents" in profile.missing_fields:
            raise PlanError("Missing deduction amount; cannot construct this method")
        if bool(profile.reference_fields) != (Op.REFERENCES in ops):
            raise PlanError("Every provided reference must be checked")
        if Op.EXACT_DESCRIPTION in ops and profile.exact_description_sku_count == 0:
            raise PlanError("No exact catalog description available")
        if Op.RANK_TEXT in ops and (not profile.text_ranking_available or "description" in profile.missing_fields):
            raise PlanError("Description ranking unavailable")
        if Op.RANK_TEXT in ops and Op.EXACT_DESCRIPTION in ops:
            raise PlanError("Choose exact comparison or advisory ranking, not both")


class Planner(Protocol):
    name: str

    def plan(self, profile: DataProfile) -> MethodPlan: ...


class TextRanker(Protocol):
    name: str

    def score(self, query: str, description: str) -> float: ...


PLAN_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "version": {"type": "integer", "enum": [1]},
        "operations": {
            "type": "array", "minItems": 3, "maxItems": 6,
            "items": {"type": "object", "additionalProperties": False,
                      "properties": {"op": {"type": "string", "enum": [op.value for op in Op]}},
                      "required": ["op"]},
        },
    },
    "required": ["version", "operations"],
}
