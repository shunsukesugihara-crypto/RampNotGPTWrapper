"""Explicit Phase 2 entry point. recon.cli remains the rules-only baseline."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from .contracts import PlannerUnavailable
from .executor import RapidFuzzRanker
from .planner import OfflinePlanner, OpenAIPlanner
from .service import reconcile, reconcile_all
from .storage import load_data


def main() -> None:
    parser = argparse.ArgumentParser(description="Typed method planning and evidence verification")
    parser.add_argument("--data", default="data")
    parser.add_argument("--deduction")
    parser.add_argument("--planner", choices=("offline", "openai"), default="offline",
                        help="offline is an adaptive deterministic policy, not AI")
    parser.add_argument("--model", help="Required for openai unless OPENAI_MODEL is set")
    parser.add_argument("--rank-text", action="store_true", help="Enable optional RapidFuzz advisory ranking")
    parser.add_argument("--output")
    args = parser.parse_args()
    try:
        planner = OpenAIPlanner(model=args.model) if args.planner == "openai" else OfflinePlanner()
        ranker = RapidFuzzRanker() if args.rank_text else None
    except (PlannerUnavailable, ImportError) as exc:
        parser.error(str(exc))
    conn = load_data(args.data)
    try:
        result = reconcile(conn, args.deduction, planner=planner, ranker=ranker) if args.deduction else reconcile_all(conn, planner=planner, ranker=ranker)
    finally:
        conn.close()
    content = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output).write_text(content, encoding="utf-8")
        print(f"Saved {args.output}")
    else:
        print(content, end="")


if __name__ == "__main__":
    main()
