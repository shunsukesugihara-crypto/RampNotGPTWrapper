"""Describe evidence availability before a planner selects any method."""
from __future__ import annotations

from recon.engine import Candidate, generate_candidates
from recon.storage import TABLES
from .contracts import DataProfile, normalize_description

REFERENCE_FIELDS = {"po_hint": "po_id", "invoice_hint": "invoice_id",
                    "shipment_hint": "shipment_id", "sku_hint": "sku"}


def respects_references(notice: dict, candidate: Candidate) -> bool:
    return all(notice[field] is None or notice[field] == getattr(candidate, target)
               for field, target in REFERENCE_FIELDS.items())


def quantity_for(notice: dict, candidate: Candidate) -> int | None:
    amount = notice["amount_cents"]
    if type(amount) is not int or amount <= 0:
        return None
    quantity = notice["short_qty"]
    if quantity is None:
        if amount % candidate.unit_price_cents:
            return None
        quantity = amount // candidate.unit_price_cents
    if type(quantity) is not int or not 0 < quantity <= min(candidate.invoiced_qty, candidate.shipped_qty):
        return None
    return quantity if quantity * candidate.unit_price_cents == amount else None


def analyze(conn, notice: dict, *, text_ranking_available: bool = False) -> DataProfile:
    candidates = generate_candidates(conn, notice)
    financial = [candidate for candidate in candidates
                 if respects_references(notice, candidate) and quantity_for(notice, candidate) is not None]
    exact = {candidate.sku for candidate in financial
             if normalize_description(notice["description"])
             and normalize_description(notice["description"]) == normalize_description(candidate.product_description)}
    return DataProfile(
        present_fields=tuple(key for key, value in notice.items() if value is not None and value != ""),
        missing_fields=tuple(key for key, value in notice.items() if value is None or value == ""),
        reference_fields=tuple(field for field in REFERENCE_FIELDS if notice[field] is not None),
        candidate_count=len(candidates), financially_consistent_count=len(financial),
        distinct_skus=len({candidate.sku for candidate in financial}),
        exact_description_sku_count=len(exact),
        receipt_count=sum(candidate.received_qty is not None for candidate in financial),
        text_ranking_available=text_ranking_available,
        available_fields={table: tuple(columns.split(',')) for table, columns in TABLES.items()},
    )
