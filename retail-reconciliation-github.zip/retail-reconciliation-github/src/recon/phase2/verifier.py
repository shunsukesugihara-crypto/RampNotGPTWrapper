"""Re-read independent business records; never trust executor or model outcomes.

This repeats essential constraints intentionally. The executor's claimed filters,
derived values, similarity scores, or empty result cannot establish correctness.
Receipts corroborate shortage observations, never legal liability.
"""
from __future__ import annotations

from dataclasses import asdict
from datetime import date, timedelta

from recon.engine import Candidate
from .analysis import analyze
from .contracts import MethodPlan, Op, PlanError, normalize_description
from .executor import Execution
from .storage import source_digest


VERIFY_SQL = """
SELECT il.invoice_line_id, i.invoice_id, i.po_id, il.sku, p.description AS product_description,
       s.shipment_id, s.ship_date, il.unit_price_cents, il.quantity AS invoiced_qty,
       sl.shipped_qty, r.received_qty, r.receipt_date, i.invoice_date, po.order_date
FROM invoice_lines il
JOIN invoices i ON il.invoice_id=i.invoice_id
JOIN purchase_orders po ON i.po_id=po.po_id
JOIN products p ON il.sku=p.sku
JOIN shipments s ON s.po_id=po.po_id
JOIN shipment_lines sl ON sl.shipment_id=s.shipment_id AND sl.sku=il.sku
LEFT JOIN receipts r ON r.shipment_id=sl.shipment_id AND r.sku=sl.sku
WHERE po.retailer=?
ORDER BY il.invoice_line_id, s.shipment_id
"""


def _source(conn, table: str, keys: dict) -> dict:
    # Table names and field names are call-site constants, never plan parameters.
    where = " AND ".join(f"{key}=?" for key in keys)
    row = conn.execute(f"SELECT * FROM {table} WHERE {where}", tuple(keys.values())).fetchone()
    return {"table": table, "key": keys, "values": dict(row) if row else None}


def verify(conn, notice: dict, plan: MethodPlan, execution: Execution, *, expected_digest: str) -> dict:
    if source_digest(conn) != expected_digest:
        return {"status": "review", "reason": "source_records_changed", "candidates": [],
                "claim_assessment": "not_assessed", "verification": {"passed": False}}
    stored_notice = conn.execute("SELECT * FROM deductions WHERE deduction_id=?", (notice["deduction_id"],)).fetchone()
    if stored_notice is None or dict(stored_notice) != notice:
        return {"status": "review", "reason": "notice_source_disagreement", "candidates": [],
                "claim_assessment": "not_assessed", "verification": {"passed": False}}
    notice = dict(stored_notice)
    # The verifier receives the proposed method too; it must not trust its shape.
    try:
        MethodPlan.from_dict(plan.to_dict()).validate(analyze(
            conn, dict(stored_notice), text_ranking_available=Op.RANK_TEXT in plan.operations))
    except PlanError:
        return {"status": "review", "reason": "invalid_plan", "candidates": [],
                "claim_assessment": "not_assessed", "verification": {"passed": False}}
    rows = conn.execute(VERIFY_SQL, (notice["retailer"],)).fetchall()
    survivors, rejected = [], []
    cutoff = date.fromisoformat(notice["notice_date"]) - timedelta(days=120)
    for record in rows:
        row = dict(record)
        checks, failures = [], []
        shipment_date = date.fromisoformat(row["ship_date"])
        chronology = (date.fromisoformat(row["order_date"]) <= shipment_date <= date.fromisoformat(notice["notice_date"])
                      and shipment_date >= cutoff
                      and row["order_date"] <= row["invoice_date"] <= notice["notice_date"])
        (checks if chronology else failures).append("order_invoice_shipment_chronology")
        checks.extend(["retailer_matches", "invoice_po_shipment_linked"])
        for field, target in (("po_hint", "po_id"), ("invoice_hint", "invoice_id"),
                              ("shipment_hint", "shipment_id"), ("sku_hint", "sku")):
            if notice[field] is not None:
                (checks if notice[field] == row[target] else failures).append(field)
        price, amount = row["unit_price_cents"], notice["amount_cents"]
        qty = notice["short_qty"]
        if qty is None:
            qty = amount // price if amount % price == 0 else None
        financial = (qty is not None and 0 < qty <= min(row["shipped_qty"], row["invoiced_qty"])
                     and qty * price == amount)
        (checks if financial else failures).append("amount_equals_quantity_times_invoice_unit_price")
        if Op.EXACT_DESCRIPTION in plan.operations:
            same = normalize_description(notice["description"]) == normalize_description(row["product_description"])
            (checks if same else failures).append("exact_catalog_description")
        candidate_fields = {field: row[field] for field in Candidate.__dataclass_fields__}
        key = (row["invoice_line_id"], row["shipment_id"], row["sku"])
        if failures:
            rejected.append({"key": key, "failed_checks": failures})
            continue
        valid_receipt = (row["received_qty"] is not None and 0 <= row["received_qty"] <= row["shipped_qty"]
                         and row["ship_date"] <= row["receipt_date"] <= notice["notice_date"])
        shortfall = row["shipped_qty"] - row["received_qty"] if valid_receipt else None
        receiving = "not_available" if shortfall is None else "consistent_with_claim" if shortfall == qty else "does_not_support_claimed_quantity"
        evidence = [
            _source(conn, "deductions", {"deduction_id": notice["deduction_id"]}),
            _source(conn, "purchase_orders", {"po_id": row["po_id"]}),
            _source(conn, "invoices", {"invoice_id": row["invoice_id"]}),
            _source(conn, "invoice_lines", {"invoice_line_id": row["invoice_line_id"]}),
            _source(conn, "products", {"sku": row["sku"]}),
            _source(conn, "shipments", {"shipment_id": row["shipment_id"]}),
            _source(conn, "shipment_lines", {"shipment_id": row["shipment_id"], "sku": row["sku"]}),
            _source(conn, "receipts", {"shipment_id": row["shipment_id"], "sku": row["sku"]}),
        ]
        survivors.append({**candidate_fields, "passed_checks": checks, "failed_checks": [],
                          "evaluated_short_qty": qty,
                          "derived_short_qty": qty if notice["short_qty"] is None else None,
                          "quantity_source": "reported" if notice["short_qty"] is not None else "amount_divided_by_invoice_price",
                          "receiving_evidence": receiving, "recorded_shortfall": shortfall,
                          "receipt_usable_at_notice": valid_receipt,
                          "financial_check": {"quantity": qty, "unit_price_cents": price,
                                              "computed_amount_cents": qty * price, "notice_amount_cents": amount},
                          "evidence": evidence})
    # Recheck the complete set, not just the executor's favorite candidate.
    expected = {(item["invoice_line_id"], item["shipment_id"], item["sku"]): item for item in survivors}
    actual = {item.key: item for item in execution.hypotheses}
    if len(actual) != len(execution.hypotheses) or set(expected) != set(actual):
        return {"status": "review", "reason": "executor_verifier_disagreement", "candidates": [],
                "claim_assessment": "not_assessed", "verification": {"passed": False}}
    for key, hypothesis in actual.items():
        fresh = expected[key]
        snapshot = {field: fresh[field] for field in Candidate.__dataclass_fields__}
        if hypothesis.quantity != fresh["evaluated_short_qty"] or asdict(hypothesis.candidate) != snapshot:
            return {"status": "review", "reason": "executor_verifier_disagreement", "candidates": [],
                    "claim_assessment": "not_assessed", "verification": {"passed": False}}
    assessment = "not_assessed"
    if not survivors:
        status = "review" if notice["short_qty"] is None else "no_match"
        reason = "no_candidate_satisfies_hard_constraints"
    elif len(survivors) > 1:
        status, reason = "review", "multiple_financially_consistent_candidates"
    else:
        sole = survivors[0]
        receipt_supports = sole["receiving_evidence"] == "consistent_with_claim"
        anchor = any(notice[field] is not None for field in ("po_hint", "invoice_hint", "shipment_hint"))
        assessment = {"not_available": "receiving_evidence_unavailable",
                      "consistent_with_claim": "receiving_records_consistent",
                      "does_not_support_claimed_quantity": "receiving_records_do_not_support_claimed_quantity"}[sole["receiving_evidence"]]
        if notice["short_qty"] is None and not receipt_supports:
            status, reason = "review", "derived_quantity_requires_receipt_corroboration"
        elif anchor or receipt_supports:
            status, reason = "matched", "unique_candidate_with_independent_anchor"
        else:
            status, reason = "review", "unique_candidate_but_weak_identification_evidence"
    return {"status": status, "reason": reason, "claim_assessment": assessment,
            "candidates": survivors, "rejected_count": len(rejected), "rejected": rejected,
            "verification": {"passed": True, "source_digest": expected_digest,
                             "independent_candidate_count": len(rows),
                             "meaning": "Transaction link only; not deduction validity or liability."}}
