"""Analyze -> plan -> validate -> execute -> independently verify -> abstain."""
from __future__ import annotations

from .analysis import analyze
from .contracts import MethodPlan, PlanError, Planner, PlannerUnavailable, TextRanker
from .executor import execute
from .planner import OfflinePlanner
from .storage import source_digest, source_issues
from .verifier import verify


def reconcile(conn, deduction_id: str, planner: Planner | None = None, ranker: TextRanker | None = None) -> dict:
    row = conn.execute("SELECT * FROM deductions WHERE deduction_id=?", (deduction_id,)).fetchone()
    if row is None:
        raise KeyError(f"Unknown deduction: {deduction_id}")
    notice = dict(row)
    planner = planner if planner is not None else OfflinePlanner()
    result = {"deduction_id": deduction_id, "notice": notice, "engine": "phase2",
              "planner": planner.name, "status": "review", "reason": "not_executed",
              "candidates": [], "claim_assessment": "not_assessed", "profile": None,
              "plan": None, "trace": [], "verification": {"passed": False}}
    issues = source_issues(conn)
    if issues:
        return {**result, "reason": "invalid_source_data", "data_issues": issues}
    if notice["reason"] != "shortage":
        return {**result, "reason": "unsupported_deduction_type"}
    profile = analyze(conn, notice, text_ranking_available=ranker is not None)
    result["profile"] = profile.to_dict()
    if notice["amount_cents"] is None:
        return {**result, "reason": "missing_amount_cents"}
    digest = source_digest(conn)
    try:
        plan = planner.plan(profile)
        if not isinstance(plan, MethodPlan):
            raise PlanError("Planner must return a typed MethodPlan")
        # Reparse at the trust boundary, including in-process planner outputs.
        plan = MethodPlan.from_dict(plan.to_dict())
        plan.validate(profile)
        result["plan"] = plan.to_dict()
    except PlanError:
        return {**result, "reason": "invalid_plan"}
    except (PlannerUnavailable, TimeoutError, OSError):
        # Deliberately no silent fallback to an allegedly AI-produced decision.
        return {**result, "reason": "planner_unavailable"}
    if source_digest(conn) != digest:
        return {**result, "reason": "source_records_changed"}
    try:
        # An operation may not mutate the reported facts retained in the result.
        execution = execute(conn, dict(notice), plan, ranker=ranker)
    except (PlanError, ValueError, ImportError):
        return {**result, "reason": "operation_failed"}
    result["trace"] = list(execution.trace)
    checked = verify(conn, notice, plan, execution, expected_digest=digest)
    result.update(checked)
    result["trace"].append({"operation": "verify_records", "input_count": len(execution.hypotheses),
                            "output_count": len(result["candidates"]), "passed": result["verification"]["passed"],
                            "tool": "independent_source_record_checks"})
    return result


def reconcile_all(conn, planner: Planner | None = None, ranker: TextRanker | None = None) -> list[dict]:
    ids = [row[0] for row in conn.execute("SELECT deduction_id FROM deductions ORDER BY deduction_id")]
    return [reconcile(conn, deduction_id, planner=planner, ranker=ranker) for deduction_id in ids]
