"""Constrained method planning; Phase 1 remains in recon.engine."""
