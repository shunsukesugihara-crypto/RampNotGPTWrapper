"""Candidate generation, deterministic constraints, independent claim checks.

Business assumptions for this narrow demo:
- Only single-line SHORTAGE deductions, expressed in cases.
- No freight, discounts, taxes, chargebacks, or bundled multi-line claims.
- Invoice unit price is the price basis for the deduction.
- Dates are ISO-8601 and deduction notice follows the shipment by <=120 days.
- Receiving quantities are independent evidence, not an automatic ruling on claim legitimacy.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
import sqlite3

@dataclass(frozen=True)
class Candidate:
    invoice_line_id: str
    invoice_id: str
    po_id: str
    sku: str
    product_description: str
    shipment_id: str
    ship_date: str
    unit_price_cents: int
    invoiced_qty: int
    shipped_qty: int
    received_qty: int | None

@dataclass(frozen=True)
class CandidateResult:
    candidate: Candidate
    passed_checks: list[str]
    failed_checks: list[str]
    receiving_evidence: str
    recorded_shortfall: int | None

    def to_dict(self) -> dict:
        return {
            **asdict(self.candidate),
            "passed_checks": self.passed_checks,
            "failed_checks": self.failed_checks,
            "receiving_evidence": self.receiving_evidence,
            "recorded_shortfall": self.recorded_shortfall,
        }

# Candidate generation starts from independently stored PO -> invoice -> shipment links.
# The dataset's labels are not in the database and are never accessible to this code.
SQL = """
SELECT il.invoice_line_id, i.invoice_id, i.po_id, il.sku,
       p.description AS product_description, s.shipment_id, s.ship_date,
       il.unit_price_cents, il.quantity AS invoiced_qty,
       sl.shipped_qty, r.received_qty
FROM purchase_orders po
JOIN invoices i ON i.po_id=po.po_id
JOIN invoice_lines il ON il.invoice_id=i.invoice_id
JOIN products p ON p.sku=il.sku
JOIN shipments s ON s.po_id=po.po_id
JOIN shipment_lines sl ON sl.shipment_id=s.shipment_id AND sl.sku=il.sku
LEFT JOIN receipts r ON r.shipment_id=s.shipment_id AND r.sku=il.sku
WHERE po.retailer=?
  AND s.ship_date <= ?
  AND s.ship_date >= date(?, '-120 days')
ORDER BY s.ship_date DESC, il.invoice_line_id
"""

def generate_candidates(conn: sqlite3.Connection, deduction: sqlite3.Row) -> list[Candidate]:
    rows = conn.execute(SQL, (deduction["retailer"], deduction["notice_date"], deduction["notice_date"])).fetchall()
    return [Candidate(**dict(row)) for row in rows]


def assess(deduction: sqlite3.Row, candidate: Candidate) -> CandidateResult:
    passed, failed = [], []
    for field, value, actual in [
        ("po_reference", deduction["po_hint"], candidate.po_id),
        ("invoice_reference", deduction["invoice_hint"], candidate.invoice_id),
        ("shipment_reference", deduction["shipment_hint"], candidate.shipment_id),
        ("sku_reference", deduction["sku_hint"], candidate.sku),
    ]:
        if value is not None:
            (passed if value == actual else failed).append(field)
    if deduction["short_qty"] <= candidate.shipped_qty:
        passed.append("claimed_quantity_not_above_shipped")
    else:
        failed.append("claimed_quantity_exceeds_shipped")
    expected_amount = deduction["short_qty"] * candidate.unit_price_cents
    if deduction["amount_cents"] == expected_amount:
        passed.append("amount_equals_quantity_times_invoice_unit_price")
    else:
        failed.append("amount_quantity_price_mismatch")
    # The SQL joins independently establish retailer/order/invoice/shipment linkage.
    passed.extend(["retailer_matches", "invoice_po_shipment_linked", "shipment_precedes_notice"])
    shortfall = (candidate.shipped_qty - candidate.received_qty) if candidate.received_qty is not None else None
    if shortfall is None:
        receiving_evidence = "not_available"
    elif shortfall == deduction["short_qty"]:
        receiving_evidence = "consistent_with_claim"
    else:
        receiving_evidence = "does_not_support_claimed_quantity"
    return CandidateResult(candidate, passed, failed, receiving_evidence, shortfall)


def reconcile(conn: sqlite3.Connection, deduction_id: str) -> dict:
    deduction = conn.execute("SELECT * FROM deductions WHERE deduction_id=?", (deduction_id,)).fetchone()
    if deduction is None:
        raise KeyError(f"Unknown deduction: {deduction_id}")
    if deduction["reason"] != "shortage":
        return {"deduction_id": deduction_id, "status": "review", "reason": "unsupported_deduction_type", "candidates": [], "rejected_count": 0}
    all_candidates = generate_candidates(conn, deduction)
    assessed = [assess(deduction, candidate) for candidate in all_candidates]
    survivors = [result for result in assessed if not result.failed_checks]
    rejected = [result for result in assessed if result.failed_checks]
    if not survivors:
        status, reason = "no_match", "no_candidate_satisfies_hard_constraints"
    elif len(survivors) > 1:
        status, reason = "review", "multiple_financially_consistent_candidates"
    else:
        sole = survivors[0]
        exact_reference = any(deduction[k] is not None for k in ("po_hint", "invoice_hint", "shipment_hint"))
        # No reference? A uniquely consistent receipt shortfall is useful evidence,
        # but absent that we do not silently promote a price coincidence to certainty.
        corroborating_receipt = sole.receiving_evidence == "consistent_with_claim"
        if exact_reference or corroborating_receipt:
            status, reason = "matched", "unique_candidate_with_independent_anchor"
        else:
            status, reason = "review", "unique_candidate_but_weak_identification_evidence"
    claim_assessment = "not_assessed"
    if len(survivors) == 1:
        ev = survivors[0].receiving_evidence
        claim_assessment = {
            "consistent_with_claim": "receiving_records_consistent",
            "does_not_support_claimed_quantity": "receiving_records_do_not_support_claimed_quantity",
            "not_available": "receiving_evidence_unavailable",
        }[ev]
    return {
        "deduction_id": deduction_id,
        "notice": {key: deduction[key] for key in deduction.keys()},
        "status": status,
        "reason": reason,
        "claim_assessment": claim_assessment,
        "candidates": [result.to_dict() for result in survivors],
        "rejected_count": len(rejected),
        "rejected": [result.to_dict() for result in rejected[:10]],
        "candidate_count_before_filter": len(assessed),
    }


def reconcile_all(conn: sqlite3.Connection) -> list[dict]:
    ids = [row[0] for row in conn.execute("SELECT deduction_id FROM deductions ORDER BY deduction_id")]
    return [reconcile(conn, key) for key in ids]
