"""Model builds an evidence-reconstruction procedure; code establishes results."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from pathlib import Path

from recon.ai.provider import create_provider
from recon.phase2.contracts import PlanError
from .contracts import ACTION_SCHEMA, Operation, RawPack, parse_operation


INSTRUCTIONS = """Construct a computational procedure for one retail deduction using the approved tools.
Return exactly one operation object. Never return financial values, record identifiers,
code, SQL, a final match, or invented facts. You see source structure first, followed by
actual execution observations. Select only an available operation.
normalize_source_records parses known source formats, preserves raw evidence, and converts
quantities/prices only with verified product-master conversion factors. Missing factors,
non-integral conversions, invalid references and unsupported facts remain unresolved.
join_financial_records reconstructs candidate invoice/order/product/shipment relationships
using supplied references, dates and currencies; it does not choose a winning transaction.
check_single_line_constraints examines individual candidate lines. It is suitable for a
source that explicitly declares a single-line claim, or a diagnostic before a broader search.
solve_receipt_shortfall_allocation invokes OR-Tools CP-SAT to search combinations of whole
independently recorded receipt shortfalls. It checks the amount, optional total quantity,
source scope, and prevents double counting. Choose it when multiple invoice lines may
contribute, or when a single-line search cannot resolve a potentially combined deduction.
An unknown claim scope requires checking both single-line and combined alternatives.
verify_reconstruction requests separate source rereads and an independent exhaustive
check within the bounded scope. It establishes supported links, ambiguity or no match.
Only ordinary code determines the outcome. A solver timeout or one found solution without
proof of completeness is insufficient for an automatic match. Missing receipts can leave
unseen alternatives and must not be guessed. request_review preserves uncertainty.
Use the observations to choose the procedure; there is no mandatory complete tool sequence.
Each operation can run once, dependencies are enforced locally, and steps are bounded.
"""


def _digest(value: dict) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def reconcile(raw: RawPack, provider=None, max_steps: int = 6, solver_options: dict | None = None) -> dict:
    from .data import normalize, structural_profile
    from .solver import check_single, join_candidates, solve_allocations
    from .verifier import verify

    if type(max_steps) is not int or not 1 <= max_steps <= 6:
        raise ValueError("max_steps must be between one and six")
    original = _digest(raw.data)
    source_file_required = Path(raw.source_path).is_file()
    profile = structural_profile(raw)
    notice_id = raw.data.get("notice", {}).get("deduction_id")
    result = {
        "deduction_id": notice_id, "engine": "evidence_reconstruction", "planner": "model_controller",
        "status": "review", "reason": "not_executed", "notice": deepcopy(raw.data.get("notice", {})),
        "profile": profile, "plan": {"version": 1, "operations": []}, "trace": [],
        "planning_decisions": [], "model_calls": 0, "live_ai": False, "candidates": [],
        "verification": {"passed": False}, "claim_assessment": "not_assessed",
        "transformations": [], "source_digest": raw.source_digest,
        "supported_scope": "single-line links or combinations of whole independently recorded receipt shortfalls",
    }
    normalized, candidates, execution, method = None, None, None, None
    performed = []

    def unchanged():
        if _digest(raw.data) != original:
            return False
        path = Path(raw.source_path)
        try:
            if source_file_required:
                return path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == raw.source_digest
            return True
        except OSError:
            return False

    def observation():
        out = {"normalized": normalized is not None, "records_joined": candidates is not None,
               "executed_operations": list(performed), "search_method": method}
        if normalized is not None:
            out.update(normalization_issue_count=len(normalized.issues),
                       transformation_count=len(normalized.transformations),
                       claim_scope=normalized.notice.get("scope", "unknown"),
                       allocation_basis=normalized.notice.get("basis"),
                       amount_available=normalized.notice.get("amount_cents") is not None,
                       reported_quantity_available=normalized.notice.get("short_qty") is not None)
        if candidates is not None:
            out.update(candidate_count=len(candidates), receipt_available_count=sum(c.received_qty is not None for c in candidates),
                       distinct_price_count=len({c.unit_price_cents for c in candidates}))
        if execution is not None:
            out.update(solution_count=len(execution.allocations), search_complete=execution.complete,
                       search_issue_codes=[item.get("code", "unresolved") for item in execution.issues],
                       search_tool=execution.tool)
        return out

    def available():
        ops = [Operation.REVIEW]
        if normalized is None:
            ops.append(Operation.NORMALIZE)
        elif normalized.issues:
            return ops
        elif candidates is None:
            ops.append(Operation.JOIN)
        elif normalized.notice.get("amount_cents") is not None:
            if Operation.SINGLE.value not in performed and Operation.MULTI.value not in performed:
                ops.append(Operation.SINGLE)
            if Operation.MULTI.value not in performed:
                ops.append(Operation.MULTI)
            if execution is not None and (method == "multi" or normalized.notice.get("scope") == "single_line"):
                ops.append(Operation.VERIFY)
        return [op for op in ops if op.value not in performed]

    if provider is None:
        try:
            provider = create_provider()
        except Exception as exc:
            return {**result, "reason": "planner_unavailable", "error_type": type(exc).__name__}
    for step in range(1, max_steps + 1):
        if not unchanged():
            return {**result, "reason": "source_records_changed"}
        before = observation()
        allowed = available()
        context = {"profile": deepcopy(profile), "observation": before,
                   "available_operations": [op.value for op in allowed], "steps_remaining": max_steps - step + 1,
                   "history": [{"action": d["action"], "observation": d["observation"]}
                               for d in result["planning_decisions"]]}
        decision = {"step": step, "action": None, "observation_before": before, "observation": None,
                    "available_operations": list(context["available_operations"]), "audit": {"live": False}}
        result["planning_decisions"].append(decision)
        result["model_calls"] += 1
        try:
            completion = provider.complete(INSTRUCTIONS, deepcopy(context), deepcopy(ACTION_SCHEMA))
            if not isinstance(completion.audit, dict):
                raise PlanError("Missing provider audit")
            decision["audit"] = deepcopy(completion.audit)
            operation = parse_operation(completion.value)
            decision["action"] = operation.value
            if operation not in allowed:
                raise PlanError("Operation unavailable or repeated")
        except Exception as exc:
            decision["audit"]["error_type"] = type(exc).__name__
            result["live_ai"] = False
            return {**result, "reason": "invalid_model_action" if isinstance(exc, PlanError) else "planner_unavailable",
                    "error_type": type(exc).__name__}
        result["live_ai"] = all(d["audit"].get("live") is True for d in result["planning_decisions"])
        if not unchanged():
            return {**result, "reason": "source_records_changed"}
        result["plan"]["operations"].append({"op": operation.value})
        if operation == Operation.REVIEW:
            decision["observation"] = before
            return {**result, "reason": "model_requested_review"}
        count_before = len(candidates) if candidates is not None else 0
        try:
            if operation == Operation.NORMALIZE:
                normalized = normalize(raw)
                result["notice"] = deepcopy(normalized.notice)
                result["transformations"] = deepcopy(list(normalized.transformations))
                result["reconstructed_records"] = {"notice": deepcopy(normalized.notice),
                                                   **deepcopy(normalized.tables)}
                if normalized.issues:
                    result["data_issues"] = deepcopy(list(normalized.issues))
            elif operation == Operation.JOIN:
                candidates = join_candidates(normalized)
            elif operation == Operation.SINGLE:
                execution, method = check_single(normalized, candidates), "single"
            elif operation == Operation.MULTI:
                execution, method = solve_allocations(normalized, candidates, **(solver_options or {})), "multi"
            elif operation == Operation.VERIFY:
                checked = verify(raw, normalized, execution, method)
                if not unchanged():
                    return {**result, "reason": "source_records_changed"}
                result.update(checked)
            performed.append(operation.value)
            if execution is not None:
                result["search"] = {"method": method, **asdict(execution)}
            decision["observation"] = observation()
            result["trace"].append({"operation": operation.value, "input_count": count_before,
                                    "output_count": len(execution.allocations) if execution is not None else len(candidates) if candidates is not None else sum(len(rows) for rows in normalized.tables.values()) if normalized is not None else 0,
                                    "tool": "independent_raw_record_verification" if operation == Operation.VERIFY else execution.tool if operation in {Operation.SINGLE, Operation.MULTI} else "python_relational_join" if operation == Operation.JOIN else "exact_source_normalization"})
        except Exception as exc:
            return {**result, "reason": "operation_failed", "error_type": type(exc).__name__}
        if not unchanged():
            return {**result, "reason": "source_records_changed"}
        if operation == Operation.VERIFY:
            return result
        if normalized is not None and normalized.issues:
            return {**result, "reason": "unresolved_source_normalization"}
    return {**result, "reason": "model_step_limit"}
