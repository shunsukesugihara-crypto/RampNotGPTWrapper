"""Frozen raw-evidence comparison: original rules, all tools, AI tools, direct AI.

All engines receive the same source facts. Hidden labels are read only by this
evaluator, never by a model, normalizer, join, solver or financial verifier.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import date
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import sqlite3
from time import perf_counter

from recon.ai.provider import create_provider
from recon.engine import reconcile as phase1_reconcile
from recon.storage import DDL, TABLES
from .data import load_pack, normalize
from .direct import reconcile as direct_reconcile
from .service import reconcile as method_reconcile


ROOT = Path(__file__).resolve().parents[3]
DEFAULT_FAMILIES = ("single_clear", "unique_two_line", "mixed_units", "ambiguous_two_line")


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _inside(directory: Path, name: str) -> Path:
    path = (directory / name).resolve()
    if not path.is_relative_to(directory.resolve()):
        raise ValueError("Corpus paths must remain inside the selected directory")
    return path


def _jsonl(path: Path) -> dict[str, dict]:
    rows = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        item = json.loads(line)
        if item["case_id"] in rows:
            raise ValueError("Duplicate corpus case ID")
        rows[item["case_id"]] = item
    return rows


def load_corpus(directory: str | Path) -> tuple[dict, dict, dict, dict]:
    directory = Path(directory)
    manifest_path = directory / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    if manifest.get("frozen") is not True:
        raise ValueError("Evaluate only a frozen source corpus")
    actual = {name: _hash(_inside(directory, name)) for name in manifest["files"]}
    if actual != manifest["files"]:
        raise ValueError("Frozen corpus hash mismatch; do not regenerate or repair it during evaluation")
    index, labels = _jsonl(directory / "index.jsonl"), _jsonl(directory / "labels.jsonl")
    if set(index) != set(labels) or len(index) != manifest["case_count"]:
        raise ValueError("Exactly one raw-case index and hidden label per frozen case are required")
    for row in index.values():
        if row["raw_path"] not in actual or row["raw_sha256"] != actual[row["raw_path"]]:
            raise ValueError("Raw-case index and frozen content hashes disagree")
    return manifest, index, labels, {"manifest_sha256": _hash(manifest_path), "files": actual}


def all_tools(raw, solver_options: dict | None = None) -> dict:
    """Deterministic new-operator control, explicitly separate from AI planning."""
    from .solver import check_single, join_candidates, solve_allocations
    from .verifier import verify
    normalized = normalize(raw)
    result = {"engine": "all_tools_control", "status": "review", "reason": "not_executed",
              "candidates": [], "notice": normalized.notice,
              "transformations": list(normalized.transformations), "source_digest": raw.source_digest,
              "model_calls": 0, "planning_decisions": [], "live_ai": False,
              "verification": {"passed": False}, "trace": [{"operation": "normalize_source_records"}]}
    if normalized.issues:
        return {**result, "reason": "unresolved_source_normalization", "data_issues": list(normalized.issues)}
    candidates = join_candidates(normalized)
    result["trace"].append({"operation": "join_financial_records", "candidate_count": len(candidates)})
    method = "single" if normalized.notice["scope"] == "single_line" else "multi"
    execution = check_single(normalized, candidates) if method == "single" else solve_allocations(
        normalized, candidates, **(solver_options or {}))
    result["trace"].append({"operation": "check_single_line_constraints" if method == "single" else "solve_receipt_shortfall_allocation",
                            "tool": execution.tool, "solution_count": len(execution.allocations), "complete": execution.complete})
    result.update(verify(raw, normalized, execution, method))
    result["trace"].append({"operation": "verify_reconstruction", "passed": result["verification"]["passed"]})
    return result


def _plain_integer(value) -> int:
    if not isinstance(value, str) or not re.fullmatch(r"\d+", value):
        raise ValueError("Original Phase 1 requires a present canonical integer quantity")
    return int(value)


def _plain_date(value) -> str:
    if not isinstance(value, str) or date.fromisoformat(value).isoformat() != value:
        raise ValueError("Original Phase 1 requires ISO dates")
    return value


def _cents(value) -> int:
    if not isinstance(value, str) or not re.fullmatch(r"\$?(?:\d+|\d{1,3}(?:,\d{3})+)\.\d{2}", value):
        raise ValueError("Original Phase 1 adapter accepts only explicit USD cents")
    return int(Decimal(value.removeprefix("$").replace(",", "")) * 100)


def baseline(raw) -> dict:
    """Use original code only where no units/currency/line semantics are lost."""
    data, n = raw.data, raw.data["notice"]
    unsupported = {"engine": "original_phase1", "status": "unsupported", "candidates": [],
                   "reason": "outside_original_phase1_input_scope", "model_calls": 0,
                   "planning_decisions": [], "live_ai": False, "source_digest": raw.source_digest}
    if n.get("scope") != "single_line" or n.get("basis") != "whole_receipt_shortfalls":
        return {**unsupported, "scope_detail": "Original engine cannot represent combined or undisclosed claim-line scope/basis"}
    currency_rows = [n] + data["invoices"] + data["invoice_lines"]
    quantity_rows = [n] + data["invoice_lines"] + data["shipment_lines"] + data["receipts"]
    if any(row.get("currency") != "USD" for row in currency_rows):
        return {**unsupported, "scope_detail": "Currency distinctions are absent from the original schema; no filtering or FX is added to that baseline"}
    if any(row.get("uom") != "CS" for row in quantity_rows) or any(row.get("price_uom") != "CS" for row in data["invoice_lines"]):
        return {**unsupported, "scope_detail": "Original engine has no each/case conversion operation"}
    conn = None
    try:
        notice_qty = _plain_integer(n.get("short_qty"))
        tables = {
            "products": [{"sku": r["sku"], "description": r["description"]} for r in data["products"]],
            "purchase_orders": [{"po_id": r["po_id"], "retailer": r["retailer"], "order_date": _plain_date(r["order_date"])} for r in data["purchase_orders"]],
            "invoices": [{"invoice_id": r["invoice_id"], "po_id": r["po_id"], "invoice_date": _plain_date(r["invoice_date"])} for r in data["invoices"]],
            "invoice_lines": [{"invoice_line_id": r["invoice_line_id"], "invoice_id": r["invoice_id"], "sku": r["sku"],
                               "quantity": _plain_integer(r["quantity"]), "unit_price_cents": _cents(r["unit_price"])} for r in data["invoice_lines"]],
            "shipments": [{"shipment_id": r["shipment_id"], "po_id": r["po_id"], "ship_date": _plain_date(r["ship_date"])} for r in data["shipments"]],
            "shipment_lines": [{"shipment_id": r["shipment_id"], "sku": r["sku"], "shipped_qty": _plain_integer(r["quantity"])} for r in data["shipment_lines"]],
            "receipts": [{"shipment_id": r["shipment_id"], "sku": r["sku"], "received_qty": _plain_integer(r["quantity"]),
                          "receipt_date": _plain_date(r["receipt_date"])} for r in data["receipts"]],
            "deductions": [{"deduction_id": n["deduction_id"], "retailer": n["retailer"], "notice_date": _plain_date(n["notice_date"]),
                            "amount_cents": _cents(n["amount"]), "short_qty": notice_qty, "reason": "shortage",
                            "description": n["description"], "sku_hint": n.get("sku_hint"), "po_hint": n.get("po_hint"),
                            "invoice_hint": n.get("invoice_hint"), "shipment_hint": None}],
        }
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript(DDL)
        for table, names in TABLES.items():
            columns = names.split(",")
            conn.executemany(f"INSERT INTO {table} ({names}) VALUES ({','.join('?' for _ in columns)})",
                             ([row[key] for key in columns] for row in tables[table]))
        conn.commit()
        result = phase1_reconcile(conn, n["deduction_id"])
        result.update(engine="original_phase1", source_digest=raw.source_digest,
                      model_calls=0, planning_decisions=[], live_ai=False)
        if result["status"] == "matched":
            result["reconstructed_allocation"] = [{"invoice_line_id": row["invoice_line_id"], "shipment_id": row["shipment_id"],
                                                   "sku": row["sku"], "quantity": notice_qty} for row in result["candidates"]]
        return result
    except (ValueError, KeyError, TypeError, sqlite3.Error) as exc:
        return {**unsupported, "scope_detail": str(exc), "error_type": type(exc).__name__}
    finally:
        if conn is not None:
            conn.close()


def _key(lines) -> tuple | None:
    if not isinstance(lines, list) or not lines:
        return None
    keys = []
    for line in lines:
        if not isinstance(line, dict) or type(line.get("quantity")) is not int or line["quantity"] <= 0:
            return None
        ids = tuple(line.get(field) for field in ("invoice_line_id", "shipment_id", "sku"))
        if any(not isinstance(value, str) or not value for value in ids):
            return None
        keys.append((*ids, line["quantity"]))
    return tuple(sorted(keys)) if len(keys) == len(set(keys)) else None


def assess(result: dict, label: dict) -> dict:
    matched = result.get("status") == "matched"
    lines = result.get("reconstructed_allocation")
    if lines is None:
        candidates = result.get("candidates", [])
        lines = candidates[0].get("lines") if len(candidates) == 1 else None
    actual, expected = _key(lines), _key(label["latent_expected_allocation"])
    correct = actual == expected if matched else None
    identity = (actual is not None and tuple(line[:3] for line in actual) == tuple(line[:3] for line in expected)) if matched else None
    inappropriate = matched and (correct is not True or not label["automatic_link_permitted"])
    verification = result.get("verification") or {}
    completed = result.get("reason") not in {
        "planner_unavailable", "model_unavailable", "invalid_provider_completion", "invalid_model_action",
        "invalid_direct_output", "operation_failed", "verification_failed", "model_step_limit",
        "evaluation_engine_error", "source_records_changed",
    } and result.get("status") != "error"
    return {
        "identity_correct": identity, "allocation_correct": correct,
        "automatic_link_permitted": label["automatic_link_permitted"],
        "inappropriate_automatic_link": inappropriate,
        "observable_allocation_feasible": actual in {_key(rows) for rows in label["observable_valid_allocations"]} if matched else None,
        "evaluation_completed": completed,
        "expected_behavior_met": completed and result["status"] == label["expected_status"] and not inappropriate,
        "independent_financial_verification_passed": verification.get("passed") is True,
        "normalized_records_independently_reconstructed": verification.get("normalized_records_reconstructed") is True,
        "transformations_verified": verification.get("transformations_verified") is True,
    }


def summarize(records: list[dict]) -> dict:
    counts = Counter(row["result"]["status"] for row in records)
    automatic = [row for row in records if row["result"]["status"] == "matched"]
    attempts = sum(row["result"].get("model_calls", 0) for row in records)
    completed, failed, unverified_attempts = [], 0, 0
    for row in records:
        for decision in row["result"].get("planning_decisions", []):
            audit = decision.get("audit")
            if isinstance(audit, dict) and audit.get("error_type") is not None:
                failed += 1
            elif (not isinstance(audit, dict) or row["result"].get("reason") == "invalid_provider_completion"
                  and decision.get("action") is None):
                unverified_attempts += 1
            else:
                completed.append(decision)
    live = sum(decision["audit"].get("live") is True for decision in completed)
    injected = sum(decision["audit"].get("live") is False and decision.get("action") is not None for decision in completed)
    correct = sum(row["evaluation"]["allocation_correct"] is True for row in automatic)
    inappropriate = sum(row["evaluation"]["inappropriate_automatic_link"] for row in automatic)
    procedures = sorted({tuple(step["op"] for step in (row["result"].get("plan") or {}).get("operations", []))
                         for row in records if row["result"].get("plan")})
    return {
        "case_count": len(records), "status_counts": dict(counts),
        "supported_cases": len(records) - counts["unsupported"], "unsupported_cases": counts["unsupported"],
        "automatic_links": len(automatic), "correct_allocations": correct,
        "wrong_allocations": len(automatic) - correct,
        "wrong_identities": sum(row["evaluation"]["identity_correct"] is not True for row in automatic),
        "inappropriate_automatic_links": inappropriate,
        "automatic_allocation_precision": correct / len(automatic) if automatic else None,
        "justified_automatic_precision": (len(automatic) - inappropriate) / len(automatic) if automatic else None,
        "automatic_coverage": len(automatic) / len(records) if records else None,
        "review_cases": counts["review"], "no_match_cases": counts["no_match"],
        "incomplete_or_failed_evaluation_cases": sum(not row["evaluation"]["evaluation_completed"] for row in records),
        "engine_error_cases": counts["error"],
        "expected_behavior_met": sum(row["evaluation"]["expected_behavior_met"] for row in records),
        "independently_verified_matches": sum(row["evaluation"]["independent_financial_verification_passed"] for row in automatic),
        "matches_with_independently_reconstructed_records": sum(row["evaluation"]["normalized_records_independently_reconstructed"] for row in automatic),
        "matches_with_verified_transformations": sum(row["evaluation"]["transformations_verified"] for row in automatic),
        "model_call_attempts": attempts, "failed_model_attempts": failed,
        "unverified_model_attempts": unverified_attempts,
        "recorded_model_completions": len(completed), "live_model_completions": live,
        "injected_model_completions": injected,
        "unverified_model_completions": len(completed) - live - injected,
        "distinct_procedures": [list(procedure) for procedure in procedures],
        "source_records_unchanged": all(row["source_digest_before"] == row["source_digest_after"] for row in records),
        "runtime_ms_total": sum(row["runtime_ms"] for row in records),
    }


def evaluate(corpus_dir: str | Path = ROOT / "evaluation/reconstruction", *, provider=None,
             direct_provider=None, provider_kind: str = "auto", model: str | None = None,
             split: str = "heldout", case_ids: list[str] | None = None, limit: int | None = 4,
             model_runs: bool = True, max_steps: int = 6, solver_options: dict | None = None) -> dict:
    directory = Path(corpus_dir)
    manifest, index, labels, freeze = load_corpus(directory)
    if limit is not None and (type(limit) is not int or limit < 1):
        raise ValueError("limit must be positive or None")
    if split not in {"development", "heldout", "all"}:
        raise ValueError("Unknown corpus split")
    eligible = [row for row in index.values() if split == "all" or row["split"] == split]
    if case_ids is not None:
        if not case_ids or len(case_ids) != len(set(case_ids)) or set(case_ids) - {row["case_id"] for row in eligible}:
            raise ValueError("Choose distinct case IDs from the selected split")
        selected = [index[key] for key in case_ids]
    else:
        prioritized = []
        for family in DEFAULT_FAMILIES:
            prioritized.extend(sorted((row for row in eligible if row["family"] == family), key=lambda row: row["case_id"]))
        seen = {row["case_id"] for row in prioritized}
        selected = prioritized + sorted((row for row in eligible if row["case_id"] not in seen), key=lambda row: row["case_id"])
        selected = selected[:limit] if limit is not None else selected
    provider_error = None
    if model_runs and provider is None:
        try:
            provider = create_provider(provider_kind, model=model)
        except Exception as exc:
            provider_error = type(exc).__name__
    if direct_provider is None:
        direct_provider = provider
    engines = ("baseline", "all_tools", "ai_method", "direct_llm") if model_runs else ("baseline", "all_tools")
    rows = []
    for metadata in selected:
        path = _inside(directory, metadata["raw_path"])
        row = {"case_id": metadata["case_id"], "family": metadata["family"], "split": metadata["split"],
               "raw_path": metadata["raw_path"], "evaluation_label": labels[metadata["case_id"]], "engines": {}}
        for engine in engines:
            raw = load_pack(path)
            before = _hash(path)
            started = perf_counter()
            try:
                if engine == "baseline":
                    result = baseline(raw)
                elif engine == "all_tools":
                    result = all_tools(raw, solver_options)
                elif provider_error and (engine == "ai_method" or direct_provider is None):
                    result = {"engine": engine, "status": "review", "reason": "planner_unavailable", "candidates": [],
                              "model_calls": 0, "planning_decisions": [], "live_ai": False, "error_type": provider_error}
                elif engine == "ai_method":
                    result = method_reconcile(raw, provider=provider, max_steps=max_steps, solver_options=solver_options)
                else:
                    result = direct_reconcile(raw, provider=direct_provider)
            except Exception as exc:
                result = {"engine": engine, "status": "error", "reason": "evaluation_engine_error", "candidates": [],
                          "error_type": type(exc).__name__, "model_calls": 0, "planning_decisions": [], "live_ai": False}
            row["engines"][engine] = {"result": result, "evaluation": assess(result, labels[metadata["case_id"]]),
                                      "source_digest_before": before, "source_digest_after": _hash(path),
                                      "runtime_ms": (perf_counter() - started) * 1000}
        rows.append(row)
    common = [row for row in rows if row["engines"]["baseline"]["result"]["status"] != "unsupported"]
    summaries = {engine: summarize([row["engines"][engine] for row in rows]) for engine in engines}
    _, _, _, after = load_corpus(directory)
    return {
        "dataset": "Frozen authored raw-source reconstruction scenarios; not real retail data",
        "generator_seed": manifest["seed"], "split": split, "case_count_per_engine": len(rows),
        "selected_case_ids": [row["case_id"] for row in rows], "engines": list(engines),
        "generator_freeze": freeze, "corpus_unchanged_after_execution": freeze == after,
        "model_runs_requested": model_runs, "provider_initialization_error": provider_error,
        "live_model_completions": sum(summary["live_model_completions"] for summary in summaries.values()),
        "live_ai_evaluated": any(summary["live_model_completions"] > 0 for summary in summaries.values()),
        "summaries": summaries,
        "common_original_baseline_inputs": {"case_count": len(common),
            "summaries": {engine: summarize([row["engines"][engine] for row in common]) for engine in engines}},
        "cases": rows,
        "limitations": [
            "Seeded authored heldout cases share a generator; they do not establish real-world accuracy or external generalization.",
            "All-tools control uses the same new normalizer, joins, solver and verifier; matching gains over Phase 1 are not automatically caused by AI planning.",
            "Original Phase 1 is evaluated only for explicit single-line, same-case-unit, USD inputs with its required fields and dates; incompatible raw cases are unsupported, never projected lossily.",
            "Direct model receives the same raw financial packet, not labels; it has no financial executor, verifier or repair step. Its answer is not independent financial evidence.",
            "Injected provider completions test orchestration only; only actual live audit records count as live model calls.",
            "Tool-supported allocations are bounded combinations of whole independently recorded receipt shortfalls with explicit source basis; partial allocations, fees and discounts are unsupported.",
            "A single passing live run does not establish repeatability, model superiority, production safety or latency at scale.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, default=ROOT / "evaluation/reconstruction")
    parser.add_argument("--provider", choices=("auto", "openai", "codex"), default="auto")
    parser.add_argument("--model")
    parser.add_argument("--split", choices=("development", "heldout", "all"), default="heldout")
    parser.add_argument("--case", action="append", dest="case_ids")
    parser.add_argument("--limit", type=int, default=4)
    parser.add_argument("--all-tools-only", action="store_true", help="Run only original baseline and deterministic new-tools control; no model calls")
    parser.add_argument("--output", type=Path, default=ROOT / "output/reconstruction_evaluation.json")
    args = parser.parse_args()
    report = evaluate(args.corpus, provider_kind=args.provider, model=args.model, split=args.split,
                      case_ids=args.case_ids, limit=args.limit, model_runs=not args.all_tools_only)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "case_count_per_engine": report["case_count_per_engine"],
                      "live_ai_evaluated": report["live_ai_evaluated"], "summaries": report["summaries"]}, indent=2))


if __name__ == "__main__":
    main()
