"""Evidence-preserving retail record reconstruction using model-selected tools."""
