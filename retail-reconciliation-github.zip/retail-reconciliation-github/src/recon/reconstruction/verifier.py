"""Independent raw-record reconstruction and exhaustive financial verification.

No normalization parser, executor join, or OR-Tools implementation is reused.
The bounded verifier examines all nonempty subsets of at most twelve source
relationships, so an executor cannot turn a pruned rival into a unique answer.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, timedelta
from decimal import Decimal
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re

from .contracts import NormalizedPack, RawPack, SolverResult

_TABLES = ("products", "purchase_orders", "invoices", "invoice_lines", "shipments", "shipment_lines", "receipts")
_KEYS = {"products": ("sku",), "purchase_orders": ("po_id",), "invoices": ("invoice_id",),
         "invoice_lines": ("invoice_line_id",), "shipments": ("shipment_id",),
         "shipment_lines": ("shipment_id", "sku"), "receipts": ("receipt_id",)}
_RAW_FIELDS = {
    "notice": {"deduction_id", "retailer", "notice_date", "amount", "currency", "short_qty", "uom", "scope", "basis",
               "po_hint", "invoice_hint", "sku_hint", "description"},
    "products": {"sku", "description", "case_pack", "source_ref"},
    "purchase_orders": {"po_id", "retailer", "order_date"},
    "invoices": {"invoice_id", "po_id", "invoice_date", "currency"},
    "invoice_lines": {"invoice_line_id", "invoice_id", "sku", "quantity", "uom", "unit_price", "price_uom", "currency"},
    "shipments": {"shipment_id", "po_id", "ship_date"},
    "shipment_lines": {"shipment_id", "sku", "quantity", "uom"},
    "receipts": {"receipt_id", "shipment_id", "sku", "quantity", "uom", "receipt_date"},
}
_MAX_INTEGER = (1 << 63) - 1


def _exact(actual, expected):
    """JSON equality that does not silently equate True, 1 and 1.0."""
    if type(actual) is not type(expected):
        return False
    if isinstance(expected, dict):
        return set(actual) == set(expected) and all(_exact(actual[key], value) for key, value in expected.items())
    if isinstance(expected, (list, tuple)):
        return len(actual) == len(expected) and all(_exact(left, right) for left, right in zip(actual, expected))
    return actual == expected


def _text(value, optional=False):
    if value in (None, "") and optional:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Invalid source text")
    return value.strip()


def _integer(value, optional=False, zero=False):
    if value in (None, "") and optional:
        return None
    if type(value) not in (str, int):
        raise ValueError("Invalid source integer")
    text = str(value).strip()
    if re.fullmatch(r"(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)", text) is None:
        raise ValueError("Invalid source integer")
    number = int(text.replace(",", ""))
    if number < (0 if zero else 1) or number > _MAX_INTEGER:
        raise ValueError("Invalid source quantity range")
    return number


def _money(value, currency, optional=False):
    if value in (None, "") and optional:
        return None
    if type(value) not in (str, int):
        raise ValueError("Invalid source money")
    text = str(value).strip()
    for symbol, denomination in (("$", "USD"), ("€", "EUR")):
        if text.startswith(symbol):
            if currency != denomination:
                raise ValueError("Source monetary symbol conflicts with currency")
            text = text[1:].strip()
            break
    if re.fullmatch(r"(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]+)?", text) is None:
        raise ValueError("Invalid source money")
    # Fraction avoids decimal-context rounding during scaling and conversion.
    cents = Fraction(Decimal(text.replace(",", ""))) * 100
    if cents.denominator != 1 or not 0 < cents <= _MAX_INTEGER:
        raise ValueError("Source money is not positive integral cents")
    return int(cents)


def _date(value):
    text = _text(value)
    if re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", text):
        year, month, day = map(int, text.split("-"))
    elif re.fullmatch(r"[0-9]{2}/[0-9]{2}/[0-9]{4}", text):
        month, day, year = map(int, text.split("/"))
    else:
        raise ValueError("Unsupported source date")
    return date(year, month, day).isoformat()


def _currency(value):
    result = _text(value).upper()
    if re.fullmatch(r"[A-Z]{3}", result) is None:
        raise ValueError("Invalid source currency")
    return result


def _unit(value):
    result = _text(value).upper()
    if result not in {"CS", "EA"}:
        raise ValueError("Unsupported source unit")
    return result


def _factor(products, sku):
    product = next((row for row in products if row["sku"] == sku), None)
    if product is None or type(product["case_pack"]) is not int or product["case_pack"] <= 0 or not product["source_ref"]:
        raise ValueError("Unit conversion lacks a verified product-master factor")
    return product["case_pack"]


def _quantity(row, field, products, sku, optional=False, zero=False):
    quantity = _integer(row.get(field), optional, zero)
    if _unit(row.get("uom")) == "EA":
        divisor = _factor(products, sku)
        if quantity is not None:
            fraction = Fraction(quantity, divisor)
            if fraction.denominator != 1:
                raise ValueError("Source quantity contains a partial case")
            quantity = int(fraction)
    return quantity


def _reconstruct(raw):
    """Recompute canonical values from raw facts without the normalizer."""
    data = raw.data
    if (not isinstance(data, dict) or type(data.get("version")) is not int or data["version"] != 1
            or set(data) != {"version", "notice", *_TABLES}):
        raise ValueError("Unsupported raw source shape")
    if not isinstance(data["notice"], dict) or any(not isinstance(data[table], list) for table in _TABLES):
        raise ValueError("Invalid raw source shape")
    for table in ("notice", *_TABLES):
        rows = [data[table]] if table == "notice" else data[table]
        if any(not isinstance(row, dict) or set(row) - _RAW_FIELDS[table] for row in rows):
            raise ValueError("Unsupported source facts cannot be silently discarded")

    def source(table, index, row):
        return {"path": raw.source_path, "table": table, "row": index,
                "raw": deepcopy(row), "digest": raw.source_digest}

    tables = {table: [] for table in _TABLES}
    for index, row in enumerate(data["products"]):
        factor = row.get("case_pack")
        if factor is not None and (type(factor) is not int or not 0 < factor <= _MAX_INTEGER):
            raise ValueError("Invalid source case pack")
        tables["products"].append({"sku": _text(row.get("sku")), "description": _text(row.get("description"), True),
                                    "case_pack": factor, "source_ref": _text(row.get("source_ref"), True),
                                    "_source": source("products", index, row)})
    for table in _TABLES[1:]:
        for index, row in enumerate(data[table]):
            result = {key: _text(row.get(key)) for key in _KEYS[table]}
            result["_source"] = source(table, index, row)
            if table == "purchase_orders":
                result.update(retailer=_text(row.get("retailer")), order_date=_date(row.get("order_date")))
            elif table == "invoices":
                result.update(po_id=_text(row.get("po_id")), invoice_date=_date(row.get("invoice_date")), currency=_currency(row.get("currency")))
            elif table == "invoice_lines":
                sku, currency = _text(row.get("sku")), _currency(row.get("currency"))
                price = _money(row.get("unit_price"), currency)
                if _unit(row.get("price_uom")) == "EA":
                    price *= _factor(tables["products"], sku)
                if price > _MAX_INTEGER:
                    raise ValueError("Converted price exceeds supported integers")
                result.update(invoice_id=_text(row.get("invoice_id")), sku=sku,
                              quantity=_quantity(row, "quantity", tables["products"], sku), unit_price_cents=price,
                              uom="CS", price_uom="CS", currency=currency)
            elif table == "shipments":
                result.update(po_id=_text(row.get("po_id")), ship_date=_date(row.get("ship_date")))
            elif table == "shipment_lines":
                result.update(shipped_qty=_quantity(row, "quantity", tables["products"], result["sku"]), uom="CS")
            else:
                sku = _text(row.get("sku"))
                result.update(shipment_id=_text(row.get("shipment_id")), sku=sku,
                              received_qty=_quantity(row, "quantity", tables["products"], sku, zero=True),
                              receipt_date=_date(row.get("receipt_date")), uom="CS")
            tables[table].append(result)
    row = data["notice"]
    notice = {key: _text(row.get(key)) for key in ("deduction_id", "retailer")}
    notice.update({key: _text(row.get(key), True) for key in ("po_hint", "invoice_hint", "sku_hint", "description")})
    notice.update(notice_date=_date(row.get("notice_date")), currency=_currency(row.get("currency")),
                  scope=row.get("scope"), basis=_text(row.get("basis"), True), shipment_hint=None, uom="CS",
                  reason="shortage" if _text(row.get("basis"), True) == "whole_receipt_shortfalls" else None,
                  _source=source("notice", 0, row))
    if notice["scope"] not in {"single_line", "multi_line", "unknown"}:
        raise ValueError("Unsupported deduction scope")
    notice["amount_cents"] = _money(row.get("amount"), notice["currency"], True)
    notice["short_qty"] = _quantity(row, "short_qty", tables["products"], notice["sku_hint"], optional=True)
    # Independent integrity checks prevent a manipulated issues list hiding
    # duplicates, foreign-key violations, conflicting receipts or currencies.
    for table, rows in tables.items():
        identities = [tuple(item[key] for key in _KEYS[table]) for item in rows]
        if len(set(identities)) != len(identities):
            raise ValueError("Duplicate source identities")
    index = {table: {item[_KEYS[table][0]]: item for item in rows} for table, rows in tables.items()}
    for table, key, destination in (("invoices", "po_id", "purchase_orders"), ("invoice_lines", "invoice_id", "invoices"),
                                   ("invoice_lines", "sku", "products"), ("shipments", "po_id", "purchase_orders"),
                                   ("shipment_lines", "shipment_id", "shipments"), ("shipment_lines", "sku", "products")):
        if any(item[key] not in index[destination] for item in tables[table]):
            raise ValueError("Broken source relationship")
    if any(item["currency"] != index["invoices"][item["invoice_id"]]["currency"] for item in tables["invoice_lines"]):
        raise ValueError("Source invoice and line currencies conflict")
    shipped = {(item["shipment_id"], item["sku"]): item["shipped_qty"] for item in tables["shipment_lines"]}
    observed = set()
    for item in tables["receipts"]:
        key = item["shipment_id"], item["sku"]
        if key in observed or key not in shipped or item["received_qty"] > shipped[key]:
            raise ValueError("Receiving evidence is missing, conflicting or inconsistent")
        observed.add(key)
    tables["deductions"] = [notice]
    return notice, tables


def _verify_ledger(raw, normalized, notice, tables):
    """Check every stated operation and require financial/conversion evidence.

    Intermediate parse steps are recomputed from the original field, not from
    a preceding ledger result. Product factors come from independently rebuilt
    source products; the normalizer's claimed inputs are never authoritative.
    """
    operations = {
        "trim_text", "normalize_currency_code", "parse_en_us_date", "parse_en_us_money_to_cents",
        "parse_en_us_integer", "normalize_unit_label", "convert_each_to_case_unit",
        "divide_each_quantity_by_verified_case_pack", "multiply_each_price_by_verified_case_pack",
        "convert_each_price_to_case_unit", "derive_shortage_classification_from_explicit_basis",
    }
    money_fields = {("notice", "amount"), ("invoice_lines", "unit_price")}
    quantity_fields = {("notice", "short_qty"), ("invoice_lines", "quantity"),
                       ("shipment_lines", "quantity"), ("receipts", "quantity")}
    date_fields = {("notice", "notice_date"), ("purchase_orders", "order_date"),
                   ("invoices", "invoice_date"), ("shipments", "ship_date"), ("receipts", "receipt_date")}
    text_fields = {
        "notice": {"deduction_id", "retailer", "po_hint", "invoice_hint", "sku_hint", "description", "basis", "currency"},
        "products": {"sku", "description", "source_ref"}, "purchase_orders": {"po_id", "retailer"},
        "invoices": {"invoice_id", "po_id", "currency"}, "invoice_lines": {"invoice_line_id", "invoice_id", "sku", "currency"},
        "shipments": {"shipment_id", "po_id"}, "shipment_lines": {"shipment_id", "sku"},
        "receipts": {"receipt_id", "shipment_id", "sku"},
    }

    def factor_inputs(table, record):
        sku = _text(record.get("sku_hint") if table == "notice" else record.get("sku"))
        factor = _factor(tables["products"], sku)
        product = next(item for item in tables["products"] if item["sku"] == sku)
        return {"case_pack": factor, "source_ref": product["source_ref"], "sku": sku}

    seen = set()
    for change in normalized.transformations:
        if not isinstance(change, dict) or set(change) != {"source", "operation", "inputs", "result"}:
            raise ValueError("Invalid transformation ledger shape")
        source, operation = change["source"], change["operation"]
        if (not isinstance(source, dict) or set(source) != {"path", "table", "row", "key", "field", "raw"}
                or operation not in operations or not isinstance(change["inputs"], dict)):
            raise ValueError("Unsupported transformation ledger entry")
        table, index, field = source["table"], source["row"], source["field"]
        if table not in {"notice", *_TABLES} or type(index) is not int or index < 0:
            raise ValueError("Invalid transformation source location")
        records = [raw.data["notice"]] if table == "notice" else raw.data[table]
        if index >= len(records) or field not in _RAW_FIELDS[table]:
            raise ValueError("Transformation source does not exist")
        record = records[index]
        expected_source = {"path": raw.source_path, "table": table, "row": index,
                           "key": {key: record.get(key) for key in (("deduction_id",) if table == "notice" else _KEYS[table])},
                           "field": field, "raw": deepcopy(record.get(field))}
        if not _exact(source, expected_source):
            raise ValueError("Transformation raw source evidence disagrees")
        identity = table, index, field, operation
        if identity in seen:
            raise ValueError("Duplicate transformation operation")
        seen.add(identity)
        inputs = {}
        if operation == "trim_text":
            if field not in text_fields[table]:
                raise ValueError("Text transform used on an unsupported field")
            result = _text(record.get(field))
        elif operation == "normalize_currency_code":
            if field != "currency" or table not in {"notice", "invoices", "invoice_lines"}:
                raise ValueError("Currency transform used on an unsupported field")
            result = _currency(record.get(field))
        elif operation == "parse_en_us_date":
            if (table, field) not in date_fields:
                raise ValueError("Date transform used on an unsupported field")
            result = _date(record.get(field))
        elif operation == "parse_en_us_money_to_cents":
            if (table, field) not in money_fields:
                raise ValueError("Money transform used on an unsupported field")
            denomination = _currency(record.get("currency"))
            result, inputs = _money(record.get(field), denomination), {"currency": denomination, "scale": 100}
        elif operation == "parse_en_us_integer":
            if (table, field) not in quantity_fields:
                raise ValueError("Quantity transform used on an unsupported field")
            result = _integer(record.get(field), zero=table == "receipts")
        elif operation == "normalize_unit_label":
            if not (field == "uom" and table in {"notice", "invoice_lines", "shipment_lines", "receipts"}
                    or field == "price_uom" and table == "invoice_lines"):
                raise ValueError("Unit transform used on an unsupported field")
            result = _unit(record.get(field))
        elif operation in {"convert_each_to_case_unit", "divide_each_quantity_by_verified_case_pack"}:
            if table not in {"notice", "invoice_lines", "shipment_lines", "receipts"} or _unit(record.get("uom")) != "EA":
                raise ValueError("Each conversion lacks an explicit each unit")
            inputs = factor_inputs(table, record)
            if operation == "convert_each_to_case_unit":
                if field != "uom":
                    raise ValueError("Unit conversion used on a quantity field")
                result = "CS"
            else:
                if (table, field) not in quantity_fields:
                    raise ValueError("Quantity conversion used on an unsupported field")
                number = Fraction(_integer(record.get(field), zero=table == "receipts"), inputs["case_pack"])
                if number.denominator != 1:
                    raise ValueError("Each conversion is not an integral case quantity")
                result = int(number)
        elif operation in {"multiply_each_price_by_verified_case_pack", "convert_each_price_to_case_unit"}:
            if table != "invoice_lines" or _unit(record.get("price_uom")) != "EA":
                raise ValueError("Price conversion lacks an explicit each price unit")
            inputs = factor_inputs(table, record)
            if operation == "convert_each_price_to_case_unit":
                if field != "price_uom":
                    raise ValueError("Price-unit conversion used on another field")
                result = "CS"
            else:
                if field != "unit_price":
                    raise ValueError("Price conversion used on another field")
                result = _money(record.get(field), _currency(record.get("currency"))) * inputs["case_pack"]
        else:
            if table != "notice" or field != "basis" or _text(record.get("basis")) != "whole_receipt_shortfalls":
                raise ValueError("Shortage classification lacks its explicit source basis")
            result, inputs = "shortage", {"output_field": "reason", "basis": "whole_receipt_shortfalls"}
        if not _exact(change["result"], result) or not _exact(change["inputs"], inputs):
            raise ValueError("Transformation result or factor evidence is forged")

    # Financial parsing and each/case conversions must have a complete ledger.
    # Pure text/date presentation steps are validated when present; canonical
    # source values were already independently reconstructed above.
    required = set()
    for table in ("notice", *_TABLES):
        records = [raw.data["notice"]] if table == "notice" else raw.data[table]
        for index, record in enumerate(records):
            for field in _RAW_FIELDS[table]:
                if (table, field) in money_fields and record.get(field) not in (None, ""):
                    required.add((table, index, field, "parse_en_us_money_to_cents"))
                if (table, field) in quantity_fields and record.get(field) not in (None, ""):
                    parsed = _integer(record.get(field), zero=table == "receipts")
                    if not _exact(record.get(field), parsed):
                        required.add((table, index, field, "parse_en_us_integer"))
                    if _unit(record.get("uom")) == "EA":
                        converted = _quantity(record, field, tables["products"],
                                              _text(record.get("sku_hint") if table == "notice" else record.get("sku")),
                                              zero=table == "receipts")
                        if not _exact(record.get(field), converted):
                            required.add((table, index, field, "divide_each_quantity_by_verified_case_pack"))
            if table in {"notice", "invoice_lines", "shipment_lines", "receipts"} and _unit(record.get("uom")) == "EA":
                required.add((table, index, "uom", "convert_each_to_case_unit"))
            if table == "invoice_lines" and _unit(record.get("price_uom")) == "EA":
                required.add((table, index, "unit_price", "multiply_each_price_by_verified_case_pack"))
                required.add((table, index, "price_uom", "convert_each_price_to_case_unit"))
    if notice.get("basis") == "whole_receipt_shortfalls":
        required.add(("notice", 0, "basis", "derive_shortage_classification_from_explicit_basis"))
    if not required <= seen:
        raise ValueError("Required financial conversion provenance is missing")


def _source_candidates(notice, tables):
    """Separate full source enumeration; deliberately no executor join helper."""
    output = []
    cutoff = date.fromisoformat(notice["notice_date"]) - timedelta(days=120)
    for line in tables["invoice_lines"]:
        for invoice in tables["invoices"]:
            if line["invoice_id"] != invoice["invoice_id"] or invoice["currency"] != notice["currency"] or line["currency"] != notice["currency"]:
                continue
            for order in tables["purchase_orders"]:
                if invoice["po_id"] != order["po_id"] or order["retailer"] != notice["retailer"]:
                    continue
                if not order["order_date"] <= invoice["invoice_date"] <= notice["notice_date"]:
                    continue
                for shipment in tables["shipments"]:
                    if shipment["po_id"] != order["po_id"] or not order["order_date"] <= shipment["ship_date"] <= notice["notice_date"] or date.fromisoformat(shipment["ship_date"]) < cutoff:
                        continue
                    for shipped in tables["shipment_lines"]:
                        if shipped["shipment_id"] != shipment["shipment_id"] or shipped["sku"] != line["sku"]:
                            continue
                        facts = {"invoice_line_id": line["invoice_line_id"], "invoice_id": invoice["invoice_id"],
                                 "po_id": order["po_id"], "shipment_id": shipment["shipment_id"], "sku": line["sku"],
                                 "unit_price_cents": line["unit_price_cents"], "invoiced_qty": line["quantity"],
                                 "shipped_qty": shipped["shipped_qty"], "received_qty": None, "shortfall": None}
                        if any(notice.get(hint) is not None and notice[hint] != facts[target]
                               for hint, target in (("po_hint", "po_id"), ("invoice_hint", "invoice_id"), ("sku_hint", "sku"), ("shipment_hint", "shipment_id"))):
                            continue
                        product = next(item for item in tables["products"] if item["sku"] == line["sku"])
                        receipt = next((item for item in tables["receipts"] if item["shipment_id"] == shipment["shipment_id"] and item["sku"] == line["sku"]), None)
                        if receipt is not None and shipment["ship_date"] <= receipt["receipt_date"] <= notice["notice_date"]:
                            facts.update(received_qty=receipt["received_qty"], shortfall=shipped["shipped_qty"] - receipt["received_qty"])
                        facts["evidence"] = [deepcopy(item["_source"]) for item in (notice, order, invoice, line, product, shipment, shipped, receipt) if item is not None]
                        output.append(facts)
                        if len(output) > 12:
                            raise ValueError("Independent candidate bound exceeded")
    return output


def _line(facts, quantity, source):
    return {key: facts[key] for key in ("invoice_line_id", "invoice_id", "po_id", "shipment_id", "sku", "unit_price_cents", "evidence")} | {
        "quantity": quantity, "amount_cents": quantity * facts["unit_price_cents"],
        "quantity_source": source, "recorded_shortfall": facts["shortfall"]}


def _allocation(lines):
    return {"lines": lines, "amount_cents": sum(item["amount_cents"] for item in lines),
            "short_qty": sum(item["quantity"] for item in lines),
            "equations": [{"invoice_line_id": item["invoice_line_id"], "shipment_id": item["shipment_id"],
                           "sku": item["sku"], "quantity_cases": item["quantity"],
                           "invoice_price_cents_per_case": item["unit_price_cents"],
                           "computed_amount_cents": item["amount_cents"], "recorded_shortfall_cases": item["recorded_shortfall"]}
                          for item in lines]}


def _key(allocation):
    return tuple(sorted((item["invoice_line_id"], item["shipment_id"], item["sku"], item["quantity"]) for item in allocation["lines"]))


def _enumerate(notice, candidates, method):
    amount, reported = notice["amount_cents"], notice["short_qty"]
    if amount is None or len(candidates) > 12:
        raise ValueError("Independent verification requires an amount and at most twelve candidates")
    if notice.get("basis") not in {"whole_receipt_shortfalls", "invoice_unit_price"}:
        raise ValueError("An explicit supported financial basis is required")
    if method == "single":
        if notice["scope"] != "single_line":
            raise ValueError("A single-line diagnostic cannot establish a potentially combined claim")
        allocations = []
        for item in candidates:
            qty = reported if reported is not None else item["shortfall"]
            if qty is None:
                if amount % item["unit_price_cents"] == 0 and 0 < amount // item["unit_price_cents"] <= min(item["invoiced_qty"], item["shipped_qty"]):
                    raise ValueError("Missing receipt leaves a possible unidentified single-line allocation")
                continue
            if 0 < qty <= min(item["invoiced_qty"], item["shipped_qty"]) and qty * item["unit_price_cents"] == amount:
                allocations.append(_allocation([_line(item, qty, "reported" if reported is not None else "independent_receipt_shortfall")]))
        return allocations
    if method != "multi" or notice.get("basis") != "whole_receipt_shortfalls":
        raise ValueError("Whole independent receipt-shortfall allocation must be explicitly declared")
    eligible = []
    for item in candidates:
        if item["unit_price_cents"] > amount:
            continue
        if item["shortfall"] is None:
            raise ValueError("Missing receipt can conceal another complete allocation")
        if 0 < item["shortfall"] <= min(item["invoiced_qty"], item["shipped_qty"]) and item["shortfall"] * item["unit_price_cents"] <= amount:
            eligible.append(item)
    allocations = []
    for mask in range(1, 1 << len(eligible)):
        chosen = [item for index, item in enumerate(eligible) if mask & (1 << index)]
        if notice["scope"] == "single_line" and len(chosen) != 1 or notice["scope"] == "multi_line" and len(chosen) < 2:
            continue
        if len({item["invoice_line_id"] for item in chosen}) != len(chosen) or len({(item["shipment_id"], item["sku"]) for item in chosen}) != len(chosen):
            continue
        total_qty = sum(item["shortfall"] for item in chosen)
        total_amount = sum(item["shortfall"] * item["unit_price_cents"] for item in chosen)
        if total_amount == amount and (reported is None or total_qty == reported):
            allocations.append(_allocation([_line(item, item["shortfall"], "independent_receipt_shortfall") for item in chosen]))
    return allocations


def verify(raw: RawPack, normalized: NormalizedPack, execution: SolverResult, method: str) -> dict:
    base = {"status": "review", "reason": "verification_incomplete", "candidates": [],
            "claim_assessment": "not_assessed", "verification": {"passed": False},
            "source": {"path": raw.source_path, "digest": raw.source_digest}, "source_evidence": deepcopy(raw.data)}
    try:
        path, reloaded = Path(raw.source_path), False
        if path.is_file():
            content = path.read_bytes()
            if hashlib.sha256(content).hexdigest() != raw.source_digest or json.loads(content) != raw.data:
                return {**base, "reason": "source_records_changed"}
            reloaded = True
        elif path.is_absolute():
            return {**base, "reason": "source_records_changed"}
        if normalized.source_digest != raw.source_digest or normalized.source_path != raw.source_path:
            return {**base, "reason": "normalized_source_disagreement"}
        if normalized.issues:
            return {**base, "reason": "unresolved_source_normalization", "data_issues": list(normalized.issues)}
        notice, tables = _reconstruct(raw)
        if not _exact(notice, normalized.notice) or not _exact(tables, normalized.tables):
            return {**base, "reason": "normalizer_verifier_disagreement"}
        try:
            _verify_ledger(raw, normalized, notice, tables)
        except (ValueError, TypeError, KeyError):
            return {**base, "reason": "transformation_ledger_disagreement"}
        candidates = _source_candidates(notice, tables)
        independent = _enumerate(notice, candidates, method)
        if execution.complete is not True or execution.issues:
            return {**base, "reason": "incomplete_solver_search", "search_issues": list(execution.issues)}
        expected = {_key(item): item for item in independent}
        actual = {item.key: item for item in execution.allocations}
        if len(actual) != len(execution.allocations) or set(expected) != set(actual):
            return {**base, "reason": "solver_verifier_disagreement"}
        for key, item in actual.items():
            fresh = expected[key]
            if not _exact(item.amount_cents, fresh["amount_cents"]) or not _exact(item.short_qty, fresh["short_qty"]):
                return {**base, "reason": "solver_verifier_disagreement"}
            recorded = {tuple(line[field] for field in ("invoice_line_id", "shipment_id", "sku", "quantity")): line for line in item.lines}
            for line in fresh["lines"]:
                line_key = tuple(line[field] for field in ("invoice_line_id", "shipment_id", "sku", "quantity"))
                if not _exact(recorded.get(line_key), line):
                    return {**base, "reason": "solver_verifier_disagreement"}
        allocations = [expected[key] for key in sorted(expected)]
        status, reason, claim = "no_match", "no_allocation_satisfies_verified_constraints", "not_assessed"
        if len(allocations) > 1:
            status, reason = "review", "multiple_verified_allocations"
        elif allocations:
            sole = allocations[0]
            supports = all(line["recorded_shortfall"] == line["quantity"] for line in sole["lines"])
            anchor = any(notice.get(field) is not None for field in ("po_hint", "invoice_hint", "shipment_hint"))
            claim = ("receiving_records_consistent" if supports else "receiving_evidence_unavailable"
                     if any(line["recorded_shortfall"] is None for line in sole["lines"]) else "receiving_records_do_not_support_claimed_quantity")
            if method == "multi" and supports or method == "single" and (anchor or supports):
                status, reason = "matched", "unique_verified_allocation_with_independent_evidence"
            else:
                status, reason = "review", "unique_candidate_but_weak_identification_evidence"
        return {**base, "notice": notice, "status": status, "reason": reason,
                "candidates": allocations, "claim_assessment": claim,
                "verification": {"passed": True, "source_reloaded": reloaded, "source_digest": raw.source_digest,
                                 "normalized_records_reconstructed": True,
                                 "transformations_verified": True,
                                 "transformation_scope": "Every supplied step and all required financial/unit conversion entries independently checked",
                                 "independent_candidate_count": len(candidates), "independent_allocation_count": len(allocations),
                                 "verifier": "independent_raw_fraction_arithmetic_and_exhaustive_subsets",
                                 "subset_bound": 4095, "meaning": "Transaction relationship only, not deduction validity or legal liability."}}
    except (ValueError, TypeError, KeyError, OSError, OverflowError):
        return {**base, "reason": "independent_verification_unresolved"}
