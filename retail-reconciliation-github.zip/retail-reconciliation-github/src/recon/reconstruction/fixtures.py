"""Freeze seeded raw evidence and independent labels before model evaluation.

The oracle enumerates immutable latent observations before any formatting. It
imports no matching engine, normalization code, or solver under evaluation.
These are authored scenarios, not real retailer data or external validation.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
import hashlib
from itertools import combinations
import json
from pathlib import Path
import random


SEED = 20261108
ROOT = Path(__file__).resolve().parents[3]
FAMILIES = (
    "single_clear", "unique_two_line", "ambiguous_two_line", "mixed_units",
    "missing_conversion", "missing_receipt", "unknown_scope", "currency_collision",
    "missing_quantity_multi",
)


def _id(prefix: str, token: str) -> str:
    return prefix + "-" + hashlib.sha256(token.encode()).hexdigest()[:18]


def _bytes(value) -> bytes:
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


@dataclass(frozen=True)
class LatentLine:
    invoice_line_id: str
    invoice_id: str
    po_id: str
    shipment_id: str
    sku: str
    price_cents: int
    short_cases: int
    shipped_cases: int
    currency: str = "USD"
    receipt_present: bool = True

    def allocation(self) -> dict:
        return {"invoice_line_id": self.invoice_line_id, "shipment_id": self.shipment_id,
                "sku": self.sku, "quantity": self.short_cases}


def _oracle(lines: tuple[LatentLine, ...], *, scope: str, amount: int,
            quantity: int | None, conversion_verified: bool) -> dict:
    """Exhaustive subset oracle over independently known receipt observations."""
    eligible = tuple(line for line in lines if line.currency == "USD")
    complete = conversion_verified and all(line.receipt_present for line in eligible)
    possible = []
    if complete:
        for size in range(1, len(eligible) + 1):
            if scope == "single_line" and size != 1:
                continue
            if scope == "multi_line" and size < 2:
                continue
            for group in combinations(eligible, size):
                if sum(line.short_cases * line.price_cents for line in group) != amount:
                    continue
                if quantity is not None and sum(line.short_cases for line in group) != quantity:
                    continue
                possible.append(sorted((line.allocation() for line in group), key=lambda item: item["invoice_line_id"]))
    permitted = complete and len(possible) == 1
    return {"observable_valid_allocations": possible, "observable_search_complete": complete,
            "automatic_link_permitted": permitted,
            "expected_status": "matched" if permitted else "review"}


def _case(seed: int, family: str, split: str, replica: int) -> tuple[dict, dict, dict]:
    token = f"{seed}:{split}:{family}:{replica}"
    case_id = _id("C", token)
    rng = random.Random(int(hashlib.sha256(token.encode()).hexdigest(), 16))
    heldout = split == "heldout"
    p1, p2 = ((7201 + replica * 1200, 3601 + replica * 600) if heldout
              else (6000 + replica * 1200, 3000 + replica * 600))
    q = 17 + replica if family == "heldout_missing_quantity_mixed_units" else (13 + replica if heldout else 6 + replica)
    is_multi = family in {"unique_two_line", "ambiguous_two_line", "missing_receipt",
                          "unknown_scope", "missing_quantity_multi", "heldout_missing_quantity_mixed_units"}
    scope = "unknown" if family == "unknown_scope" else "multi_line" if is_multi else "single_line"
    specs = [(p1, q, "USD"), (p2, q, "USD")] if is_multi else [(p1, q, "USD"), (p2, q, "USD")]
    if family == "unique_two_line":
        specs.append((p1 + p2, q, "USD"))  # Same amount, wrong total case count.
    elif family == "ambiguous_two_line":
        specs.extend(((p1 + 200, q, "USD"), (p2 - 200, q, "USD")))
    elif family == "unknown_scope":
        specs.append(((p1 + p2) // 2, 2 * q, "USD"))
    elif family == "currency_collision":
        specs = [(p1, q, "USD"), (p1, q, "EUR")]
    lines = tuple(LatentLine(
        _id("L", token + f":{index}"), _id("I", token + f":{index}"),
        _id("P", token + f":{index}"), _id("S", token + f":{index}"),
        _id("K", token + f":{index}"), price, shortage,
        (220 if heldout else 100) + index * 12, currency,
        not (family == "missing_receipt" and index == 1),
    ) for index, (price, shortage, currency) in enumerate(specs))
    truth = lines[:2] if is_multi else lines[:1]
    amount = sum(line.short_cases * line.price_cents for line in truth)
    quantity = None if family in {"missing_quantity_multi", "heldout_missing_quantity_mixed_units"} else sum(line.short_cases for line in truth)
    conversion_verified = family != "missing_conversion"
    # Label creation precedes the messy raw adapter and never calls an engine.
    label = {"case_id": case_id, "family": family, "split": split,
             "latent_expected_allocation": sorted((line.allocation() for line in truth), key=lambda item: item["invoice_line_id"]),
             **_oracle(lines, scope=scope, amount=amount, quantity=quantity,
                       conversion_verified=conversion_verified)}
    mixed = family in {"mixed_units", "missing_conversion", "heldout_missing_quantity_mixed_units"}
    retailer = _id("Retailer", token)
    day = "2026-10" if heldout else "2026-09"
    def formatted_date(value: str) -> str:
        parsed = date.fromisoformat(value)
        return parsed.strftime("%m/%d/%Y") if mixed else value
    raw = {
        "version": 1,
        "notice": {"deduction_id": _id("D", token), "retailer": retailer,
                   "notice_date": formatted_date(day + "-20"),
                   "amount": "$" + format(Decimal(amount) / 100, ",.2f"), "currency": "USD",
                   "short_qty": str(quantity) if quantity is not None else None,
                   "uom": "CS", "scope": scope,
                   "basis": "whole_receipt_shortfalls",
                   "po_hint": lines[0].po_id if family in {"single_clear", "mixed_units", "missing_conversion"} else None,
                   "invoice_hint": None, "sku_hint": None, "description": "Reported merchandise shortage"},
        "products": [], "purchase_orders": [], "invoices": [], "invoice_lines": [],
        "shipments": [], "shipment_lines": [], "receipts": [],
    }
    for index, line in enumerate(lines):
        use_each = mixed and index == 0
        factor = 12
        quantity_uom = "EA" if use_each else "CS"
        multiplier = factor if use_each else 1
        raw["products"].append({"sku": line.sku, "description": f"Merchandise {line.sku[-6:]}",
                                "case_pack": factor if conversion_verified else None,
                                "source_ref": "verified-catalog#" + line.sku if conversion_verified else None})
        raw["purchase_orders"].append({"po_id": line.po_id, "retailer": retailer,
                                        "order_date": formatted_date(day + "-01")})
        raw["invoices"].append({"invoice_id": line.invoice_id, "po_id": line.po_id,
                               "invoice_date": formatted_date(day + "-03"), "currency": line.currency})
        raw["invoice_lines"].append({"invoice_line_id": line.invoice_line_id, "invoice_id": line.invoice_id,
                                    "sku": line.sku, "quantity": format(line.shipped_cases * multiplier, ","),
                                    "uom": quantity_uom,
                                    "unit_price": format(Decimal(line.price_cents) / 100, ".2f"),
                                    "price_uom": "CS", "currency": line.currency})
        raw["shipments"].append({"shipment_id": line.shipment_id, "po_id": line.po_id,
                                "ship_date": formatted_date(day + "-04")})
        raw["shipment_lines"].append({"shipment_id": line.shipment_id, "sku": line.sku,
                                     "quantity": format(line.shipped_cases * multiplier, ","), "uom": quantity_uom})
        if line.receipt_present:
            raw["receipts"].append({"receipt_id": _id("R", token + f":{index}"),
                                    "shipment_id": line.shipment_id, "sku": line.sku,
                                    "quantity": format((line.shipped_cases - line.short_cases) * multiplier, ","),
                                    "uom": quantity_uom, "receipt_date": formatted_date(day + "-07")})
    for key, rows in raw.items():
        if isinstance(rows, list):
            rng.shuffle(rows)
    metadata = {"case_id": case_id, "family": family, "split": split,
                "raw_path": f"cases/{case_id}.json", "raw_sha256": hashlib.sha256(_bytes(raw)).hexdigest()}
    return raw, label, metadata


def generate(output_dir: str | Path, seed: int = SEED) -> dict:
    """Write an immutable, repeatable 30-case corpus; never overwrite a freeze."""
    target = Path(output_dir)
    if target.exists() and any(target.iterdir()):
        raise FileExistsError("Corpus directory is not empty; choose a new location to preserve the existing freeze")
    target.mkdir(parents=True, exist_ok=True)
    (target / "cases").mkdir()
    cases = [_case(seed, family, "development", replica) for family in FAMILIES for replica in range(2)]
    cases += [_case(seed, family, "heldout", 0) for family in FAMILIES]
    cases += [_case(seed, "heldout_missing_quantity_mixed_units", "heldout", replica) for replica in range(3)]
    random.Random(seed).shuffle(cases)
    files, labels, index = {}, [], []
    for raw, label, metadata in cases:
        content = _bytes(raw)
        (target / metadata["raw_path"]).write_bytes(content)
        files[metadata["raw_path"]] = hashlib.sha256(content).hexdigest()
        labels.append(label)
        index.append(metadata)
    for name, rows in (("labels.jsonl", labels), ("index.jsonl", index)):
        content = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows).encode()
        (target / name).write_bytes(content)
        files[name] = hashlib.sha256(content).hexdigest()
    manifest = {
        "version": 1, "seed": seed, "frozen": True, "case_count": len(cases),
        "source": "Authored latent financial worlds; no real retailer records",
        "label_method": "Independent exhaustive subset enumeration over latent receipt observations BEFORE raw formatting; no matching engine/normalizer/solver imported",
        "split_counts": {split: sum(row["split"] == split for row in index) for split in ("development", "heldout")},
        "family_counts": {family: sum(row["family"] == family for row in index) for family in sorted({row["family"] for row in index})},
        "heldout_only_families": ["heldout_missing_quantity_mixed_units"],
        "numeric_split": "Development base unit prices end in 00 cents; heldout base prices end in 01 cents. Development shortages are 6..7 cases per line; heldout shortages are 13 or 17..19.",
        "raw_facts": "Financial arrays retain currency, explicit scope, source units and verified catalog conversion references; labels and scenario metadata are separate files.",
        "limitations": ["Synthetic authored scenarios are not representative real retailer data.",
                        "Heldout combinations share an authored world model; not external generalization evidence.",
                        "Allocations are whole positive receipt shortfalls, not partial allocations or deductions with fees/discounts.",
                        "Missing conversion factors and receipts are intentionally unresolved; hidden latent truth does not authorize a guess."],
        "files": dict(sorted(files.items())),
    }
    (target / "manifest.json").write_bytes(_bytes(manifest))
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "evaluation/reconstruction")
    parser.add_argument("--seed", type=int, default=SEED)
    args = parser.parse_args()
    print(json.dumps({"output": str(args.output), **generate(args.output, args.seed)}, indent=2))


if __name__ == "__main__":
    main()
