"""Execute a model-constructed reconstruction against a raw evidence pack."""
import argparse
import json
from pathlib import Path

from recon.ai.provider import create_provider
from .data import load_pack
from .service import reconcile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", type=Path, required=True)
    parser.add_argument("--provider", choices=("auto", "openai", "codex"), default="auto")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--max-steps", type=int, default=6)
    args = parser.parse_args()
    try:
        raw = load_pack(args.case)
        provider = create_provider(args.provider)
    except Exception as exc:
        parser.error(f"Source or model connection unavailable ({type(exc).__name__}); no rules fallback")
    result = reconcile(raw, provider=provider, max_steps=args.max_steps)
    content = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content)
        print(json.dumps({"output": str(args.output), "status": result["status"], "reason": result["reason"],
                          "model_calls": result["model_calls"], "live_ai": result["live_ai"]}))
    else:
        print(content, end="")


if __name__ == "__main__":
    main()
