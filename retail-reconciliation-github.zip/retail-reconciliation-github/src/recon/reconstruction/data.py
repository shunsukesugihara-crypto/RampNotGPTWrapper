"""Exact en-US source adapter with immutable raw evidence and explicit gaps."""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime
from decimal import Decimal, InvalidOperation, localcontext
import hashlib
import json
import math
from pathlib import Path
import re

from .contracts import NormalizedPack, RawPack

MAX_SOURCE_BYTES = 1024 * 1024
MAX_SOURCE_ROWS = 2000
MAX_INTEGER = (1 << 63) - 1
TABLES = ("products", "purchase_orders", "invoices", "invoice_lines", "shipments", "shipment_lines", "receipts")
FIELDS = {
    "notice": {"deduction_id", "retailer", "notice_date", "amount", "currency", "short_qty", "uom", "scope",
               "po_hint", "invoice_hint", "sku_hint", "description", "basis"},
    "products": {"sku", "description", "case_pack", "source_ref"},
    "purchase_orders": {"po_id", "retailer", "order_date"},
    "invoices": {"invoice_id", "po_id", "invoice_date", "currency"},
    "invoice_lines": {"invoice_line_id", "invoice_id", "sku", "quantity", "uom", "unit_price", "price_uom", "currency"},
    "shipments": {"shipment_id", "po_id", "ship_date"},
    "shipment_lines": {"shipment_id", "sku", "quantity", "uom"},
    "receipts": {"receipt_id", "shipment_id", "sku", "quantity", "uom", "receipt_date"},
}
KEYS = {"notice": ("deduction_id",), "products": ("sku",), "purchase_orders": ("po_id",),
        "invoices": ("invoice_id",), "invoice_lines": ("invoice_line_id",), "shipments": ("shipment_id",),
        "shipment_lines": ("shipment_id", "sku"), "receipts": ("receipt_id",)}


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON field")
        result[key] = value
    return result


def _constant(value):
    raise ValueError("Nonfinite JSON number")


def _float(value):
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("Nonfinite JSON number")
    return number


def _shape(data):
    if not isinstance(data, dict) or type(data.get("version")) is not int or data["version"] != 1:
        raise ValueError("Source pack must be a version-1 JSON object")
    if not isinstance(data.get("notice"), dict):
        raise ValueError("Source pack requires a notice object")
    for table in TABLES:
        if not isinstance(data.get(table), list) or not all(isinstance(row, dict) for row in data[table]):
            raise ValueError(f"Source pack requires an array of objects: {table}")
    if sum(len(data[table]) for table in TABLES) > MAX_SOURCE_ROWS:
        raise ValueError("Source pack exceeds the supported row limit")


def load_pack(path: str | Path) -> RawPack:
    path = Path(path)
    with path.open("rb") as stream:
        content = stream.read(MAX_SOURCE_BYTES + 1)
    if len(content) > MAX_SOURCE_BYTES:
        raise ValueError("Source pack exceeds one MiB")
    try:
        data = json.loads(content.decode("utf-8"), object_pairs_hook=_object,
                          parse_constant=_constant, parse_float=_float)
    except (ValueError, UnicodeError, RecursionError):
        raise ValueError("Source pack contains invalid or ambiguous JSON") from None
    _shape(data)
    return RawPack(data, str(path.resolve()), hashlib.sha256(content).hexdigest())


def structural_profile(raw: RawPack) -> dict:
    """Inventory supplied structure and units, without linking financial rows."""
    _shape(raw.data)
    notice = raw.data["notice"]
    all_rows = [notice] + [row for table in TABLES for row in raw.data[table]]
    return {
        "version": 1,
        "schemas": {table: sorted({key for row in raw.data[table] for key in row}) for table in TABLES},
        "notice_fields": sorted(notice),
        "row_counts": {table: len(raw.data[table]) for table in TABLES},
        "source_row_count": sum(len(raw.data[table]) for table in TABLES),
        "source_limits": {"max_bytes": MAX_SOURCE_BYTES, "max_rows": MAX_SOURCE_ROWS},
        "missing_facts": sorted(key for key in FIELDS["notice"] if notice.get(key) in (None, "")),
        "amount_available": notice.get("amount") not in (None, ""),
        "quantity_available": notice.get("short_qty") not in (None, ""),
        "description_available": bool(notice.get("description")),
        "provided_reference_fields": [key for key in ("po_hint", "invoice_hint", "sku_hint") if notice.get(key) not in (None, "")],
        "unit_values": sorted({str(row[key]) for row in all_rows for key in ("uom", "price_uom") if row.get(key) is not None}),
        "currency_values": sorted({str(row["currency"]) for row in all_rows if row.get("currency") is not None}),
        "scope": notice.get("scope", "unknown"),
        "basis": notice.get("basis"),
        "relationships": ["purchase_orders -> invoices -> invoice_lines -> products",
                          "purchase_orders -> shipments -> shipment_lines -> products",
                          "shipment_lines -> receipts (optional)", "products.case_pack + source_ref -> verified unit conversion"],
    }


class _Normalizer:
    def __init__(self, raw):
        self.raw = raw
        self.transformations = []
        self.issues = []
        self.products = {}

    def issue(self, code, table, row, field, message):
        self.issues.append({"code": code, "table": table, "row": row, "field": field, "message": message})

    def source(self, table, index, record):
        return {"path": self.raw.source_path, "table": table, "row": index,
                "raw": deepcopy(record), "digest": self.raw.source_digest}

    def change(self, table, index, record, field, operation, result, inputs=None):
        if type(record.get(field)) is type(result) and record.get(field) == result:
            return
        self.transformations.append({"source": {"path": self.raw.source_path, "table": table, "row": index,
            "key": {key: record.get(key) for key in KEYS[table]}, "field": field, "raw": deepcopy(record.get(field))},
            "operation": operation, "inputs": deepcopy(inputs or {}), "result": result})

    def text(self, table, index, record, field, required=True):
        value = record.get(field)
        if value in (None, "") and not required:
            return None
        if not isinstance(value, str) or not value.strip():
            self.issue("invalid_text", table, index, field, "A nonempty text value is required")
            return None
        result = value.strip()
        self.change(table, index, record, field, "trim_text", result)
        return result

    def currency(self, table, index, record):
        value = self.text(table, index, record, "currency")
        if value is None:
            return None
        result = value.upper()
        if not re.fullmatch(r"[A-Z]{3}", result):
            self.issue("invalid_currency", table, index, "currency", "Use a three-letter currency code; no exchange rate is inferred")
            return None
        self.change(table, index, record, "currency", "normalize_currency_code", result)
        return result

    def date(self, table, index, record, field):
        value = record.get(field)
        result = None
        if isinstance(value, str):
            try:
                if re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", value.strip()):
                    result = date.fromisoformat(value.strip()).isoformat()
                elif re.fullmatch(r"[0-9]{2}/[0-9]{2}/[0-9]{4}", value.strip()):
                    result = datetime.strptime(value.strip(), "%m/%d/%Y").date().isoformat()
            except ValueError:
                pass
        if result is None:
            self.issue("invalid_date", table, index, field, "Expected a valid ISO date or MM/DD/YYYY date")
        else:
            self.change(table, index, record, field, "parse_en_us_date", result)
        return result

    def money(self, table, index, record, field, currency, optional=False):
        value = record.get(field)
        if value in (None, "") and optional:
            return None
        text = str(value).strip() if type(value) in (str, int) else ""
        for symbol, declared in (("$", "USD"), ("€", "EUR")):
            if text.startswith(symbol):
                if currency != declared:
                    self.issue("currency_symbol_conflict", table, index, field, "Currency symbol conflicts with the explicitly declared currency")
                    return None
                text = text.removeprefix(symbol).strip()
                break
        if not re.fullmatch(r"(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]+)?", text):
            self.issue("invalid_money", table, index, field, "Expected a positive exact en-US monetary amount")
            return None
        try:
            with localcontext() as context:
                context.prec = max(28, len(text) + 4)
                number = Decimal(text.replace(",", "")) * 100
                if number != number.to_integral_value() or number <= 0 or number > MAX_INTEGER:
                    raise InvalidOperation
                result = int(number)
        except (InvalidOperation, ValueError, OverflowError):
            self.issue("nonintegral_money", table, index, field, "Money must be positive and exactly representable in cents")
            return None
        self.change(table, index, record, field, "parse_en_us_money_to_cents", result, {"currency": currency, "scale": 100})
        return result

    def integer(self, table, index, record, field, optional=False, zero=False):
        value = record.get(field)
        if value in (None, "") and optional:
            return None
        text = str(value).strip() if type(value) in (str, int) else ""
        if not re.fullmatch(r"(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)", text):
            self.issue("invalid_quantity", table, index, field, "Expected an integer or correctly grouped comma integer")
            return None
        digits = text.replace(",", "").lstrip("0") or "0"
        if len(digits) > 19 or (len(digits) == 19 and digits > str(MAX_INTEGER)):
            self.issue("quantity_out_of_range", table, index, field, "Quantity exceeds supported signed integer range")
            return None
        result = int(digits)
        if result < (0 if zero else 1):
            self.issue("invalid_quantity", table, index, field, "Quantity must be nonnegative for receipts and positive otherwise")
            return None
        self.change(table, index, record, field, "parse_en_us_integer", result)
        return result

    def factor(self, table, index, sku, field):
        product = self.products.get(sku)
        if product is None or type(product.get("case_pack")) is not int or not product.get("source_ref"):
            self.issue("missing_verified_case_pack", table, index, field,
                       "Each-to-case conversion requires a product-master integer case pack and source reference")
            return None
        return product

    def unit(self, table, index, record, field):
        value = record.get(field)
        result = value.strip().upper() if isinstance(value, str) else None
        if result not in {"CS", "EA"}:
            self.issue("unsupported_unit", table, index, field, "Only explicit CS and EA units are supported")
            return None
        self.change(table, index, record, field, "normalize_unit_label", result)
        return result

    def quantity(self, table, index, record, field, sku, *, optional=False, zero=False):
        number = self.integer(table, index, record, field, optional, zero)
        unit = self.unit(table, index, record, "uom")
        if unit is None:
            return None
        if unit == "EA":
            product = self.factor(table, index, sku, "uom")
            if product is None:
                return None
            inputs = {"case_pack": product["case_pack"], "source_ref": product["source_ref"], "sku": sku}
            self.change(table, index, record, "uom", "convert_each_to_case_unit", "CS", inputs)
            if number is not None:
                if number % product["case_pack"]:
                    self.issue("partial_case", table, index, field, "Each quantity does not form an exact integer number of cases")
                    return None
                number //= product["case_pack"]
                self.change(table, index, record, field, "divide_each_quantity_by_verified_case_pack", number, inputs)
        return number

    def check_fields(self, table, index, record):
        for field in sorted(set(record) - FIELDS[table]):
            self.issue("unexpected_field", table, index, field, "Unsupported source field is preserved in evidence but cannot be silently interpreted")

    def normalize(self):
        data = self.raw.data
        for field in sorted(set(data) - ({"version", "notice"} | set(TABLES))):
            self.issue("unexpected_field", "notice", 0, field, "Unsupported top-level source field")
        tables = {table: [] for table in TABLES}
        for index, row in enumerate(data["products"]):
            self.check_fields("products", index, row)
            product = {"sku": self.text("products", index, row, "sku"),
                       "description": self.text("products", index, row, "description", False),
                       "case_pack": row.get("case_pack"), "source_ref": self.text("products", index, row, "source_ref", False),
                       "_source": self.source("products", index, row)}
            if product["case_pack"] is not None and (type(product["case_pack"]) is not int or not 0 < product["case_pack"] <= MAX_INTEGER):
                self.issue("invalid_case_pack", "products", index, "case_pack", "Case pack must be a positive source integer")
                product["case_pack"] = None
            tables["products"].append(product)
            if product["sku"] not in self.products:
                self.products[product["sku"]] = product
        for table in TABLES[1:]:
            for index, row in enumerate(data[table]):
                self.check_fields(table, index, row)
                fields = {field: self.text(table, index, row, field) for field in KEYS[table]}
                fields["_source"] = self.source(table, index, row)
                if table == "purchase_orders":
                    fields.update(retailer=self.text(table, index, row, "retailer"), order_date=self.date(table, index, row, "order_date"))
                elif table == "invoices":
                    fields.update(po_id=self.text(table, index, row, "po_id"), invoice_date=self.date(table, index, row, "invoice_date"), currency=self.currency(table, index, row))
                elif table == "invoice_lines":
                    sku = self.text(table, index, row, "sku")
                    currency = self.currency(table, index, row)
                    price = self.money(table, index, row, "unit_price", currency)
                    price_unit = self.unit(table, index, row, "price_uom")
                    if price_unit == "EA":
                        product = self.factor(table, index, sku, "price_uom")
                        if product is None:
                            price = None
                        elif price is not None:
                            price *= product["case_pack"]
                            inputs = {"case_pack": product["case_pack"], "source_ref": product["source_ref"], "sku": sku}
                            self.change(table, index, row, "unit_price", "multiply_each_price_by_verified_case_pack", price, inputs)
                            self.change(table, index, row, "price_uom", "convert_each_price_to_case_unit", "CS", inputs)
                            if price > MAX_INTEGER:
                                self.issue("price_out_of_range", table, index, "unit_price", "Converted case price exceeds supported signed integer range")
                                price = None
                    if price_unit is None:
                        price = None
                    fields.update(invoice_id=self.text(table, index, row, "invoice_id"), sku=sku,
                                  quantity=self.quantity(table, index, row, "quantity", sku),
                                  unit_price_cents=price, uom="CS", price_uom="CS", currency=currency)
                elif table == "shipments":
                    fields.update(po_id=self.text(table, index, row, "po_id"), ship_date=self.date(table, index, row, "ship_date"))
                elif table == "shipment_lines":
                    fields.update(shipped_qty=self.quantity(table, index, row, "quantity", fields["sku"]), uom="CS")
                elif table == "receipts":
                    sku = self.text(table, index, row, "sku")
                    fields.update(shipment_id=self.text(table, index, row, "shipment_id"), sku=sku,
                                  received_qty=self.quantity(table, index, row, "quantity", sku, zero=True),
                                  receipt_date=self.date(table, index, row, "receipt_date"), uom="CS")
                tables[table].append(fields)
        raw_notice = data["notice"]
        self.check_fields("notice", 0, raw_notice)
        notice = {field: self.text("notice", 0, raw_notice, field) for field in ("deduction_id", "retailer")}
        notice.update({field: self.text("notice", 0, raw_notice, field, False) for field in ("po_hint", "invoice_hint", "sku_hint", "description", "basis")})
        notice.update(notice_date=self.date("notice", 0, raw_notice, "notice_date"), currency=self.currency("notice", 0, raw_notice),
                      scope=raw_notice.get("scope"), shipment_hint=None, uom="CS", reason=None, _source=self.source("notice", 0, raw_notice))
        if notice["basis"] == "whole_receipt_shortfalls":
            notice["reason"] = "shortage"
            self.change("notice", 0, raw_notice, "basis", "derive_shortage_classification_from_explicit_basis", "shortage",
                        {"output_field": "reason", "basis": notice["basis"]})
        if notice["scope"] not in {"single_line", "multi_line", "unknown"}:
            self.issue("unsupported_scope", "notice", 0, "scope", "An explicit supported scope declaration is required")
        notice["amount_cents"] = self.money("notice", 0, raw_notice, "amount", notice["currency"], optional=True)
        notice["short_qty"] = self.quantity("notice", 0, raw_notice, "short_qty", notice["sku_hint"], optional=True)
        self.validate_relationships(tables)
        tables["deductions"] = [notice]
        return NormalizedPack(notice, tables, tuple(self.transformations), tuple(self.issues),
                              self.raw.source_digest, self.raw.source_path)

    def validate_relationships(self, tables):
        for table, rows in tables.items():
            seen = set()
            for index, row in enumerate(rows):
                key = tuple(row.get(field) for field in KEYS[table])
                if key in seen:
                    self.issue("duplicate_id", table, index, ",".join(KEYS[table]), "Duplicate source identity")
                seen.add(key)
        ids = {table: {row.get(KEYS[table][0]) for row in rows} for table, rows in tables.items()}
        for table, field, target in (("invoices", "po_id", "purchase_orders"), ("invoice_lines", "invoice_id", "invoices"),
                                     ("invoice_lines", "sku", "products"), ("shipments", "po_id", "purchase_orders"),
                                     ("shipment_lines", "shipment_id", "shipments"), ("shipment_lines", "sku", "products")):
            for index, row in enumerate(tables[table]):
                if row.get(field) not in ids[target]:
                    self.issue("broken_reference", table, index, field, f"Referenced {target} record is absent")
        invoices = {row["invoice_id"]: row for row in tables["invoices"]}
        for index, row in enumerate(tables["invoice_lines"]):
            invoice = invoices.get(row["invoice_id"])
            if invoice and invoice["currency"] != row["currency"]:
                self.issue("currency_mismatch", "invoice_lines", index, "currency", "Invoice and line currencies disagree; no conversion is inferred")
        shipments = {(row["shipment_id"], row["sku"]): row for row in tables["shipment_lines"]}
        seen_receipts = set()
        for index, row in enumerate(tables["receipts"]):
            key = row["shipment_id"], row["sku"]
            if key not in shipments:
                self.issue("broken_reference", "receipts", index, "shipment_id,sku", "Referenced shipment line is absent")
            if key in seen_receipts:
                self.issue("conflicting_receipts", "receipts", index, "shipment_id,sku", "Multiple receiving observations require explicit resolution; they are not summed or overwritten")
            seen_receipts.add(key)
            shipped = shipments.get(key, {}).get("shipped_qty")
            if type(shipped) is int and type(row["received_qty"]) is int and row["received_qty"] > shipped:
                self.issue("receipt_exceeds_shipment", "receipts", index, "quantity", "Received quantity exceeds recorded shipped quantity")


def normalize(raw: RawPack) -> NormalizedPack:
    _shape(raw.data)
    return _Normalizer(raw).normalize()
