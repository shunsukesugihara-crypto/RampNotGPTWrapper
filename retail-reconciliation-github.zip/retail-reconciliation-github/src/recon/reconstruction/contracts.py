"""Shared typed boundaries for raw evidence, normalized records and solver output."""
from dataclasses import dataclass, field
from enum import Enum

from recon.phase2.contracts import PlanError


class Operation(str, Enum):
    NORMALIZE = "normalize_source_records"
    JOIN = "join_financial_records"
    SINGLE = "check_single_line_constraints"
    MULTI = "solve_receipt_shortfall_allocation"
    VERIFY = "verify_reconstruction"
    REVIEW = "request_review"


ACTION_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {"operation": {"type": "string", "enum": [op.value for op in Operation]}},
    "required": ["operation"],
}


def parse_operation(value) -> Operation:
    if not isinstance(value, dict) or set(value) != {"operation"} or type(value["operation"]) is not str:
        raise PlanError("One approved operation name is required; no parameters or answers are accepted")
    try:
        return Operation(value["operation"])
    except ValueError:
        raise PlanError("Unsupported reconstruction operation") from None


@dataclass(frozen=True)
class RawPack:
    data: dict
    source_path: str
    source_digest: str


@dataclass(frozen=True)
class NormalizedPack:
    notice: dict
    tables: dict
    transformations: tuple[dict, ...]
    issues: tuple[dict, ...]
    source_digest: str
    source_path: str


@dataclass(frozen=True)
class CandidateLine:
    invoice_line_id: str
    invoice_id: str
    po_id: str
    sku: str
    shipment_id: str
    unit_price_cents: int
    invoiced_qty: int
    shipped_qty: int
    received_qty: int | None
    evidence: tuple[dict, ...] = ()

    @property
    def key(self) -> tuple[str, str, str]:
        return self.invoice_line_id, self.shipment_id, self.sku

    @property
    def shortfall(self) -> int | None:
        return None if self.received_qty is None else self.shipped_qty - self.received_qty


@dataclass(frozen=True)
class Allocation:
    # Each line records source keys and a quantity computed by trusted code.
    lines: tuple[dict, ...]
    amount_cents: int
    short_qty: int

    @property
    def key(self):
        return tuple(sorted((line["invoice_line_id"], line["shipment_id"], line["sku"], line["quantity"])
                            for line in self.lines))


@dataclass(frozen=True)
class SolverResult:
    allocations: tuple[Allocation, ...]
    complete: bool
    tool: str
    issues: tuple[dict, ...] = ()
    diagnostics: dict = field(default_factory=dict)
