"""Trusted record joins and bounded receipt-shortfall allocation solving.

The optimizer selects whole independently recorded shortages, never arbitrary
partial quantities. No model-returned expressions, identifiers or code execute.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta
import math

from .contracts import Allocation, CandidateLine, NormalizedPack, SolverResult

MAX_CANDIDATES = 12


def _issue(code: str, message: str) -> dict:
    return {"code": code, "message": message}


def join_candidates(pack: NormalizedPack) -> tuple[CandidateLine, ...]:
    """Fixed Python relational join; currency and document references are hard gates."""
    if pack.issues:
        return ()
    notice, tables = pack.notice, pack.tables
    cutoff = date.fromisoformat(notice["notice_date"]) - timedelta(days=120)
    orders = {row["po_id"]: row for row in tables["purchase_orders"]}
    invoices = {row["invoice_id"]: row for row in tables["invoices"]}
    products = {row["sku"]: row for row in tables["products"]}
    shipments = {row["shipment_id"]: row for row in tables["shipments"]}
    receipts = {(row["shipment_id"], row["sku"]): row for row in tables["receipts"]}
    shipment_lines = defaultdict(list)
    for line in tables["shipment_lines"]:
        shipment = shipments.get(line["shipment_id"])
        if shipment is not None:
            shipment_lines[(shipment["po_id"], line["sku"])].append((shipment, line))
    candidates = []
    for line in tables["invoice_lines"]:
        invoice = invoices.get(line["invoice_id"])
        if invoice is None:
            continue
        order, product = orders.get(invoice["po_id"]), products.get(line["sku"])
        if order is None or product is None or order["retailer"] != notice["retailer"]:
            continue
        if invoice.get("currency") != notice["currency"] or line.get("currency") != notice["currency"]:
            continue
        if not order["order_date"] <= invoice["invoice_date"] <= notice["notice_date"]:
            continue
        for shipment, shipped in shipment_lines[(order["po_id"], line["sku"])]:
            if not order["order_date"] <= shipment["ship_date"] <= notice["notice_date"] or date.fromisoformat(shipment["ship_date"]) < cutoff:
                continue
            identities = {"po_hint": order["po_id"], "invoice_hint": invoice["invoice_id"],
                          "sku_hint": line["sku"], "shipment_hint": shipment["shipment_id"]}
            if any(notice.get(field) is not None and notice[field] != actual for field, actual in identities.items()):
                continue
            if any(type(value) is not int or value <= 0 for value in (line["quantity"], shipped["shipped_qty"], line["unit_price_cents"])):
                continue
            receipt = receipts.get((shipment["shipment_id"], line["sku"]))
            usable = (receipt is not None and type(receipt.get("received_qty")) is int
                      and 0 <= receipt["received_qty"] <= shipped["shipped_qty"]
                      and shipment["ship_date"] <= receipt["receipt_date"] <= notice["notice_date"])
            evidence = tuple(row["_source"] for row in (notice, order, invoice, line, product, shipment, shipped, receipt) if row is not None)
            candidates.append(CandidateLine(line["invoice_line_id"], invoice["invoice_id"], order["po_id"],
                                            line["sku"], shipment["shipment_id"], line["unit_price_cents"],
                                            line["quantity"], shipped["shipped_qty"],
                                            receipt["received_qty"] if usable else None, evidence))
            if len(candidates) > MAX_CANDIDATES:
                # This sentinel is already over the supported limit. Returning
                # thirteen forces incomplete/review; it cannot establish a
                # smaller, falsely unique candidate set.
                return tuple(sorted(candidates, key=lambda item: item.key))
    return tuple(sorted(candidates, key=lambda item: item.key))


def _preflight(pack: NormalizedPack, candidates: tuple[CandidateLine, ...]) -> tuple[dict, ...]:
    if pack.issues:
        return pack.issues
    amount, quantity = pack.notice.get("amount_cents"), pack.notice.get("short_qty")
    if type(amount) is not int or amount <= 0:
        return (_issue("missing_or_invalid_amount", "A positive recorded deduction amount is required."),)
    if quantity is not None and (type(quantity) is not int or quantity <= 0):
        return (_issue("invalid_notice_quantity", "The reported case quantity must be a positive integer or absent."),)
    if pack.notice.get("scope") not in {"single_line", "multi_line", "unknown"}:
        return (_issue("unsupported_scope", "The declared deduction scope is unsupported."),)
    if pack.notice.get("basis") not in {"whole_receipt_shortfalls", "invoice_unit_price"}:
        return (_issue("unsupported_price_basis", "An explicit supported financial basis is required; adjustments cannot be guessed."),)
    if len(candidates) > MAX_CANDIDATES:
        return (_issue("candidate_limit", "More than twelve candidates require a larger, separately validated method."),)
    for item in candidates:
        if any(type(value) is not int or value <= 0 for value in (item.unit_price_cents, item.invoiced_qty, item.shipped_qty)):
            return (_issue("invalid_candidate", "Candidate quantities and prices must be positive integers."),)
        if item.received_qty is not None and (type(item.received_qty) is not int or not 0 <= item.received_qty <= item.shipped_qty):
            return (_issue("invalid_candidate", "Receiving quantity contradicts the shipment."),)
    return ()


def _line(item: CandidateLine, quantity: int, source: str) -> dict:
    return {"invoice_line_id": item.invoice_line_id, "invoice_id": item.invoice_id, "po_id": item.po_id,
            "shipment_id": item.shipment_id, "sku": item.sku, "quantity": quantity,
            "unit_price_cents": item.unit_price_cents, "amount_cents": quantity * item.unit_price_cents,
            "quantity_source": source, "recorded_shortfall": item.shortfall, "evidence": list(item.evidence)}


def check_single(pack: NormalizedPack, candidates: tuple[CandidateLine, ...]) -> SolverResult:
    issues = _preflight(pack, candidates)
    if issues:
        return SolverResult((), False, "python_exact_arithmetic", issues)
    allocations, incomplete = [], []
    amount, reported = pack.notice["amount_cents"], pack.notice.get("short_qty")
    for item in candidates:
        if reported is None:
            # A missing reported fact is not filled by a model or a price-only
            # coincidence. Receipt subtraction independently determines cases.
            if item.shortfall is None:
                if amount % item.unit_price_cents == 0 and 0 < amount // item.unit_price_cents <= min(item.invoiced_qty, item.shipped_qty):
                    incomplete.append(_issue("missing_receipt", "A financially possible line has no usable independent receipt."))
                continue
            quantity, source = item.shortfall, "independent_receipt_shortfall"
        else:
            quantity, source = reported, "reported"
        if not 0 < quantity <= min(item.invoiced_qty, item.shipped_qty) or quantity * item.unit_price_cents != amount:
            continue
        allocations.append(Allocation((_line(item, quantity, source),), amount, quantity))
    return SolverResult(tuple(sorted(allocations, key=lambda item: item.key)), not incomplete,
                        "python_exact_arithmetic", tuple(incomplete),
                        {"candidate_count": len(candidates), "method": "single", "scope": pack.notice["scope"]})


def solve_allocations(pack: NormalizedPack, candidates: tuple[CandidateLine, ...],
                      max_seconds: float = 2, max_solutions: int = 64) -> SolverResult:
    issues = _preflight(pack, candidates)
    if issues:
        return SolverResult((), False, "ortools_cp_sat", issues)
    if pack.notice.get("basis") != "whole_receipt_shortfalls":
        return SolverResult((), False, "ortools_cp_sat", (_issue(
            "unsupported_allocation_basis", "Allocation needs an explicit whole-receipt-shortfalls basis; fees or partial quantities cannot be assumed away."),))
    if (type(max_seconds) not in (int, float) or not math.isfinite(max_seconds) or not 0 < max_seconds <= 60
            or type(max_solutions) is not int or not 1 <= max_solutions <= 4095):
        return SolverResult((), False, "ortools_cp_sat", (_issue("invalid_solver_limits", "Solver limits are outside the bounded contract."),))
    try:
        from ortools.sat.python import cp_model
    except ImportError:
        return SolverResult((), False, "ortools_cp_sat", (_issue("solver_unavailable", "OR-Tools is not installed; there is no hidden fallback solver."),))
    amount = pack.notice["amount_cents"]
    eligible, missing = [], []
    for item in candidates:
        if item.unit_price_cents > amount:
            continue  # Even one whole case cannot contribute to this amount.
        if item.shortfall is None:
            missing.append(_issue("missing_receipt", "A potential allocation line has no usable independently recorded shortfall."))
        elif 0 < item.shortfall <= min(item.invoiced_qty, item.shipped_qty) and item.shortfall * item.unit_price_cents <= amount:
            eligible.append(item)
    if missing:
        return SolverResult((), False, "ortools_cp_sat", tuple(missing), {"candidate_count": len(candidates)})
    # CP-SAT integers are signed 64-bit. Conservative limits prevent wraparound
    # or an invalid model from being mistaken for a proof of impossibility.
    if amount > 10**15 or any(item.shortfall * item.unit_price_cents > 10**15 for item in eligible):
        return SolverResult((), False, "ortools_cp_sat", (_issue("numeric_solver_limit", "Amounts exceed the supported solver range."),))
    model = cp_model.CpModel()
    selected = [model.new_bool_var(f"select_{index}") for index in range(len(eligible))]
    model.add(sum(selected) >= (2 if pack.notice["scope"] == "multi_line" else 1))
    if pack.notice["scope"] == "single_line":
        model.add(sum(selected) == 1)
    model.add(sum(variable * item.shortfall * item.unit_price_cents for variable, item in zip(selected, eligible)) == amount)
    if pack.notice.get("short_qty") is not None:
        model.add(sum(variable * item.shortfall for variable, item in zip(selected, eligible)) == pack.notice["short_qty"])
    by_invoice, by_physical = defaultdict(list), defaultdict(list)
    for variable, item in zip(selected, eligible):
        by_invoice[item.invoice_line_id].append(variable)
        by_physical[(item.shipment_id, item.sku)].append(variable)
    for group in (*by_invoice.values(), *by_physical.values()):
        model.add(sum(group) <= 1)

    class Collector(cp_model.CpSolverSolutionCallback):
        def __init__(self):
            super().__init__()
            self.allocations, self.capped = [], False

        def on_solution_callback(self):
            lines = tuple(_line(item, item.shortfall, "independent_receipt_shortfall")
                          for variable, item in zip(selected, eligible) if self.value(variable))
            self.allocations.append(Allocation(lines, sum(line["amount_cents"] for line in lines),
                                               sum(line["quantity"] for line in lines)))
            if len(self.allocations) >= max_solutions:
                self.capped = True
                self.stop_search()

    solver, collector = cp_model.CpSolver(), Collector()
    solver.parameters.max_time_in_seconds = max_seconds
    solver.parameters.num_search_workers = 1
    solver.parameters.enumerate_all_solutions = True
    status = solver.solve(model, collector)
    complete = status in (cp_model.OPTIMAL, cp_model.INFEASIBLE) and not collector.capped
    result_issues = () if complete else (_issue("incomplete_search", "Timeout, solution cap, or solver status prevented complete enumeration."),)
    return SolverResult(tuple(sorted(collector.allocations, key=lambda item: item.key)), complete,
                        "ortools_cp_sat", result_issues,
                        {"status": solver.status_name(status), "candidate_count": len(candidates),
                         "eligible_receipt_lines": len(eligible), "solutions": len(collector.allocations),
                         "solution_cap": max_solutions, "max_seconds": max_seconds,
                         "scope": pack.notice["scope"], "method": "multi"})
