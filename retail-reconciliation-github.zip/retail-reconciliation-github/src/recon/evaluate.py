"""Offline evaluator using hidden labels (never passed to matcher)."""
from __future__ import annotations
import argparse
import csv
import json
from collections import Counter
from pathlib import Path
from .storage import load_data
from .engine import reconcile_all


def evaluate(data_dir: str | Path, labels_path: str | Path) -> dict:
    conn = load_data(data_dir)
    results = reconcile_all(conn)
    with Path(labels_path).open(newline="", encoding="utf-8") as f:
        truth = {row["deduction_id"]: row for row in csv.DictReader(f)}
    counts = Counter(result["status"] for result in results)
    wrong_auto = 0
    correct_auto = 0
    for result in results:
        if result["status"] == "matched":
            chosen = result["candidates"][0]
            actual = truth[result["deduction_id"]]
            match = (chosen["invoice_line_id"] == actual["true_invoice_line_id"] and
                     chosen["shipment_id"] == actual["true_shipment_id"])
            if match:
                correct_auto += 1
            else:
                wrong_auto += 1
    return {
        "dataset": "Synthetic test fixture, not real retail transactions",
        "total_cases": len(results),
        "status_counts": dict(counts),
        "correct_automatic_links": correct_auto,
        "incorrect_automatic_links": wrong_auto,
        "automatic_link_accuracy_when_matched": (correct_auto / (correct_auto + wrong_auto)) if (correct_auto + wrong_auto) else None,
        "automatic_link_coverage": (correct_auto + wrong_auto) / len(results) if results else 0,
        "note": "These metrics measure transaction linking, NOT retailer deduction legitimacy or recovery dollars.",
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data")
    parser.add_argument("--truth", default="evaluation/ground_truth.csv")
    args = parser.parse_args()
    print(json.dumps(evaluate(args.data, args.truth), indent=2))

if __name__ == "__main__":
    main()
