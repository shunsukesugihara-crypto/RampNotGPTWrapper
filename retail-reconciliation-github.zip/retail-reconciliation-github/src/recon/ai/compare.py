"""Compare AI-constructed procedures with unchanged deterministic controls.

The default four cases are small, previously authored synthetic examples, not
held-out retail evidence. Evaluation labels stay outside every engine/provider.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import sqlite3
from time import perf_counter

from recon.phase2.compare import _baseline_result, _read_labels, build_challenges
from recon.phase2.executor import RapidFuzzRanker
from recon.phase2.service import reconcile as offline_reconcile
from recon.phase2.storage import load_data, source_digest
from .provider import create_provider
from .service import reconcile as ai_reconcile


ROOT = Path(__file__).resolve().parents[3]
DEFAULT_IDS = ("D-DEMO-PO", "D-DEMO-AMBIG", "D-P2-EXACT-TEXT", "D-P2-MISSING-QTY")
ENGINES = ("baseline", "phase2_offline", "ai")
# These are authored evaluation expectations for the named demo scenarios, not
# decisions obtained by running either comparison engine. Unknown scenarios do
# not acquire an automatic-link permission label by guessing from a control.
DEMO_PERMISSIONS = {
    "unique_reference_receipt_support": True,
    "ambiguous_two_same_priced_products": False,
    "matched_transaction_conflicting_receipt": True,
    "invalid_amount": False,
    "missing_receiving_evidence": True,
}


def _clone(conn: sqlite3.Connection) -> sqlite3.Connection:
    clone = sqlite3.connect(":memory:")
    clone.row_factory = sqlite3.Row
    conn.backup(clone)
    return clone


def _assess(result: dict, label: dict) -> dict:
    matched = result.get("status") == "matched"
    candidates = result.get("candidates", [])
    correct = None
    if matched:
        correct = len(candidates) == 1 and (
            candidates[0].get("invoice_line_id") == label["true_invoice_line_id"]
            and candidates[0].get("shipment_id") == label["true_shipment_id"])
    permission = label.get("automatic_link_permitted")
    return {
        "automatic_link_correct": correct,
        "automatic_link_permitted": permission,
        "inappropriate_automatic_link": matched and (correct is not True or permission is False),
        "automatic_link_justification_assessed": not matched or permission is not None,
    }


def _actions(result: dict) -> tuple[str, ...]:
    return tuple(step["op"] for step in (result.get("plan") or {}).get("operations", []))


def _summary(records: list[dict]) -> dict:
    counts = Counter(record["result"]["status"] for record in records)
    matched = [record for record in records if record["result"]["status"] == "matched"]
    correct = sum(record["evaluation"]["automatic_link_correct"] is True for record in matched)
    inappropriate = sum(record["evaluation"]["inappropriate_automatic_link"] for record in matched)
    decisions, failed_attempts, unverified_attempts = [], 0, 0
    for record in records:
        result = record["result"]
        for decision in result.get("planning_decisions", []):
            audit = decision.get("audit")
            if isinstance(audit, dict) and audit.get("error_type") is not None:
                failed_attempts += 1
            elif (result.get("reason") == "invalid_provider_completion"
                  and decision.get("action") is None):
                # The controller records an attempt before invoking a provider.
                # A missing/malformed return object is not a model completion,
                # despite that attempt's initial audit marker being live=False.
                unverified_attempts += 1
            else:
                decisions.append(decision)
    live = sum((decision.get("audit") or {}).get("live") is True for decision in decisions)
    injected = sum((decision.get("audit") or {}).get("live") is False
                   and decision.get("action") is not None for decision in decisions)
    procedures = sorted({_actions(record["result"]) for record in records if _actions(record["result"])})
    return {
        "case_count": len(records),
        "status_counts": dict(counts),
        "input_supported_cases": sum(record["input_supported"] for record in records),
        "unsupported_input_cases": sum(not record["input_supported"] for record in records),
        "automatic_links": len(matched),
        "identity_correct_automatic_links": correct,
        "identity_wrong_automatic_links": len(matched) - correct,
        "inappropriate_automatic_links": inappropriate,
        "unassessed_automatic_link_justifications": sum(
            not record["evaluation"]["automatic_link_justification_assessed"] for record in matched),
        "automatic_identity_precision": correct / len(matched) if matched else None,
        "automatic_coverage": len(matched) / len(records) if records else None,
        "review_cases": counts["review"],
        "no_match_cases": counts["no_match"],
        "model_call_attempts": sum(record["result"].get("model_calls", 0) for record in records),
        "failed_model_attempts": failed_attempts,
        "unverified_model_attempts": unverified_attempts,
        "recorded_model_completions": len(decisions),
        "live_model_completions": live,
        "injected_model_completions": injected,
        "unverified_model_completions": len(decisions) - live - injected,
        "cases_with_fully_live_planning": sum(record["result"].get("live_ai") is True for record in records),
        "distinct_procedure_count": len(procedures),
        "actual_procedures": [list(procedure) for procedure in procedures],
        "source_records_unchanged": all(record["source_hash_before"] == record["source_hash_after"] for record in records),
        "runtime_ms_total": sum(record["runtime_ms"] for record in records),
    }


def compare(
    data_dir: str | Path = ROOT / "data",
    labels_path: str | Path = ROOT / "evaluation/ground_truth.csv",
    *,
    provider=None,
    deduction_ids: list[str] | tuple[str, ...] | None = None,
    provider_kind: str = "auto",
    model: str | None = None,
    rank_text: bool = False,
    max_steps: int = 8,
    include_challenges: bool = True,
) -> dict:
    provider_was_injected = provider is not None
    ids = tuple(DEFAULT_IDS if deduction_ids is None else deduction_ids)
    if not ids or len(ids) != len(set(ids)):
        raise ValueError("Choose at least one distinct deduction ID")
    if type(max_steps) is not int or not 1 <= max_steps <= 8:
        raise ValueError("max_steps must be an integer from 1 to 8")
    labels = _read_labels(labels_path)
    for label in labels.values():
        label["automatic_link_permitted"] = DEMO_PERMISSIONS.get(label.get("scenario"))
    source = load_data(data_dir)
    try:
        if include_challenges:
            for expectation in build_challenges(source):
                labels[expectation.deduction_id] = {
                    "true_invoice_line_id": expectation.true_invoice_line_id,
                    "true_shipment_id": expectation.true_shipment_id,
                    "scenario": expectation.scenario,
                    "automatic_link_permitted": expectation.phase2_status == "matched",
                }
        available = {row[0] for row in source.execute("SELECT deduction_id FROM deductions")}
        if set(ids) - available:
            raise ValueError(f"Unknown deduction IDs: {sorted(set(ids) - available)}")
        if set(ids) - set(labels):
            raise ValueError(f"Missing evaluation labels: {sorted(set(ids) - set(labels))}")
        ranker = RapidFuzzRanker() if rank_text else None
        provider_error = None
        if provider is None:
            try:
                provider = create_provider(provider_kind, model=model)
            except Exception as exc:
                # Controls can still be measured, but a missing live provider
                # must never silently become a deterministic AI implementation.
                provider_error = type(exc).__name__
        rows = []
        for deduction_id in ids:
            row = {"deduction_id": deduction_id, "scenario": labels[deduction_id].get("scenario"),
                   "evaluation_label": dict(labels[deduction_id]), "engines": {}}
            for engine in ENGINES:
                conn = _clone(source)
                before = source_digest(conn)
                started = perf_counter()
                try:
                    if engine == "baseline":
                        result = _baseline_result(conn, deduction_id)
                    elif engine == "phase2_offline":
                        result = offline_reconcile(conn, deduction_id, ranker=ranker)
                    elif provider_error:
                        result = {"deduction_id": deduction_id, "engine": "ai_controller",
                                  "planner": "model_controller", "status": "review", "candidates": [],
                                  "reason": "planner_unavailable", "error_type": provider_error,
                                  "model_calls": 0, "planning_decisions": [], "live_ai": False,
                                  "plan": {"version": 1, "operations": []}}
                    else:
                        result = ai_reconcile(conn, deduction_id, provider=provider,
                                              ranker=ranker, max_steps=max_steps)
                    after = source_digest(conn)
                finally:
                    conn.close()
                row["engines"][engine] = {
                    "result": result,
                    "input_supported": result["status"] != "unsupported",
                    "evaluation": _assess(result, labels[deduction_id]),
                    "source_hash_before": before,
                    "source_hash_after": after,
                    "runtime_ms": (perf_counter() - started) * 1000,
                    "actual_actions": list(_actions(result)),
                }
            rows.append(row)
        summaries = {engine: _summary([row["engines"][engine] for row in rows]) for engine in ENGINES}
        common = [row for row in rows if row["engines"]["baseline"]["input_supported"]]
        live = summaries["ai"]["live_model_completions"]
        return {
            "dataset": "Previously authored synthetic fixture examples; not real retail records or a held-out benchmark",
            "deduction_ids": list(ids),
            "case_count_per_engine": len(ids),
            "provider_requested": "injected" if provider_was_injected else provider_kind,
            "provider_initialization_error": provider_error,
            "live_ai_evaluated": live > 0,
            "live_model_completions": live,
            "all_ai_cases_fully_live": bool(rows) and all(row["engines"]["ai"]["result"].get("live_ai") is True for row in rows),
            "source_hash": source_digest(source),
            "summaries": summaries,
            "common_baseline_input_cases": {
                "case_count": len(common),
                "summaries": {engine: _summary([row["engines"][engine] for row in common]) for engine in ENGINES},
            },
            "cases": rows,
            "limitations": [
                "Small synthetic examples were already used in development; results are not real-world accuracy estimates.",
                "Phase 1 inputs missing its required amount, quantity, or description are unsupported, not presumed review outcomes.",
                "The common-baseline-input subset separates matching behavior from expanded nullable-input coverage.",
                "Injected scripted completions test controller wiring and cannot demonstrate live AI quality.",
                "Distinct procedures demonstrate observed variation, not that AI causes better matching outcomes than rules.",
                "Identity precision concerns transaction links, not deduction validity, recovered money, or broader financial scope.",
                "Only allowlisted single-line shortage computations are supported; no arbitrary model-generated SQL or Python runs.",
            ],
        }
    finally:
        source.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "data")
    parser.add_argument("--truth", type=Path, default=ROOT / "evaluation/ground_truth.csv")
    parser.add_argument("--provider", choices=("auto", "openai", "codex"), default="auto")
    parser.add_argument("--model")
    parser.add_argument("--deduction", action="append", dest="deduction_ids")
    parser.add_argument("--rank-text", action="store_true")
    parser.add_argument("--max-steps", type=int, default=8)
    parser.add_argument("--no-challenge-fixtures", action="store_true")
    parser.add_argument("--output", type=Path, default=ROOT / "output/ai_comparison.json")
    args = parser.parse_args()
    report = compare(args.data, args.truth, deduction_ids=args.deduction_ids,
                     provider_kind=args.provider, model=args.model, rank_text=args.rank_text,
                     max_steps=args.max_steps, include_challenges=not args.no_challenge_fixtures)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "live_ai_evaluated": report["live_ai_evaluated"],
                      "summaries": report["summaries"]}, indent=2))


if __name__ == "__main__":
    main()
