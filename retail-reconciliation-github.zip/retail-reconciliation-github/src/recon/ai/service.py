"""AI chooses each next computation; code executes and independently verifies."""
from copy import deepcopy

from recon.phase2.contracts import PlanError
from recon.phase2.executor import Execution
from recon.phase2.storage import source_digest, source_issues
from recon.phase2.verifier import verify
from .analysis import inspect
from .contracts import ACTION_SCHEMA, Action
from .executor import State, available_actions, execute, observe, verification_plan

INSTRUCTIONS = """Choose one next computational operation, never a transaction or financial value.
Return exactly {\"operation\": <one allowed name>} using the supplied schema.
You see structural field availability first. No candidate search, reference filtering,
or financial matching has run before your first choice. Each selected operation is
executed by trusted code; subsequent observations describe its actual surviving set.
lookup_provided_references retrieves related retailer/order/invoice/shipment records
and checks every provided notice reference. enumerate_retailer_records instead
retrieves the broad retailer/date set, allowing other filters before references.
filter_references checks all provided references against the current set.
check_reported_quantity_amount checks positive integer quantity times invoice price
against the recorded amount, with shipped and invoiced quantity bounds.
derive_quantity_from_amount requires missing reported quantity, exact integer division
of recorded amount by invoice price, and quantity bounds. Derived quantities require
independent receipt corroboration before any automatic link.
compare_exact_catalog_description filters the current set by normalized catalog text;
it is available only when an actual exact match exists. It may run before or after
arithmetic. rank_description is optional advisory ordering and never removes candidates.
Choose at most one text comparison operation. Operations do not accept parameters.
Use finish only after source retrieval, every provided reference check, and the correct
arithmetic operation have executed. Finish requests independent verification; ordinary
code alone decides matched/review/no_match, and never guesses between tied candidates.
request_review ends without establishing a match when evidence/tools are insufficient.
Select only available_operations, use each computation once, and respect steps_remaining.
The operation list defines allowed tools and dependencies, not a prescribed workflow.
"""


def reconcile(conn, deduction_id: str, provider=None, ranker=None, max_steps: int = 8) -> dict:
    if type(max_steps) is not int or not 1 <= max_steps <= 8:
        raise ValueError("max_steps must be an integer from 1 to 8")
    row = conn.execute("SELECT * FROM deductions WHERE deduction_id=?", (deduction_id,)).fetchone()
    if row is None:
        raise KeyError(f"Unknown deduction: {deduction_id}")
    notice = dict(row)
    profile = inspect(conn, notice, ranker is not None)
    result = {"deduction_id": deduction_id, "notice": notice, "engine": "ai_controller",
              "planner": "model_controller", "status": "review", "reason": "not_executed",
              "candidates": [], "claim_assessment": "not_assessed", "profile": profile,
              "plan": {"version": 1, "operations": []}, "trace": [], "planning_decisions": [],
              "model_calls": 0, "live_ai": False, "verification": {"passed": False}}
    if notice["reason"] != "shortage":
        return {**result, "reason": "unsupported_deduction_type"}
    digest = source_digest(conn)
    if provider is None:
        try:
            from .provider import create_provider
            provider = create_provider()
        except Exception as exc:
            return {**result, "reason": "planner_unavailable", "error_type": type(exc).__name__}
    state = State()
    history = []
    for step in range(1, max_steps + 1):
        if source_digest(conn) != digest:
            return {**result, "reason": "source_records_changed"}
        observation = observe(state, notice)
        available = available_actions(profile, state, observation)
        context = {"profile": deepcopy(profile), "observation": deepcopy(observation),
                   "history": deepcopy(history), "available_operations": [action.value for action in available],
                   "steps_remaining": max_steps - step + 1}
        result["model_calls"] += 1
        decision = {"step": step, "audit": {"live": False}, "action": None,
                    "observation_before": observation, "observation": None,
                    "available_operations": list(context["available_operations"]),
                    "steps_remaining": context["steps_remaining"]}
        result["planning_decisions"].append(decision)
        try:
            completion = provider.complete(INSTRUCTIONS, context, deepcopy(ACTION_SCHEMA))
        except Exception as exc:
            decision["audit"]["error_type"] = type(exc).__name__
            return {**result, "reason": "planner_unavailable", "error_type": type(exc).__name__, "live_ai": False}
        audit = getattr(completion, "audit", None)
        if not isinstance(audit, dict):
            return {**result, "reason": "invalid_provider_completion", "live_ai": False}
        decision["audit"] = deepcopy(audit)
        result["live_ai"] = all(item["audit"].get("live") is True for item in result["planning_decisions"])
        if source_digest(conn) != digest:
            return {**result, "reason": "source_records_changed"}
        try:
            action = Action.from_dict(getattr(completion, "value", None))
            decision["action"] = action.value
            if action not in available:
                raise PlanError("Operation is unavailable, repeated, or misses required checks")
        except PlanError:
            return {**result, "reason": "invalid_model_action"}
        result["plan"]["operations"].append({"op": action.value})
        if action == Action.REVIEW:
            decision["observation"] = observation
            result["trace"].append({"operation": action.value, "input_count": len(state.hypotheses),
                                    "output_count": len(state.hypotheses), "tool": "model_requested_abstention"})
            return {**result, "reason": "model_requested_review"}
        if action == Action.FINISH:
            # No computation is inserted to repair a model's incomplete method.
            try:
                plan = verification_plan(state)
                checked = verify(conn, dict(notice), plan, Execution(state.hypotheses, ()), expected_digest=digest)
            except Exception as exc:
                return {**result, "reason": "verification_failed", "error_type": type(exc).__name__}
            if source_digest(conn) != digest:
                return {**result, "reason": "source_records_changed"}
            result.update(checked)
            decision["observation"] = {**observation, "verification_passed": result["verification"]["passed"]}
            result["trace"].append({"operation": action.value, "input_count": len(state.hypotheses),
                                    "output_count": len(result["candidates"]), "tool": "independent_source_record_checks",
                                    "passed": result["verification"]["passed"]})
            result["verification_plan"] = plan.to_dict()
            return result
        # Source validation is deliberately after the first model choice. It
        # must not precompute joins or financial evidence before planning.
        issues = source_issues(conn)
        if issues:
            return {**result, "reason": "invalid_source_data", "data_issues": issues}
        before = len(state.hypotheses)
        try:
            state = execute(conn, dict(notice), deepcopy(profile), state, action, ranker=ranker)
        except Exception as exc:
            return {**result, "reason": "operation_failed", "error_type": type(exc).__name__}
        if source_digest(conn) != digest:
            return {**result, "reason": "source_records_changed"}
        after = observe(state, notice)
        decision["observation"] = after
        history.append({"action": action.value, "observation": after})
        result["trace"].append({"operation": action.value, "input_count": before,
                                "output_count": len(state.hypotheses), "advisory_only": action == Action.RANK,
                                "tool": ranker.name if action == Action.RANK else "sqlite" if action in (Action.LOOKUP, Action.ENUMERATE) else "python"})
    return {**result, "reason": "model_step_limit"}
