"""Bounded model-selected actions. No generated code, parameters, or match IDs."""
from enum import Enum

from recon.phase2.contracts import PlanError


class Action(str, Enum):
    LOOKUP = "lookup_provided_references"
    ENUMERATE = "enumerate_retailer_records"
    REFERENCES = "filter_references"
    AMOUNT = "check_reported_quantity_amount"
    DERIVE = "derive_quantity_from_amount"
    EXACT = "compare_exact_catalog_description"
    RANK = "rank_description"
    FINISH = "finish"
    REVIEW = "request_review"

    @classmethod
    def from_dict(cls, value):
        if not isinstance(value, dict) or set(value) != {"operation"}:
            raise PlanError("Return exactly one operation without parameters")
        if type(value["operation"]) is not str:
            raise PlanError("Operation must be an allowlisted name")
        try:
            return cls(value["operation"])
        except ValueError:
            raise PlanError("Unsupported operation") from None


ACTION_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {"operation": {"type": "string", "enum": [action.value for action in Action]}},
    "required": ["operation"],
}
