"""Pre-model inspection of structure only; never computes matching evidence."""
from recon.storage import TABLES

REFERENCE_FIELDS = ("po_hint", "invoice_hint", "shipment_hint", "sku_hint")


def inspect(conn, notice: dict, rankerAvailable: bool = False) -> dict:
    """Only known table schemas, row counts, and notice field availability."""
    return {
        "schema": {table: columns.split(",") for table, columns in TABLES.items()},
        "relationships": [
            "purchase_orders.po_id -> invoices.po_id",
            "invoices.invoice_id -> invoice_lines.invoice_id",
            "products.sku -> invoice_lines.sku",
            "purchase_orders.po_id -> shipments.po_id",
            "shipments.shipment_id -> shipment_lines.shipment_id",
            "products.sku -> shipment_lines.sku",
            "shipment_lines.(shipment_id,sku) -> receipts.(shipment_id,sku) (optional)",
        ],
        "row_counts": {table: conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] for table in TABLES},
        "present_notice_fields": [key for key, value in notice.items() if value is not None and value != ""],
        "missing_notice_fields": [key for key, value in notice.items() if value is None or value == ""],
        "provided_reference_fields": [key for key in REFERENCE_FIELDS if notice[key] is not None],
        "amount_available": notice["amount_cents"] is not None,
        "reported_quantity_available": notice["short_qty"] is not None,
        "description_available": bool(notice["description"]),
        "text_ranking_available": bool(rankerAvailable),
    }
