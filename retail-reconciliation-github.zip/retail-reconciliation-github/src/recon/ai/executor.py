"""Trusted, single-action execution; no hidden offline routing or winner choice."""
from dataclasses import dataclass, replace
import math

from recon.engine import generate_candidates
from recon.phase2.analysis import quantity_for, respects_references
from recon.phase2.contracts import MethodPlan, Op, PlanError, normalize_description
from recon.phase2.executor import Hypothesis
from .contracts import Action


@dataclass(frozen=True)
class State:
    hypotheses: tuple[Hypothesis, ...] = ()
    source_loaded: bool = False
    references_checked: bool = False
    arithmetic: Action | None = None
    actions: tuple[Action, ...] = ()


def observe(state: State, notice: dict) -> dict:
    result = {"source_loaded": state.source_loaded, "references_checked": state.references_checked,
              "arithmetic_operation": state.arithmetic.value if state.arithmetic else None}
    if state.source_loaded:
        items = state.hypotheses
        exact = normalize_description(notice["description"])
        result.update(candidate_count=len(items), distinct_sku_count=len({item.candidate.sku for item in items}),
                      distinct_unit_price_count=len({item.candidate.unit_price_cents for item in items}),
                      receipt_available_count=sum(item.candidate.received_qty is not None for item in items),
                      exact_description_sku_count=len({item.candidate.sku for item in items
                          if exact and normalize_description(item.candidate.product_description) == exact}))
    return result


def available_actions(profile: dict, state: State, observation: dict) -> list[Action]:
    actions = [Action.REVIEW]
    if not state.source_loaded:
        actions.append(Action.ENUMERATE)
        if profile["provided_reference_fields"]:
            actions.append(Action.LOOKUP)
    else:
        if profile["provided_reference_fields"] and not state.references_checked:
            actions.append(Action.REFERENCES)
        if state.arithmetic is None and profile["amount_available"]:
            actions.append(Action.AMOUNT if profile["reported_quantity_available"] else Action.DERIVE)
        if not any(action in state.actions for action in (Action.EXACT, Action.RANK)):
            if observation["exact_description_sku_count"] > 0:
                actions.append(Action.EXACT)
            if profile["description_available"] and profile["text_ranking_available"]:
                actions.append(Action.RANK)
        if state.arithmetic is not None and (not profile["provided_reference_fields"] or state.references_checked):
            actions.append(Action.FINISH)
    return [action for action in actions if action not in state.actions]


def execute(conn, notice: dict, profile: dict, state: State, action: Action, ranker=None) -> State:
    if action not in available_actions(profile, state, observe(state, notice)):
        raise PlanError("Operation violates prerequisites or repeats an executed action")
    if action in (Action.FINISH, Action.REVIEW):
        raise PlanError("Terminal decisions are handled by the independent controller")
    items = state.hypotheses
    if action in (Action.LOOKUP, Action.ENUMERATE):
        items = tuple(Hypothesis(candidate) for candidate in generate_candidates(conn, notice))
        if action == Action.LOOKUP:
            items = tuple(item for item in items if respects_references(notice, item.candidate))
        return State(items, True, action == Action.LOOKUP, None, state.actions + (action,))
    if action == Action.REFERENCES:
        items = tuple(item for item in items if respects_references(notice, item.candidate))
    elif action in (Action.AMOUNT, Action.DERIVE):
        evaluated = []
        for item in items:
            quantity = quantity_for(notice, item.candidate)
            if quantity is not None:
                evaluated.append(replace(item, quantity=quantity,
                                         quantity_source="reported" if action == Action.AMOUNT else "amount_divided_by_invoice_price"))
        items = tuple(evaluated)
    elif action == Action.EXACT:
        text = normalize_description(notice["description"])
        items = tuple(item for item in items if normalize_description(item.candidate.product_description) == text)
    elif action == Action.RANK:
        ranked = []
        for item in items:
            try:
                score = ranker.score(notice["description"], item.candidate.product_description)
            except Exception:
                raise ValueError("Advisory ranking failed") from None
            if type(score) not in (int, float) or not math.isfinite(score) or not 0 <= score <= 100:
                raise ValueError("Invalid advisory score")
            ranked.append(replace(item, text_score=float(score)))
        items = tuple(sorted(ranked, key=lambda item: (-item.text_score, item.key)))
    return replace(state, hypotheses=items, references_checked=state.references_checked or action == Action.REFERENCES,
                   arithmetic=action if action in (Action.AMOUNT, Action.DERIVE) else state.arithmetic,
                   actions=state.actions + (action,))


def verification_plan(state: State) -> MethodPlan:
    """Canonical verifier contract records only operations the model executed.

    The order here is the historical verifier's input format. The separate AI
    trace retains actual execution order, including text-before-arithmetic.
    """
    if not state.source_loaded or state.arithmetic is None:
        raise PlanError("Cannot verify a method missing source or arithmetic operations")
    ops = [Op.JOIN]
    if state.references_checked:
        ops.append(Op.REFERENCES)
    ops.append(Op.AMOUNT if state.arithmetic == Action.AMOUNT else Op.DERIVE_QUANTITY)
    if Action.EXACT in state.actions:
        ops.append(Op.EXACT_DESCRIPTION)
    elif Action.RANK in state.actions:
        ops.append(Op.RANK_TEXT)
    ops.append(Op.VERIFY)
    return MethodPlan(tuple(ops))
