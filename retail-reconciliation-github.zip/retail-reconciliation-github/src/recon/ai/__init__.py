"""Bounded model-directed procedures with ordinary-code execution."""
