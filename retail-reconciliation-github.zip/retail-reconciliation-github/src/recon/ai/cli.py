"""Run a live-provider method controller; no automatic offline substitution."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from recon.phase2.compare import build_challenges
from recon.phase2.executor import RapidFuzzRanker
from recon.phase2.storage import load_data
from .provider import create_provider
from .service import reconcile


ROOT = Path(__file__).resolve().parents[3]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "data")
    parser.add_argument("--deduction", required=True)
    parser.add_argument("--provider", choices=("auto", "openai", "codex"), default="auto")
    parser.add_argument("--model")
    parser.add_argument("--rank-text", action="store_true", help="Enable optional advisory RapidFuzz ordering")
    parser.add_argument("--challenge-fixtures", action="store_true",
                        help="Explicitly append the authored synthetic D-P2 examples to this in-memory run")
    parser.add_argument("--max-steps", type=int, default=8)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        provider = create_provider(args.provider, model=args.model)
        ranker = RapidFuzzRanker() if args.rank_text else None
    except Exception as exc:
        parser.error(f"Live provider or optional tool unavailable ({type(exc).__name__}); no offline fallback")
    conn = load_data(args.data)
    try:
        if args.challenge_fixtures:
            build_challenges(conn)
        result = reconcile(conn, args.deduction, provider=provider, ranker=ranker, max_steps=args.max_steps)
    finally:
        conn.close()
    content = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content, encoding="utf-8")
        print(json.dumps({"output": str(args.output), "status": result["status"],
                          "reason": result["reason"], "live_ai": result["live_ai"],
                          "model_calls": result["model_calls"]}))
    else:
        print(content, end="")


if __name__ == "__main__":
    main()
