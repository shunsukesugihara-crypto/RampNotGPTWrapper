"""Only named source relationships can cross the planner/executor boundary."""
from recon.phase2.contracts import PlanError

OPERATIONS = ("read_evidence", "check_shortfalls", "verify_evidence", "request_review")
SOURCES = ("invoices", "shipments", "receipts", "products")
RELATIONS = ("notice_references", "retailer_and_amount", "candidate_orders", "shipment_product_pairs", "candidate_products")
ACTION_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "operation": {"type": "string", "enum": list(OPERATIONS)},
        "source": {"type": ["string", "null"], "enum": [*SOURCES, None]},
        "relation": {"type": ["string", "null"], "enum": [*RELATIONS, None]},
    }, "required": ["operation", "source", "relation"],
}


def action(operation, source=None, relation=None):
    return {"operation": operation, "source": source, "relation": relation}


def parse_action(value, available):
    if not isinstance(value, dict) or set(value) != {"operation", "source", "relation"}:
        raise PlanError("An approved operation, source and relation are required; financial values and code are forbidden")
    if value not in available:
        raise PlanError("This source relationship is not available at this investigation step")
    return dict(value)

