"""Independent raw-record check for the bounded evidence-investigation demo.

No executor, normalizer, model output parser, or evaluation labels are imported.
Reading all source records here does not excuse missing executor evidence reads:
the required source-access ledger must be present before any verified match.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, localcontext
import hashlib
import json
from pathlib import Path
import re


MAX_INTEGER = (1 << 63) - 1
TABLES = ("products", "purchase_orders", "invoices", "invoice_lines", "shipments", "shipment_lines", "receipts")
KEYS = {"products": ("sku",), "purchase_orders": ("po_id",), "invoices": ("invoice_id",),
        "invoice_lines": ("invoice_line_id",), "shipments": ("shipment_id",),
        "shipment_lines": ("shipment_id", "sku"), "receipts": ("receipt_id",)}
CLAIM_FIELDS = ("invoice_line_id", "invoice_id", "po_id", "sku", "shipment_id", "unit_price_cents",
                "invoiced_qty", "shipped_qty", "received_qty", "shortfall", "amount_cents")


class EvidenceError(ValueError):
    pass


def _text(value):
    if not isinstance(value, str) or not value.strip():
        raise EvidenceError("Missing or invalid source identifier")
    return value.strip()


def _day(value):
    text = _text(value)
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
            return date.fromisoformat(text)
        if re.fullmatch(r"\d{2}/\d{2}/\d{4}", text):
            return datetime.strptime(text, "%m/%d/%Y").date()
    except ValueError:
        pass
    raise EvidenceError("Unsupported source date")


def _integer(value, *, zero=False):
    if type(value) not in (str, int):
        raise EvidenceError("An exact recorded integer is required")
    text = str(value).strip()
    if not re.fullmatch(r"(?:\d+|\d{1,3}(?:,\d{3})+)", text):
        raise EvidenceError("Unsupported integer grouping")
    number = int(text.replace(",", ""))
    if not (0 if zero else 1) <= number <= MAX_INTEGER:
        raise EvidenceError("Quantity is outside the supported range")
    return number


def _currency(value):
    text = _text(value).upper()
    if not re.fullmatch(r"[A-Z]{3}", text):
        raise EvidenceError("An explicit currency is required")
    return text


def _money(value, currency):
    if type(value) not in (str, int):
        raise EvidenceError("Recorded exact money is required")
    text = str(value).strip()
    for symbol, expected in (("$", "USD"), ("€", "EUR")):
        if text.startswith(symbol):
            if currency != expected:
                raise EvidenceError("Currency symbol disagrees with source currency")
            text = text[1:].strip()
    if not re.fullmatch(r"(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?", text):
        raise EvidenceError("Unsupported monetary representation")
    try:
        with localcontext() as context:
            context.prec = max(28, len(text) + 4)
            cents = Decimal(text.replace(",", "")) * 100
            if cents != cents.to_integral_value() or not 0 < cents <= MAX_INTEGER:
                raise EvidenceError("Money must be positive and exact in cents")
            return int(cents)
    except InvalidOperation:
        raise EvidenceError("Invalid source money") from None


def _unit(value):
    unit = _text(value).upper()
    if unit not in ("CS", "EA"):
        raise EvidenceError("Unsupported source unit")
    return unit


def _factor(sku, products, executed):
    if "products" not in executed:
        raise EvidenceError("Product conversion evidence was not retrieved")
    product = products.get(sku)
    if product is None or type(product.get("case_pack")) is not int or not 0 < product["case_pack"] <= MAX_INTEGER or not product.get("source_ref"):
        raise EvidenceError("A verified product-master conversion is absent")
    _text(product["source_ref"])
    return product["case_pack"]


def _quantity(row, products, executed, sku, *, zero=False, optional=False):
    if row.get("quantity") in (None, "") and optional:
        return None
    number = _integer(row.get("quantity"), zero=zero)
    if _unit(row.get("uom")) == "EA":
        factor = _factor(sku, products, executed)
        if number % factor:
            raise EvidenceError("Recorded eaches do not form whole cases")
        number //= factor
    return number


def _identity(row):
    return tuple(row[field] for field in ("invoice_line_id", "shipment_id", "sku"))


def _source(raw, table, index, record):
    return {"path": raw.source_path, "digest": raw.source_digest, "table": table,
            "row": index, "raw": deepcopy(record)}


def _result(reason, *, passed=False, status="review", candidates=None, equations=None, evidence=None, **extra):
    return {"passed": passed, "independent": True, "status": status, "reason": reason,
            "candidates": candidates or [], "equations": equations or [], "evidence": evidence or [],
            "claim_assessment": "not_assessed", "scope": "single-line whole recorded receipt shortfall", **extra}


def verify(raw, claimed_candidates, executed_sources):
    """Rebuild the eligible universe and check every supplied candidate value.

    The executor must supply ALL financially possible invoice/shipment pairs,
    including zero-shortage and missing-receipt alternatives. An omitted rival,
    missing source read, absent receiving record, or unsupported conversion
    prevents a match. A successful mathematical match does not prove liability.
    """
    try:
        executed = set(executed_sources)
        needed = {"purchase_orders", "invoices", "invoice_lines", "shipments", "shipment_lines", "receipts"}
        if not needed <= executed:
            return _result("evidence_not_retrieved", missing_sources=sorted(needed - executed))
        data = raw.data
        source_path = Path(raw.source_path)
        canonical = lambda value: json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
        if raw.source_path == "<memory>":
            if hashlib.sha256(canonical(data).encode()).hexdigest() != raw.source_digest:
                return _result("source_records_changed")
        else:
            if not source_path.is_file():
                return _result("source_record_file_unavailable")
            content = source_path.read_bytes()
            if hashlib.sha256(content).hexdigest() != raw.source_digest or canonical(json.loads(content)) != canonical(data):
                return _result("source_records_changed")
        if type(data.get("version")) is not int or data["version"] != 1:
            raise EvidenceError("Unsupported source version")
        notice = data["notice"]
        if notice.get("scope") != "single_line" or notice.get("basis") != "whole_receipt_shortfalls":
            return _result("unsupported_investigation_scope")
        for table in TABLES:
            if not isinstance(data[table], list) or any(not isinstance(row, dict) for row in data[table]):
                raise EvidenceError("Source arrays are invalid")
            identities = [tuple(_text(row.get(field)) for field in KEYS[table]) for row in data[table]]
            if len(set(identities)) != len(identities):
                return _result("duplicate_source_identity")
        notice_day, currency = _day(notice["notice_date"]), _currency(notice["currency"])
        amount, retailer = _money(notice["amount"], currency), _text(notice["retailer"])
        products = {_text(row["sku"]): row for row in data["products"]}
        requested = None
        if notice.get("short_qty") not in (None, ""):
            requested = _integer(notice["short_qty"])
            if _unit(notice["uom"]) == "EA":
                factor = _factor(notice.get("sku_hint"), products, executed)
                if requested % factor:
                    raise EvidenceError("Notice quantity does not form whole cases")
                requested //= factor
        orders = {_text(row["po_id"]): (i, row) for i, row in enumerate(data["purchase_orders"])}
        invoices = {_text(row["invoice_id"]): (i, row) for i, row in enumerate(data["invoices"])}
        shipments = {_text(row["shipment_id"]): (i, row) for i, row in enumerate(data["shipments"])}
        shipment_lines = {}
        for index, row in enumerate(data["shipment_lines"]):
            key = (_text(row["shipment_id"]), _text(row["sku"]))
            if key[0] not in shipments or key[1] not in products:
                return _result("broken_source_relationship")
            shipment_lines[key] = (index, row)
        receipts = {}
        for index, row in enumerate(data["receipts"]):
            key = (_text(row["shipment_id"]), _text(row["sku"]))
            if key not in shipment_lines:
                return _result("broken_source_relationship")
            if key in receipts:
                return _result("conflicting_receiving_records")
            receipts[key] = (index, row)
        universe, evidence, equations, issues = [], [], [], []
        for line_index, line in enumerate(data["invoice_lines"]):
            invoice_id, sku = _text(line["invoice_id"]), _text(line["sku"])
            if invoice_id not in invoices or sku not in products:
                return _result("broken_source_relationship")
            invoice_index, invoice = invoices[invoice_id]
            po_id = _text(invoice["po_id"])
            if po_id not in orders:
                return _result("broken_source_relationship")
            order_index, order = orders[po_id]
            inv_currency, line_currency = _currency(invoice["currency"]), _currency(line["currency"])
            if inv_currency != line_currency:
                return _result("conflicting_source_currency")
            if inv_currency != currency or _text(order["retailer"]) != retailer:
                continue
            order_day, invoice_day = _day(order["order_date"]), _day(invoice["invoice_date"])
            if not order_day <= invoice_day <= notice_day:
                continue
            if any(notice.get(field) not in (None, "") and _text(notice[field]) != expected
                   for field, expected in (("po_hint", po_id), ("invoice_hint", invoice_id), ("sku_hint", sku))):
                continue
            price = _money(line["unit_price"], currency)
            if _unit(line["price_uom"]) == "EA":
                price *= _factor(sku, products, executed)
            invoiced = _quantity(line, products, executed, sku)
            if requested is not None:
                financially_possible = requested <= invoiced and requested * price == amount
            else:
                financially_possible = amount % price == 0 and 0 < amount // price <= invoiced
            if not financially_possible:
                continue
            related = []
            for (shipment_id, shipment_sku), (shipment_index, shipment_line) in shipment_lines.items():
                _, shipment = shipments[shipment_id]
                if _text(shipment["po_id"]) != po_id or shipment_sku != sku:
                    continue
                shipped_day = _day(shipment["ship_date"])
                if not order_day <= shipped_day <= notice_day or shipped_day < notice_day - timedelta(days=120):
                    continue
                shipped = _quantity(shipment_line, products, executed, sku)
                related.append(shipment_id)
                receipt_pair = receipts.get((shipment_id, sku))
                received, receiving_index, receipt = None, None, None
                if receipt_pair is not None:
                    receiving_index, receipt = receipt_pair
                    receiving_day = _day(receipt["receipt_date"])
                    received = _quantity(receipt, products, executed, sku, zero=True)
                    if received > shipped or not shipped_day <= receiving_day <= notice_day:
                        issues.append("contradictory_receiving_evidence")
                        received = None
                if received is None:
                    issues.append("missing_receiving_evidence")
                shortage = None if received is None else shipped - received
                record = {"invoice_line_id": _text(line["invoice_line_id"]), "invoice_id": invoice_id,
                          "po_id": po_id, "sku": sku, "shipment_id": shipment_id,
                          "unit_price_cents": price, "invoiced_qty": invoiced,
                          "shipped_qty": shipped, "received_qty": received, "shortfall": shortage,
                          "amount_cents": None if shortage is None else shortage * price}
                universe.append(record)
                row_evidence = [_source(raw, "notice", 0, notice), _source(raw, "purchase_orders", order_index, order),
                                _source(raw, "invoices", invoice_index, invoice), _source(raw, "invoice_lines", line_index, line),
                                _source(raw, "shipments", shipments[shipment_id][0], shipment),
                                _source(raw, "shipment_lines", shipment_index, shipment_line)]
                if receipt is not None:
                    row_evidence.append(_source(raw, "receipts", receiving_index, receipt))
                unit_sources = [(line, "uom"), (line, "price_uom"), (shipment_line, "uom")]
                if receipt is not None:
                    unit_sources.append((receipt, "uom"))
                if any(_unit(row.get(field)) == "EA" for row, field in unit_sources):
                    row_evidence.append(_source(raw, "products", next(i for i, p in enumerate(data["products"]) if _text(p["sku"]) == sku), products[sku]))
                evidence.extend(row_evidence)
                equations.append({"invoice_line_id": record["invoice_line_id"], "shipment_id": shipment_id,
                                  "expression": None if shortage is None else f"({shipped} - {received}) × {price} = {shortage * price} cents",
                                  "shortfall_cases": shortage, "amount_cents": record["amount_cents"],
                                  "notice_amount_cents": amount, "notice_quantity_cases": requested,
                                  "supported": shortage is not None and 0 < shortage <= invoiced and shortage * price == amount and (requested is None or shortage == requested)})
            if not related:
                issues.append("missing_shipment_evidence")
        if len(universe) > 12:
            return _result("candidate_limit_exceeded")
        if not isinstance(claimed_candidates, list) or any(not isinstance(row, dict) for row in claimed_candidates):
            return _result("invalid_executor_candidate_ledger")
        claimed = [{field: row.get(field) for field in CLAIM_FIELDS} for row in claimed_candidates]
        identity_fields = {"invoice_line_id", "invoice_id", "po_id", "sku", "shipment_id"}
        if any((type(row[field]) is not str if field in identity_fields else type(row[field]) not in (int, type(None)))
               for row in claimed for field in CLAIM_FIELDS):
            return _result("invalid_executor_candidate_ledger")
        if sorted(claimed, key=_identity) != sorted(universe, key=_identity):
            return _result("executor_candidate_ledger_mismatch", independent_candidates=universe,
                           equations=equations, evidence=evidence)
        if issues:
            return _result("incomplete_or_conflicting_receiving_evidence", independent_candidates=universe,
                           equations=equations, evidence=evidence, issues=sorted(set(issues)))
        supported = [row for row in universe if row["shortfall"] is not None and 0 < row["shortfall"] <= row["invoiced_qty"]
                     and row["amount_cents"] == amount and (requested is None or row["shortfall"] == requested)]
        if len(supported) != 1:
            return _result("ambiguous_supported_relationships" if supported else "no_supported_relationship",
                           passed=True, candidates=supported, equations=equations, evidence=evidence,
                           candidate_universe_count=len(universe))
        return _result("independently_verified_receipt_relationship", passed=True, status="matched", candidates=supported,
                       equations=equations, evidence=evidence, candidate_universe_count=len(universe))
    except (EvidenceError, KeyError, ValueError, TypeError, OverflowError, OSError, RecursionError) as error:
        return _result("unresolved_source_evidence", issue=str(error))
