"""Bounded, evidence-seeking retail investigation; original engines stay separate."""

