"""Small authored demonstrations; none is represented as a genuine retailer case."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from recon.reconstruction.data import load_pack

ROOT = Path(__file__).resolve().parents[3]
FOLDER = ROOT / "evaluation/investigation"
CASES = (
    {"id": "ambiguous-product", "title": "Two products, one supported shortage", "description": "Both invoice prices fit. Shipment and warehouse records establish which product has the recorded shortage."},
    {"id": "missing-receipt", "title": "Missing warehouse evidence", "description": "One possible product lacks its receiving record. A known shortage on another line cannot prove uniqueness."},
    {"id": "reference-mixed-units", "title": "Invoice reference + different units", "description": "An invoice reference narrows the search; receiving units require the documented product conversion."},
)


def catalog():
    output = []
    for row in CASES:
        notice = load_case(row["id"]).data["notice"]
        output.append({**deepcopy(row), "case_id": row["id"], "data_kind": "authored_synthetic",
                       "notice": {key: deepcopy(notice.get(key)) for key in
                                  ("amount", "currency", "short_qty", "uom", "invoice_hint", "po_hint", "description")}})
    return output


def make_pack(case_id):
    if case_id not in {x["id"] for x in CASES}:
        raise ValueError("Unknown investigation case")
    pack = {"version": 1, "notice": {"deduction_id": "D-INVESTIGATION", "retailer": "Example Retail", "notice_date": "2026-10-20", "amount": "$900.00", "currency": "USD", "short_qty": "15", "uom": "CS", "scope": "single_line", "basis": "whole_receipt_shortfalls", "po_hint": None, "invoice_hint": None, "sku_hint": None, "description": "15 cases short; product not identified"}, "products": [], "purchase_orders": [], "invoices": [], "invoice_lines": [], "shipments": [], "shipment_lines": [], "receipts": []}
    for suffix, description in (("A", "Oat cereal 12-pack"), ("B", "Rice cereal 12-pack")):
        pack["products"].append({"sku": "SKU-"+suffix, "description": description, "case_pack": 12, "source_ref": "catalog-2026#SKU-"+suffix})
        pack["purchase_orders"].append({"po_id": "PO-"+suffix, "retailer": "Example Retail", "order_date": "10/01/2026"})
        pack["invoices"].append({"invoice_id": "INV-"+suffix, "po_id": "PO-"+suffix, "invoice_date": "2026-10-03", "currency": "USD"})
        pack["invoice_lines"].append({"invoice_line_id": "LINE-"+suffix, "invoice_id": "INV-"+suffix, "sku": "SKU-"+suffix, "quantity": "100", "uom": "CS", "unit_price": "60.00", "price_uom": "CS", "currency": "USD"})
        pack["shipments"].append({"shipment_id": "SHIP-"+suffix, "po_id": "PO-"+suffix, "ship_date": "2026-10-04"})
        pack["shipment_lines"].append({"shipment_id": "SHIP-"+suffix, "sku": "SKU-"+suffix, "quantity": "100", "uom": "CS"})
        if not (case_id == "missing-receipt" and suffix == "B"):
            quantity = "85" if suffix == "A" else "100"
            if case_id == "reference-mixed-units":
                quantity = "1,020" if suffix == "B" else "1,200"
            pack["receipts"].append({"receipt_id": "RECEIPT-"+suffix, "shipment_id": "SHIP-"+suffix, "sku": "SKU-"+suffix, "quantity": quantity, "uom": "EA" if case_id == "reference-mixed-units" else "CS", "receipt_date": "10/07/2026"})
    if case_id == "reference-mixed-units":
        pack["notice"]["invoice_hint"] = "INV-B"
        pack["notice"]["description"] = "Shortage against referenced invoice; warehouse uses individual units"
    return pack


def write_fixtures():
    FOLDER.mkdir(parents=True, exist_ok=True)
    files = {}
    for item in CASES:
        path = FOLDER / (item["id"] + ".json")
        payload = (json.dumps(make_pack(item["id"]), indent=2, sort_keys=True) + "\n").encode()
        if path.exists() and path.read_bytes() != payload:
            raise ValueError("Refusing to replace an existing investigation source")
        if not path.exists():
            path.write_bytes(payload)
        files[path.name] = hashlib.sha256(payload).hexdigest()
    manifest = {"data_kind": "authored_synthetic", "scope": "Three hand-authored engineering demonstrations, not an external benchmark", "files": files}
    target = FOLDER / "manifest.json"
    payload = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    if target.exists() and target.read_bytes() != payload:
        raise ValueError("Refusing to replace investigation manifest")
    if not target.exists():
        target.write_bytes(payload)
    return manifest


def load_case(case_id):
    if case_id not in {x["id"] for x in CASES}:
        raise ValueError("Unknown investigation case")
    manifest = json.loads((FOLDER / "manifest.json").read_text())
    path = FOLDER / (case_id + ".json")
    if hashlib.sha256(path.read_bytes()).hexdigest() != manifest["files"][path.name]:
        raise ValueError("Investigation source changed after publication")
    return load_pack(path)


if __name__ == "__main__":
    print(json.dumps(write_fixtures(), indent=2))
