"""Model orchestration checks; scripted responses are explicitly not live inference."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from recon.ai.provider import Completion
from recon.reconstruction.contracts import RawPack
from recon.reconstruction.service import reconcile

ROOT = Path(__file__).resolve().parents[1]


class ScriptedProvider:
    def __init__(self, operations):
        self.operations = list(operations)
        self.contexts = []

    def complete(self, instructions, context, schema):
        self.contexts.append(deepcopy(context))
        value = self.operations.pop(0)
        return Completion(value if isinstance(value, dict) else {"operation": value},
                          {"provider": "scripted_test", "live": False})


def development_case(family):
    from recon.reconstruction.data import load_pack
    folder = ROOT / "evaluation/reconstruction"
    index = [json.loads(line) for line in (folder / "index.jsonl").read_text().splitlines()]
    row = next(row for row in index if row["family"] == family and row["split"] == "development")
    return load_pack(folder / row["raw_path"])


class ReconstructionControllerTests(unittest.TestCase):
    def test_model_selects_actual_oss_solver_and_sources_stay_unchanged(self):
        raw = development_case("unique_two_line")
        before = deepcopy(raw.data)
        provider = ScriptedProvider(["normalize_source_records", "join_financial_records",
                                     "solve_receipt_shortfall_allocation", "verify_reconstruction"])
        result = reconcile(raw, provider=provider)
        self.assertEqual(result["status"], "matched", result)
        self.assertFalse(result["live_ai"])
        self.assertEqual(result["model_calls"], 4)
        self.assertTrue(result["verification"]["passed"])
        self.assertEqual(raw.data, before)
        self.assertEqual(len(result["candidates"][0]["lines"]), 2)
        self.assertIn("ortools", result["search"]["tool"].lower())
        self.assertNotIn("candidate_count", provider.contexts[0]["observation"])
        self.assertIn("candidate_count", provider.contexts[2]["observation"])
        self.assertIn("reconstructed_records", result)

    def test_single_line_diagnostic_can_be_followed_by_combination_search(self):
        provider = ScriptedProvider(["normalize_source_records", "join_financial_records",
                                     "check_single_line_constraints", "solve_receipt_shortfall_allocation",
                                     "verify_reconstruction"])
        result = reconcile(development_case("unique_two_line"), provider=provider)
        self.assertEqual(result["status"], "matched", result)
        self.assertEqual(provider.contexts[3]["observation"]["solution_count"], 0)
        self.assertEqual(result["search"]["method"], "multi")

    def test_single_line_search_cannot_claim_completeness_for_unknown_scope(self):
        provider = ScriptedProvider(["normalize_source_records", "join_financial_records",
                                     "check_single_line_constraints", "verify_reconstruction"])
        result = reconcile(development_case("unknown_scope"), provider=provider)
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "invalid_model_action")
        self.assertFalse(result["verification"]["passed"])

    def test_ambiguous_allocations_remain_review(self):
        provider = ScriptedProvider(["normalize_source_records", "join_financial_records",
                                     "solve_receipt_shortfall_allocation", "verify_reconstruction"])
        result = reconcile(development_case("ambiguous_two_line"), provider=provider)
        self.assertEqual(result["status"], "review", result)
        self.assertGreaterEqual(len(result["candidates"]), 2)

    def test_conversion_is_grounded_in_product_master_and_missing_factor_abstains(self):
        operations = ["normalize_source_records", "join_financial_records",
                      "check_single_line_constraints", "verify_reconstruction"]
        good = reconcile(development_case("mixed_units"), provider=ScriptedProvider(operations))
        self.assertEqual(good["status"], "matched", good)
        self.assertTrue(good["transformations"])
        bad = reconcile(development_case("missing_conversion"), provider=ScriptedProvider(operations))
        self.assertEqual(bad["status"], "review")
        self.assertEqual(bad["reason"], "unresolved_source_normalization")
        self.assertEqual(bad["model_calls"], 1)

    def test_no_normalization_or_search_before_first_model_call(self):
        from recon.reconstruction.data import normalize
        from recon.reconstruction.solver import join_candidates
        provider = ScriptedProvider(["normalize_source_records", "request_review"])
        original = provider.complete
        with patch("recon.reconstruction.data.normalize", wraps=normalize) as normalization, \
                patch("recon.reconstruction.solver.join_candidates", wraps=join_candidates) as join:
            def first(*args):
                if not provider.contexts:
                    normalization.assert_not_called()
                    join.assert_not_called()
                return original(*args)
            provider.complete = first
            result = reconcile(development_case("single_clear"), provider=provider)
        self.assertEqual(result["status"], "review")

    def test_ids_guessed_values_and_generated_code_are_rejected(self):
        for action in ({"operation": "normalize_source_records", "sql": "SELECT * FROM invoices"},
                       {"operation": "normalize_source_records", "match": "L-secret"},
                       {"operation": "run_python"}):
            with self.subTest(action=action):
                result = reconcile(development_case("single_clear"), provider=ScriptedProvider([action]))
                self.assertEqual(result["reason"], "invalid_model_action")
                self.assertEqual(result["candidates"], [])

    def test_model_failure_does_not_fall_back_and_limit_is_enforced(self):
        provider = ScriptedProvider([])
        result = reconcile(development_case("single_clear"), provider=provider)
        self.assertEqual(result["reason"], "planner_unavailable")
        result = reconcile(development_case("single_clear"), provider=ScriptedProvider(["normalize_source_records"]), max_steps=1)
        self.assertEqual(result["reason"], "model_step_limit")
        self.assertEqual(result["candidates"], [])

    def test_one_solution_before_search_cap_is_not_a_unique_match(self):
        provider = ScriptedProvider(["normalize_source_records", "join_financial_records",
                                     "solve_receipt_shortfall_allocation", "verify_reconstruction"])
        result = reconcile(development_case("unique_two_line"), provider=provider,
                           solver_options={"max_solutions": 1})
        self.assertEqual(result["status"], "review")
        self.assertFalse(result["search"]["complete"])
        self.assertFalse(result["verification"]["passed"])

    def test_missing_reported_total_is_not_overwritten_by_computed_allocation(self):
        raw = development_case("missing_quantity_multi")
        provider = ScriptedProvider(["normalize_source_records", "join_financial_records",
                                     "solve_receipt_shortfall_allocation", "verify_reconstruction"])
        result = reconcile(raw, provider=provider)
        self.assertEqual(result["status"], "matched", result)
        self.assertIsNone(raw.data["notice"]["short_qty"])
        self.assertIsNone(result["notice"]["short_qty"])
        self.assertGreater(result["candidates"][0]["short_qty"], 0)

    def test_source_mutation_during_model_request_cannot_support_result(self):
        loaded = development_case("single_clear")
        raw = RawPack(deepcopy(loaded.data), "<memory>", loaded.source_digest)
        provider = ScriptedProvider(["normalize_source_records"])
        original = provider.complete
        def mutate(*args):
            raw.data["notice"]["amount"] = "$999.00"
            return original(*args)
        provider.complete = mutate
        result = reconcile(raw, provider=provider)
        self.assertEqual(result["reason"], "source_records_changed")
        self.assertEqual(result["candidates"], [])


if __name__ == "__main__":
    unittest.main()
