"""Phase 2 contracts and financial abstention checks on independent fixture copies."""
from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import csv
import importlib.util
import json
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.engine import reconcile as baseline_reconcile
from recon.storage import load_data as baseline_load_data
from recon.phase2.contracts import DataProfile, MethodPlan, Op, PlanError, PlannerUnavailable
from recon.phase2.executor import Execution, RapidFuzzRanker, execute
from recon.phase2.service import reconcile
from recon.phase2.storage import load_data, source_digest
from recon.phase2.verifier import verify


class FixedPlanner:
    name = "test_fixed_planner"

    def __init__(self, operations):
        self.operations = operations

    def plan(self, profile):
        return MethodPlan(tuple(self.operations))


class WaterFirstRanker:
    name = "test_advisory_ranker"

    def score(self, query, description):
        return 1.0 if "Water" in description else 0.0


def operation_names(result):
    return [step["op"] for step in result["plan"]["operations"]]


def profile(**changes):
    base = DataProfile(
        present_fields=("amount_cents", "short_qty", "description"),
        missing_fields=(), reference_fields=(), candidate_count=2,
        financially_consistent_count=2, distinct_skus=2,
        exact_description_sku_count=0, receipt_count=2,
        text_ranking_available=False, available_fields={},
    )
    return replace(base, **changes)


class MethodPlanContractTests(unittest.TestCase):
    def test_strict_round_trip(self):
        plan = MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY))
        self.assertEqual(MethodPlan.from_dict(json.loads(json.dumps(plan.to_dict()))), plan)
        plan.validate(profile())

    def test_model_cannot_supply_code_sql_or_a_candidate_id(self):
        valid = MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY)).to_dict()
        for key, value in (("sql", "SELECT * FROM deductions"),
                           ("python", "return 'INV-ABC-A'"),
                           ("candidate_id", "LINE-ABC-A"),
                           ("amount_cents", 90000)):
            with self.subTest(key=key), self.assertRaises(PlanError):
                MethodPlan.from_dict({**valid, key: value})
        for step in ({"op": "execute_sql"}, {"op": Op.AMOUNT.value, "quantity": 15},
                     {"op": Op.REFERENCES.value, "candidate_id": "LINE-ABC-A"}):
            with self.subTest(step=step), self.assertRaises(PlanError):
                MethodPlan.from_dict({"version": 1, "operations": [
                    {"op": Op.JOIN.value}, step, {"op": Op.VERIFY.value}]})

    def test_version_type_and_duplicate_operations_are_rejected(self):
        for version in (True, 1.0, "1", 2):
            with self.subTest(version=version), self.assertRaises(PlanError):
                MethodPlan.from_dict({"version": version, "operations": [
                    {"op": Op.JOIN.value}, {"op": Op.AMOUNT.value}, {"op": Op.VERIFY.value}]})
        with self.assertRaises(PlanError):
            MethodPlan((Op.JOIN, Op.AMOUNT, Op.AMOUNT, Op.VERIFY)).validate(profile())

    def test_dependencies_require_join_arithmetic_and_final_verification(self):
        invalid = (
            (Op.AMOUNT, Op.JOIN, Op.VERIFY),
            (Op.JOIN, Op.VERIFY, Op.AMOUNT),
            (Op.JOIN, Op.RANK_TEXT, Op.AMOUNT, Op.VERIFY),
            (Op.JOIN, Op.EXACT_DESCRIPTION, Op.VERIFY),
            (Op.JOIN, Op.DERIVE_QUANTITY, Op.VERIFY),
        )
        for operations in invalid:
            with self.subTest(operations=operations), self.assertRaises(PlanError):
                MethodPlan(operations).validate(profile(text_ranking_available=True,
                                                       exact_description_sku_count=1))

    def test_provided_references_cannot_be_omitted(self):
        with self.assertRaises(PlanError):
            MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY)).validate(
                profile(reference_fields=("po_hint",)))
        MethodPlan((Op.JOIN, Op.REFERENCES, Op.AMOUNT, Op.VERIFY)).validate(
            profile(reference_fields=("po_hint",)))

    def test_missing_quantity_requires_derivation_and_missing_amount_abstains(self):
        missing_quantity = profile(missing_fields=("short_qty",))
        MethodPlan((Op.JOIN, Op.DERIVE_QUANTITY, Op.VERIFY)).validate(missing_quantity)
        with self.assertRaises(PlanError):
            MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY)).validate(missing_quantity)
        with self.assertRaises(PlanError):
            MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY)).validate(
                profile(missing_fields=("amount_cents",)))

    def test_unavailable_text_operations_are_rejected(self):
        for operation in (Op.EXACT_DESCRIPTION, Op.RANK_TEXT):
            with self.subTest(operation=operation), self.assertRaises(PlanError):
                MethodPlan((Op.JOIN, Op.AMOUNT, operation, Op.VERIFY)).validate(profile())


class Phase2ReconciliationTests(unittest.TestCase):
    def setUp(self):
        self.conn = load_data(ROOT / "data")
        self.addCleanup(self.conn.close)

    def change_notice(self, deduction_id, **changes):
        # The SQL identifiers here come only from static test code, never a model.
        fields = ", ".join(f"{field}=?" for field in changes)
        self.conn.execute(f"UPDATE deductions SET {fields} WHERE deduction_id=?",
                          (*changes.values(), deduction_id))
        self.conn.commit()

    def test_plans_depend_on_available_fields_and_ambiguity(self):
        anchored = reconcile(self.conn, "D-DEMO-PO")
        self.change_notice("D-DEMO-PO", short_qty=None)
        missing_quantity = reconcile(self.conn, "D-DEMO-PO")
        self.change_notice("D-DEMO-AMBIG", description="Sparkling Water Variety Pack 12 x 355mL")
        exact_description = reconcile(self.conn, "D-DEMO-AMBIG")
        self.assertIn(Op.REFERENCES.value, operation_names(anchored))
        self.assertIn(Op.AMOUNT.value, operation_names(anchored))
        self.assertIn(Op.DERIVE_QUANTITY.value, operation_names(missing_quantity))
        self.assertNotIn(Op.AMOUNT.value, operation_names(missing_quantity))
        self.assertIn(Op.EXACT_DESCRIPTION.value, operation_names(exact_description))
        self.assertNotEqual(anchored["plan"], missing_quantity["plan"])
        self.assertIn("short_qty", missing_quantity["profile"]["missing_fields"])

    def test_missing_quantity_is_derived_only_with_financial_and_receiving_support(self):
        self.change_notice("D-DEMO-PO", short_qty=None)
        result = reconcile(self.conn, "D-DEMO-PO")
        self.assertEqual(result["status"], "matched")
        self.assertEqual(result["candidates"][0]["sku"], "SKU-WATER")
        self.assertEqual(result["claim_assessment"], "receiving_records_consistent")
        self.assertIsNone(result["notice"]["short_qty"])
        self.assertIsNone(self.conn.execute(
            "SELECT short_qty FROM deductions WHERE deduction_id='D-DEMO-PO'").fetchone()[0])
        self.assertTrue(result["trace"])
        candidate = result["candidates"][0]
        self.assertEqual(candidate["derived_short_qty"], 15)
        self.assertEqual(candidate["financial_check"]["computed_amount_cents"], 90000)
        records = {source["table"]: source for source in candidate["evidence"]}
        self.assertEqual(records["receipts"]["values"]["received_qty"], 85)
        self.assertIsNone(records["deductions"]["values"]["short_qty"])
        self.assertEqual(set(records), {"deductions", "purchase_orders", "invoices", "invoice_lines",
                                        "products", "shipments", "shipment_lines", "receipts"})

    def test_non_integral_amount_does_not_invent_missing_quantity(self):
        self.change_notice("D-DEMO-PO", short_qty=None, amount_cents=90001)
        result = reconcile(self.conn, "D-DEMO-PO")
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["candidates"], [])

    def test_derived_quantity_cannot_exceed_shipped_quantity(self):
        self.change_notice("D-DEMO-PO", short_qty=None, amount_cents=606000)
        result = reconcile(self.conn, "D-DEMO-PO")
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["candidates"], [])

    def test_missing_receipt_blocks_automatic_match_for_derived_quantity_even_with_po(self):
        self.change_notice("D-DEMO-NORECEIPT", short_qty=None)
        result = reconcile(self.conn, "D-DEMO-NORECEIPT")
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["claim_assessment"], "receiving_evidence_unavailable")
        self.assertIsNone(result["candidates"][0]["received_qty"])

    def test_conflicting_receipt_blocks_derived_quantity_but_not_known_quantity_link(self):
        known = reconcile(self.conn, "D-DEMO-CONFLICT")
        self.assertEqual(known["status"], "matched")
        self.assertEqual(known["claim_assessment"],
                         "receiving_records_do_not_support_claimed_quantity")
        self.change_notice("D-DEMO-CONFLICT", short_qty=None)
        derived = reconcile(self.conn, "D-DEMO-CONFLICT")
        self.assertEqual(derived["status"], "review")
        self.assertEqual(derived["claim_assessment"],
                         "receiving_records_do_not_support_claimed_quantity")

    def test_missing_amount_remains_unresolved_without_inventing_a_value(self):
        self.change_notice("D-DEMO-PO", amount_cents=None)
        result = reconcile(self.conn, "D-DEMO-PO")
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["candidates"], [])
        self.assertIn("amount_cents", result["profile"]["missing_fields"])
        self.assertIsNone(self.conn.execute(
            "SELECT amount_cents FROM deductions WHERE deduction_id='D-DEMO-PO'").fetchone()[0])

    def test_missing_description_does_not_require_semantic_model(self):
        self.change_notice("D-DEMO-PO", description=None)
        result = reconcile(self.conn, "D-DEMO-PO")
        self.assertEqual(result["status"], "matched")
        self.assertNotIn(Op.RANK_TEXT.value, operation_names(result))
        self.assertNotIn(Op.EXACT_DESCRIPTION.value, operation_names(result))

    def test_same_price_candidates_are_not_guessed_without_exact_description(self):
        result = reconcile(self.conn, "D-DEMO-AMBIG")
        self.assertEqual(result["status"], "review")
        self.assertEqual({candidate["sku"] for candidate in result["candidates"]},
                         {"SKU-WATER", "SKU-SODA"})

    def test_normalized_exact_description_resolves_same_price_products(self):
        self.change_notice("D-DEMO-AMBIG", description=" SPARKLING water variety pack 12 x 355mL!!! ")
        result = reconcile(self.conn, "D-DEMO-AMBIG")
        self.assertEqual(result["status"], "matched")
        self.assertEqual([candidate["sku"] for candidate in result["candidates"]], ["SKU-WATER"])
        self.assertIn(Op.EXACT_DESCRIPTION.value, operation_names(result))

    def test_exact_description_is_not_sufficient_without_independent_anchor(self):
        self.change_notice("D-DEMO-AMBIG", description="Soda Assortment 12 x 355mL")
        result = reconcile(self.conn, "D-DEMO-AMBIG")
        self.assertEqual(result["status"], "review")
        self.assertEqual([candidate["sku"] for candidate in result["candidates"]], ["SKU-SODA"])

    def test_description_never_overrides_provided_reference(self):
        self.change_notice("D-DEMO-PO", description="Soda Assortment 12 x 355mL")
        result = reconcile(self.conn, "D-DEMO-PO")
        self.assertNotIn("SKU-SODA", {candidate["sku"] for candidate in result["candidates"]})
        self.assertTrue(all(candidate["po_id"] == "PO-ABC-A" for candidate in result["candidates"]))

    def test_advisory_text_ranking_never_removes_candidates_or_matches(self):
        plain = reconcile(self.conn, "D-DEMO-AMBIG")
        ranked = reconcile(self.conn, "D-DEMO-AMBIG", ranker=WaterFirstRanker())
        self.assertEqual(ranked["status"], "review")
        self.assertEqual({candidate["invoice_line_id"] for candidate in plain["candidates"]},
                         {candidate["invoice_line_id"] for candidate in ranked["candidates"]})
        self.assertIn(Op.RANK_TEXT.value, operation_names(ranked))

    @unittest.skipUnless(importlib.util.find_spec("rapidfuzz"), "Install optional text extra for RapidFuzz")
    def test_real_rapidfuzz_adapter_runs_without_resolving_financial_ambiguity(self):
        ranker = RapidFuzzRanker()
        self.assertEqual(ranker.score("Sparkling Water", "Sparkling Water"), 100.0)
        result = reconcile(self.conn, "D-DEMO-AMBIG", ranker=ranker)
        self.assertEqual(result["status"], "review")
        self.assertEqual({candidate["sku"] for candidate in result["candidates"]},
                         {"SKU-WATER", "SKU-SODA"})
        self.assertTrue(result["verification"]["passed"])

    def test_equal_catalog_descriptions_cannot_break_financial_tie(self):
        self.conn.execute("UPDATE products SET description=(SELECT description FROM products "
                          "WHERE sku='SKU-WATER') WHERE sku='SKU-SODA'")
        self.change_notice("D-DEMO-AMBIG", description="Sparkling Water Variety Pack 12 x 355mL")
        result = reconcile(self.conn, "D-DEMO-AMBIG")
        self.assertEqual(result["status"], "review")
        self.assertEqual({candidate["sku"] for candidate in result["candidates"]},
                         {"SKU-WATER", "SKU-SODA"})

    def test_receipt_after_notice_cannot_corroborate_derived_quantity(self):
        self.conn.execute("UPDATE receipts SET receipt_date='2026-08-22' "
                          "WHERE shipment_id='SHP-ABC-A'")
        self.change_notice("D-DEMO-PO", short_qty=None)
        result = reconcile(self.conn, "D-DEMO-PO")
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["claim_assessment"], "receiving_evidence_unavailable")
        self.assertFalse(result["candidates"][0]["receipt_usable_at_notice"])

    def test_source_change_during_planning_is_detected_before_execution(self):
        conn = self.conn

        class MutatingPlanner:
            name = "test_mutating_planner"

            def plan(self, profile):
                conn.execute("UPDATE invoice_lines SET unit_price_cents=1 "
                             "WHERE invoice_line_id='LINE-ABC-A'")
                return MethodPlan((Op.JOIN, Op.REFERENCES, Op.AMOUNT, Op.VERIFY))

        with patch("recon.phase2.service.execute") as executor:
            result = reconcile(self.conn, "D-DEMO-PO", planner=MutatingPlanner())
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "source_records_changed")
        self.assertFalse(result["verification"]["passed"])
        executor.assert_not_called()

    def test_verifier_detects_executor_discarding_an_ambiguous_candidate(self):
        def discard_candidate(conn, notice, plan, **options):
            execution = execute(conn, notice, plan, **options)
            return Execution(execution.hypotheses[:1], execution.trace)

        with patch("recon.phase2.service.execute", side_effect=discard_candidate):
            result = reconcile(self.conn, "D-DEMO-AMBIG")
        self.assertEqual(result["status"], "review")
        self.assertFalse(result["verification"]["passed"])
        self.assertEqual(result["reason"], "executor_verifier_disagreement")
        self.assertEqual(result["candidates"], [])

    def test_verifier_rejects_forged_quantity_record_or_price(self):
        for forged_field in ("quantity", "record_id", "price"):
            with self.subTest(forged_field=forged_field):
                def forge(conn, notice, plan, **options):
                    execution = execute(conn, notice, plan, **options)
                    item = execution.hypotheses[0]
                    if forged_field == "quantity":
                        forged = replace(item, quantity=item.quantity + 1)
                    elif forged_field == "record_id":
                        forged = replace(item, candidate=replace(item.candidate,
                                                                invoice_line_id="MODEL-INVENTED-LINE"))
                    else:
                        forged = replace(item, candidate=replace(item.candidate, unit_price_cents=1))
                    return Execution((forged,), execution.trace)

                with patch("recon.phase2.service.execute", side_effect=forge):
                    result = reconcile(self.conn, "D-DEMO-PO")
                self.assertEqual(result["status"], "review")
                self.assertFalse(result["verification"]["passed"])
                self.assertEqual(result["candidates"], [])

    def test_compromised_executor_cannot_change_notice_reference(self):
        def alter_notice(conn, notice, plan, **options):
            notice["po_hint"] = "PO-ABC-B"
            return execute(conn, notice, plan, **options)

        with patch("recon.phase2.service.execute", side_effect=alter_notice):
            result = reconcile(self.conn, "D-DEMO-PO")
        self.assertEqual(result["status"], "review")
        self.assertFalse(result["verification"]["passed"])
        self.assertEqual(result["candidates"], [])
        self.assertEqual(result["notice"]["po_hint"], "PO-ABC-A")
        self.assertEqual(self.conn.execute("SELECT po_hint FROM deductions "
                                          "WHERE deduction_id='D-DEMO-PO'").fetchone()[0], "PO-ABC-A")

    def test_verifier_independently_rereads_notice_before_using_its_values(self):
        notice = dict(self.conn.execute("SELECT * FROM deductions "
                                        "WHERE deduction_id='D-DEMO-PO'").fetchone())
        digest = source_digest(self.conn)
        forged_notice = {**notice, "po_hint": "PO-ABC-B"}
        plan = MethodPlan((Op.JOIN, Op.REFERENCES, Op.AMOUNT, Op.VERIFY))
        execution = execute(self.conn, forged_notice, plan)
        self.assertEqual(source_digest(self.conn), digest)
        result = verify(self.conn, forged_notice, plan, execution, expected_digest=digest)
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "notice_source_disagreement")
        self.assertFalse(result["verification"]["passed"])
        self.assertEqual(result["candidates"], [])

    def test_verifier_independently_validates_plan_dependencies(self):
        notice = dict(self.conn.execute("SELECT * FROM deductions "
                                        "WHERE deduction_id='D-DEMO-PO'").fetchone())
        digest = source_digest(self.conn)
        valid_plan = MethodPlan((Op.JOIN, Op.REFERENCES, Op.AMOUNT, Op.VERIFY))
        execution = execute(self.conn, notice, valid_plan)
        invalid_plan = MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY))
        result = verify(self.conn, notice, invalid_plan, execution, expected_digest=digest)
        self.assertEqual(result["status"], "review")
        self.assertFalse(result["verification"]["passed"])
        self.assertEqual(result["candidates"], [])

    def test_source_change_during_execution_is_detected_by_verifier(self):
        conn = self.conn

        class MutatingRanker(WaterFirstRanker):
            def score(self, query, description):
                conn.execute("UPDATE receipts SET received_qty=100 "
                             "WHERE shipment_id='SHP-ABC-A'")
                return super().score(query, description)

        result = reconcile(self.conn, "D-DEMO-AMBIG", ranker=MutatingRanker())
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "source_records_changed")
        self.assertFalse(result["verification"]["passed"])

    def test_nonfinite_and_out_of_range_text_scores_abstain(self):
        class InvalidRanker:
            name = "invalid_ranker"

            def __init__(self, value):
                self.value = value

            def score(self, query, description):
                return self.value

        for score in (float("nan"), float("inf"), -1.0, 101.0, None, "100", True):
            with self.subTest(score=score):
                result = reconcile(self.conn, "D-DEMO-AMBIG", ranker=InvalidRanker(score))
                self.assertEqual(result["status"], "review")
                self.assertEqual(result["candidates"], [])

    def test_failed_text_plugin_leaves_case_for_review(self):
        class FailingRanker:
            name = "unavailable_ranker"

            def __init__(self, error):
                self.error = error

            def score(self, query, description):
                raise self.error("Text service is unavailable")

        for error in (TimeoutError, OSError):
            with self.subTest(error=error):
                result = reconcile(self.conn, "D-DEMO-AMBIG", ranker=FailingRanker(error))
                self.assertEqual(result["status"], "review")
                self.assertEqual(result["candidates"], [])
                self.assertFalse(result["verification"]["passed"])

    def test_invalid_dates_and_noninteger_financial_values_abstain(self):
        for field, value in (("notice_date", "2026-02-30"),
                             ("notice_date", "2026-8-21"),
                             ("amount_cents", "unknown"),
                             ("amount_cents", 90000.5),
                             ("short_qty", 15.5)):
            with self.subTest(field=field, value=value):
                self.change_notice("D-DEMO-PO", **{field: value})
                result = reconcile(self.conn, "D-DEMO-PO")
                self.assertEqual(result["status"], "review")
                self.assertEqual(result["reason"], "invalid_source_data")
                self.assertEqual(result["candidates"], [])
                self.conn.execute("UPDATE deductions SET notice_date='2026-08-21', "
                                  "amount_cents=90000, short_qty=15 WHERE deduction_id='D-DEMO-PO'")

    def test_invoice_after_notice_cannot_support_match(self):
        self.conn.execute("UPDATE invoices SET invoice_date='2026-08-22' "
                          "WHERE invoice_id='INV-ABC-A'")
        result = reconcile(self.conn, "D-DEMO-PO")
        self.assertEqual(result["status"], "review")
        self.assertFalse(result["verification"]["passed"])
        self.assertEqual(result["candidates"], [])

    def test_invalid_plans_abstain_before_execution(self):
        invalid = (
            (Op.JOIN, Op.AMOUNT, Op.VERIFY),  # Omits the supplied PO reference.
            (Op.JOIN, Op.REFERENCES, Op.DERIVE_QUANTITY, Op.VERIFY),
            (Op.JOIN, Op.AMOUNT, Op.REFERENCES, Op.VERIFY),
            (Op.JOIN, Op.REFERENCES, Op.AMOUNT),
        )
        for operations in invalid:
            with self.subTest(operations=operations):
                result = reconcile(self.conn, "D-DEMO-PO", planner=FixedPlanner(operations))
                self.assertEqual(result["status"], "review")
                self.assertEqual(result["candidates"], [])

    def test_inprocess_planner_cannot_bypass_enum_types_with_raw_strings(self):
        class RawStringPlanner:
            name = "test_raw_string_planner"

            def plan(self, profile):
                return MethodPlan(("join_records", "check_amount", "verify_records"))

        result = reconcile(self.conn, "D-DEMO-PO", planner=RawStringPlanner())
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "invalid_plan")
        self.assertEqual(result["candidates"], [])

    def test_overreceived_quantity_is_invalid_source_data(self):
        self.conn.execute("UPDATE receipts SET received_qty=101 WHERE shipment_id='SHP-ABC-A'")
        result = reconcile(self.conn, "D-DEMO-PO")
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "invalid_source_data")
        self.assertEqual(result["candidates"], [])

    def test_unavailable_planner_does_not_fall_back_to_a_guessed_match(self):
        class UnavailablePlanner:
            name = "unavailable"

            def plan(self, profile):
                raise PlannerUnavailable("No model configured")

        result = reconcile(self.conn, "D-DEMO-PO", planner=UnavailablePlanner())
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["candidates"], [])

    def test_unknown_deduction_is_an_error(self):
        with self.assertRaises(KeyError):
            reconcile(self.conn, "NONEXISTENT")

    def test_evaluation_labels_are_not_available_to_planner_or_executor(self):
        names = {row[0] for row in self.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertNotIn("ground_truth", names)

    def test_phase1_decisions_are_preserved_on_original_complete_fixture(self):
        baseline = baseline_load_data(ROOT / "data")
        self.addCleanup(baseline.close)
        ids = [row[0] for row in baseline.execute("SELECT deduction_id FROM deductions")]
        for deduction_id in ids:
            with self.subTest(deduction_id=deduction_id):
                before = baseline_reconcile(baseline, deduction_id)
                after = reconcile(self.conn, deduction_id)
                self.assertEqual(after["status"], before["status"])
                self.assertEqual(after["claim_assessment"], before["claim_assessment"])
                self.assertEqual(
                    {(c["invoice_line_id"], c["shipment_id"]) for c in after["candidates"]},
                    {(c["invoice_line_id"], c["shipment_id"]) for c in before["candidates"]})
        self.assertEqual(baseline_reconcile(baseline, "D-DEMO-PO")["status"], "matched")


class Phase2StorageTests(unittest.TestCase):
    def fixture_copy(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        target = Path(directory.name)
        for source in (ROOT / "data").glob("*.csv"):
            shutil.copy2(source, target / source.name)
        return target

    def change_csv(self, directory, table, predicate, **changes):
        path = directory / f"{table}.csv"
        with path.open(newline="", encoding="utf-8") as stream:
            reader = csv.DictReader(stream)
            fieldnames = reader.fieldnames
            rows = list(reader)
        for row in rows:
            if predicate(row):
                row.update(changes)
        with path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def test_nullable_extracted_fields_load_as_null(self):
        directory = self.fixture_copy()
        self.change_csv(directory, "deductions", lambda row: row["deduction_id"] == "D-DEMO-PO",
                        amount_cents="", short_qty="", description="")
        conn = load_data(directory)
        self.addCleanup(conn.close)
        row = conn.execute("SELECT amount_cents, short_qty, description FROM deductions "
                           "WHERE deduction_id='D-DEMO-PO'").fetchone()
        self.assertEqual(tuple(row), (None, None, None))


if __name__ == "__main__":
    unittest.main()
