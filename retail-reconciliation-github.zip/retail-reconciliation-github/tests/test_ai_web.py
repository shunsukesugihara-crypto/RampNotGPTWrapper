"""HTTP boundary tests for AI-first UI. Scripted provider is test wiring only."""
import http.client
import json
from pathlib import Path
from threading import Thread
import unittest
from unittest.mock import patch

from recon.ai.provider import Completion
from recon.web import create_server

ROOT = Path(__file__).resolve().parents[1]


class ScriptedTestProvider:
    """A deterministic test double, never reported as live inference."""
    def __init__(self):
        self.calls = []

    def complete(self, instructions, context, schema):
        self.calls.append(context)
        available = context["available_operations"]
        if "lookup_provided_references" in available:
            action = "lookup_provided_references"
        elif "enumerate_retailer_records" in available:
            action = "enumerate_retailer_records"
        elif "filter_references" in available:
            action = "filter_references"
        elif "check_reported_quantity_amount" in available:
            action = "check_reported_quantity_amount"
        elif "derive_quantity_from_amount" in available:
            action = "derive_quantity_from_amount"
        else:
            action = "finish"
        return Completion({"operation": action}, {"provider": "scripted_test", "live": False})


class AIWebTests(unittest.TestCase):
    def setUp(self):
        self.provider = ScriptedTestProvider()
        self.server = create_server(port=0, provider=self.provider)
        self.thread = Thread(target=self.server.serve_forever, kwargs={"poll_interval": .01}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def request(self, method, route, body=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
        try:
            conn.request(method, route, body=body, headers={"Content-Type": "application/json"})
            response = conn.getresponse()
            return response.status, response.read()
        finally:
            conn.close()

    def run_case(self, key="D-DEMO-PO"):
        status, body = self.request("POST", "/api/run", json.dumps({"deduction_id": key}))
        return status, json.loads(body)

    def test_default_mode_is_model_controller_and_load_does_not_infer(self):
        status, content = self.request("GET", "/api/cases")
        data = json.loads(content)
        self.assertEqual(status, 200)
        self.assertEqual(data["planner_mode"], "ai")
        self.assertEqual(data["planner"], "model_controller")
        self.assertTrue(data["ai_available"])
        self.assertIsNone(data["live_ai"])
        self.assertEqual(self.provider.calls, [])

    def test_button_runs_controller_without_offline_substitution(self):
        with patch("recon.web.reconcile", side_effect=AssertionError("Offline control must not run")):
            status, data = self.run_case()
        self.assertEqual(status, 200)
        self.assertEqual(data["result"]["engine"], "ai_controller")
        self.assertEqual(data["result"]["status"], "matched")
        self.assertEqual(data["result"]["model_calls"], 3)
        self.assertFalse(data["live_ai"], "Injected completions must not become a live AI claim")
        self.assertEqual(data["result"]["plan"]["operations"], [
            {"op": "lookup_provided_references"}, {"op": "check_reported_quantity_amount"}, {"op": "finish"}])
        self.assertNotIn("candidate_count", self.provider.calls[0]["observation"])
        self.assertEqual(self.provider.calls[1]["observation"]["candidate_count"], 1)

    def test_ambiguous_data_uses_broad_search_and_remains_unresolved(self):
        status, data = self.run_case("D-DEMO-AMBIG")
        result = data["result"]
        self.assertEqual(status, 200)
        self.assertEqual(result["status"], "review")
        self.assertEqual(len(result["candidates"]), 2)
        self.assertEqual(result["plan"]["operations"][0]["op"], "enumerate_retailer_records")
        self.assertTrue(result["verification"]["passed"])

    def test_provider_failure_is_visible_and_does_not_run_rules(self):
        self.provider.complete = lambda *args: (_ for _ in ()).throw(OSError("provider failed"))
        with patch("recon.web.reconcile", side_effect=AssertionError("No fallback")):
            status, data = self.run_case()
        self.assertEqual(status, 200)
        self.assertEqual(data["result"]["reason"], "planner_unavailable")
        self.assertFalse(data["live_ai"])
        self.assertEqual(data["result"]["candidates"], [])

    def test_missing_provider_cannot_start_a_run(self):
        self.server.provider = None
        with patch("recon.web.load_data") as loader:
            status, data = self.run_case()
        self.assertEqual(status, 503)
        self.assertEqual(data["error"]["code"], "planner_unavailable")
        loader.assert_not_called()

    def test_each_request_reinvokes_provider_and_has_distinct_execution_id(self):
        _, first = self.run_case()
        _, second = self.run_case()
        self.assertNotEqual(first["run_id"], second["run_id"])
        self.assertEqual(len(self.provider.calls), 6)

    def test_page_shows_ai_action_and_never_embeds_saved_financial_results(self):
        status, page = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn(b"Run with AI", page)
        self.assertNotIn(b"recorded-data", page)
        self.assertNotIn(b"INV-ABC-A", page)


if __name__ == "__main__":
    unittest.main()
