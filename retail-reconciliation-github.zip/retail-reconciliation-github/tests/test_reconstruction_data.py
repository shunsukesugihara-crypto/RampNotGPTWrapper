"""Independent raw-adapter tests: exact conversions, provenance, and abstention gaps."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.reconstruction.contracts import RawPack
from recon.reconstruction.data import MAX_SOURCE_BYTES, MAX_SOURCE_ROWS, load_pack, normalize, structural_profile


def source():
    return {
        "version": 1,
        "notice": {"deduction_id": "D-A", "retailer": "Retailer", "notice_date": "08/21/2026",
                   "amount": "$900.00", "currency": "USD", "short_qty": "15", "uom": "CS",
                   "scope": "single_line", "basis": "whole_receipt_shortfalls", "po_hint": "P-A",
                   "invoice_hint": None, "sku_hint": "SKU-A", "description": "Short cases"},
        "products": [{"sku": "SKU-A", "description": "Water Case", "case_pack": 12, "source_ref": "product-master/SKU-A"}],
        "purchase_orders": [{"po_id": "P-A", "retailer": "Retailer", "order_date": "08/01/2026"}],
        "invoices": [{"invoice_id": "I-A", "po_id": "P-A", "invoice_date": "2026-08-02", "currency": "USD"}],
        "invoice_lines": [{"invoice_line_id": "L-A", "invoice_id": "I-A", "sku": "SKU-A", "quantity": "100",
                           "uom": "CS", "unit_price": "$60.00", "price_uom": "CS", "currency": "USD"}],
        "shipments": [{"shipment_id": "S-A", "po_id": "P-A", "ship_date": "08/03/2026"}],
        "shipment_lines": [{"shipment_id": "S-A", "sku": "SKU-A", "quantity": "100", "uom": "CS"}],
        "receipts": [{"receipt_id": "R-A", "shipment_id": "S-A", "sku": "SKU-A", "quantity": "1,020",
                      "uom": "EA", "receipt_date": "08/05/2026"}],
    }


def pack(data=None):
    data = source() if data is None else data
    encoded = json.dumps(data).encode()
    return RawPack(data, "/test/raw-source.json", hashlib.sha256(encoded).hexdigest())


def codes(normalized):
    return {issue["code"] for issue in normalized.issues}


class SourceLoadingTests(unittest.TestCase):
    def path(self, content):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        path = Path(directory.name) / "source.json"
        path.write_bytes(content)
        return path

    def test_digest_uses_original_bytes_not_reserialized_json(self):
        content = (json.dumps(source(), indent=3) + "\n").encode()
        path = self.path(content)
        raw = load_pack(path)
        self.assertEqual(raw.source_digest, hashlib.sha256(content).hexdigest())
        self.assertEqual(raw.source_path, str(path.resolve()))
        self.assertEqual(raw.data, source())

    def test_duplicate_json_keys_nonfinite_constants_and_malformed_utf8_are_rejected(self):
        for content in (b'{"version":1,"version":1}', b'{"number":NaN}', b'{"number":Infinity}',
                        b'{"number":1e999}', b'\xff', b'{'):
            with self.subTest(content=content), self.assertRaises(ValueError):
                load_pack(self.path(content))

    def test_oversized_source_and_row_count_are_rejected(self):
        with self.assertRaises(ValueError):
            load_pack(self.path(b" " * (MAX_SOURCE_BYTES + 1)))
        data = source()
        data["products"] = data["products"] * (MAX_SOURCE_ROWS + 1)
        with self.assertRaises(ValueError):
            load_pack(self.path(json.dumps(data).encode()))

    def test_wrong_version_and_missing_source_table_are_rejected(self):
        for change in (lambda data: data.update(version=True), lambda data: data.pop("receipts")):
            data = source()
            change(data)
            with self.assertRaises(ValueError):
                load_pack(self.path(json.dumps(data).encode()))


class NormalizationTests(unittest.TestCase):
    def test_money_dates_and_mixed_unit_receipt_convert_exactly(self):
        normalized = normalize(pack())
        self.assertEqual(normalized.issues, ())
        self.assertEqual(normalized.notice["amount_cents"], 90000)
        self.assertEqual(normalized.notice["short_qty"], 15)
        self.assertEqual(normalized.notice["notice_date"], "2026-08-21")
        self.assertEqual(normalized.notice["basis"], "whole_receipt_shortfalls")
        self.assertEqual(normalized.tables["invoice_lines"][0]["unit_price_cents"], 6000)
        self.assertEqual(normalized.tables["receipts"][0]["received_qty"], 85)
        self.assertEqual(normalized.tables["receipts"][0]["uom"], "CS")

    def test_all_rows_preserve_original_raw_evidence_and_change_provenance(self):
        raw = pack()
        normalized = normalize(raw)
        for table in ("products", "purchase_orders", "invoices", "invoice_lines", "shipments", "shipment_lines", "receipts"):
            record = normalized.tables[table][0]["_source"]
            self.assertEqual(record, {"path": raw.source_path, "table": table, "row": 0,
                                      "raw": raw.data[table][0], "digest": raw.source_digest})
        receipt_conversion = next(change for change in normalized.transformations
                                  if change["operation"] == "divide_each_quantity_by_verified_case_pack")
        self.assertEqual(receipt_conversion["source"]["raw"], "1,020")
        self.assertEqual(receipt_conversion["source"]["key"], {"receipt_id": "R-A"})
        self.assertEqual(receipt_conversion["inputs"]["case_pack"], 12)
        self.assertEqual(receipt_conversion["inputs"]["source_ref"], "product-master/SKU-A")
        self.assertEqual(receipt_conversion["result"], 85)

    def test_normalize_is_pure_and_returned_evidence_does_not_alias_raw(self):
        raw = pack()
        original = deepcopy(raw.data)
        normalized = normalize(raw)
        self.assertEqual(raw.data, original)
        normalized.tables["receipts"][0]["_source"]["raw"]["quantity"] = "changed"
        self.assertEqual(raw.data, original)

    def test_each_priced_lines_and_each_notice_require_same_verified_case_pack(self):
        data = source()
        data["invoice_lines"][0].update(quantity="1,200", uom="EA", unit_price="5.00", price_uom="EA")
        data["notice"].update(short_qty="180", uom="EA")
        normalized = normalize(pack(data))
        self.assertEqual(normalized.issues, ())
        self.assertEqual(normalized.tables["invoice_lines"][0]["quantity"], 100)
        self.assertEqual(normalized.tables["invoice_lines"][0]["unit_price_cents"], 6000)
        self.assertEqual(normalized.notice["short_qty"], 15)

    def test_missing_case_pack_or_master_reference_never_assumes_twelve(self):
        for field, value in (("case_pack", None), ("source_ref", None), ("case_pack", True), ("case_pack", "12")):
            with self.subTest(field=field, value=value):
                data = source()
                data["products"][0][field] = value
                normalized = normalize(pack(data))
                self.assertIn("missing_verified_case_pack", codes(normalized))
                self.assertIsNone(normalized.tables["receipts"][0]["received_qty"])

    def test_already_case_quantities_do_not_require_conversion_metadata(self):
        data = source()
        data["products"][0].update(case_pack=None, source_ref=None)
        data["receipts"][0].update(quantity="85", uom="CS")
        normalized = normalize(pack(data))
        self.assertEqual(normalized.issues, ())
        self.assertEqual(normalized.tables["receipts"][0]["received_qty"], 85)

    def test_each_notice_without_product_identity_is_ambiguous(self):
        data = source()
        data["notice"].update(uom="EA", short_qty="180", sku_hint=None)
        normalized = normalize(pack(data))
        self.assertIn("missing_verified_case_pack", codes(normalized))
        self.assertIsNone(normalized.notice["short_qty"])

    def test_partial_cases_and_decimal_quantities_are_not_rounded(self):
        for quantity, expected in (("1,021", "partial_case"), ("1.5", "invalid_quantity"), (1.5, "invalid_quantity"),
                                   (True, "invalid_quantity"), ("10,20", "invalid_quantity"), ("-12", "invalid_quantity"),
                                   ("١٠٢٠", "invalid_quantity")):
            with self.subTest(quantity=quantity):
                data = source()
                data["receipts"][0]["quantity"] = quantity
                normalized = normalize(pack(data))
                self.assertIn(expected, codes(normalized))
                self.assertIsNone(normalized.tables["receipts"][0]["received_qty"])

    def test_zero_receipt_is_observed_zero_not_missing(self):
        data = source()
        data["receipts"][0]["quantity"] = "0"
        normalized = normalize(pack(data))
        self.assertEqual(normalized.issues, ())
        self.assertEqual(normalized.tables["receipts"][0]["received_qty"], 0)

    def test_money_never_rounds_fractional_cents_or_accepts_binary_floats(self):
        for amount in ("0.001", 900.0, True, "9,00.00", "NaN", "-1.00", "١.٠٠", "900.000000000000000000000000000001"):
            with self.subTest(amount=amount):
                data = source()
                data["notice"]["amount"] = amount
                normalized = normalize(pack(data))
                self.assertTrue(normalized.issues)
                self.assertIsNone(normalized.notice["amount_cents"])

    def test_exact_large_money_and_comma_money_stay_integer_cents(self):
        for value, cents in (("$1,234.56", 123456), ("900.000", 90000), ("12345678901234.56", 1234567890123456)):
            with self.subTest(value=value):
                data = source()
                data["notice"]["amount"] = value
                normalized = normalize(pack(data))
                self.assertEqual(normalized.issues, ())
                self.assertEqual(normalized.notice["amount_cents"], cents)

    def test_currency_symbols_must_agree_and_no_exchange_conversion_occurs(self):
        data = source()
        data["notice"].update(currency="EUR", amount="€900.00")
        data["invoices"][0]["currency"] = "EUR"
        data["invoice_lines"][0].update(currency="EUR", unit_price="€60.00")
        normalized = normalize(pack(data))
        self.assertEqual(normalized.issues, ())
        self.assertEqual(normalized.notice["currency"], "EUR")
        self.assertEqual(normalized.notice["amount_cents"], 90000)
        data["notice"]["amount"] = "$900.00"
        self.assertIn("currency_symbol_conflict", codes(normalize(pack(data))))

    def test_foreign_currency_rows_preserved_but_internal_currency_conflicts_flagged(self):
        data = source()
        data["invoices"][0]["currency"] = "EUR"
        data["invoice_lines"][0].update(currency="EUR", unit_price="60.00")
        normalized = normalize(pack(data))
        self.assertEqual(normalized.issues, ())
        self.assertEqual(normalized.tables["invoice_lines"][0]["currency"], "EUR")
        data["invoice_lines"][0]["currency"] = "USD"
        self.assertIn("currency_mismatch", codes(normalize(pack(data))))

    def test_missing_receipt_and_missing_notice_facts_are_not_fabricated(self):
        data = source()
        data["receipts"] = []
        data["notice"].update(amount=None, short_qty=None, basis=None)
        normalized = normalize(pack(data))
        self.assertEqual(normalized.issues, ())
        self.assertEqual(normalized.tables["receipts"], [])
        self.assertIsNone(normalized.notice["amount_cents"])
        self.assertIsNone(normalized.notice["short_qty"])
        self.assertIsNone(normalized.notice["basis"])
        self.assertIsNone(normalized.notice["reason"])

    def test_shortage_classification_requires_explicit_source_basis_and_trace(self):
        normalized = normalize(pack())
        self.assertEqual(normalized.notice["reason"], "shortage")
        trace = next(item for item in normalized.transformations
                     if item["operation"] == "derive_shortage_classification_from_explicit_basis")
        self.assertEqual(trace["source"]["field"], "basis")
        self.assertEqual(trace["source"]["raw"], "whole_receipt_shortfalls")
        self.assertEqual(trace["inputs"]["output_field"], "reason")
        data = source()
        data["notice"]["basis"] = "includes_unknown_fees"
        self.assertIsNone(normalize(pack(data)).notice["reason"])

    def test_impossible_dates_and_undeclared_units_produce_issues(self):
        for field, value in (("notice_date", "02/30/2026"), ("notice_date", "21/08/2026"),
                             ("notice_date", "2026-8-21"), ("uom", "BOX")):
            with self.subTest(field=field, value=value):
                data = source()
                data["notice"][field] = value
                self.assertTrue(normalize(pack(data)).issues)

    def test_duplicate_ids_broken_links_and_receipt_conflicts_are_explicit(self):
        cases = []
        data = source(); data["products"].append(deepcopy(data["products"][0])); cases.append((data, "duplicate_id"))
        data = source(); data["invoice_lines"][0]["invoice_id"] = "MISSING"; cases.append((data, "broken_reference"))
        data = source(); data["receipts"].append({**data["receipts"][0], "receipt_id": "R-B", "quantity": "1,008"}); cases.append((data, "conflicting_receipts"))
        data = source(); data["receipts"][0]["quantity"] = "1,212"; cases.append((data, "receipt_exceeds_shipment"))
        for data, expected in cases:
            with self.subTest(expected=expected):
                self.assertIn(expected, codes(normalize(pack(data))))

    def test_unknown_financial_fields_cannot_be_silently_dropped(self):
        data = source()
        data["notice"]["unmodeled_fee"] = "10.00"
        normalized = normalize(pack(data))
        self.assertIn("unexpected_field", codes(normalized))
        self.assertEqual(normalized.notice["_source"]["raw"]["unmodeled_fee"], "10.00")

    def test_structural_profile_exposes_units_missingness_and_relationships_without_matching(self):
        data = source()
        data["notice"].update(short_qty=None, sku_hint=None)
        profile = structural_profile(pack(data))
        self.assertEqual(profile["unit_values"], ["CS", "EA"])
        self.assertEqual(profile["currency_values"], ["USD"])
        self.assertFalse(profile["quantity_available"])
        self.assertIn("short_qty", profile["missing_facts"])
        self.assertEqual(profile["scope"], "single_line")
        self.assertTrue(profile["relationships"])
        self.assertNotIn("candidate_count", profile)
        self.assertNotIn("financially_consistent_count", profile)


if __name__ == "__main__":
    unittest.main()
