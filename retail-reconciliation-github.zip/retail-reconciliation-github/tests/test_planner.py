"""Planner contracts are tested without model credentials or network calls."""
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.phase2.contracts import DataProfile, MethodPlan, Op, PLAN_SCHEMA, PlanError, PlannerUnavailable
from recon.phase2.planner import OfflinePlanner, OpenAIPlanner


def profile(**overrides):
    values = {
        "present_fields": ("amount_cents", "short_qty", "description"),
        "missing_fields": ("po_hint", "invoice_hint", "shipment_hint", "sku_hint"),
        "reference_fields": (), "candidate_count": 4,
        "financially_consistent_count": 2, "distinct_skus": 2,
        "exact_description_sku_count": 0, "receipt_count": 1,
        "text_ranking_available": False,
        "available_fields": {"invoice_lines": ("invoice_id", "sku", "quantity", "unit_price_cents")},
    }
    values.update(overrides)
    return DataProfile(**values)


def completed(plan):
    text = json.dumps(plan.to_dict()) if isinstance(plan, MethodPlan) else plan
    return {"status": "completed", "output": [{
        "type": "message", "role": "assistant", "status": "completed",
        "content": [{"type": "output_text", "text": text}],
    }]}


class OfflinePlannerTests(unittest.TestCase):
    def test_routes_missing_quantity_and_checks_all_provided_references(self):
        item = profile(
            present_fields=("amount_cents", "po_hint"), missing_fields=("short_qty", "description"),
            reference_fields=("po_hint",), financially_consistent_count=1,
        )
        self.assertEqual(OfflinePlanner().plan(item).operations,
                         (Op.JOIN, Op.REFERENCES, Op.DERIVE_QUANTITY, Op.VERIFY))

    def test_uses_exact_comparison_only_for_ambiguity(self):
        planner = OfflinePlanner()
        self.assertEqual(planner.plan(profile(exact_description_sku_count=1)).operations,
                         (Op.JOIN, Op.AMOUNT, Op.EXACT_DESCRIPTION, Op.VERIFY))
        self.assertEqual(planner.plan(profile(financially_consistent_count=1, exact_description_sku_count=1)).operations,
                         (Op.JOIN, Op.AMOUNT, Op.VERIFY))

    def test_text_ranking_is_optional_and_exact_match_takes_precedence(self):
        planner = OfflinePlanner()
        self.assertIn(Op.RANK_TEXT, planner.plan(profile(text_ranking_available=True)).operations)
        self.assertNotIn(Op.RANK_TEXT, planner.plan(profile(
            present_fields=("amount_cents", "short_qty"), missing_fields=("description",),
            text_ranking_available=True,
        )).operations)
        selected = planner.plan(profile(exact_description_sku_count=1, text_ranking_available=True))
        self.assertIn(Op.EXACT_DESCRIPTION, selected.operations)
        self.assertNotIn(Op.RANK_TEXT, selected.operations)

    def test_missing_amount_cannot_be_planned(self):
        with self.assertRaises(PlanError):
            OfflinePlanner().plan(profile(missing_fields=("amount_cents",)))
        self.assertEqual(OfflinePlanner.name, "offline_policy")


class OpenAIPlannerTests(unittest.TestCase):
    def test_requests_only_aggregate_profile_with_strict_recipe_schema(self):
        seen = []
        expected = MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY))
        def transport(payload):
            seen.append(payload)
            return completed(expected)
        planner = OpenAIPlanner(model="configured-test-model", transport=transport)
        self.assertEqual(planner.plan(profile()), expected)
        self.assertEqual(planner.name, "openai:configured-test-model")
        request = seen[0]
        self.assertEqual(request["model"], "configured-test-model")
        self.assertIs(request["store"], False)
        self.assertEqual(request["text"]["format"], {
            "type": "json_schema", "name": "reconciliation_method", "strict": True, "schema": PLAN_SCHEMA,
        })
        self.assertEqual(json.loads(request["input"][1]["content"][0]["text"]),
                         json.loads(json.dumps(profile().to_dict())))
        serialized = json.dumps(request)
        self.assertNotIn("ground_truth", serialized)
        self.assertNotIn("invoice_line_id", serialized)
        self.assertEqual(request["max_output_tokens"], 2048)

    def test_fake_model_selects_different_valid_methods_from_profile(self):
        # This verifies model-adapter wiring; it does not claim model quality.
        def transport(payload):
            data = json.loads(payload["input"][1]["content"][0]["text"])
            steps = [Op.JOIN]
            if data["reference_fields"]:
                steps.append(Op.REFERENCES)
            steps.append(Op.DERIVE_QUANTITY if "short_qty" in data["missing_fields"] else Op.AMOUNT)
            if data["financially_consistent_count"] > 1 and data["exact_description_sku_count"]:
                steps.append(Op.EXACT_DESCRIPTION)
            steps.append(Op.VERIFY)
            return completed(MethodPlan(tuple(steps)))
        planner = OpenAIPlanner(model="test-model", transport=transport)
        simple = planner.plan(profile(financially_consistent_count=1))
        complex_case = planner.plan(profile(
            missing_fields=("short_qty",), reference_fields=("po_hint",), exact_description_sku_count=1,
        ))
        self.assertEqual(simple.operations, (Op.JOIN, Op.AMOUNT, Op.VERIFY))
        self.assertEqual(complex_case.operations,
                         (Op.JOIN, Op.REFERENCES, Op.DERIVE_QUANTITY, Op.EXACT_DESCRIPTION, Op.VERIFY))

    def test_missing_configuration_never_calls_network(self):
        with patch.dict(os.environ, {}, clear=True), patch("urllib.request.urlopen") as request:
            with self.assertRaises(PlannerUnavailable):
                OpenAIPlanner()
            planner = OpenAIPlanner(model="test-model")
            with self.assertRaises(PlannerUnavailable):
                planner.plan(profile())
            request.assert_not_called()

    def test_model_environment_and_late_key_loading_use_responses_endpoint(self):
        expected = MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY))
        from io import BytesIO
        with patch.dict(os.environ, {"OPENAI_MODEL": "env-model"}, clear=True):
            planner = OpenAIPlanner()
            with patch.dict(os.environ, {"OPENAI_API_KEY": "secret-for-test"}):
                with patch("urllib.request.urlopen", return_value=BytesIO(json.dumps(completed(expected)).encode())) as request:
                    self.assertEqual(planner.plan(profile()), expected)
            sent = request.call_args.args[0]
            self.assertEqual(sent.full_url, "https://api.openai.com/v1/responses")
            self.assertEqual(sent.get_method(), "POST")
            self.assertEqual(sent.headers["Authorization"], "Bearer secret-for-test")
            self.assertEqual(request.call_args.kwargs["timeout"], 30)

    def test_refusal_and_incomplete_output_do_not_fall_back(self):
        responses = [
            {"status": "incomplete", "output": []},
            {"status": "failed", "error": {"message": "test"}},
            {"status": "completed", "output": [{"type": "message", "role": "assistant",
              "content": [{"type": "refusal", "refusal": "cannot do that"}]}]},
        ]
        for response in responses:
            with self.subTest(response=response):
                planner = OpenAIPlanner(model="test", transport=lambda payload: response)
                with self.assertRaises(PlannerUnavailable):
                    planner.plan(profile())

    def test_malformed_or_answer_bearing_recipes_are_rejected(self):
        valid = MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY)).to_dict()
        invalid = [
            "not JSON", "```json\n{}\n```", json.dumps({**valid, "match": "INV-123"}),
            json.dumps({**valid, "operations": [{"op": "join_records", "sql": "DELETE FROM invoices"}]}),
            json.dumps({"version": 1, "operations": [{"op": "run_python"}]}),
            '{"version":1,"version":1,"operations":[]}',
            json.dumps({"version": 1, "operations": [{"op": "join_records"}, {"op": "check_amount"}, {"op": "rank_description"}]}),
        ]
        for text in invalid:
            with self.subTest(text=text):
                with self.assertRaises(PlanError):
                    OpenAIPlanner(model="test", transport=lambda payload: completed(text)).plan(profile())

    def test_model_cannot_omit_reference_checks_or_use_wrong_arithmetic(self):
        response = completed(MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY)))
        for data in [profile(reference_fields=("po_hint",)), profile(missing_fields=("short_qty",))]:
            with self.subTest(data=data):
                with self.assertRaises(PlanError):
                    OpenAIPlanner(model="test", transport=lambda payload: response).plan(data)

    def test_provider_output_must_be_one_completed_assistant_recipe(self):
        text = json.dumps(MethodPlan((Op.JOIN, Op.AMOUNT, Op.VERIFY)).to_dict())
        responses = [None, {"status": "completed"}, {"status": "completed", "output": []},
                     {"status": "completed", "output": [{"type": "function_call", "arguments": text}]},
                     {"status": "completed", "output": completed(text)["output"] * 2}]
        for response in responses:
            with self.subTest(response=response):
                with self.assertRaises(PlanError):
                    OpenAIPlanner(model="test", transport=lambda payload: response).plan(profile())

    def test_transport_exception_does_not_expose_secret_or_fabricate_plan(self):
        def failing_transport(payload):
            raise OSError("secret-api-key and private response")
        with self.assertRaises(PlannerUnavailable) as caught:
            OpenAIPlanner(model="test", transport=failing_transport).plan(profile())
        self.assertNotIn("secret", str(caught.exception))
        self.assertIsNone(caught.exception.__cause__)

    def test_unsupported_missing_amount_stops_before_transport(self):
        with patch("urllib.request.urlopen") as network:
            with self.assertRaises(PlanError):
                OpenAIPlanner(model="test").plan(profile(missing_fields=("amount_cents",)))
            network.assert_not_called()


if __name__ == "__main__":
    unittest.main()
