// User-action checks for the buildless client; no browser runtime required.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const project = path.resolve(__dirname, '..');
const page = fs.readFileSync(path.join(project, 'web/index.html'), 'utf8');
const code = page.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
const report = JSON.parse(fs.readFileSync(path.join(project, 'output/ai_live_comparison.json'), 'utf8'));
const fixtures = Object.fromEntries(report.cases
  .filter(row => ['D-DEMO-PO', 'D-DEMO-AMBIG'].includes(row.deduction_id))
  .map(row => [row.deduction_id, row.engines.ai.result]));
const reconstructionReport = JSON.parse(fs.readFileSync(path.join(project, 'output/reconstruction_live_comparison.json'), 'utf8'));
const reconstructionCases = reconstructionReport.cases.map(row => ({
  family: row.family, result: row.engines.ai_method.result,
}));
for (const entry of reconstructionCases) fixtures[entry.result.deduction_id] = entry.result;
const reconstructionTitles = {
  single_clear: 'Raw single-line records', unique_two_line: 'Combined invoice lines',
  mixed_units: 'Cases and individual units', ambiguous_two_line: 'Competing combinations',
};

class Element {
  constructor() {
    this.attributes = {}; this.children = []; this.dataset = {}; this.style = {};
    this.events = {}; this.textContent = ''; this.value = ''; this.hidden = false;
    this.classes = new Set();
    this.classList = { toggle: (key, enabled) => enabled ? this.classes.add(key) : this.classes.delete(key) };
  }
  setAttribute(key, value) { this.attributes[key] = String(value); }
  get firstChild() { return this.children[0] || null; }
  append(...elements) { this.children.push(...elements); }
  appendChild(element) { this.children.push(element); }
  removeChild(element) { this.children.splice(this.children.indexOf(element), 1); }
  addEventListener(event, callback) { this.events[event] = callback; }
  getBoundingClientRect() { return { width: 704 }; }
}

async function main() {
  const selectors = ['.map-stage', '.map-floor', '.run-label', 'select', '.run-button', '.run-status',
    '.floor-grid', '.floor-patches', '.floor-flows', '.floor-labels', '.detail-heading h3',
    '.detail-subtitle', '.input-main', '.input-note', '.output-main', '.output-note',
    '.evidence', '.trace-list', '.source-evidence', '.raw-result'];
  const elements = Object.fromEntries(selectors.map(key => [key, new Element()]));
  const nodes = ['records', 'analyze', 'plan', 'execute', 'verify', 'match', 'review']
    .map(key => { const el = new Element(); el.dataset.stage = key; return el; });
  const root = {
    querySelector(selector) { assert(elements[selector], selector); return elements[selector]; },
    querySelectorAll(selector) { assert.equal(selector, '[data-stage]'); return nodes; },
  };
  const requests = [];
  let responder;
  const response = payload => ({ ok: true, json: async () => payload });
  const context = {
    document: {
      getElementById: id => { assert.equal(id, 'recon-isometric'); return root; },
      createElementNS: () => new Element(), createElement: () => new Element(),
    },
    location: { search: '' }, URLSearchParams, Intl, Date, console,
    ResizeObserver: class { observe() {} },
    fetch: async (url, options) => {
      requests.push({ url, options });
      if (url === '/api/cases') return response({ cases: [
        { deduction_id: 'D-DEMO-PO', title: 'With order reference' },
        { deduction_id: 'D-DEMO-AMBIG', title: 'Missing references' },
        ...reconstructionCases.map(entry => ({ deduction_id: entry.result.deduction_id,
          title: reconstructionTitles[entry.family], description: 'Raw financial source pack' })),
      ], planner_mode: 'ai', ai_available: true });
      assert.equal(url, '/api/run');
      return responder(JSON.parse(options.body));
    },
  };
  vm.runInNewContext(code, context);
  await new Promise(setImmediate);
  const button = elements['.run-button'], select = elements.select;
  assert.equal(button.disabled, false);
  assert.equal(requests.length, 1, 'loading the page must not auto-run the engine');
  assert.equal(elements['.source-evidence'].hidden, true);
  assert.match(elements['.output-main'].textContent, /Click Run with AI/);
  let release;
  responder = () => new Promise(resolve => { release = resolve; });
  const firstRun = button.events.click();
  assert.equal(button.disabled, true);
  assert.equal(select.disabled, true);
  assert.equal(button.textContent, 'Running…');
  assert.equal(elements['.source-evidence'].hidden, true);
  await button.events.click();
  assert.equal(requests.filter(r => r.url === '/api/run').length, 1, 'double click must not duplicate execution');
  const payload = (id, runId) => ({ result: fixtures[id], run_id: runId,
    elapsed_ms: 12.3, started_at: '2026-11-08T01:00:00Z', completed_at: '2026-11-08T01:00:01Z' });
  const simulateRun = async (id, runId) => {
    select.value = id; select.events.change();
    assert.equal(elements['.source-evidence'].hidden, true);
    responder = body => {
      assert.equal(body.deduction_id, id);
      return response(payload(body.deduction_id, runId));
    };
    await button.events.click();
    assert.equal(elements['.source-evidence'].hidden, false);
    assert.equal(button.disabled, false);
    assert.equal(JSON.parse(elements['.raw-result'].textContent).run_id, runId);
  };
  release(response(payload('D-DEMO-PO', 'run-first')));
  await firstRun;
  assert.equal(button.disabled, false);
  assert.match(elements['.output-main'].textContent, /INV-ABC-A.*SKU-WATER/);
  assert.equal(elements['.source-evidence'].hidden, false);
  assert.match(elements['.raw-result'].textContent, /run-first/);
  for (const n of nodes) { n.events.click(); assert(elements['.output-main'].textContent); }

  select.value = 'D-DEMO-AMBIG'; select.events.change();
  assert.equal(elements['.source-evidence'].hidden, true, 'case change must clear the old result');
  responder = body => { assert.equal(body.deduction_id, 'D-DEMO-AMBIG'); return response(payload(body.deduction_id, 'run-second')); };
  await button.events.click();
  assert.match(elements['.output-main'].textContent, /Unresolved/);
  assert.match(elements['.raw-result'].textContent, /run-second/);
  nodes.find(n => n.dataset.stage === 'plan').events.click();
  assert(!elements['.trace-list'].children.some(e => e.textContent === 'Check references'));
  assert(elements['.trace-list'].children.some(e => e.textContent === 'Search related records'));
  assert.match(elements['.input-note'].textContent, /3 model requests/);
  assert.match(elements['.detail-subtitle'].textContent, /Model-directed/);

  responder = () => { throw new Error('Connection failed'); };
  await button.events.click();
  assert.equal(elements['.run-status'].attributes.role, 'alert');
  assert.equal(elements['.run-status'].textContent, 'Connection failed');
  assert.equal(elements['.source-evidence'].hidden, true, 'failure must not keep previous success visible');
  assert.equal(elements['.raw-result'].textContent, '');
  assert.equal(button.disabled, false, 'failed runs must be retryable');

  responder = () => response(payload('D-DEMO-PO', 'wrong-case'));
  await button.events.click();
  assert.match(elements['.run-status'].textContent, /different case/);
  assert.equal(elements['.source-evidence'].hidden, true);

  const inspect = name => nodes.find(n => n.dataset.stage === name).events.click();
  const visibleDetail = () => ['.detail-subtitle', '.input-main', '.input-note', '.output-main', '.output-note', '.evidence']
    .map(selector => elements[selector].textContent).join('\n');
  const money = cents => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);
  for (const entry of reconstructionCases) {
    const executed = entry.result, id = executed.deduction_id;
    assert.equal(executed.engine, 'evidence_reconstruction', 'use actual new-engine payloads');
    await simulateRun(id, `reconstruction-${entry.family}`);
    for (const n of nodes) {
      n.events.click();
      assert(elements['.input-main'].textContent, `${entry.family}: ${n.dataset.stage} input`);
      assert(elements['.output-main'].textContent, `${entry.family}: ${n.dataset.stage} output`);
      assert.doesNotMatch(visibleDetail(), /\b(?:NaN|undefined)\b/, `${entry.family}: ${n.dataset.stage} must render real fields`);
    }
    inspect('plan');
    assert.match(elements['.detail-subtitle'].textContent, /AI constructs the reconstruction method/);
    assert.match(elements['.input-note'].textContent, /4 model requests; live provider recorded/);
    assert(elements['.trace-list'].children.some(e => e.textContent === 'Normalize from source evidence'));
    assert(elements['.trace-list'].children.some(e => e.textContent === 'Verify reconstructed relationships'));
    const stored = JSON.parse(elements['.raw-result'].textContent).result;
    assert.equal(stored.source_digest, executed.source_digest);
    assert.deepEqual(stored.plan, executed.plan);
    assert.deepEqual(stored.transformations, executed.transformations);
    assert.deepEqual(stored.source_evidence, executed.source_evidence);
    assert.doesNotMatch(elements['.raw-result'].textContent, /latent_expected_allocation|observable_valid_allocations/,
      'evaluation answers must not enter the source inspector');

    if (entry.family === 'unique_two_line') {
      assert.equal(executed.candidates.length, 1);
      const allocation = executed.candidates[0];
      assert.equal(allocation.lines.length, 2);
      assert(elements['.trace-list'].children.some(e => e.textContent === 'OR-Tools allocation search'));
      inspect('execute');
      assert.match(elements['.output-main'].textContent, /ortools_cp_sat.*1 allocations.*complete search/);
      inspect('match');
      assert.match(elements['.input-main'].textContent, /2 supported invoice-line relationships/);
      for (const line of allocation.lines) {
        assert(elements['.output-main'].textContent.includes(line.invoice_line_id));
        assert(elements['.output-note'].textContent.includes(`${line.quantity} cases × ${money(line.unit_price_cents)} = ${money(line.amount_cents)}`));
        assert(elements['.raw-result'].textContent.includes(line.shipment_id));
        assert(elements['.raw-result'].textContent.includes(line.sku));
      }
      assert.equal(allocation.lines.reduce((sum, line) => sum + line.amount_cents, 0), executed.notice.amount_cents);
      assert(nodes.find(n => n.dataset.stage === 'match').classes.has('active'));
    }

    if (entry.family === 'mixed_units') {
      inspect('records');
      assert.match(elements['.input-note'].textContent, /CS.*EA|EA.*CS/);
      inspect('execute');
      assert.match(elements['.output-note'].textContent, /EA → CS/);
      const conversion = stored.transformations.find(t => t.operation === 'divide_each_quantity_by_verified_case_pack');
      assert(conversion, 'the source conversion must be inspectable');
      assert.equal(conversion.inputs.case_pack, 12);
      assert(conversion.inputs.source_ref, 'conversion factor must carry its supplied catalog reference');
      assert.match(conversion.source.path, /evaluation\/reconstruction\/cases\/C-/);
      assert.equal(typeof conversion.source.row, 'number');
      assert.match(conversion.source.raw, /,/);
      assert.equal(Number(conversion.source.raw.replaceAll(',', '')) / conversion.inputs.case_pack, conversion.result);
      const canonical = stored.reconstructed_records.invoice_lines.find(line => line._source.raw.uom === 'EA');
      assert(canonical);
      assert.equal(canonical.uom, 'CS');
      assert.equal(canonical._source.raw.uom, 'EA');
      assert.equal(canonical._source.digest, stored.source_digest);
      assert.equal(stored.verification.transformations_verified, true);
    }

    if (entry.family === 'ambiguous_two_line') {
      assert.equal(executed.status, 'review');
      assert.equal(executed.candidates.length, 2, 'both competing allocations must remain in the inspector');
      inspect('execute');
      assert.match(elements['.output-main'].textContent, /ortools_cp_sat.*2 allocations.*complete search/);
      inspect('verify');
      assert.match(elements['.output-main'].textContent, /2 independently checked allocations/);
      inspect('match');
      assert.equal(elements['.output-main'].textContent, 'No automatic link');
      inspect('review');
      assert.match(elements['.output-main'].textContent, /Unresolved/);
      assert.match(elements['.input-main'].textContent, /2 verified allocations/);
      assert.match(elements['.run-status'].textContent, /Human review/);
      assert(nodes.find(n => n.dataset.stage === 'review').classes.has('active'));
      assert(!nodes.find(n => n.dataset.stage === 'match').classes.has('active'));
    }
  }
  console.log('PASS: original AI run/loading/error checks; actual reconstruction payloads at every stage; multi-line identities/equations; OR-Tools labels; preserved conversion/source provenance; ambiguous allocations remain for review.');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
