import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.engine import reconcile, reconcile_all
from recon.storage import load_data
from recon.evaluate import evaluate

class ReconciliationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.conn = load_data(ROOT / "data")

    def test_link_with_known_po(self):
        item = reconcile(self.conn, "D-DEMO-PO")
        self.assertEqual(item["status"], "matched")
        self.assertEqual(item["candidates"][0]["sku"], "SKU-WATER")
        self.assertEqual(item["claim_assessment"], "receiving_records_consistent")

    def test_same_price_ambiguity_is_not_guessed(self):
        item = reconcile(self.conn, "D-DEMO-AMBIG")
        self.assertEqual(item["status"], "review")
        self.assertGreaterEqual(len(item["candidates"]), 2)
        self.assertIn("SKU-SODA", {c["sku"] for c in item["candidates"]})
        self.assertIn("SKU-WATER", {c["sku"] for c in item["candidates"]})

    def test_matched_link_can_still_have_disputed_shortage(self):
        item = reconcile(self.conn, "D-DEMO-CONFLICT")
        self.assertEqual(item["status"], "matched")
        self.assertEqual(item["claim_assessment"], "receiving_records_do_not_support_claimed_quantity")

    def test_amount_mismatch_rejected_even_with_po_hint(self):
        item = reconcile(self.conn, "D-DEMO-AMOUNT")
        self.assertEqual(item["status"], "no_match")
        self.assertTrue(any("amount_quantity_price_mismatch" in c["failed_checks"] for c in item["rejected"]))

    def test_missing_receipt_not_fabricated(self):
        item = reconcile(self.conn, "D-DEMO-NORECEIPT")
        self.assertEqual(item["status"], "matched")
        self.assertEqual(item["claim_assessment"], "receiving_evidence_unavailable")
        self.assertIsNone(item["candidates"][0]["received_qty"])

    def test_candidate_has_traceable_evidence(self):
        candidate = reconcile(self.conn, "D-DEMO-PO")["candidates"][0]
        self.assertEqual(candidate["po_id"], "PO-ABC-A")
        self.assertEqual(candidate["shipment_id"], "SHP-ABC-A")
        self.assertIn("invoice_po_shipment_linked", candidate["passed_checks"])

    def test_unknown_deduction_id_is_error(self):
        with self.assertRaises(KeyError):
            reconcile(self.conn, "NONEXISTENT")

    def test_all_cases_evaluated(self):
        self.assertEqual(len(reconcile_all(self.conn)), 35)

    def test_labels_not_loaded_into_database(self):
        names = {row[0] for row in self.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertNotIn("ground_truth", names)

    def test_no_false_automatic_matches_on_generated_fixture(self):
        report = evaluate(ROOT / "data", ROOT / "evaluation" / "ground_truth.csv")
        self.assertEqual(report["incorrect_automatic_links"], 0)

if __name__ == "__main__":
    unittest.main()
