"""Cross-deduction physical shortage reuse, separate from arithmetic checking."""
from copy import deepcopy
import unittest

from recon.workspace.consistency import MESSAGE, REASON, enforce_batch_consistency


def claim(deduction, *, shipment="DL-482", sku="SNACK-6", invoice="B-482", multi=False,
          basis="whole_receipt_shortfalls", verified=True, status="matched"):
    line = {"invoice_line_id": invoice + "-1", "invoice_id": invoice, "shipment_id": shipment,
            "sku": sku, "shortfall": 4, "quantity": 4, "amount_cents": 15000,
            "evidence": [{"table": "receipts", "row": 6, "raw": {"receipt_id": "WH-482", "quantity": "16"}}]}
    candidate = {"lines": [line], "amount_cents": 15000, "short_qty": 4} if multi else line
    return {"deduction_id": deduction, "notice": {"basis": basis}, "status": status,
            "reason": "verified_relationship", "amount": "150.00",
            "result": {"status": status, "reason": "verified_relationship", "candidates": [candidate],
                       "verification": {"passed": verified, "source_digest": "retained-source-hash"}}}


class WorkspaceBatchConsistencyTests(unittest.TestCase):
    def test_different_invoice_ids_cannot_reuse_one_receiving_shortage(self):
        original = [claim("CLAIM-11", invoice="B-482"), claim("CLAIM-29", invoice="B-999")]
        before = deepcopy(original)
        rows = enforce_batch_consistency(original)
        self.assertEqual(original, before)
        self.assertEqual([r["status"] for r in rows], ["review", "review"])
        for index, row in enumerate(rows):
            self.assertEqual(row["reason"], REASON)
            self.assertEqual(row["result"]["status"], "review")
            self.assertTrue(row["result"]["verification"]["passed"])
            self.assertFalse(row["result"]["verification"]["batch_consistency_passed"])
            self.assertEqual(row["result"]["candidates"], before[index]["result"]["candidates"])
            conflict = row["result"]["verification"]["batch_conflicts"][0]
            self.assertEqual((conflict["shipment_id"], conflict["sku"]), ("DL-482", "SNACK-6"))
            self.assertEqual(conflict["deduction_ids"], ["CLAIM-11", "CLAIM-29"])
            self.assertEqual(conflict["message"], MESSAGE)

    def test_multi_line_allocation_conflicts_with_direct_relationship(self):
        multiple = claim("CLAIM-COMB", multi=True)
        multiple["result"]["candidates"][0]["lines"].append({"invoice_line_id": "B-OTHER-2", "shipment_id": "DL-OTHER", "sku": "PASTA-8", "quantity": 2})
        direct = claim("CLAIM-SINGLE")
        rows = enforce_batch_consistency([multiple, direct])
        self.assertEqual([r["status"] for r in rows], ["review", "review"])
        self.assertEqual(len(rows[0]["result"]["candidates"][0]["lines"]), 2)
        self.assertEqual(len(rows[0]["batch_conflicts"]), 1)

    def test_distinct_shipments_or_products_are_unchanged(self):
        original = [claim("A"), claim("B", shipment="DL-483"), claim("C", sku="PASTA-8")]
        self.assertEqual(enforce_batch_consistency(original), original)

    def test_other_financial_basis_or_unverified_model_answer_is_not_allocated(self):
        rows = [claim("A"), claim("B", basis="invoice_unit_price"), claim("C", verified=False)]
        self.assertEqual(enforce_batch_consistency(rows), rows)

    def test_same_deduction_is_not_mistaken_for_two_distinct_claims(self):
        rows = [claim("A"), claim("A", invoice="B-OTHER")]
        self.assertEqual(enforce_batch_consistency(rows), rows)

    def test_repeated_calls_are_idempotent_without_duplicate_conflict_entries(self):
        once = enforce_batch_consistency([claim("A"), claim("B")])
        twice = enforce_batch_consistency(once)
        self.assertEqual(twice, once)
        self.assertEqual(len(twice[0]["batch_conflicts"]), 1)

    def test_third_claim_is_propagated_to_prior_flagged_reviews(self):
        first = enforce_batch_consistency([claim("A"), claim("B")])
        rows = enforce_batch_consistency([*first, claim("C")])
        self.assertEqual([r["status"] for r in rows], ["review", "review", "review"])
        self.assertTrue(all(r["batch_conflicts"][0]["deduction_ids"] == ["A", "B", "C"] for r in rows))

    def test_multiple_conflicting_shortages_are_deduplicated_and_sorted(self):
        multi = claim("A", multi=True)
        lines = multi["result"]["candidates"][0]["lines"]
        lines.extend([deepcopy(lines[0]), {"shipment_id": "DL-AB", "sku": "OTHER"}])
        rows = enforce_batch_consistency([multi, claim("B"), claim("C", shipment="DL-AB", sku="OTHER")])
        self.assertEqual(len(rows[0]["batch_conflicts"]), 2)
        self.assertEqual([c["shipment_id"] for c in rows[0]["batch_conflicts"]], ["DL-482", "DL-AB"])

    def test_basis_can_come_from_the_verified_result_notice(self):
        a, b = claim("A"), claim("B")
        for row in (a, b):
            row["result"]["notice"] = row.pop("notice")
        self.assertEqual([r["status"] for r in enforce_batch_consistency([a, b])], ["review", "review"])

    def test_unresolved_review_does_not_reserve_financial_evidence(self):
        rows = [claim("A"), claim("B", status="review")]
        self.assertEqual(enforce_batch_consistency(rows), rows)


if __name__ == "__main__":
    unittest.main()
