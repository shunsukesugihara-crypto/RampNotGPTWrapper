"""Real HTTP reconstruction execution; injected completions are not live AI."""
from copy import deepcopy
from dataclasses import replace
import hashlib
import http.client
import json
from pathlib import Path
import sys
from threading import Thread
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.ai.provider import Completion
from recon.reconstruction.data import load_pack
from recon.web import create_server

MULTI_METHOD = ["normalize_source_records", "join_financial_records",
                "solve_receipt_shortfall_allocation", "verify_reconstruction"]
SINGLE_METHOD = ["normalize_source_records", "join_financial_records",
                 "check_single_line_constraints", "verify_reconstruction"]


class ScriptedProvider:
    def __init__(self):
        self.operations = []
        self.contexts = []

    def complete(self, instructions, context, schema):
        self.contexts.append(deepcopy(context))
        operation = self.operations.pop(0)
        assert operation in context["available_operations"]
        return Completion({"operation": operation}, {"provider": "scripted_http_test", "live": False,
                                                     "response_id": f"test-{len(self.contexts)}"})


class ReconstructionWebTests(unittest.TestCase):
    def setUp(self):
        self.provider = ScriptedProvider()
        with patch("recon.web.create_provider", side_effect=AssertionError("Tests must not initialize live providers")):
            self.server = create_server(port=0, provider=self.provider)
        self.thread = Thread(target=self.server.serve_forever, kwargs={"poll_interval": .01}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def request(self, method, path, body=None, headers=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=60)
        try:
            conn.request(method, path, body=body, headers={"Content-Type": "application/json", **(headers or {})})
            response = conn.getresponse()
            return response.status, json.loads(response.read())
        finally:
            conn.close()

    def case_id(self, title):
        return next(case["deduction_id"] for case in self.server.cases if case["title"] == title)

    def run_case(self, title, operations):
        self.provider.operations = list(operations)
        return self.request("POST", "/api/run", json.dumps({"deduction_id": self.case_id(title)}))

    def test_catalog_exposes_five_source_packs_with_titles_without_starting_inference(self):
        status, data = self.request("GET", "/api/cases")
        self.assertEqual(status, 200)
        self.assertEqual(data["planner_mode"], "ai")
        self.assertEqual(len(data["cases"]), 7)
        reconstruction = [row for row in data["cases"] if row.get("source_kind") == "reconstruction_pack"]
        self.assertEqual({row["title"] for row in reconstruction}, {
            "Combined invoice lines", "Missing quantity + mixed units", "Receiving units differ",
            "Competing combinations", "Missing conversion record"})
        self.assertTrue(all(row["description"] for row in reconstruction))
        self.assertEqual(self.provider.contexts, [])
        self.assertIsNone(data["live_ai"])

    def test_combined_invoice_lines_execute_real_ortools_and_independent_verification(self):
        with patch("recon.web.ai_reconcile", side_effect=AssertionError("Legacy AI engine must not run")), \
                patch("recon.web.reconcile", side_effect=AssertionError("Offline matcher must not run")), \
                patch("recon.web.load_data", side_effect=AssertionError("Legacy CSVs must not load")):
            status, data = self.run_case("Combined invoice lines", MULTI_METHOD)
        self.assertEqual(status, 200)
        result = data["result"]
        self.assertEqual(result["engine"], "evidence_reconstruction")
        self.assertEqual(result["status"], "matched")
        self.assertTrue(result["verification"]["passed"])
        self.assertEqual(result["search"]["tool"], "ortools_cp_sat")
        self.assertTrue(result["search"]["complete"])
        self.assertEqual(len(result["candidates"]), 1)
        self.assertEqual(len(result["candidates"][0]["lines"]), 2)
        self.assertEqual([item["operation"] for item in result["trace"]], MULTI_METHOD)
        self.assertEqual([item["op"] for item in result["plan"]["operations"]], MULTI_METHOD)
        self.assertEqual(result["model_calls"], 4)
        self.assertTrue(all(item["audit"]["provider"] == "scripted_http_test" for item in result["planning_decisions"]))
        self.assertFalse(result["live_ai"])
        self.assertFalse(data["live_ai"])
        self.assertNotIn("candidate_count", self.provider.contexts[0]["observation"])
        self.assertIn("candidate_count", self.provider.contexts[2]["observation"])
        for line in result["candidates"][0]["lines"]:
            self.assertTrue(line["evidence"])
            self.assertTrue(all(source["raw"] and source["digest"] for source in line["evidence"]))

    def test_competing_combinations_preserve_all_verified_alternatives(self):
        status, data = self.run_case("Competing combinations", MULTI_METHOD)
        result = data["result"]
        self.assertEqual(status, 200)
        self.assertEqual(result["status"], "review")
        self.assertTrue(result["verification"]["passed"])
        self.assertTrue(result["search"]["complete"])
        self.assertGreaterEqual(len(result["candidates"]), 2)
        self.assertFalse(data["live_ai"])

    def test_mixed_unit_run_returns_raw_evidence_and_verified_conversion_trace(self):
        status, data = self.run_case("Receiving units differ", SINGLE_METHOD)
        self.assertEqual(status, 200)
        result = data["result"]
        self.assertEqual(result["status"], "matched")
        self.assertTrue(result["verification"]["passed"])
        conversions = [item for item in result["transformations"]
                       if item["operation"] == "divide_each_quantity_by_verified_case_pack"]
        self.assertTrue(conversions)
        self.assertTrue(all(item["inputs"]["case_pack"] == 12 for item in conversions))
        self.assertTrue(all(item["inputs"]["source_ref"] for item in conversions))
        self.assertTrue(any(item["source"]["raw"] != item["result"] for item in conversions))
        self.assertIn("reconstructed_records", result)
        self.assertTrue(result["reconstructed_records"]["receipts"][0]["_source"]["raw"])

    def test_missing_quantity_and_mixed_units_use_receipt_constrained_combination_search(self):
        status, data = self.run_case("Missing quantity + mixed units", MULTI_METHOD)
        self.assertEqual(status, 200)
        result = data["result"]
        self.assertEqual(result["status"], "matched")
        self.assertIsNone(result["notice"]["short_qty"])
        self.assertEqual(result["search"]["tool"], "ortools_cp_sat")
        self.assertEqual(len(result["candidates"][0]["lines"]), 2)
        self.assertTrue(result["transformations"])
        self.assertTrue(result["verification"]["passed"])

    def test_missing_conversion_abstains_after_normalization_without_guessing_factor(self):
        with patch("recon.reconstruction.solver.solve_allocations", side_effect=AssertionError("No unresolved-unit solving")):
            status, data = self.run_case("Missing conversion record", ["normalize_source_records"])
        self.assertEqual(status, 200)
        result = data["result"]
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "unresolved_source_normalization")
        self.assertEqual(result["model_calls"], 1)
        self.assertFalse(result["verification"]["passed"])
        self.assertTrue(any(item["code"] == "missing_verified_case_pack" for item in result["data_issues"]))
        self.assertEqual(result["candidates"], [])

    def test_each_request_has_fresh_execution_id_and_provider_decisions(self):
        first_status, first = self.run_case("Combined invoice lines", MULTI_METHOD)
        second_status, second = self.run_case("Combined invoice lines", MULTI_METHOD)
        self.assertEqual((first_status, second_status), (200, 200))
        self.assertNotEqual(first["run_id"], second["run_id"])
        self.assertEqual(len(self.provider.contexts), 8)
        self.assertEqual(first["result"]["source_digest"], second["result"]["source_digest"])

    def test_source_corpus_and_labels_remain_bytewise_unchanged(self):
        folder = ROOT / "evaluation/reconstruction"
        before = {str(path.relative_to(folder)): hashlib.sha256(path.read_bytes()).hexdigest()
                  for path in folder.rglob("*") if path.is_file()}
        self.run_case("Combined invoice lines", MULTI_METHOD)
        self.run_case("Missing conversion record", ["normalize_source_records"])
        after = {str(path.relative_to(folder)): hashlib.sha256(path.read_bytes()).hexdigest()
                 for path in folder.rglob("*") if path.is_file()}
        self.assertEqual(before, after)

    def test_changed_source_digest_is_rejected_before_provider_request(self):
        key = self.case_id("Combined invoice lines")
        original = load_pack(self.server.reconstruction_sources[key]["path"])
        forged = replace(original, source_digest="0" * 64)
        with patch("recon.web.load_pack", return_value=forged), \
                patch("recon.web.reconstruct", side_effect=AssertionError("Tampered source must not run")):
            status, data = self.request("POST", "/api/run", json.dumps({"deduction_id": key}))
        self.assertEqual(status, 500)
        self.assertEqual(data["error"]["code"], "run_failed")
        self.assertNotIn("result", data)
        self.assertEqual(self.provider.contexts, [])

    def test_catalog_request_cannot_choose_arbitrary_file_or_extra_operation(self):
        key = self.case_id("Combined invoice lines")
        for request in ({"deduction_id": "../../source.json"}, {"deduction_id": key, "raw_path": "/tmp/other.json"},
                        {"deduction_id": key, "operation": "solve_receipt_shortfall_allocation"}):
            with self.subTest(request=request):
                status, data = self.request("POST", "/api/run", json.dumps(request))
                self.assertEqual(status, 400)
                self.assertIn("error", data)
        self.assertEqual(self.provider.contexts, [])

    def test_cross_origin_request_cannot_start_reconstruction(self):
        key = self.case_id("Combined invoice lines")
        status, data = self.request("POST", "/api/run", json.dumps({"deduction_id": key}),
                                    {"Origin": "https://example.com"})
        self.assertEqual(status, 403)
        self.assertEqual(data["error"]["code"], "invalid_origin")
        self.assertEqual(self.provider.contexts, [])


if __name__ == "__main__":
    unittest.main()
