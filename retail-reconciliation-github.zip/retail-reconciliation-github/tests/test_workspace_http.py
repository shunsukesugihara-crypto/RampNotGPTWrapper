"""Real localhost workspace routes over imported records; no live model calls."""
from copy import deepcopy
import base64
import csv
import http.client
import io
import json
from pathlib import Path
import tempfile
from threading import Thread
import time
import unittest
from unittest.mock import patch
import uuid

from recon.web import create_server
from recon.workspace.http import WorkspaceApp
from test_workspace_jobs import FakeModels, source_tables


class ConfigurableFakeModels(FakeModels):
    def __init__(self):
        super().__init__()
        self.updates = []
        self.connection_checks = 0

    def update(self, value):
        if set(value) != {"provider", "model"} or value["provider"] != "codex" or not isinstance(value["model"], str) or not value["model"].strip():
            raise ValueError("Choose an explicit provider and model")
        self.updates.append(deepcopy(value))
        self.fake.model = value["model"]
        return self.view()

    def test_connection(self):
        self.connection_checks += 1
        return {"ok": True, "provider": "codex", "model": self.fake.model,
                "audit": {"provider": "injected_http_test", "live": False}}


def source_uploads(tables):
    files = []
    for role, rows in tables.items():
        if not rows:
            continue
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
        files.append({"name": role + ".csv", "content_base64": base64.b64encode(stream.getvalue().encode()).decode()})
    return files


class WorkspaceHTTPTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        (self.root / "web").mkdir()
        (self.root / "web/workspace.html").write_text("<!doctype html><title>User data workspace</title>")
        self.root_patch = patch("recon.web.ROOT", self.root)
        self.root_patch.start()
        self.models = ConfigurableFakeModels()
        self.app = WorkspaceApp(self.root, models=self.models)
        self.server = create_server(port=0, planner_mode="offline")
        self.server._workspace_application = self.app
        self.thread = Thread(target=self.server.serve_forever, kwargs={"poll_interval": .01}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.models.fake.release.set()
        for event in list(self.app.jobs.cancellations.values()):
            event.set()
        deadline = time.monotonic() + 3
        while self.app.jobs.active and time.monotonic() < deadline:
            time.sleep(.01)
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.root_patch.stop()
        self.temporary.cleanup()

    def request(self, method, path, value=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=10)
        try:
            connection.request(method, path, body=json.dumps(value) if value is not None else None,
                               headers={"Content-Type": "application/json", **(headers or {})})
            response = connection.getresponse()
            return response.status, response.getheader("Content-Type"), response.read()
        finally:
            connection.close()

    def json(self, method, path, value=None, expected=200, headers=None):
        status, content_type, body = self.request(method, path, value, headers=headers)
        self.assertEqual(status, expected, body.decode(errors="replace"))
        self.assertIn("application/json", content_type)
        return json.loads(body)

    def imported(self, tables=None):
        return self.json("POST", "/api/workspace/import", {"name": "Independent uploaded adjustment batch", "files": source_uploads(source_tables() if tables is None else tables)}, expected=201)

    def mappings(self, workspace):
        return [{"document_id": d["id"], "role": Path(d["name"]).stem,
                 "columns": {column: column for column in d["columns"]}, "defaults": {}}
                for d in workspace["documents"]]

    def mapped(self, workspace):
        return self.json("POST", "/api/workspace/map", {"workspace_id": workspace["workspace_id"], "mappings": self.mappings(workspace), "settings": {}})

    def finished(self, job_id):
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            job = self.json("GET", "/api/workspace/jobs/" + job_id)
            if job["status"] in {"complete", "failed", "cancelled", "interrupted"}:
                return job
            time.sleep(.01)
        self.fail("The real HTTP batch did not reach a terminal state")

    def test_import_confirm_async_results_export_and_restore_persist_real_source_records(self):
        workspace = self.imported()
        self.assertFalse(workspace["ready"])
        self.assertEqual(len(workspace["documents"]), 8)
        confirmed = self.mapped(workspace)
        self.assertTrue(confirmed["ready"], confirmed["issues"])
        self.assertEqual(confirmed["notice_count"], 2)
        started = self.json("POST", "/api/workspace/run", {"workspace_id": workspace["id"], "mode": "fixed"}, expected=202)
        job = self.finished(started["job_id"])
        self.assertEqual(job["status"], "complete")
        self.assertEqual([(r["deduction_id"], r["status"]) for r in job["results"]], [("ADJ-C104", "matched"), ("ADJ-C205", "matched")])
        self.assertTrue(all(r["result"]["verification"]["passed"] for r in job["results"]))
        self.assertTrue(any(p["raw"] == "37.50" for p in job["results"][0]["source_provenance"]))
        status, content_type, body = self.request("GET", "/api/workspace/jobs/" + job["id"] + "/export.csv")
        self.assertEqual(status, 200)
        self.assertIn("text/csv", content_type)
        rows = list(csv.DictReader(io.StringIO(body.decode("utf-8-sig"))))
        self.assertEqual([r["deduction_id"] for r in rows], ["ADJ-C104", "ADJ-C205"])
        exported = self.json("GET", "/api/workspace/jobs/" + job["id"] + "/export.json")
        self.assertEqual(exported["job"]["results"], job["results"])
        self.assertTrue(any(p["raw"] == "37.50" and p["file"] == "invoice_lines.csv" for p in exported["import_provenance"]))
        self.assertEqual(self.json("GET", "/api/workspace/history")["jobs"][0]["id"], job["id"])
        reopened = WorkspaceApp(self.root, models=self.models)
        self.server._workspace_application = reopened
        restored = self.json("GET", "/api/workspace/" + workspace["id"])
        self.assertTrue(restored["ready"])
        self.assertEqual(restored["mappings"], workspace["mappings"] if workspace["mappings"] else self.mappings(workspace))
        self.assertEqual(self.json("GET", "/api/workspace/jobs/" + job["id"])["results"], job["results"])
        self.assertEqual(self.models.fake.requests, [])

    def test_workspace_upload_over_old_body_limit_is_accepted_while_legacy_run_is_not(self):
        tables = source_tables()
        tables["notice"][0]["description"] = "Original source memo. " * 400
        payload = {"files": source_uploads(tables)}
        self.assertGreater(len(json.dumps(payload).encode()), 4096)
        imported = self.json("POST", "/api/workspace/import", payload, expected=201)
        self.assertEqual(imported["documents"][0]["rows"][0]["description"], tables["notice"][0]["description"])
        status, _, _ = self.request("POST", "/api/run", {"deduction_id": "D-DEMO-PO", "padding": "x" * 5000})
        self.assertEqual(status, 413)
        self.assertEqual(self.models.fake.requests, [])

    def test_unconfirmed_or_missing_financial_mapping_prevents_a_job(self):
        workspace = self.imported()
        self.json("POST", "/api/workspace/run", {"workspace_id": workspace["id"], "mode": "fixed"}, expected=400)
        mapped = self.json("POST", "/api/workspace/map", {"workspace_id": workspace["id"], "mappings": [], "settings": {}})
        self.assertFalse(mapped["ready"])
        self.assertIn("missing_notices", {i["code"] for i in mapped["issues"]})
        self.json("POST", "/api/workspace/run", {"workspace_id": workspace["id"], "mode": "fixed"}, expected=400)
        self.assertEqual(self.app.store.list("jobs"), [])

    def test_invalid_mapping_columns_defaults_and_settings_cannot_be_saved_as_ready(self):
        workspace = self.imported()
        for mutation in ("unknown_column", "invented_money", "invented_link"):
            mapping = self.mappings(workspace)
            line = next(m for m in mapping if m["role"] == "invoice_lines")
            if mutation == "unknown_column":
                line["columns"]["unit_price"] = "DOES NOT EXIST"
            elif mutation == "invented_money":
                line["defaults"]["unit_price"] = "37.50"
            else:
                line["defaults"]["invoice_id"] = "GUESS"
            with self.subTest(mutation=mutation):
                self.json("POST", "/api/workspace/map", {"workspace_id": workspace["id"], "mappings": mapping, "settings": {}}, expected=400)
        self.json("POST", "/api/workspace/map", {"workspace_id": workspace["id"], "mappings": self.mappings(workspace), "settings": {"python": "evil"}}, expected=400)
        self.assertFalse(self.json("GET", "/api/workspace/" + workspace["id"])["ready"])

    def test_unknown_saved_objects_and_path_traversal_return_errors_without_file_access(self):
        for path in ("/api/workspace/jobs/" + str(uuid.uuid4()), "/api/workspace/../../secret", "/api/workspace/jobs/../../secret", "/api/workspace/%2e%2e%2fsecret"):
            with self.subTest(path=path):
                status, _, body = self.request("GET", path)
                self.assertIn(status, {400, 404})
                self.assertIn("error", json.loads(body))
        self.assertEqual(self.models.fake.requests, [])

    def test_user_filename_is_display_metadata_and_never_an_arbitrary_write_path(self):
        files = source_uploads({"notice": source_tables()["notice"]})
        files[0]["name"] = "../../outside.csv"
        workspace = self.json("POST", "/api/workspace/import", {"files": files}, expected=201)
        self.assertEqual(workspace["documents"][0]["name"], "outside.csv")
        for saved in self.app.store.get("workspaces", workspace["id"])["files"]:
            self.assertTrue(Path(saved["path"]).resolve().is_relative_to(self.app.store.root.resolve()))
        self.assertFalse((self.root / "outside.csv").exists())

    def test_explicit_model_configuration_and_connection_check_are_visible_without_live_calls(self):
        config = self.json("GET", "/api/workspace/config")
        self.assertEqual(config["model"], "explicit-fixture-model")
        self.assertIn("field_catalog", config)
        self.assertIn("engine_limits", config)
        updated = self.json("POST", "/api/workspace/config", {"provider": "codex", "model": "visible-selected-model"})
        self.assertEqual(updated["model"], "visible-selected-model")
        tested = self.json("POST", "/api/workspace/test", {})
        self.assertTrue(tested["ok"])
        self.assertFalse(tested["audit"]["live"])
        self.assertEqual(self.models.connection_checks, 1)
        self.assertEqual(self.models.fake.requests, [])

    def test_workspace_pages_and_api_preserve_host_and_origin_boundaries(self):
        for path in ("/", "/workspace/", "/investigate/"):
            self.assertEqual(self.request("GET", path)[0], 200)
        self.assertEqual(self.request("GET", "/api/workspace/config", headers={"Host": "outside.example"})[0], 403)
        self.assertEqual(self.request("POST", "/api/workspace/import", {"files": source_uploads(source_tables())}, headers={"Origin": "https://outside.example"})[0], 403)
        self.assertEqual(self.app.store.list("workspaces"), [])
        self.assertEqual(self.models.fake.requests, [])


if __name__ == "__main__":
    unittest.main()
