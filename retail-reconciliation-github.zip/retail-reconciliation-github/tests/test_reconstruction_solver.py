"""Real CP-SAT and independently reconstructed financial evidence tests."""
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.reconstruction.data import load_pack, normalize
from recon.reconstruction.solver import check_single, join_candidates, solve_allocations
from recon.reconstruction.verifier import verify


def source_pack(prices=(30, 20, 70), shortfalls=(2, 3, 1), *, amount=120, quantity=5,
                scope="multi_line", basis="whole_receipt_shortfalls"):
    data = {"version": 1, "notice": {"deduction_id": "D1", "retailer": "Retailer", "notice_date": "08/20/2026",
            "amount": f"${amount:,.2f}", "currency": "USD", "short_qty": None if quantity is None else str(quantity),
            "uom": "CS", "scope": scope, "basis": basis, "po_hint": "P1", "invoice_hint": None,
            "sku_hint": None, "description": "Recorded shortage"},
            "products": [], "purchase_orders": [{"po_id": "P1", "retailer": "Retailer", "order_date": "08/01/2026"}],
            "invoices": [], "invoice_lines": [], "shipments": [], "shipment_lines": [], "receipts": []}
    for index, (price, shortfall) in enumerate(zip(prices, shortfalls)):
        sku, invoice, line, shipment = f"K{index}", f"I{index}", f"L{index}", f"S{index}"
        data["products"].append({"sku": sku, "description": f"Product {index}", "case_pack": 6, "source_ref": "verified-master"})
        data["invoices"].append({"invoice_id": invoice, "po_id": "P1", "invoice_date": "08/02/2026", "currency": "USD"})
        data["invoice_lines"].append({"invoice_line_id": line, "invoice_id": invoice, "sku": sku,
            "quantity": "100", "uom": "CS", "unit_price": f"{price:.2f}", "price_uom": "CS", "currency": "USD"})
        data["shipments"].append({"shipment_id": shipment, "po_id": "P1", "ship_date": "08/04/2026"})
        data["shipment_lines"].append({"shipment_id": shipment, "sku": sku, "quantity": "100", "uom": "CS"})
        if shortfall is not None:
            data["receipts"].append({"receipt_id": f"R{index}", "shipment_id": shipment, "sku": sku,
                "quantity": str(100 - shortfall), "uom": "CS", "receipt_date": "08/06/2026"})
    return data


class ReconstructionSolverTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.path = Path(self.directory.name) / "pack.json"

    def tearDown(self):
        self.directory.cleanup()

    def prepare(self, data=None):
        self.path.write_text(json.dumps(data or source_pack()), encoding="utf-8")
        raw = load_pack(self.path)
        normalized = normalize(raw)
        return raw, normalized, join_candidates(normalized)

    def test_actual_cp_sat_finds_unique_combination_and_verifier_reconstructs_sources(self):
        raw, normalized, candidates = self.prepare()
        self.assertFalse(normalized.issues)
        execution = solve_allocations(normalized, candidates)
        self.assertEqual(execution.tool, "ortools_cp_sat")
        self.assertTrue(execution.complete, execution.issues)
        self.assertEqual(len(execution.allocations), 1)
        self.assertEqual({line["invoice_line_id"] for line in execution.allocations[0].lines}, {"L0", "L1"})
        result = verify(raw, normalized, execution, "multi")
        self.assertEqual(result["status"], "matched")
        self.assertTrue(result["verification"]["source_reloaded"])
        self.assertEqual(result["candidates"][0]["amount_cents"], 12000)
        self.assertEqual(len(result["candidates"][0]["equations"]), 2)
        self.assertEqual(result["source_evidence"], raw.data)
        self.assertTrue(result["verification"]["normalized_records_reconstructed"])
        self.assertTrue(result["verification"]["transformations_verified"])

    def test_distinct_combinations_remain_ambiguous(self):
        raw, normalized, candidates = self.prepare(source_pack((30, 90, 50, 70), (1, 1, 1, 1), quantity=2))
        execution = solve_allocations(normalized, candidates)
        self.assertTrue(execution.complete)
        self.assertEqual(len(execution.allocations), 2)
        result = verify(raw, normalized, execution, "multi")
        self.assertEqual(result["status"], "review")
        self.assertEqual(len(result["candidates"]), 2)

    def test_unknown_scope_checks_single_and_combined_rivals(self):
        raw, normalized, candidates = self.prepare(source_pack((30, 20, 24), (2, 3, 5), scope="unknown"))
        execution = solve_allocations(normalized, candidates)
        self.assertTrue(execution.complete)
        self.assertEqual({len(item.lines) for item in execution.allocations}, {1, 2})
        self.assertEqual(verify(raw, normalized, execution, "multi")["status"], "review")
        self.assertEqual(verify(raw, normalized, check_single(normalized, candidates), "single")["status"], "review")

    def test_missing_receipt_cannot_hide_an_unsearched_rival(self):
        raw, normalized, candidates = self.prepare(source_pack(shortfalls=(2, 3, None)))
        execution = solve_allocations(normalized, candidates)
        self.assertFalse(execution.complete)
        self.assertIn("missing_receipt", {item["code"] for item in execution.issues})
        self.assertEqual(verify(raw, normalized, execution, "multi")["status"], "review")

    def test_missing_quantity_is_derived_from_independent_receipts(self):
        raw, normalized, candidates = self.prepare(source_pack(quantity=None))
        result = verify(raw, normalized, solve_allocations(normalized, candidates), "multi")
        self.assertEqual(result["status"], "matched")
        self.assertIsNone(result["notice"]["short_qty"])
        self.assertEqual(result["candidates"][0]["short_qty"], 5)

    def test_case_each_conversion_is_independently_recomputed(self):
        data = source_pack((30,), (2,), amount=60, quantity=2, scope="single_line")
        data["notice"].update(short_qty="12", uom="EA", sku_hint="K0")
        data["invoice_lines"][0].update(quantity="600", uom="EA", unit_price="$5.00", price_uom="EA")
        data["shipment_lines"][0].update(quantity="600", uom="EA")
        data["receipts"][0].update(quantity="588", uom="EA")
        raw, normalized, candidates = self.prepare(data)
        self.assertFalse(normalized.issues)
        result = verify(raw, normalized, check_single(normalized, candidates), "single")
        self.assertEqual(result["status"], "matched")
        self.assertEqual(result["candidates"][0]["lines"][0]["quantity"], 2)
        self.assertEqual(result["candidates"][0]["lines"][0]["unit_price_cents"], 3000)
        self.assertEqual(raw.data["notice"]["short_qty"], "12")

    def test_missing_conversion_evidence_does_not_get_invented(self):
        data = source_pack((30,), (2,), amount=60, quantity=2, scope="single_line")
        data["invoice_lines"][0]["uom"] = "EA"
        data["products"][0]["source_ref"] = None
        raw, normalized, candidates = self.prepare(data)
        self.assertTrue(normalized.issues)
        self.assertFalse(check_single(normalized, candidates).complete)
        self.assertEqual(verify(raw, normalized, check_single(normalized, candidates), "single")["status"], "review")

    def test_transformation_ledger_raw_result_factor_and_missing_steps_are_rejected(self):
        data = source_pack((30,), (2,), amount=60, quantity=2, scope="single_line")
        data["notice"].update(short_qty="12", uom="EA", sku_hint="K0")
        data["invoice_lines"][0].update(quantity="600", uom="EA", unit_price="$5.00", price_uom="EA")
        data["shipment_lines"][0].update(quantity="600", uom="EA")
        data["receipts"][0].update(quantity="588", uom="EA")
        raw, normalized, candidates = self.prepare(data)
        execution = check_single(normalized, candidates)
        self.assertEqual(verify(raw, normalized, execution, "single")["status"], "matched")
        index = next(index for index, item in enumerate(normalized.transformations)
                     if item["operation"] == "multiply_each_price_by_verified_case_pack")
        for corruption in ("raw", "result", "factor", "operation", "missing"):
            with self.subTest(corruption=corruption):
                changes = deepcopy(list(normalized.transformations))
                if corruption == "raw":
                    changes[index]["source"]["raw"] = "$0.01"
                elif corruption == "result":
                    changes[index]["result"] += 1
                elif corruption == "factor":
                    changes[index]["inputs"]["case_pack"] += 1
                elif corruption == "operation":
                    changes[index]["operation"] = "model_invented_conversion"
                else:
                    changes.pop(index)
                result = verify(raw, replace(normalized, transformations=tuple(changes)), execution, "single")
                self.assertEqual(result["status"], "review")
                self.assertEqual(result["reason"], "transformation_ledger_disagreement")
                self.assertFalse(result["verification"]["passed"])

    def test_foreign_currency_decoy_is_filtered_without_inferred_exchange(self):
        data = source_pack((30, 30), (2, 2), amount=60, quantity=2, scope="single_line")
        data["invoices"][1]["currency"] = "EUR"
        data["invoice_lines"][1].update(currency="EUR", unit_price="€30.00")
        raw, normalized, candidates = self.prepare(data)
        self.assertFalse(normalized.issues)
        self.assertEqual(len(candidates), 1)
        result = verify(raw, normalized, check_single(normalized, candidates), "single")
        self.assertEqual(result["status"], "matched")
        self.assertEqual(result["candidates"][0]["lines"][0]["invoice_line_id"], "L0")

    def test_solution_cap_never_becomes_a_unique_match(self):
        raw, normalized, candidates = self.prepare(source_pack((30, 90, 50, 70), (1, 1, 1, 1), quantity=2))
        execution = solve_allocations(normalized, candidates, max_solutions=1)
        self.assertFalse(execution.complete)
        self.assertEqual(len(execution.allocations), 1)
        self.assertEqual(verify(raw, normalized, execution, "multi")["status"], "review")

    def test_verifier_rejects_pruned_rival_or_forged_equations(self):
        raw, normalized, candidates = self.prepare(source_pack((30, 90, 50, 70), (1, 1, 1, 1), quantity=2))
        execution = solve_allocations(normalized, candidates)
        pruned = replace(execution, allocations=execution.allocations[:1])
        self.assertEqual(verify(raw, normalized, pruned, "multi")["reason"], "solver_verifier_disagreement")
        changed = deepcopy(execution.allocations[0].lines)
        changed[0]["unit_price_cents"] += 1
        forged = replace(execution, allocations=(replace(execution.allocations[0], lines=changed), *execution.allocations[1:]))
        self.assertEqual(verify(raw, normalized, forged, "multi")["reason"], "solver_verifier_disagreement")
        independently_pruned = solve_allocations(normalized, candidates[:2])
        self.assertEqual(verify(raw, normalized, independently_pruned, "multi")["status"], "review")

    def test_verifier_rejects_normalized_price_tampering_and_raw_file_changes(self):
        raw, normalized, candidates = self.prepare()
        execution = solve_allocations(normalized, candidates)
        changed_tables = deepcopy(normalized.tables)
        changed_tables["invoice_lines"][0]["unit_price_cents"] = 1
        self.assertEqual(verify(raw, replace(normalized, tables=changed_tables), execution, "multi")["reason"], "normalizer_verifier_disagreement")
        self.path.write_text(self.path.read_text() + " ")
        self.assertEqual(verify(raw, normalized, execution, "multi")["reason"], "source_records_changed")

    def test_known_single_quantity_document_can_identify_without_receipt(self):
        raw, normalized, candidates = self.prepare(source_pack((30,), (None,), amount=60, quantity=2, scope="single_line"))
        result = verify(raw, normalized, check_single(normalized, candidates), "single")
        self.assertEqual(result["status"], "matched")
        self.assertEqual(result["claim_assessment"], "receiving_evidence_unavailable")

    def test_missing_single_quantity_needs_receipt_even_with_reference(self):
        raw, normalized, candidates = self.prepare(source_pack((30,), (None,), amount=60, quantity=None, scope="single_line"))
        result = check_single(normalized, candidates)
        self.assertFalse(result.complete)
        self.assertEqual(verify(raw, normalized, result, "single")["status"], "review")

    def test_unknown_price_basis_is_not_silently_assumed(self):
        for basis in (None, "adjusted_invoice_price"):
            raw, normalized, candidates = self.prepare(source_pack((30,), (2,), amount=60, quantity=2, scope="single_line", basis=basis))
            self.assertFalse(check_single(normalized, candidates).complete)
            self.assertFalse(solve_allocations(normalized, candidates).complete)
            self.assertEqual(verify(raw, normalized, check_single(normalized, candidates), "single")["status"], "review")

    def test_more_than_twelve_candidates_is_explicitly_incomplete(self):
        raw, normalized, candidates = self.prepare(source_pack(tuple(range(1, 14)), (1,) * 13, amount=10, quantity=None))
        execution = solve_allocations(normalized, candidates)
        self.assertFalse(execution.complete)
        self.assertEqual(execution.issues[0]["code"], "candidate_limit")
        self.assertEqual(verify(raw, normalized, execution, "multi")["status"], "review")

    def test_missing_solver_library_has_no_bruteforce_fallback(self):
        import builtins
        original_import = builtins.__import__
        def no_solver(name, *args, **kwargs):
            if name.startswith("ortools"):
                raise ImportError("not installed")
            return original_import(name, *args, **kwargs)
        raw, normalized, candidates = self.prepare()
        with patch("builtins.__import__", side_effect=no_solver):
            execution = solve_allocations(normalized, candidates)
        self.assertFalse(execution.complete)
        self.assertEqual(execution.issues[0]["code"], "solver_unavailable")


if __name__ == "__main__":
    unittest.main()
