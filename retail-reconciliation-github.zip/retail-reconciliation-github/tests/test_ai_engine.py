"""Orchestration tests use injected providers; these are not live AI evaluation."""
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
from types import SimpleNamespace
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.ai.analysis import inspect
from recon.ai.contracts import ACTION_SCHEMA, Action
from recon.ai.executor import execute
from recon.ai.service import reconcile
from recon.engine import generate_candidates
from recon.phase2.analysis import quantity_for, respects_references
from recon.phase2.contracts import PlannerUnavailable
from recon.phase2.storage import load_data, source_digest


class ScriptedProvider:
    def __init__(self, actions):
        self.actions = list(actions)
        self.contexts = []

    def complete(self, instructions, context, schema):
        self.contexts.append(deepcopy(context))
        assert schema == ACTION_SCHEMA
        item = self.actions.pop(0)
        value = {"operation": item.value} if isinstance(item, Action) else item
        return SimpleNamespace(value=value, audit={"provider": "scripted_test", "model": "none",
                              "response_id": f"test-{len(self.contexts)}", "live": False})


class AdaptiveProvider(ScriptedProvider):
    """Test double branches on actual observations; explicitly not an AI model."""
    def __init__(self):
        super().__init__([])

    def complete(self, instructions, context, schema):
        observation, profile = context["observation"], context["profile"]
        if not profile["amount_available"]:
            action = Action.REVIEW
        elif not observation["source_loaded"]:
            action = Action.LOOKUP if profile["provided_reference_fields"] else Action.ENUMERATE
        elif observation["candidate_count"] > 1 and observation["exact_description_sku_count"] > 0 and \
                Action.EXACT.value in context["available_operations"]:
            action = Action.EXACT
        elif observation["arithmetic_operation"] is None:
            action = Action.AMOUNT if profile["reported_quantity_available"] else Action.DERIVE
        elif Action.REFERENCES.value in context["available_operations"]:
            action = Action.REFERENCES
        else:
            action = Action.FINISH
        self.actions.append(action)
        return super().complete(instructions, context, schema)


class AIEngineTests(unittest.TestCase):
    def setUp(self):
        self.conn = load_data(ROOT / "data")
        self.addCleanup(self.conn.close)

    def update(self, deduction_id="D-DEMO-PO", **values):
        fields = ",".join(f"{field}=?" for field in values)
        self.conn.execute(f"UPDATE deductions SET {fields} WHERE deduction_id=?", (*values.values(), deduction_id))
        self.conn.commit()

    def run_script(self, actions, deduction_id="D-DEMO-PO", **kwargs):
        provider = ScriptedProvider(actions)
        return reconcile(self.conn, deduction_id, provider=provider, **kwargs), provider

    def test_structural_inspection_computes_no_candidate_or_financial_statistics(self):
        notice = dict(self.conn.execute("SELECT * FROM deductions WHERE deduction_id='D-DEMO-PO'").fetchone())
        statements = []
        self.conn.set_trace_callback(statements.append)
        profile = inspect(self.conn, notice, False)
        self.conn.set_trace_callback(None)
        self.assertTrue(all("COUNT(*)" in sql for sql in statements))
        self.assertTrue(all("JOIN" not in sql.upper() for sql in statements))
        self.assertEqual(profile["provided_reference_fields"], ["po_hint"])
        self.assertNotIn("candidate_count", profile)
        self.assertNotIn("financially_consistent_count", profile)
        self.assertNotIn("exact_description_sku_count", profile)

    def test_no_matching_computation_before_first_model_choice(self):
        provider = ScriptedProvider([Action.LOOKUP, Action.AMOUNT, Action.FINISH])
        original = provider.complete
        statements = []
        self.conn.set_trace_callback(statements.append)
        with patch("recon.ai.executor.generate_candidates", wraps=generate_candidates) as join, \
                patch("recon.ai.executor.quantity_for", wraps=quantity_for) as arithmetic, \
                patch("recon.ai.executor.respects_references", wraps=respects_references) as references:
            def check_first_call(*args):
                if not provider.contexts:
                    join.assert_not_called()
                    arithmetic.assert_not_called()
                    references.assert_not_called()
                    self.assertFalse(any("JOIN" in sql.upper() for sql in statements))
                return original(*args)
            provider.complete = check_first_call
            result = reconcile(self.conn, "D-DEMO-PO", provider=provider)
        self.conn.set_trace_callback(None)
        self.assertEqual(result["status"], "matched")
        self.assertEqual(result["model_calls"], 3)
        self.assertFalse(result["live_ai"])

    def test_model_context_never_contains_record_ids_amounts_or_hidden_labels(self):
        result, provider = self.run_script([Action.LOOKUP, Action.AMOUNT, Action.FINISH])
        serialized = json.dumps(provider.contexts)
        for value in ("D-DEMO-PO", "PO-ABC-A", "INV-ABC-A", "LINE-ABC-A", "SKU-WATER", "90000", "ground_truth"):
            self.assertNotIn(value, serialized)
        self.assertEqual(result["planning_decisions"][0]["audit"]["provider"], "scripted_test")
        self.assertNotIn("candidate_count", provider.contexts[0]["observation"])
        self.assertEqual(provider.contexts[1]["observation"]["candidate_count"], 1)

    def test_sequential_observations_change_the_next_model_choice(self):
        self.update("D-DEMO-AMBIG", description="Sparkling Water Variety Pack 12 x 355mL")
        provider = AdaptiveProvider()
        result = reconcile(self.conn, "D-DEMO-AMBIG", provider=provider)
        actions = [decision["action"] for decision in result["planning_decisions"]]
        self.assertEqual(actions, [Action.ENUMERATE.value, Action.EXACT.value, Action.AMOUNT.value, Action.FINISH.value])
        self.assertEqual(provider.contexts[1]["observation"]["candidate_count"], 3)
        self.assertEqual(provider.contexts[2]["observation"]["candidate_count"], 1)
        self.assertEqual(result["status"], "matched")
        self.assertEqual(result["candidates"][0]["sku"], "SKU-WATER")

    def test_text_before_or_after_arithmetic_both_work_and_preserve_quantity(self):
        self.update("D-DEMO-AMBIG", description="Sparkling Water Variety Pack 12 x 355mL")
        methods = ([Action.ENUMERATE, Action.EXACT, Action.AMOUNT, Action.FINISH],
                   [Action.ENUMERATE, Action.AMOUNT, Action.EXACT, Action.FINISH])
        outputs = []
        for method in methods:
            result, _ = self.run_script(method, "D-DEMO-AMBIG")
            self.assertEqual(result["status"], "matched")
            self.assertEqual(result["candidates"][0]["evaluated_short_qty"], 15)
            self.assertEqual([step["op"] for step in result["plan"]["operations"]], [action.value for action in method])
            outputs.append(result["candidates"][0]["invoice_line_id"])
        self.assertEqual(outputs[0], outputs[1])

    def test_broad_lookup_can_check_arithmetic_before_provided_references(self):
        result, _ = self.run_script([Action.ENUMERATE, Action.AMOUNT, Action.REFERENCES, Action.FINISH])
        self.assertEqual(result["status"], "matched")
        self.assertEqual(result["candidates"][0]["po_id"], "PO-ABC-A")

    def test_missing_quantity_uses_selected_exact_division_then_independent_receipt(self):
        self.update(short_qty=None)
        result, _ = self.run_script([Action.LOOKUP, Action.DERIVE, Action.FINISH])
        self.assertEqual(result["status"], "matched")
        self.assertEqual(result["candidates"][0]["derived_short_qty"], 15)
        self.assertIsNone(result["notice"]["short_qty"])
        self.assertTrue(result["verification"]["passed"])

    def test_derived_quantity_without_receipt_remains_review(self):
        self.update("D-DEMO-NORECEIPT", short_qty=None)
        result, _ = self.run_script([Action.LOOKUP, Action.DERIVE, Action.FINISH], "D-DEMO-NORECEIPT")
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["claim_assessment"], "receiving_evidence_unavailable")

    def test_missing_amount_is_visible_and_model_can_request_review_without_computation(self):
        self.update(amount_cents=None)
        provider = AdaptiveProvider()
        with patch("recon.ai.executor.generate_candidates") as join:
            result = reconcile(self.conn, "D-DEMO-PO", provider=provider)
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "model_requested_review")
        self.assertFalse(provider.contexts[0]["profile"]["amount_available"])
        self.assertEqual(result["model_calls"], 1)
        join.assert_not_called()

    def test_ambiguity_is_kept_even_if_model_requests_finish(self):
        result, _ = self.run_script([Action.ENUMERATE, Action.AMOUNT, Action.FINISH], "D-DEMO-AMBIG")
        self.assertEqual(result["status"], "review")
        self.assertEqual(len(result["candidates"]), 2)

    def test_rank_is_advisory_and_can_precede_arithmetic(self):
        ranker = SimpleNamespace(name="test_ranker", score=lambda query, text: 100 if "Water" in text else 0)
        result, _ = self.run_script([Action.ENUMERATE, Action.RANK, Action.AMOUNT, Action.FINISH],
                                    "D-DEMO-AMBIG", ranker=ranker)
        self.assertEqual(result["status"], "review")
        self.assertEqual(len(result["candidates"]), 2)
        self.assertTrue(result["trace"][1]["advisory_only"])

    def test_invalid_action_sql_identifier_and_extra_fields_never_execute(self):
        values = ({"operation": "execute_sql"}, {"operation": Action.LOOKUP.value, "sql": "SELECT 1"},
                  {"operation": Action.LOOKUP.value, "candidate_id": "LINE-ABC-A"},
                  {"operation": Action.LOOKUP.value, "amount_cents": 90000}, {"operation": True})
        for value in values:
            with self.subTest(value=value), patch("recon.ai.executor.generate_candidates") as join:
                result, _ = self.run_script([value])
                self.assertEqual(result["reason"], "invalid_model_action")
                self.assertEqual(result["status"], "review")
                join.assert_not_called()

    def test_finish_cannot_insert_missing_reference_or_arithmetic_operations(self):
        for method in ([Action.FINISH], [Action.LOOKUP, Action.FINISH],
                       [Action.ENUMERATE, Action.AMOUNT, Action.FINISH]):
            with self.subTest(method=method), patch("recon.ai.service.verify") as verifier:
                result, _ = self.run_script(method)
                self.assertEqual(result["status"], "review")
                self.assertEqual(result["reason"], "invalid_model_action")
                verifier.assert_not_called()

    def test_wrong_arithmetic_and_repeated_actions_are_rejected(self):
        for method in ([Action.LOOKUP, Action.DERIVE], [Action.LOOKUP, Action.LOOKUP],
                       [Action.LOOKUP, Action.AMOUNT, Action.AMOUNT]):
            with self.subTest(method=method):
                result, _ = self.run_script(method)
                self.assertEqual(result["status"], "review")
                self.assertEqual(result["reason"], "invalid_model_action")

    def test_exact_filter_cannot_be_invoked_without_an_actual_catalog_match(self):
        result, _ = self.run_script([Action.LOOKUP, Action.EXACT])
        self.assertEqual(result["reason"], "invalid_model_action")

    def test_provider_failure_and_refusal_fail_closed_without_offline_fallback(self):
        class Unavailable:
            def complete(self, *args):
                raise PlannerUnavailable("refused; private-secret-do-not-log")
        with patch("recon.phase2.planner.OfflinePlanner.plan", side_effect=AssertionError("No fallback")):
            result = reconcile(self.conn, "D-DEMO-PO", provider=Unavailable())
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "planner_unavailable")
        self.assertEqual(result["model_calls"], 1)
        self.assertFalse(result["live_ai"])
        self.assertNotIn("private-secret-do-not-log", json.dumps(result))

    def test_step_limit_abstains_even_after_partially_complete_method(self):
        result, provider = self.run_script([Action.LOOKUP, Action.AMOUNT], max_steps=2)
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "model_step_limit")
        self.assertEqual(result["model_calls"], 2)
        self.assertEqual(len(provider.contexts), 2)

    def test_source_change_during_provider_call_is_detected(self):
        conn = self.conn
        class Mutating(ScriptedProvider):
            def complete(self, *args):
                conn.execute("UPDATE invoice_lines SET unit_price_cents=1 WHERE invoice_line_id='LINE-ABC-A'")
                return super().complete(*args)
        provider = Mutating([Action.LOOKUP])
        with patch("recon.ai.service.execute") as executor:
            result = reconcile(self.conn, "D-DEMO-PO", provider=provider)
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "source_records_changed")
        executor.assert_not_called()

    def test_source_change_during_rank_execution_is_detected(self):
        conn = self.conn
        def score(query, description):
            conn.execute("UPDATE receipts SET received_qty=100 WHERE shipment_id='SHP-ABC-A'")
            return 100
        ranker = SimpleNamespace(name="mutating_ranker", score=score)
        result, _ = self.run_script([Action.ENUMERATE, Action.RANK], "D-DEMO-AMBIG", ranker=ranker)
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "source_records_changed")

    def test_independent_verifier_rejects_executor_pruning_an_ambiguous_set(self):
        def prune(conn, notice, profile, state, action, **kwargs):
            updated = execute(conn, notice, profile, state, action, **kwargs)
            return replace(updated, hypotheses=updated.hypotheses[:1])
        with patch("recon.ai.service.execute", side_effect=prune):
            result, _ = self.run_script([Action.ENUMERATE, Action.AMOUNT, Action.FINISH], "D-DEMO-AMBIG")
        self.assertEqual(result["status"], "review")
        self.assertFalse(result["verification"]["passed"])
        self.assertEqual(result["reason"], "executor_verifier_disagreement")

    def test_engine_preserves_source_and_original_notice(self):
        before = source_digest(self.conn)
        result, _ = self.run_script([Action.LOOKUP, Action.AMOUNT, Action.FINISH])
        self.assertEqual(before, source_digest(self.conn))
        self.assertEqual(result["notice"]["po_hint"], "PO-ABC-A")
        self.assertFalse(result["live_ai"])

    def test_max_steps_validation_and_unknown_deduction(self):
        for value in (0, 9, True, "8"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                reconcile(self.conn, "D-DEMO-PO", provider=ScriptedProvider([]), max_steps=value)
        with self.assertRaises(KeyError):
            reconcile(self.conn, "UNKNOWN", provider=ScriptedProvider([]))


if __name__ == "__main__":
    unittest.main()
