"""Real loopback HTTP integration tests for the locally executed demo app."""
from __future__ import annotations

import csv
from datetime import datetime
import hashlib
import http.client
import json
from pathlib import Path
import shutil
import sys
import tempfile
from threading import Thread
import unittest
from unittest.mock import Mock, patch
from uuid import UUID

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.web import MAX_BODY_BYTES, create_server


class LocalWebTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.folder = Path(self.directory.name)
        self.data = self.folder / "data"
        self.data.mkdir()
        for source in (ROOT / "data").glob("*.csv"):
            shutil.copy2(source, self.data / source.name)
        self.index = self.folder / "index.html"
        self.index.write_text("<!doctype html><title>Local test</title><button>Run reconciliation</button>", encoding="utf-8")
        self.server = create_server(port=0, data_dir=self.data, index_path=self.index, planner_mode="offline")
        self.port = self.server.server_port
        self.thread = Thread(target=self.server.serve_forever, kwargs={"poll_interval": .01}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.directory.cleanup()

    def request(self, method, path, body=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            connection.request(method, path, body=body, headers=headers or {})
            response = connection.getresponse()
            content = response.read()
            response_headers = dict(response.getheaders())
            return response.status, response_headers, content
        finally:
            connection.close()

    def post(self, deduction_id="D-DEMO-PO", **extra):
        status, headers, content = self.request("POST", "/api/run", json.dumps({"deduction_id": deduction_id, **extra}),
                                                 {"Content-Type": "application/json",
                                                  "Origin": f"http://127.0.0.1:{self.port}"})
        return status, headers, json.loads(content)

    def test_factory_binds_only_loopback_and_ephemeral_port(self):
        self.assertEqual(self.server.server_address[0], "127.0.0.1")
        self.assertGreater(self.port, 0)

    def test_home_serves_only_configured_page_and_no_arbitrary_files(self):
        status, headers, body = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertEqual(body, self.index.read_bytes())
        self.assertTrue(headers["Content-Type"].startswith("text/html"))
        for path in ("/README.md", "/data/deductions.csv", "/../README.md", "/api/run"):
            with self.subTest(path=path):
                self.assertEqual(self.request("GET", path)[0], 404)

    def test_case_list_contains_only_two_demo_ids_and_explicit_execution_mode(self):
        status, headers, content = self.request("GET", "/api/cases")
        data = json.loads(content)
        self.assertEqual(status, 200)
        self.assertEqual({case["deduction_id"] for case in data["cases"]}, {"D-DEMO-PO", "D-DEMO-AMBIG"})
        self.assertEqual(data["planner"], "offline_policy")
        self.assertIsNone(data["live_ai"])
        self.assertEqual(data["data_kind"], "synthetic_fixture")
        self.assertTrue(data["text_ranking"]["advisory_only"])
        self.assertEqual(data["text_ranking"]["available"], data["text_ranking"]["enabled"])
        self.assertEqual(headers["Cache-Control"], "no-store")

    def test_actual_known_po_run_returns_verified_result_and_execution_metadata(self):
        with patch("recon.phase2.planner.OpenAIPlanner._request", side_effect=AssertionError("No model call allowed")):
            status, _, data = self.post()
        self.assertEqual(status, 200)
        self.assertEqual(str(UUID(data["run_id"])), data["run_id"])
        self.assertLessEqual(datetime.fromisoformat(data["started_at"]), datetime.fromisoformat(data["completed_at"]))
        self.assertGreaterEqual(data["elapsed_ms"], 0)
        self.assertEqual(data["planner"], "offline_policy")
        self.assertFalse(data["live_ai"])
        result = data["result"]
        self.assertEqual(result["status"], "matched")
        self.assertEqual(result["deduction_id"], "D-DEMO-PO")
        self.assertEqual(result["candidates"][0]["sku"], "SKU-WATER")
        self.assertTrue(result["verification"]["passed"])
        self.assertTrue(result["trace"])
        self.assertTrue(result["candidates"][0]["evidence"])

    def test_actual_ambiguous_run_returns_review_without_choosing_text_favorite(self):
        status, _, data = self.post("D-DEMO-AMBIG")
        self.assertEqual(status, 200)
        result = data["result"]
        self.assertEqual(result["status"], "review")
        self.assertEqual({candidate["sku"] for candidate in result["candidates"]}, {"SKU-WATER", "SKU-SODA"})
        self.assertTrue(result["verification"]["passed"])
        ranked = any(step["operation"] == "rank_description" for step in result["trace"])
        self.assertEqual(ranked, data["text_ranking"]["enabled"])

    def test_each_click_has_new_run_id_and_reads_current_source(self):
        first_status, _, first = self.post()
        path = self.data / "deductions.csv"
        with path.open(newline="", encoding="utf-8") as stream:
            reader = csv.DictReader(stream)
            columns, records = reader.fieldnames, list(reader)
        for record in records:
            if record["deduction_id"] == "D-DEMO-PO":
                record["amount_cents"] = "87500"
        with path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=columns)
            writer.writeheader()
            writer.writerows(records)
        second_status, _, second = self.post()
        self.assertEqual((first_status, second_status), (200, 200))
        self.assertNotEqual(first["run_id"], second["run_id"])
        self.assertEqual(first["result"]["status"], "matched")
        self.assertEqual(second["result"]["status"], "no_match")
        self.assertEqual(second["result"]["notice"]["amount_cents"], 87500)

    def test_running_does_not_modify_source_files_or_save_results(self):
        before = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in self.data.iterdir()}
        self.post()
        self.post("D-DEMO-AMBIG")
        after = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in self.data.iterdir()}
        self.assertEqual(before, after)
        self.assertEqual({path.name for path in self.folder.iterdir()}, {"data", "index.html"})

    def test_unknown_ids_extra_fields_and_nonstring_id_are_rejected(self):
        for request in ({"deduction_id": "D-0001"}, {"deduction_id": "D-DEMO-PO", "sql": "SELECT 1"},
                        {"deduction_id": ["D-DEMO-PO"]}, {}, []):
            with self.subTest(request=request):
                status, _, body = self.request("POST", "/api/run", json.dumps(request), {"Content-Type": "application/json"})
                self.assertEqual(status, 400)
                self.assertIn("error", json.loads(body))

    def test_invalid_and_duplicate_json_is_rejected_before_loading_data(self):
        with patch("recon.web.load_data") as loader:
            for body in ("{", '{"deduction_id":"D-DEMO-PO","deduction_id":"D-DEMO-AMBIG"}',
                         '{"deduction_id":NaN}', b'\xff', "[" * 1500 + "]" * 1500):
                with self.subTest(body=body):
                    status, _, _ = self.request("POST", "/api/run", body, {"Content-Type": "application/json"})
                    self.assertEqual(status, 400)
        loader.assert_not_called()

    def test_wrong_content_type_oversized_body_and_chunked_body_are_rejected(self):
        self.assertEqual(self.request("POST", "/api/run", "{}", {"Content-Type": "text/plain"})[0], 415)
        self.assertEqual(self.request("POST", "/api/run", "x" * (MAX_BODY_BYTES + 1),
                                      {"Content-Type": "application/json"})[0], 413)
        self.assertEqual(self.request("POST", "/api/run", "{}", {"Content-Type": "application/json",
                                                                  "Transfer-Encoding": "chunked"})[0], 400)

    def test_cross_origin_and_untrusted_host_cannot_trigger_run(self):
        for headers in ({"Origin": "https://example.com"}, {"Origin": "null"},
                        {"Host": f"attacker.example:{self.port}"}, {"Sec-Fetch-Site": "cross-site"}):
            with self.subTest(headers=headers), patch("recon.web.load_data") as loader:
                status, _, _ = self.request("POST", "/api/run", '{"deduction_id":"D-DEMO-PO"}',
                                             {"Content-Type": "application/json", **headers})
                self.assertEqual(status, 403)
                loader.assert_not_called()

    def test_load_failure_is_safe_error_without_fabricated_result(self):
        with patch("recon.web.load_data", side_effect=ValueError("private-source-path-and-secret")):
            status, _, data = self.post()
        self.assertEqual(status, 500)
        self.assertEqual(data["error"]["code"], "run_failed")
        self.assertNotIn("private-source-path-and-secret", json.dumps(data))
        self.assertNotIn("result", data)

    def test_engine_failure_closes_database(self):
        connection = Mock()
        with patch("recon.web.load_data", return_value=connection), \
                patch("recon.web.reconcile", side_effect=RuntimeError("engine failed")):
            status, _, data = self.post()
        self.assertEqual(status, 500)
        self.assertNotIn("result", data)
        connection.close.assert_called_once_with()

    def test_optional_ranker_absence_is_explicit_and_engine_still_executes(self):
        self.server.ranker = None
        self.server.text_ranking.update(available=False, enabled=False, name=None)
        status, _, data = self.post("D-DEMO-AMBIG")
        self.assertEqual(status, 200)
        self.assertFalse(data["text_ranking"]["enabled"])
        self.assertEqual(data["result"]["status"], "review")
        self.assertFalse(any(step["operation"] == "rank_description" for step in data["result"]["trace"]))

    def test_port_validation(self):
        for port in (-1, 65536, True, "8765"):
            with self.subTest(port=port), self.assertRaises(ValueError):
                create_server(port=port)


if __name__ == "__main__":
    unittest.main()
