"""Uploads map real cells; no financial facts or relationships are fabricated."""
import base64
from copy import deepcopy
import io
import json
import unittest
from unittest.mock import patch
import zipfile

from recon.investigation.fixtures import make_pack
from recon.workspace.ingestion import (FIELD_CATALOG, build_pack, capabilities,
                                       inspect_files, suggest_mapping)


def upload(name, body):
    body = body.encode() if isinstance(body, str) else body
    return {"name": name, "content_base64": base64.b64encode(body).decode()}


def inspect(name, body):
    return inspect_files([upload(name, body)])["documents"]


def mappings(documents):
    return [{"document_id": d["id"], "role": d["role_suggestion"],
             "columns": d["mapping_suggestion"], "defaults": {}} for d in documents]


def workbook_xml_bytes():
    """Minimal OOXML input fixture; no spreadsheet authoring dependency needed."""
    output = io.BytesIO()
    files = {
        "[Content_Types].xml": '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>',
        "_rels/.rels": '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
        "xl/workbook.xml": '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Invoice Lines" sheetId="1" r:id="rId1"/></sheets></workbook>',
        "xl/_rels/workbook.xml.rels": '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
        "xl/styles.xml": '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="000000"/></numFmts><fonts count="1"><font/></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0"/><xf numFmtId="164" applyNumberFormat="1"/></cellXfs></styleSheet>',
        "xl/worksheets/sheet1.xml": '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:C2"/><sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>Invoice Number</t></is></c><c r="B1" t="inlineStr"><is><t>Unit Price</t></is></c><c r="C1" t="inlineStr"><is><t>SKU</t></is></c></row><row r="2"><c r="A2" s="1"><v>123</v></c><c r="B2"><v>0.10000000000000001</v></c><c r="C2" t="inlineStr"><is><t>00047</t></is></c></row></sheetData></worksheet>',
    }
    with zipfile.ZipFile(output, "w") as archive:
        for name, content in files.items():
            archive.writestr(name, content)
    return output.getvalue()


class WorkspaceIngestionTests(unittest.TestCase):
    def test_csv_preserves_identifiers_quoted_money_and_multiline_cells(self):
        body = '\ufeffInvoice Number,Item Code,Unit Price,Invoiced Qty,Notes\r\n000012,00047,"1,250.00",5,"line one\nline two"\r\n'
        doc = inspect("invoice_detail.csv", body)[0]
        self.assertEqual(doc["rows"][0]["Invoice Number"], "000012")
        self.assertEqual(doc["rows"][0]["Item Code"], "00047")
        self.assertEqual(doc["rows"][0]["Unit Price"], "1,250.00")
        self.assertEqual(doc["rows"][0]["Notes"], "line one\nline two")
        self.assertEqual(doc["role_suggestion"], "invoice_lines")

    def test_utf16_semicolon_export_is_inspected_without_value_coercion(self):
        doc = inspect("receiving.csv", 'Receipt ID;Shipment ID;Received Qty\nR-01;S-01;0\n'.encode("utf-16"))[0]
        self.assertEqual(doc["delimiter"], ";")
        self.assertEqual(doc["rows"][0]["Received Qty"], "0")

    def test_title_rows_are_retained_while_financial_headers_are_detected(self):
        doc = inspect("receiving.csv", "Warehouse export for October\nReceipt ID,Shipment ID,SKU,Received Qty\nR-01,S-01,P-01,0\n")[0]
        self.assertEqual(doc["header_row"], 2)
        self.assertEqual(doc["preamble_rows"], [["Warehouse export for October"]])
        self.assertEqual(doc["rows"][0]["Receipt ID"], "R-01")
        self.assertEqual(doc["row_numbers"], [3])
        self.assertIn("header_row_detected", [i["code"] for i in doc["issues"]])

    def test_malformed_width_and_duplicate_headers_preserve_raw_cells_and_block(self):
        doc = inspect("invoice.csv", "Invoice Number,SKU\nI-1,P-1,EXTRA\n")[0]
        self.assertIn("row_width_mismatch", [i["code"] for i in doc["issues"]])
        self.assertEqual(doc["raw_rows"][1], ["I-1", "P-1", "EXTRA"])
        duplicate = inspect("invoice.csv", "SKU,SKU\nP-1,P-2\n")[0]
        self.assertIn("duplicate_headers", [i["code"] for i in duplicate["issues"]])
        self.assertEqual(duplicate["raw_rows"][1], ["P-1", "P-2"])

    def test_ambiguous_aliases_are_not_arbitrarily_selected(self):
        proposed = suggest_mapping(["Invoiced Qty", "Billed Quantity"], "invoice_lines")
        self.assertIsNone(proposed["columns"]["quantity"])
        self.assertEqual(len(proposed["candidates"]["quantity"]), 2)

    def test_canonical_json_pack_roundtrips_without_financial_normalization(self):
        pack = make_pack("reference-mixed-units")
        docs = inspect("my-business-records.json", json.dumps(pack))
        result = build_pack(docs, mappings(docs))
        self.assertTrue(result["ready"], result["issues"])
        self.assertEqual(result["pack"], pack)
        self.assertEqual(result["pack"]["receipts"][1]["quantity"], "1,020")
        self.assertTrue(all(p["source_sha256"] and p["file"] for p in result["provenance"]))

    def test_json_decimal_tokens_are_not_binary_float_rounded(self):
        doc = inspect("values.json", '[{"amount":0.10000000000000001,"id":"001"}]')[0]
        self.assertEqual(doc["rows"][0]["amount"], "0.10000000000000001")
        self.assertEqual(doc["rows"][0]["id"], "001")

    def test_one_combined_export_projects_headers_and_keeps_every_line(self):
        docs = inspect("combined.csv", 'Invoice Number,PO Number,Invoice Date,Currency,SKU,Invoiced Qty,Qty UOM,Unit Price,Price UOM\nI-1,PO-1,2026-10-03,USD,P-1,10,CS,60.00,CS\nI-1,PO-1,2026-10-03,USD,P-2,20,CS,60.00,CS\n')
        doc = docs[0]
        proposed = [{"document_id": doc["id"], "role": role, "columns": suggest_mapping(doc["columns"], role)["columns"], "defaults": {}} for role in ("invoices", "invoice_lines")]
        result = build_pack(docs, proposed)
        self.assertEqual(len(result["pack"]["invoices"]), 1)
        self.assertEqual(len(result["pack"]["invoice_lines"]), 2)
        self.assertNotEqual(result["pack"]["invoice_lines"][0]["invoice_line_id"], result["pack"]["invoice_lines"][1]["invoice_line_id"])
        self.assertTrue(result["pack"]["invoice_lines"][0]["invoice_line_id"].startswith("source-row:"))
        self.assertEqual({p["source_row"] for p in result["provenance"] if p["table"] == "invoices"}, {2, 3})
        self.assertIn("repeated_header_projection", [i["code"] for i in result["issues"]])

    def test_conflicting_header_identity_blocks_instead_of_picking_first(self):
        docs = inspect("invoices.csv", 'Invoice Number,PO Number,Invoice Date,Currency\nI-1,PO-1,2026-10-03,USD\nI-1,PO-1,2026-10-03,EUR\n')
        result = build_pack(docs, mappings(docs))
        self.assertFalse(result["ready"])
        self.assertIn("conflicting_source_identity", [i["code"] for i in result["issues"]])

    def test_duplicate_financial_rows_are_retained_and_blocked(self):
        docs = inspect("receiving.csv", 'Receipt ID,Shipment ID,SKU,Received Qty,Qty UOM,Receipt Date\nR-1,S-1,P-1,10,CS,2026-10-05\nR-1,S-1,P-1,10,CS,2026-10-05\n')
        result = build_pack(docs, mappings(docs))
        self.assertEqual(len(result["pack"]["receipts"]), 2)
        self.assertIn("duplicate_financial_identity", [i["code"] for i in result["issues"]])

    def test_only_explicit_defaults_supply_currency_unit_or_scope(self):
        pack = make_pack("ambiguous-product")
        del pack["notice"]["currency"]
        docs = inspect("source.json", json.dumps(pack))
        maps = mappings(docs)
        without = build_pack(docs, maps)
        self.assertIsNone(without["pack"]["notice"]["currency"])
        self.assertFalse(without["ready"])
        notice_mapping = next(m for m in maps if m["role"] == "notice")
        notice_mapping["defaults"]["currency"] = "USD"
        with_default = build_pack(docs, maps)
        self.assertTrue(with_default["ready"], with_default["issues"])
        entry = next(p for p in with_default["provenance"] if p["table"] == "notice" and p["field"] == "currency")
        self.assertEqual(entry["operation"], "user_declared_default")
        self.assertIsNone(entry["raw"])

    def test_multiple_notices_are_retained_and_selectable(self):
        pack = make_pack("ambiguous-product")
        first = pack["notice"]
        second = {**first, "deduction_id": "SECOND", "amount": "120.00"}
        pack["notice"] = [first, second]
        docs = inspect("source.json", json.dumps(pack))
        result = build_pack(docs, mappings(docs), notice_row_id="SECOND")
        self.assertEqual(len(result["notices"]), 2)
        self.assertEqual(result["pack"]["notice"]["deduction_id"], "SECOND")
        self.assertEqual(result["pack"]["notice"]["amount"], "120.00")

    def test_unknown_mapping_columns_or_fields_cannot_be_executed(self):
        docs = inspect("invoices.csv", "Invoice Number\nI-1\n")
        for columns in ({"invoice_id": "DOES NOT EXIST"}, {"python": "Invoice Number"}):
            with self.subTest(columns=columns), self.assertRaises(ValueError):
                build_pack(docs, [{"document_id": docs[0]["id"], "role": "invoices", "columns": columns, "defaults": {}}])

    def test_defaults_cannot_invent_business_links_or_financial_amounts(self):
        docs = inspect("invoice_detail.csv", "SKU,Invoiced Qty\nP-1,10\n")
        for defaults in ({"invoice_id": "INVENTED"}, {"unit_price": "60.00"}, {"quantity": "100"}):
            with self.subTest(defaults=defaults), self.assertRaises(ValueError):
                build_pack(docs, [{"document_id": docs[0]["id"], "role": "invoice_lines", "columns": {}, "defaults": defaults}])

    def test_formula_cells_are_not_executed_or_credited_as_values(self):
        docs = inspect("invoice_detail.csv", 'Invoice Number,SKU,Invoiced Qty,Qty UOM,Unit Price,Price UOM,Currency\nI-1,P-1,10,CS,=SUM(A1:A2),CS,USD\n')
        result = build_pack(docs, mappings(docs))
        self.assertFalse(result["ready"])
        self.assertIn("formula_requires_values", [i["code"] for i in result["issues"]])

    def test_invalid_upload_content_and_duplicate_source_are_visible(self):
        with self.assertRaises(ValueError):
            inspect_files([{"name": "source.csv", "content_base64": "not base64!"}])
        source = upload("../../invoice.csv", "Invoice Number\n0001\n")
        result = inspect_files([source, source])
        self.assertEqual(result["documents"][0]["name"], "invoice.csv")
        self.assertIn("duplicate_upload", [i["code"] for i in result["issues"]])

    def test_inspection_limit_never_silently_drops_rows_after_blank_preamble(self):
        body = "Invoice Number\nI-1\n" + "\n" * 30 + "I-2\n"
        with patch("recon.workspace.ingestion.MAX_ROWS", 2):
            doc = inspect("invoices.csv", body)[0]
        self.assertIn("too_many_source_rows", [i["code"] for i in doc["issues"]])

    @unittest.skipUnless(capabilities()["xlsx"], "openpyxl is optional and not installed")
    def test_xlsx_preserves_explicit_zero_padded_identifiers_and_exact_numeric_xml(self):
        doc = inspect("exports.xlsx", workbook_xml_bytes())[0]
        self.assertEqual(doc["sheet"], "Invoice Lines")
        self.assertEqual(doc["rows"][0]["Invoice Number"], "000123")
        self.assertEqual(doc["rows"][0]["Unit Price"], "0.10000000000000001")
        self.assertEqual(doc["rows"][0]["SKU"], "00047")
        self.assertEqual(doc["cell_metadata"]["A2"]["rule"], "excel_explicit_zero_padding")

    @unittest.skipUnless(capabilities()["xlsx"], "openpyxl is optional and not installed")
    def test_excel_midnight_dates_become_iso_calendar_dates_with_raw_serial_retained(self):
        original = io.BytesIO(workbook_xml_bytes())
        updated = io.BytesIO()
        with zipfile.ZipFile(original) as source, zipfile.ZipFile(updated, "w") as target:
            for name in source.namelist():
                value = source.read(name)
                if name == "xl/styles.xml":
                    value = value.replace(b'<xf numFmtId="164" applyNumberFormat="1"/>', b'<xf numFmtId="14" applyNumberFormat="1"/>')
                if name == "xl/worksheets/sheet1.xml":
                    value = value.replace(b"Invoice Number", b"Invoice Date").replace(b"<v>123</v>", b"<v>46023</v>")
                target.writestr(name, value)
        doc = inspect("dates.xlsx", updated.getvalue())[0]
        self.assertEqual(doc["rows"][0]["Invoice Date"], "2026-01-01")
        self.assertEqual(doc["cell_metadata"]["A2"]["raw"], "46023")


if __name__ == "__main__":
    unittest.main()
