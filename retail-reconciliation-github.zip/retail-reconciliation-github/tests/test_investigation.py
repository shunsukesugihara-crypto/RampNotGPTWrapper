"""Evidence investigation: independent-record support, ambiguity, and safe reads.

Amounts and expected candidate rows below are authored assertions, not answers
computed using the executor or the verifier under test. Model doubles are
explicitly injected and never make live requests.
"""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from recon.ai.provider import Completion
from recon.investigation.contracts import action
from recon.investigation.fixtures import load_case, make_pack
from recon.reconstruction.data import load_pack
from recon.investigation.verification import verify


SOURCES = {"purchase_orders", "invoices", "invoice_lines", "shipments", "shipment_lines", "receipts"}


def source_pack():
    return {
        "version": 1,
        "notice": {"deduction_id": "D-TEST", "retailer": "Retailer", "notice_date": "2026-10-20",
                   "amount": "$900.00", "currency": "USD", "short_qty": "15", "uom": "CS",
                   "scope": "single_line", "basis": "whole_receipt_shortfalls", "po_hint": None,
                   "invoice_hint": None, "sku_hint": None, "description": "Unidentified merchandise shortage"},
        "products": [{"sku": "SKU-A", "description": "Product A", "case_pack": 12, "source_ref": "catalog:A"},
                     {"sku": "SKU-B", "description": "Product B", "case_pack": 12, "source_ref": "catalog:B"}],
        "purchase_orders": [{"po_id": "PO-A", "retailer": "Retailer", "order_date": "2026-10-01"},
                            {"po_id": "PO-B", "retailer": "Retailer", "order_date": "2026-10-01"}],
        "invoices": [{"invoice_id": "INV-A", "po_id": "PO-A", "invoice_date": "2026-10-03", "currency": "USD"},
                     {"invoice_id": "INV-B", "po_id": "PO-B", "invoice_date": "2026-10-03", "currency": "USD"}],
        "invoice_lines": [{"invoice_line_id": "LINE-A", "invoice_id": "INV-A", "sku": "SKU-A", "quantity": "100",
                           "uom": "CS", "unit_price": "60.00", "price_uom": "CS", "currency": "USD"},
                          {"invoice_line_id": "LINE-B", "invoice_id": "INV-B", "sku": "SKU-B", "quantity": "100",
                           "uom": "CS", "unit_price": "60.00", "price_uom": "CS", "currency": "USD"}],
        "shipments": [{"shipment_id": "SHIP-A", "po_id": "PO-A", "ship_date": "2026-10-04"},
                      {"shipment_id": "SHIP-B", "po_id": "PO-B", "ship_date": "2026-10-04"}],
        "shipment_lines": [{"shipment_id": "SHIP-A", "sku": "SKU-A", "quantity": "100", "uom": "CS"},
                           {"shipment_id": "SHIP-B", "sku": "SKU-B", "quantity": "100", "uom": "CS"}],
        "receipts": [{"receipt_id": "REC-A", "shipment_id": "SHIP-A", "sku": "SKU-A", "quantity": "85",
                      "uom": "CS", "receipt_date": "2026-10-05"},
                     {"receipt_id": "REC-B", "shipment_id": "SHIP-B", "sku": "SKU-B", "quantity": "100",
                      "uom": "CS", "receipt_date": "2026-10-05"}],
    }


def candidate_a():
    return {"invoice_line_id": "LINE-A", "invoice_id": "INV-A", "po_id": "PO-A", "sku": "SKU-A",
            "shipment_id": "SHIP-A", "unit_price_cents": 6000, "invoiced_qty": 100, "shipped_qty": 100,
            "received_qty": 85, "shortfall": 15, "amount_cents": 90000}


def candidate_b():
    return {"invoice_line_id": "LINE-B", "invoice_id": "INV-B", "po_id": "PO-B", "sku": "SKU-B",
            "shipment_id": "SHIP-B", "unit_price_cents": 6000, "invoiced_qty": 100, "shipped_qty": 100,
            "received_qty": 100, "shortfall": 0, "amount_cents": 0}


class IndependentInvestigationVerificationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "source.json"

    def tearDown(self):
        self.temp.cleanup()

    def raw(self, source=None):
        self.path.write_text(json.dumps(source or source_pack(), indent=2) + "\n")
        return load_pack(self.path)

    def test_receiving_records_resolve_two_equal_price_candidates(self):
        result = verify(self.raw(), [candidate_a(), candidate_b()], SOURCES)
        self.assertEqual(result["status"], "matched", result)
        self.assertTrue(result["passed"])
        self.assertTrue(result["independent"])
        self.assertEqual([r["invoice_line_id"] for r in result["candidates"]], ["LINE-A"])
        self.assertEqual(result["candidate_universe_count"], 2)
        self.assertTrue(any(r["table"] == "receipts" and r["raw"]["receipt_id"] == "REC-A" for r in result["evidence"]))
        self.assertEqual(result["claim_assessment"], "not_assessed")

    def test_hidden_receiving_values_cannot_replace_executed_evidence_reads(self):
        result = verify(self.raw(), [candidate_a(), candidate_b()], SOURCES - {"receipts"})
        self.assertEqual(result["status"], "review")
        self.assertFalse(result["passed"])
        self.assertEqual(result["reason"], "evidence_not_retrieved")
        self.assertEqual(result["missing_sources"], ["receipts"])
        self.assertEqual(result["candidates"], [])

    def test_missing_receipt_for_rival_blocks_false_unique_match(self):
        source = source_pack()
        source["receipts"].pop()
        rival = candidate_b()
        rival.update(received_qty=None, shortfall=None, amount_cents=None)
        result = verify(self.raw(source), [candidate_a(), rival], SOURCES)
        self.assertEqual(result["status"], "review", result)
        self.assertFalse(result["passed"])
        self.assertIn("missing_receiving_evidence", result["issues"])

    def test_omitted_zero_shortage_rival_is_a_failed_candidate_ledger(self):
        result = verify(self.raw(), [candidate_a()], SOURCES)
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "executor_candidate_ledger_mismatch")
        self.assertFalse(result["passed"])

    def test_forged_quantity_amount_or_numeric_type_cannot_pass(self):
        for field, value in (("received_qty", 84), ("amount_cents", 60000), ("shortfall", 15.0), ("unit_price_cents", True)):
            with self.subTest(field=field):
                forged = candidate_a()
                forged[field] = value
                result = verify(self.raw(), [forged, candidate_b()], SOURCES)
                self.assertFalse(result["passed"])
                self.assertEqual(result["status"], "review")

    def test_two_supported_relationships_stay_ambiguous(self):
        source = source_pack()
        source["receipts"][1]["quantity"] = "85"
        rival = candidate_b()
        rival.update(received_qty=85, shortfall=15, amount_cents=90000)
        result = verify(self.raw(source), [candidate_a(), rival], SOURCES)
        self.assertEqual(result["status"], "review")
        self.assertTrue(result["passed"])
        self.assertEqual(result["reason"], "ambiguous_supported_relationships")
        self.assertEqual(len(result["candidates"]), 2)

    def test_explicit_invoice_reference_and_recorded_each_conversion(self):
        source = source_pack()
        source["notice"]["invoice_hint"] = "INV-B"
        source["receipts"][1].update(quantity="1,020", uom="EA")
        rival = candidate_b()
        rival.update(received_qty=85, shortfall=15, amount_cents=90000)
        result = verify(self.raw(source), [rival], SOURCES | {"products"})
        self.assertEqual(result["status"], "matched", result)
        self.assertEqual(result["candidates"][0]["invoice_id"], "INV-B")
        self.assertTrue(any(r["table"] == "products" and r["raw"]["source_ref"] == "catalog:B" for r in result["evidence"]))

    def test_each_conversion_requires_retrieved_product_record_and_source_factor(self):
        source = source_pack()
        source["receipts"][0].update(quantity="1,020", uom="EA")
        result = verify(self.raw(source), [candidate_a(), candidate_b()], SOURCES)
        self.assertEqual(result["status"], "review")
        self.assertFalse(result["passed"])
        source["products"][0]["source_ref"] = None
        result = verify(self.raw(source), [candidate_a(), candidate_b()], SOURCES | {"products"})
        self.assertEqual(result["status"], "review")
        self.assertFalse(result["passed"])

    def test_duplicate_or_contradictory_receipts_do_not_get_summed(self):
        source = source_pack()
        duplicate = deepcopy(source["receipts"][0])
        duplicate["receipt_id"] = "REC-A-SECOND"
        source["receipts"].append(duplicate)
        result = verify(self.raw(source), [candidate_a(), candidate_b()], SOURCES)
        self.assertEqual(result["reason"], "conflicting_receiving_records")
        self.assertFalse(result["passed"])

    def test_source_file_or_in_memory_changes_prevent_verification(self):
        raw = self.raw()
        raw.data["notice"]["amount"] = "$1.00"
        self.assertEqual(verify(raw, [candidate_a(), candidate_b()], SOURCES)["reason"], "source_records_changed")
        raw = self.raw()
        self.path.write_text(self.path.read_text() + " ")
        self.assertEqual(verify(raw, [candidate_a(), candidate_b()], SOURCES)["reason"], "source_records_changed")

    def test_conflicting_currency_is_not_silently_converted(self):
        source = source_pack()
        source["invoice_lines"][0]["currency"] = "EUR"
        result = verify(self.raw(source), [candidate_a(), candidate_b()], SOURCES)
        self.assertEqual(result["reason"], "conflicting_source_currency")
        self.assertFalse(result["passed"])

    def test_fractional_case_quantity_and_fractional_cents_are_not_rounded(self):
        source = source_pack()
        source["receipts"][0].update(quantity="1,021", uom="EA")
        self.assertFalse(verify(self.raw(source), [candidate_a(), candidate_b()], SOURCES | {"products"})["passed"])
        source = source_pack()
        source["invoice_lines"][0]["unit_price"] = "60.001"
        self.assertFalse(verify(self.raw(source), [candidate_a(), candidate_b()], SOURCES)["passed"])


class ScriptedInvestigator:
    def __init__(self, actions, *, on_call=None):
        self.actions = iter(actions)
        self.contexts = []
        self.on_call = on_call

    def complete(self, instructions, context, schema):
        self.contexts.append(deepcopy(context))
        if self.on_call:
            self.on_call(len(self.contexts), context)
        selected = next(self.actions)
        if isinstance(selected, Exception):
            raise selected
        return Completion(selected, {"provider": "scripted_investigation_test", "live": False,
                                     "model": "none", "usage": {"input_tokens": 0, "output_tokens": 0}})


def evidence_plan(*, referenced=False, conversion=False):
    steps = [action("read_evidence", "invoices", "notice_references" if referenced else "retailer_and_amount"),
             action("read_evidence", "shipments", "candidate_orders"),
             action("read_evidence", "receipts", "shipment_product_pairs")]
    if conversion:
        steps.append(action("read_evidence", "products", "candidate_products"))
    return steps + [action("check_shortfalls"), action("verify_evidence")]


class InvestigationControllerTests(unittest.TestCase):
    def run_ai(self, case_id, actions=None, **kwargs):
        from recon.investigation.service import run_case
        provider = ScriptedInvestigator(actions or evidence_plan(), **kwargs)
        with patch("recon.investigation.service.create_provider", side_effect=AssertionError("Tests cannot initialize a live model")):
            result = run_case(load_case(case_id), provider=provider, mode="ai")
        return result, provider

    def test_selected_source_reads_narrow_two_candidates_to_one_verified_relationship(self):
        result, provider = self.run_ai("ambiguous-product")
        self.assertEqual(result["status"], "matched", result)
        self.assertEqual([x["after_count"] for x in result["trace"]], [2, 2, 2, 1, 1])
        self.assertEqual(result["candidates"][0]["invoice_line_id"], "LINE-A")
        self.assertTrue(result["verification"]["passed"])
        self.assertTrue(result["verification"]["independent"])
        self.assertEqual(result["model_calls"], 5)
        self.assertEqual(len(provider.contexts), 5)
        self.assertFalse(result["live_ai"])
        self.assertTrue(result["source_unchanged"])
        self.assertEqual({row["table"] for row in result["read_ledger"]}, SOURCES)
        self.assertEqual(result["trace"][3]["tool"], "exact_financial_constraints")
        self.assertTrue(any("100 - 85" in row["expression"] for row in result["trace"][3]["equations"]))

    def test_reference_and_unit_observations_produce_a_different_typed_method(self):
        result, provider = self.run_ai("reference-mixed-units", evidence_plan(referenced=True, conversion=True))
        self.assertEqual(result["status"], "matched", result)
        self.assertEqual(result["candidates"][0]["invoice_line_id"], "LINE-B")
        self.assertEqual(result["trace"][0]["relation"], "notice_references")
        self.assertEqual(result["trace"][0]["after_count"], 1)
        self.assertTrue(provider.contexts[3]["observation"]["product_conversion_required"])
        self.assertEqual(result["trace"][3]["source"], "products")
        self.assertTrue(any(row["operation"] == "divide_each_quantity_by_verified_case_pack" for row in result["transformations"]))
        self.assertEqual(result["model_calls"], 6)

    def test_retrieved_evidence_is_distinct_from_not_yet_computed_shortfalls(self):
        result, provider = self.run_ai("ambiguous-product")
        pending = provider.contexts[3]["observation"]
        self.assertEqual(pending["calculation_state"], "ready_to_check")
        self.assertEqual(pending["source_row_counts"]["receipts"], 2)
        self.assertEqual(pending["evidence_gaps"], [])
        self.assertNotIn("received_qty", pending["candidate_summaries"][0])
        self.assertNotIn("shortfall", pending["candidate_summaries"][0])
        checked = provider.contexts[4]["observation"]
        self.assertEqual(checked["calculation_state"], "checked")
        self.assertEqual(checked["candidate_summaries"][0]["received_qty"], 85)
        self.assertEqual(checked["candidate_summaries"][0]["shortfall"], 15)
        self.assertEqual(result["status"], "matched")

    def test_missing_receipt_blocks_match_despite_a_known_supported_shortage(self):
        result, _ = self.run_ai("missing-receipt")
        self.assertEqual(result["status"], "review", result)
        self.assertFalse(result["verification"]["passed"])
        self.assertEqual(result["candidates"], [])
        self.assertTrue(any(row["code"] == "missing_receipt" for row in result["evidence_gaps"]))

    def test_initial_context_has_no_invoice_receiving_or_hidden_label_values(self):
        result, provider = self.run_ai("ambiguous-product", [action("request_review")])
        context = provider.contexts[0]
        self.assertEqual(context["task"], "reconcile_notice")
        self.assertEqual(context["observation"]["sources_read"], [])
        self.assertEqual(context["observation"]["candidate_summaries"], [])
        self.assertNotIn("source_pack", context)
        self.assertNotIn("expected_status", json.dumps(context))
        self.assertNotIn('"85"', json.dumps(context))
        self.assertEqual(result["read_ledger"], [])
        self.assertEqual(result["status"], "review")

    def test_model_cannot_supply_answer_values_or_skip_evidence_to_verify(self):
        malicious = [{"operation": "read_evidence", "source": "invoices", "relation": "retailer_and_amount", "invoice_line_id": "LINE-A"},
                     action("verify_evidence"),
                     action("read_evidence", "receipts", "shipment_product_pairs")]
        for selected in malicious:
            with self.subTest(selected=selected):
                result, _ = self.run_ai("ambiguous-product", [selected])
                self.assertEqual(result["status"], "failed")
                self.assertEqual(result["read_ledger"], [])
                self.assertEqual(result["candidates"], [])
                self.assertFalse(result["verification"]["passed"])

    def test_provider_failure_does_not_become_review_or_fixed_policy_success(self):
        result, _ = self.run_ai("ambiguous-product", [RuntimeError("simulated unavailable provider")])
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["trace"], [])
        self.assertFalse(result["live_ai"])
        self.assertEqual(result["provider_audit"]["failed_attempts"], 1)

    def test_fixed_control_uses_same_evidence_and_verifier_with_no_model(self):
        from recon.investigation.service import run_case
        with patch("recon.investigation.service.create_provider", side_effect=AssertionError("Fixed policy must not call AI")):
            for case_id, expected in (("ambiguous-product", "matched"), ("missing-receipt", "review"), ("reference-mixed-units", "matched")):
                with self.subTest(case_id=case_id):
                    result = run_case(load_case(case_id), mode="fixed")
                    self.assertEqual(result["status"], expected, result)
                    self.assertEqual(result["model_calls"], 0)
                    self.assertFalse(result["live_ai"])
                    self.assertTrue(result["source_unchanged"])

    def test_model_mutation_of_original_records_is_a_failed_execution(self):
        from recon.investigation.service import run_case
        raw = load_case("ambiguous-product")
        def mutate(number, context):
            raw.data["receipts"][0]["quantity"] = "1"
        provider = ScriptedInvestigator(evidence_plan(), on_call=mutate)
        result = run_case(raw, provider=provider)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["reason"], "source_records_changed")
        self.assertEqual(result["trace"], [])

    def test_in_memory_pack_retains_digest_guard_and_can_be_verified(self):
        from recon.investigation.service import run_case
        pack = make_pack("ambiguous-product")
        original = deepcopy(pack)
        result = run_case(pack, provider=ScriptedInvestigator(evidence_plan()))
        self.assertEqual(result["status"], "matched", result)
        self.assertEqual(pack, original)
        self.assertTrue(result["verification"]["passed"])

    def test_source_file_disappearing_during_a_request_is_a_failed_execution(self):
        from recon.investigation.service import run_case
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "source.json"
            path.write_text(json.dumps(make_pack("ambiguous-product")))
            raw = load_pack(path)
            provider = ScriptedInvestigator(evidence_plan(), on_call=lambda number, context: path.unlink())
            result = run_case(raw, provider=provider)
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["reason"], "source_records_changed")
            self.assertEqual(result["candidates"], [])

    def test_direct_answer_control_is_not_silently_verified_or_repaired(self):
        from recon.investigation.service import run_case
        wrong_direct_answer = {"status": "matched", "invoice_line_id": "LINE-B", "shipment_id": "SHIP-B"}
        provider = ScriptedInvestigator([wrong_direct_answer])
        with patch("recon.investigation.verification.verify", side_effect=AssertionError("Do not repair the direct baseline")):
            result = run_case(load_case("ambiguous-product"), provider=provider, mode="direct")
        self.assertEqual(result["candidates"][0]["invoice_line_id"], "LINE-B")
        self.assertTrue(result["candidates"][0]["unverified"])
        self.assertFalse(result["verification"]["passed"])
        self.assertEqual(result["reason"], "unverified_direct_model_answer")
        self.assertEqual(result["model_calls"], 1)
        self.assertEqual(result["trace"], [])
        self.assertIn("source_pack", provider.contexts[0])


if __name__ == "__main__":
    unittest.main()
