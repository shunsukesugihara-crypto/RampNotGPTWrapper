"""All inference is simulated. These tests never contact a model service."""
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.ai.provider import Completion, OpenAIJSONProvider, CodexJSONProvider, create_provider, DISABLED_CODEX_FEATURES
from recon.phase2.contracts import PlanError, PlannerUnavailable

SCHEMA = {"type": "object", "additionalProperties": False,
          "properties": {"operation": {"type": "string", "enum": ["join", "verify"]}}, "required": ["operation"]}
VALUE = {"operation": "join"}


def response(value=VALUE):
    return {"status": "completed", "id": "resp_test", "usage": {"input_tokens": 10, "output_tokens": 4},
            "output": [{"type": "message", "role": "assistant", "status": "completed",
                        "content": [{"type": "output_text", "text": json.dumps(value)}]}]}


def events(value=VALUE, extra=()):
    return "\n".join(json.dumps(event) for event in [
        {"type": "thread.started", "thread_id": "thread_test"}, {"type": "turn.started"}, *extra,
        {"type": "item.completed", "item": {"type": "agent_message", "text": json.dumps(value)}},
        {"type": "turn.completed", "usage": {"input_tokens": 11, "output_tokens": 5}},
    ])


class APIProviderTests(unittest.TestCase):
    def test_strict_request_and_hashed_audit_for_injected_transport(self):
        requests = []
        def transport(payload):
            requests.append(payload)
            return response()
        provider = OpenAIJSONProvider(model="configured-model", transport=transport)
        first = provider.complete("Choose one allowed operation.", {"missing": ["quantity"]}, SCHEMA)
        second = provider.complete("Choose one allowed operation.", {"missing": ["quantity"]}, SCHEMA)
        self.assertIsInstance(first, Completion)
        self.assertEqual(first.value, VALUE)
        self.assertFalse(first.audit["live"])
        self.assertEqual(first.audit, second.audit)
        self.assertEqual(first.audit["response_id"], "resp_test")
        self.assertEqual(len(first.audit["input_hash"]), 64)
        self.assertEqual(len(first.audit["output_hash"]), 64)
        request = requests[0]
        self.assertIs(request["store"], False)
        self.assertEqual(request["text"]["format"]["schema"], SCHEMA)
        self.assertIs(request["text"]["format"]["strict"], True)
        self.assertNotIn("tools", request)

    def test_real_http_shape_is_mocked_and_key_not_in_audit(self):
        with patch.dict(os.environ, {"OPENAI_API_KEY": "secret-test-key"}, clear=True):
            with patch("urllib.request.urlopen", return_value=io.BytesIO(json.dumps(response()).encode())) as network:
                item = OpenAIJSONProvider(model="configured-model", timeout=45).complete("Choose.", {}, SCHEMA)
        sent = network.call_args.args[0]
        self.assertEqual(sent.full_url, "https://api.openai.com/v1/responses")
        self.assertEqual(sent.headers["Authorization"], "Bearer secret-test-key")
        self.assertEqual(network.call_args.kwargs["timeout"], 45)
        self.assertNotIn("secret-test-key", json.dumps(item.audit))

    def test_missing_model_or_key_never_calls_network(self):
        with patch.dict(os.environ, {}, clear=True), patch("urllib.request.urlopen") as network:
            with self.assertRaises(PlannerUnavailable):
                OpenAIJSONProvider()
            with self.assertRaises(PlannerUnavailable):
                OpenAIJSONProvider(model="configured").complete("Choose.", {}, SCHEMA)
            network.assert_not_called()

    def test_invalid_incomplete_refused_and_tool_responses_fail_closed(self):
        refusal = response()
        refusal["output"][0]["content"] = [{"type": "refusal", "refusal": "No"}]
        samples = [(response({"operation": "shell"}), PlanError),
                   (response({"operation": "join", "match": "invented-id"}), PlanError),
                   ({"status": "incomplete", "output": []}, PlannerUnavailable),
                   (refusal, PlannerUnavailable),
                   ({"status": "completed", "output": [{"type": "function_call"}]}, PlanError)]
        for sample, error in samples:
            with self.subTest(sample=sample), self.assertRaises(error):
                OpenAIJSONProvider(model="configured", transport=lambda payload: sample).complete("Choose.", {}, SCHEMA)

    def test_duplicate_keys_and_nonfinite_values_are_rejected(self):
        for text in ('{"operation":"join","operation":"verify"}', '{"operation":NaN}', '```json\n{}\n```'):
            sample = response()
            sample["output"][0]["content"][0]["text"] = text
            with self.subTest(text=text), self.assertRaises(PlanError):
                OpenAIJSONProvider(model="configured", transport=lambda payload: sample).complete("Choose.", {}, SCHEMA)

    def test_exceptions_do_not_include_provider_secrets(self):
        def transport(payload):
            raise RuntimeError("secret-test-key plus private provider response")
        with self.assertRaises(PlannerUnavailable) as caught:
            OpenAIJSONProvider(model="configured", api_key="secret-test-key", transport=transport).complete("Choose.", {}, SCHEMA)
        self.assertNotIn("secret-test-key", str(caught.exception))
        self.assertIsNone(caught.exception.__cause__)

    def test_audit_never_copies_arbitrary_metadata_text_or_keys(self):
        sample = response()
        sample["id"] = "resp_secret-test-key"
        sample["usage"] = {"secret-test-key": 1, "private_response": "private", "input_tokens": 5}
        item = OpenAIJSONProvider(model="configured", api_key="secret-test-key", transport=lambda payload: sample).complete("Choose.", {}, SCHEMA)
        self.assertNotIn("secret-test-key", json.dumps(item.audit))
        self.assertEqual(item.audit["usage"], {"input_tokens": 5})


class CLIProviderTests(unittest.TestCase):
    def run_cli(self, *, output=VALUE, event_text=None, extra=(), model=None, returncode=0, callback=None):
        requests = []
        def process(args, **kwargs):
            requests.append((args, kwargs))
            self.assertEqual(list(Path(kwargs["cwd"]).iterdir()), [])
            self.assertEqual(json.loads(Path(args[args.index("--output-schema") + 1]).read_text()), SCHEMA)
            Path(args[args.index("--output-last-message") + 1]).write_text(json.dumps(output))
            if callback:
                callback(args, kwargs)
            return subprocess.CompletedProcess(args, returncode, event_text if event_text is not None else events(output, extra), "private stderr")
        with patch.object(Path, "is_file", return_value=True), patch("os.access", return_value=True):
            completion = CodexJSONProvider(binary="/fake/codex", model=model, process_runner=process).complete("Choose.", {"count": 2}, SCHEMA)
        return completion, requests

    def test_no_tool_flags_empty_working_directory_stdin_and_audit(self):
        with patch.dict(os.environ, {"OPENAI_API_KEY": "secret-key"}, clear=True):
            result, requests = self.run_cli()
        args, options = requests[0]
        self.assertIn("--ephemeral", args)
        self.assertIn("--skip-git-repo-check", args)
        self.assertIn("--ignore-user-config", args)
        self.assertEqual(args[args.index("--sandbox") + 1], "read-only")
        disabled = {args[index + 1] for index, value in enumerate(args) if value == "--disable"}
        self.assertEqual(disabled, set(DISABLED_CODEX_FEATURES))
        self.assertIn('web_search="disabled"', args)
        self.assertIn('approval_policy="never"', args)
        self.assertNotIn("--model", args)
        self.assertFalse(any("dangerously" in arg for arg in args))
        self.assertEqual(args[-1], "-")
        self.assertIn("CONTEXT_JSON", options["input"])
        self.assertNotIn("OPENAI_API_KEY", options["env"])
        self.assertLessEqual(options["timeout"], 60)
        self.assertFalse(result.audit["live"])
        self.assertEqual(result.audit["model"], "cli_default_not_reported")
        self.assertEqual(result.audit["response_id"], "thread_test")
        self.assertEqual(result.audit["usage"]["input_tokens"], 11)

    def test_model_is_only_explicit_or_user_environment(self):
        with patch.dict(os.environ, {"CODEX_MODEL": "user-chosen"}, clear=True):
            _, requests = self.run_cli()
            self.assertEqual(requests[0][0][requests[0][0].index("--model") + 1], "user-chosen")

    def test_any_tool_or_unknown_event_rejects_otherwise_valid_json(self):
        for item_type in ("command_execution", "mcp_tool_call", "web_search", "file_change", "collab_tool_call"):
            with self.subTest(item_type=item_type), self.assertRaises(PlanError):
                self.run_cli(extra=({"type": "item.started", "item": {"type": item_type}},))
        with self.assertRaises(PlanError):
            self.run_cli(extra=({"type": "unknown.event"},))

    def test_only_exact_disabled_host_startup_diagnostic_is_permitted(self):
        warning = {"type": "item.completed", "item": {"id": "item_0", "type": "error", "message":
            "Code Mode is unavailable because code-mode host is disabled. Code mode will fail closed; "
            "enable `features.code_mode_host` and install `codex-code-mode-host`."}}
        stream = [json.loads(line) for line in events().splitlines()]
        stream.insert(1, warning)
        result, requests = self.run_cli(event_text="\n".join(json.dumps(item) for item in stream))
        self.assertEqual(result.audit["startup_warnings"], ["code_mode_disabled"])
        self.assertFalse(result.audit["tool_activity_detected"])
        args = requests[0][0]
        self.assertIn("code_mode_host", {args[index + 1] for index, flag in enumerate(args) if flag == "--disable"})
        with self.assertRaises(PlannerUnavailable):
            self.run_cli(extra=(warning,))  # The same diagnostic after turn start is not startup.

    def test_other_native_errors_and_expanded_startup_messages_are_rejected(self):
        for message in ("private unexpected error", "Code Mode is unavailable because code-mode host is disabled."):
            stream = [json.loads(line) for line in events().splitlines()]
            stream.insert(1, {"type": "item.completed", "item": {"id": "item_0", "type": "error", "message": message}})
            with self.subTest(message=message), self.assertRaises(PlannerUnavailable) as caught:
                self.run_cli(event_text="\n".join(json.dumps(item) for item in stream))
            self.assertNotIn(message, str(caught.exception))

    def test_bad_exit_and_timeout_never_fall_back(self):
        with self.assertRaises(PlannerUnavailable):
            self.run_cli(returncode=1)
        def timeout(*args, **kwargs):
            raise subprocess.TimeoutExpired("secret-command", 60, output="private prompt")
        with patch.object(Path, "is_file", return_value=True), patch("os.access", return_value=True):
            with self.assertRaises(PlannerUnavailable) as caught:
                CodexJSONProvider(binary="/fake/codex", process_runner=timeout).complete("Choose.", {}, SCHEMA)
        self.assertNotIn("secret", str(caught.exception))

    def test_incomplete_turn_and_mismatched_output_fail(self):
        with self.assertRaises(PlannerUnavailable):
            self.run_cli(event_text='{"type":"thread.started","thread_id":"test"}\n')
        with self.assertRaises(PlanError):
            self.run_cli(output={"operation": "verify"}, event_text=events(VALUE))


class FactoryTests(unittest.TestCase):
    def test_explicit_api_configuration_preferred_without_cli_fallback(self):
        with patch.dict(os.environ, {"OPENAI_API_KEY": "key", "OPENAI_MODEL": "model"}, clear=True):
            self.assertIsInstance(create_provider(), OpenAIJSONProvider)
        with patch.dict(os.environ, {}, clear=True), patch.object(Path, "is_file", return_value=True), patch("os.access", return_value=True):
            self.assertIsInstance(create_provider(), CodexJSONProvider)
        with patch.dict(os.environ, {}, clear=True), patch.object(Path, "is_file", return_value=False):
            with self.assertRaises(PlannerUnavailable):
                create_provider()

    def test_timeout_and_schema_limits_fail_before_inference(self):
        for value in (0, 61, float("inf"), True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                OpenAIJSONProvider(model="model", timeout=value)
        with patch("urllib.request.urlopen") as network:
            with self.assertRaises(PlanError):
                OpenAIJSONProvider(model="model").complete("Choose.", {}, {"type": "object", "properties": {}})
            network.assert_not_called()


if __name__ == "__main__":
    unittest.main()
