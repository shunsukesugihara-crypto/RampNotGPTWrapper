"""Nonsecret explicit settings and reviewable AI schema proposals; no live calls."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from recon.ai.provider import Completion
from recon.phase2.contracts import PlanError, PlannerUnavailable
from recon.workspace.model import ModelSettings, discover_model, suggest_mappings


class FakeProvider:
    def __init__(self, value=None, audit=None, error=None):
        self.value = {"ok": True} if value is None else value
        self.audit = {"provider": "scripted_test", "model": "fixture-model", "live": False} if audit is None else audit
        self.error = error
        self.requests = []

    def complete(self, instructions, context, schema):
        self.requests.append({"instructions": instructions, "context": deepcopy(context), "schema": deepcopy(schema)})
        if self.error:
            raise self.error
        return Completion(deepcopy(self.value), deepcopy(self.audit))


class WorkspaceModelSettingsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.binary = self.root / "codex"
        self.binary.write_text("test executable is never launched")
        self.binary.chmod(0o700)
        self.user_config = self.root / "config.toml"
        self.user_config.write_text('model = "fixture-model"\n[other]\nsecret = "DO-NOT-EXPOSE"\n')
        self.state = self.root / "state/settings.json"
        self.fake = FakeProvider()
        self.calls = []

    def tearDown(self):
        self.temp.cleanup()

    def settings(self, **kwargs):
        def factory(kind, **options):
            self.calls.append((kind, options))
            return self.fake
        return ModelSettings(self.state, provider_factory=factory, environ=kwargs.pop("environ", {}),
                             codex_config_path=self.user_config, codex_binary=self.binary, **kwargs)

    def test_local_named_model_is_explicitly_sent_but_not_claimed_verified(self):
        settings = self.settings()
        view = settings.view()
        self.assertEqual(view["model"], "fixture-model")
        self.assertEqual(view["source"], "codex_user_model_setting")
        self.assertFalse(view["model_identity_verified"])
        self.assertEqual(view["connection_status"], "untested")
        self.assertIs(settings.provider(), self.fake)
        self.assertEqual(self.calls, [("codex", {"model": "fixture-model", "timeout": 60})])

    def test_discovery_never_treats_nested_profile_model_as_global(self):
        self.user_config.write_text('[profiles.test]\nmodel="nested-only"\n')
        self.assertIsNone(discover_model({}, self.user_config)["model"])
        with self.assertRaises(PlannerUnavailable):
            self.settings().provider()

    def test_environment_model_selection_does_not_persist_api_key(self):
        settings = self.settings(environ={"OPENAI_MODEL": "fixture-api", "OPENAI_API_KEY": "DO-NOT-PERSIST"})
        self.assertEqual(settings.view()["provider"], "openai")
        self.assertEqual(settings.view()["model"], "fixture-api")
        settings.update({"provider": "openai", "model": "chosen-model"})
        self.assertNotIn("DO-NOT-PERSIST", self.state.read_text())
        self.assertNotIn("DO-NOT-EXPOSE", json.dumps(settings.view()))

    def test_unknown_or_missing_model_does_not_fall_back_to_cli_default(self):
        self.user_config.unlink()
        settings = self.settings()
        self.assertFalse(settings.view()["available"])
        self.assertIsNone(settings.view()["model"])
        with self.assertRaises(PlannerUnavailable):
            settings.provider()
        self.assertEqual(self.calls, [])

    def test_save_reload_and_model_change_clear_old_connection_result(self):
        settings = self.settings()
        result = settings.test_connection()
        self.assertTrue(result["ok"])
        self.assertFalse(result["live"])
        self.assertFalse(result["model_identity_verified"])
        self.assertEqual(self.settings().view()["connection_status"], "connected")
        settings.update({"provider": "codex", "model": "different-model"})
        reloaded = self.settings().view()
        self.assertEqual(reloaded["model"], "different-model")
        self.assertEqual(reloaded["connection_status"], "untested")

    def test_api_provider_requires_environment_key_without_inspecting_auth_files(self):
        settings = self.settings()
        settings.update({"provider": "openai", "model": "fixture-model"})
        self.assertFalse(settings.view()["available"])
        result = settings.test_connection()
        self.assertFalse(result["ok"])
        self.assertIn("OPENAI_API_KEY", result["error"])
        self.assertEqual(self.calls, [])

    def test_transport_error_is_safe_and_never_retries_other_model(self):
        self.fake.error = RuntimeError("DO-NOT-LEAK provider data")
        settings = self.settings()
        result = settings.test_connection()
        self.assertFalse(result["ok"])
        self.assertNotIn("DO-NOT-LEAK", json.dumps(result))
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(settings.view()["model"], "fixture-model")

    def test_extra_secret_fields_or_invalid_model_names_are_rejected(self):
        for value in ({"provider": "codex", "model": "valid", "api_key": "secret"},
                      {"provider": [], "model": "valid"}, {"provider": "codex", "model": "x\n--shell"},
                      {"provider": "codex", "model": ""}, {"provider": "unknown", "model": "valid"}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.settings().update(value)
        self.assertFalse(self.state.exists())

    def test_false_or_malformed_connection_reply_is_not_connected(self):
        for value in ({"ok": False}, {"ok": True, "answer": 1}):
            self.fake.value = value
            result = self.settings().test_connection()
            self.assertFalse(result["ok"])

    def test_selection_captures_provider_and_same_explicit_model(self):
        provider, snapshot = self.settings().selection()
        self.assertIs(provider, self.fake)
        self.assertEqual(snapshot["model"], self.calls[0][1]["model"])

    def test_session_api_key_is_forwarded_only_to_api_and_never_persisted(self):
        secret = "sk-unit-test-memory-only-credential"
        settings = self.settings()
        view = settings.update({"provider": "openai", "model": "fixture-api", "api_key": secret})
        self.assertTrue(view["available"])
        self.assertEqual(view["key_source"], "memory")
        self.assertNotIn(secret, json.dumps(view))
        settings.provider()
        self.assertEqual(self.calls[-1], ("openai", {"model": "fixture-api", "timeout": 60, "api_key": secret}))
        settings.test_connection()
        self.assertNotIn(secret, self.state.read_text())
        self.assertNotIn(secret, json.dumps(settings.snapshot()))
        restarted = self.settings().view()
        self.assertEqual(restarted["provider"], "openai")
        self.assertEqual(restarted["model"], "fixture-api")
        self.assertEqual(restarted["key_source"], "none")
        self.assertFalse(restarted["api_key_present"])
        self.assertFalse(restarted["available"])
        self.assertEqual(restarted["connection_status"], "untested")

    def test_blank_key_keeps_session_key_and_explicit_clear_restores_environment(self):
        session = "sk-memory-key-for-test"
        environment = "sk-environment-key-for-test"
        settings = self.settings(environ={"OPENAI_API_KEY": environment})
        settings.update({"provider": "openai", "model": "fixture-api", "api_key": session})
        settings.update({"provider": "openai", "model": "fixture-api", "api_key": ""})
        self.assertEqual(settings.view()["key_source"], "memory")
        settings.provider()
        self.assertEqual(self.calls[-1][1]["api_key"], session)
        settings.update({"provider": "openai", "model": "fixture-api", "clear_api_key": True})
        self.assertEqual(settings.view()["key_source"], "environment")
        settings.provider()
        self.assertEqual(self.calls[-1][1]["api_key"], environment)
        self.assertNotIn(session, self.state.read_text())
        self.assertNotIn(environment, self.state.read_text())

    def test_switching_to_codex_does_not_forward_an_api_credential(self):
        settings = self.settings()
        settings.update({"provider": "openai", "model": "fixture-api", "api_key": "sk-session-key-only-test"})
        settings.update({"provider": "codex", "model": "fixture-model"})
        settings.provider()
        self.assertEqual(self.calls[-1], ("codex", {"model": "fixture-model", "timeout": 60}))

    def test_invalid_key_fields_cannot_be_saved_or_echoed(self):
        for extra, provider in (({"api_key": True}, "openai"), ({"api_key": []}, "openai"),
                                ({"api_key": "sk-key\nInjected-header"}, "openai"),
                                ({"clear_api_key": "true"}, "openai"),
                                ({"api_key": "sk-new-key-only-test", "clear_api_key": True}, "openai"),
                                ({"api_key": "sk-api-key-not-for-cli"}, "codex")):
            with self.subTest(extra=extra), self.assertRaises(ValueError):
                self.settings().update({"provider": provider, "model": "fixture-model", **extra})
        self.assertFalse(self.state.exists())
        secret = "sk-key-is-not-a-model-name"
        with self.assertRaises(ValueError):
            self.settings().update({"provider": "openai", "model": secret, "api_key": secret})
        self.assertFalse(self.state.exists())

    def test_api_audit_and_errors_cannot_echo_session_key(self):
        secret = "sk-private-session-only-test"
        self.fake.audit = {"provider": "scripted_api", "model": "fixture-api", "live": False,
                           "response_id": "response-" + secret, "usage": {"input_tokens": 3},
                           "diagnostic": {secret: "echo:" + secret}}
        settings = self.settings()
        settings.update({"provider": "openai", "model": "fixture-api", "api_key": secret})
        completion = settings.provider().complete("test", {}, {})
        self.assertNotIn(secret, json.dumps(completion.audit))
        self.assertIn("[redacted]", json.dumps(completion.audit))
        receipt = settings.test_connection()
        self.assertTrue(receipt["ok"])
        self.assertNotIn(secret, json.dumps(receipt))
        self.assertNotIn(secret, self.state.read_text())
        self.fake.error = RuntimeError("Raw transport leaked " + secret)
        with self.assertRaises(PlannerUnavailable) as error:
            settings.provider().complete("test", {}, {})
        self.assertNotIn(secret, str(error.exception))
        self.assertNotIn(secret, json.dumps(settings.test_connection()))

    def test_actual_api_adapter_sends_key_in_header_and_structured_payload(self):
        secret = "sk-injected-http-only-test"
        settings = ModelSettings(self.state, environ={}, codex_config_path=self.user_config, codex_binary=self.binary)
        settings.update({"provider": "openai", "model": "fixture-api", "api_key": secret})
        captured = []
        response = {"id": "resp-unit-test", "status": "completed", "output": [
            {"type": "message", "role": "assistant", "status": "completed",
             "content": [{"type": "output_text", "text": '{"ok":true}'}]}],
             "usage": {"input_tokens": 7, "output_tokens": 3}}

        class HTTPResponse:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def read(self, limit):
                return json.dumps(response).encode()

        def transport(request, timeout):
            captured.append(request)
            return HTTPResponse()

        with patch("recon.ai.provider.urllib.request.urlopen", side_effect=transport):
            receipt = settings.test_connection()
        self.assertTrue(receipt["ok"])
        self.assertEqual(len(captured), 1)
        self.assertEqual(captured[0].get_header("Authorization"), "Bearer " + secret)
        payload = json.loads(captured[0].data)
        self.assertEqual(payload["model"], "fixture-api")
        self.assertFalse(payload["store"])
        self.assertEqual(payload["text"]["format"]["type"], "json_schema")
        self.assertNotIn(secret, captured[0].data.decode())
        self.assertNotIn(secret, self.state.read_text())

    def test_key_change_during_connection_test_cannot_certify_new_key(self):
        settings = self.settings()
        old_key, new_key = "sk-old-session-test-only", "sk-new-session-test-only"
        settings.update({"provider": "openai", "model": "fixture-api", "api_key": old_key})
        original = self.fake.complete

        def complete(*args):
            settings.update({"provider": "openai", "model": "fixture-api", "api_key": new_key})
            return original(*args)

        self.fake.complete = complete
        self.assertTrue(settings.test_connection()["ok"])
        self.assertIsNone(settings.view()["last_test"])
        self.assertEqual(settings.view()["connection_status"], "untested")

    def test_explicit_api_preference_never_falls_back_to_local_cli(self):
        settings = self.settings(environ={"RECON_PROVIDER": "openai", "OPENAI_MODEL": "fixture-api"})
        self.assertEqual(settings.view()["provider"], "openai")
        self.assertEqual(settings.view()["model"], "fixture-api")
        self.assertFalse(settings.view()["available"])
        with self.assertRaises(PlannerUnavailable):
            settings.provider()
        self.assertEqual(self.calls, [])
        missing_model = self.settings(environ={"RECON_PROVIDER": "openai"}).view()
        self.assertEqual(missing_model["provider"], "openai")
        self.assertIsNone(missing_model["model"])

    def test_explicit_cli_preference_overrides_api_environment_selection(self):
        settings = self.settings(environ={"RECON_PROVIDER": "codex", "OPENAI_MODEL": "api-model", "OPENAI_API_KEY": "sk-env-key-only-test"})
        self.assertEqual(settings.view()["provider"], "codex")
        self.assertEqual(settings.view()["model"], "fixture-model")
        settings.provider()
        self.assertNotIn("api_key", self.calls[-1][1])

    def test_invalid_provider_or_explicit_model_is_visible_without_fallback(self):
        for env in ({"RECON_PROVIDER": "unknown"}, {"RECON_PROVIDER": "openai", "OPENAI_MODEL": "invalid model"},
                    {"RECON_PROVIDER": "codex", "CODEX_MODEL": "invalid model"}):
            with self.subTest(env=env):
                view = self.settings(environ=env).view()
                self.assertFalse(view["available"])
                self.assertIsNone(view["model"])
                self.assertIsNotNone(view["error"])


class WorkspaceMappingProposalTests(unittest.TestCase):
    def documents(self):
        return [{"id": "invoice-export", "name": "customer invoice export.csv",
                 "columns": ["Invoice #", "PO", "Issued", "Item", "Units", "Unit Price", "Currency"],
                 "rows": [{"Invoice #": "00017", "PO": "P-2", "Issued": "2026-10-01", "Item": "ABC", "Units": "10", "Unit Price": "$60.00", "Currency": "USD"}],
                 "role_suggestion": "invoice_lines"}]

    def proposal(self):
        return {"mappings": [{"document_id": "invoice-export", "role": "invoices", "bindings": [
            {"field": "invoice_id", "column": "Invoice #"}, {"field": "po_id", "column": "PO"},
            {"field": "invoice_date", "column": "Issued"}, {"field": "currency", "column": "Currency"}], "notes": "Review the date format."},
            {"document_id": "invoice-export", "role": "invoice_lines", "bindings": [
                {"field": "invoice_id", "column": "Invoice #"}, {"field": "sku", "column": "Item"},
                {"field": "quantity", "column": "Units"}, {"field": "unit_price", "column": "Unit Price"},
                {"field": "currency", "column": "Currency"}, {"field": "uom", "column": None}], "notes": "The unit of measure must be supplied explicitly."}],
                "unmapped_documents": []}

    def test_one_flat_export_can_propose_multiple_roles_without_inventing_values(self):
        provider = FakeProvider(self.proposal())
        result = suggest_mappings(self.documents(), provider)
        self.assertEqual(len(result["mappings"]), 2)
        self.assertTrue(result["requires_review"])
        self.assertFalse(result["live_ai"])
        self.assertEqual(result["mappings"][1]["columns"]["uom"], None)
        self.assertTrue(all(m["defaults"] == {} for m in result["mappings"]))
        self.assertEqual(provider.requests[0]["context"]["documents"][0]["sample_rows"][0]["Invoice #"], "00017")

    def test_unknown_column_and_wrong_role_field_are_rejected(self):
        for field, column in (("invoice_id", "invented column"), ("received_qty", "Units")):
            value = self.proposal()
            value["mappings"][0]["bindings"] = [{"field": field, "column": column}]
            with self.assertRaises(PlanError):
                suggest_mappings(self.documents(), FakeProvider(value))

    def test_repeated_role_or_field_is_rejected(self):
        for variant in ("role", "field"):
            value = self.proposal()
            if variant == "role":
                value["mappings"].append(deepcopy(value["mappings"][0]))
            else:
                value["mappings"][0]["bindings"].append(deepcopy(value["mappings"][0]["bindings"][0]))
            with self.assertRaises(PlanError):
                suggest_mappings(self.documents(), FakeProvider(value))

    def test_model_cannot_return_financial_defaults_or_code(self):
        for extra in ({"defaults": {"currency": "USD"}}, {"sql": "SELECT 1"}, {"value": 900}):
            value = self.proposal()
            value["mappings"][0].update(extra)
            with self.assertRaises(PlanError):
                suggest_mappings(self.documents(), FakeProvider(value))

    def test_sample_rows_are_bounded_and_source_remains_unchanged(self):
        docs = self.documents()
        docs[0]["rows"] *= 100
        docs[0]["rows"][0]["Item"] = "a" * 1000
        before = deepcopy(docs)
        provider = FakeProvider(self.proposal())
        suggest_mappings(docs, provider)
        sent = provider.requests[0]["context"]["documents"][0]
        self.assertEqual(len(sent["sample_rows"]), 3)
        self.assertEqual(len(sent["sample_rows"][0]["Item"]), 200)
        self.assertEqual(docs, before)

    def test_unassigned_source_is_flagged_for_manual_review(self):
        value = {"mappings": [], "unmapped_documents": ["invoice-export"]}
        result = suggest_mappings(self.documents(), FakeProvider(value))
        self.assertTrue(result["requires_review"])
        self.assertEqual(result["issues"][0]["document_id"], "invoice-export")

    def test_duplicate_document_ids_and_ambiguous_headers_are_rejected(self):
        for docs in (self.documents() * 2, [{**self.documents()[0], "columns": ["A", "A"]}]):
            with self.assertRaises(ValueError):
                suggest_mappings(docs, FakeProvider(self.proposal()))


if __name__ == "__main__":
    unittest.main()
