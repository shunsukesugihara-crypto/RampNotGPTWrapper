"""Frozen labels, input comparability and actual provider boundaries."""
from copy import deepcopy
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.ai.provider import Completion
from recon.phase2.contracts import PlannerUnavailable
from recon.reconstruction.data import load_pack
from recon.reconstruction.direct import reconcile as direct
from recon.reconstruction.evaluate import assess, baseline, evaluate, load_corpus
from recon.reconstruction.fixtures import generate


class ScriptedProvider:
    """Controller test double; the direct-answer branch explicitly abstains."""
    def __init__(self):
        self.contexts = []

    def complete(self, instructions, context, schema):
        self.contexts.append(deepcopy(context))
        if "status" in schema["properties"]:
            value = {"status": "review", "lines": []}
        else:
            available = context["available_operations"]
            observation = context["observation"]
            if "normalize_source_records" in available:
                operation = "normalize_source_records"
            elif "join_financial_records" in available:
                operation = "join_financial_records"
            elif "verify_reconstruction" in available:
                operation = "verify_reconstruction"
            elif observation.get("claim_scope") == "single_line":
                operation = "check_single_line_constraints"
            elif "solve_receipt_shortfall_allocation" in available:
                operation = "solve_receipt_shortfall_allocation"
            else:
                operation = "request_review"
            value = {"operation": operation}
        return Completion(value, {"provider": "scripted_test", "live": False})


class ReconstructionEvaluationTests(unittest.TestCase):
    def corpus(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        path = Path(temp.name) / "frozen"
        generate(path)
        return path

    def raw(self, corpus, family, split="heldout"):
        _, index, labels, _ = load_corpus(corpus)
        row = next(row for row in index.values() if row["family"] == family and row["split"] == split)
        return load_pack(corpus / row["raw_path"]), labels[row["case_id"]], row

    def test_seed_freeze_repeats_exactly_and_does_not_overwrite(self):
        first, second = self.corpus(), self.corpus()
        manifest, index, labels, freeze = load_corpus(first)
        self.assertEqual(freeze, load_corpus(second)[3])
        self.assertEqual(manifest["case_count"], 30)
        self.assertEqual(manifest["split_counts"], {"development": 18, "heldout": 12})
        self.assertEqual(set(index), set(labels))
        self.assertTrue(all("heldout_missing_quantity_mixed_units" != row["family"] or row["split"] == "heldout" for row in index.values()))
        with self.assertRaises(FileExistsError):
            generate(first)

    def test_oracle_labels_exist_before_any_engine_or_normalizer_runs(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        path = Path(temp.name) / "new"
        with patch("recon.reconstruction.evaluate.normalize", side_effect=AssertionError("normalizer used for labels")):
            manifest = generate(path)
        _, index, labels, _ = load_corpus(path)
        self.assertEqual(manifest["case_count"], len(labels))
        for family, expected_count in (("unique_two_line", 1), ("ambiguous_two_line", 2), ("unknown_scope", 2)):
            key = next(row["case_id"] for row in index.values() if row["family"] == family)
            self.assertEqual(len(labels[key]["observable_valid_allocations"]), expected_count)
        for family in ("missing_conversion", "missing_receipt"):
            key = next(row["case_id"] for row in index.values() if row["family"] == family)
            self.assertFalse(labels[key]["automatic_link_permitted"])
            self.assertEqual(labels[key]["expected_status"], "review")

    def test_split_financial_numbers_are_disjoint_and_raw_units_preserved(self):
        corpus = self.corpus()
        _, index, _, _ = load_corpus(corpus)
        prices, shortages = {"development": set(), "heldout": set()}, {"development": set(), "heldout": set()}
        for row in index.values():
            raw = load_pack(corpus / row["raw_path"]).data
            prices[row["split"]].update(int(Decimal(line["unit_price"]) * 100) for line in raw["invoice_lines"])
            if raw["notice"]["short_qty"] is not None:
                shortages[row["split"]].add(int(raw["notice"]["short_qty"]))
            self.assertEqual(raw["notice"]["basis"], "whole_receipt_shortfalls")
        self.assertFalse(prices["development"] & prices["heldout"])
        self.assertFalse(shortages["development"] & shortages["heldout"])
        mixed, _, _ = self.raw(corpus, "mixed_units")
        self.assertIn("EA", {line["uom"] for line in mixed.data["receipts"]})
        self.assertTrue(any("," in line["quantity"] for line in mixed.data["receipts"]))

    def test_frozen_source_changes_are_rejected_before_any_provider_call(self):
        corpus = self.corpus()
        _, _, row = self.raw(corpus, "single_clear")
        path = corpus / row["raw_path"]
        path.write_bytes(path.read_bytes() + b" ")
        provider = ScriptedProvider()
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            evaluate(corpus, provider=provider)
        self.assertEqual(provider.contexts, [])

    def test_phase1_rejects_unrepresentable_scope_units_and_currency(self):
        corpus = self.corpus()
        raw, _, _ = self.raw(corpus, "single_clear")
        self.assertEqual(baseline(raw)["status"], "matched")
        for family in ("unique_two_line", "mixed_units", "currency_collision", "unknown_scope"):
            raw, _, _ = self.raw(corpus, family)
            result = baseline(raw)
            self.assertEqual(result["status"], "unsupported", family)
            self.assertIn("scope_detail", result)

    def test_direct_model_answer_is_not_computed_or_repaired(self):
        corpus = self.corpus()
        raw, label, _ = self.raw(corpus, "single_clear")
        seen = []
        class DirectWrongProvider:
            def complete(self, instructions, context, schema):
                seen.append(deepcopy(context))
                return Completion({"status": "matched", "lines": [{
                    "invoice_line_id": "INVENTED-LINE", "shipment_id": "INVENTED-SHIPMENT",
                    "sku": "INVENTED-SKU", "quantity": 1}]}, {"live": False})
        with patch("recon.reconstruction.evaluate.normalize", side_effect=AssertionError("direct used normalizer")):
            result = direct(raw, DirectWrongProvider())
        self.assertEqual(seen, [{"records": raw.data}])
        self.assertEqual(result["status"], "matched")
        self.assertFalse(result["financial_verification"]["performed"])
        self.assertFalse(result["live_ai"])
        score = assess(result, label)
        self.assertFalse(score["allocation_correct"])
        self.assertTrue(score["inappropriate_automatic_link"])
        self.assertFalse(score["independent_financial_verification_passed"])

    def test_direct_schema_failure_is_review_and_never_claims_financial_proof(self):
        corpus = self.corpus()
        raw, _, _ = self.raw(corpus, "single_clear")
        class InvalidProvider:
            def complete(self, *args):
                return Completion({"status": [], "lines": []}, {"live": False})
        result = direct(raw, InvalidProvider())
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["reason"], "invalid_direct_output")
        self.assertFalse(result["financial_verification"]["performed"])

    @unittest.skipUnless(importlib.util.find_spec("ortools"), "Install the solver extra for actual OR-Tools evaluation")
    def test_failed_models_are_not_credited_for_review_shaped_error_results(self):
        corpus = self.corpus()
        _, _, metadata = self.raw(corpus, "ambiguous_two_line")
        class FailedProvider:
            def complete(self, *args):
                raise PlannerUnavailable("test unavailable")
        report = evaluate(corpus, provider=FailedProvider(), case_ids=[metadata["case_id"]])
        for engine in ("ai_method", "direct_llm"):
            summary = report["summaries"][engine]
            self.assertEqual(summary["review_cases"], 1)
            self.assertEqual(summary["expected_behavior_met"], 0)
            self.assertEqual(summary["failed_model_attempts"], 1)
            self.assertEqual(summary["recorded_model_completions"], 0)
            self.assertEqual(summary["injected_model_completions"], 0)
            self.assertEqual(summary["incomplete_or_failed_evaluation_cases"], 1)
        self.assertEqual(report["summaries"]["all_tools"]["expected_behavior_met"], 1)

    @unittest.skipUnless(importlib.util.find_spec("ortools"), "Install the solver extra for actual OR-Tools evaluation")
    def test_same_raw_facts_four_engines_and_injected_runs_never_count_as_live(self):
        corpus = self.corpus()
        provider = ScriptedProvider()
        report = evaluate(corpus, provider=provider)
        self.assertEqual(report["case_count_per_engine"], 4)
        self.assertTrue(report["corpus_unchanged_after_execution"])
        self.assertFalse(report["live_ai_evaluated"])
        self.assertEqual(report["live_model_completions"], 0)
        for engine in ("all_tools", "ai_method"):
            summary = report["summaries"][engine]
            self.assertEqual(summary["status_counts"], {"matched": 3, "review": 1})
            self.assertEqual(summary["inappropriate_automatic_links"], 0)
            self.assertEqual(summary["correct_allocations"], 3)
        self.assertEqual(report["summaries"]["baseline"]["status_counts"], {"matched": 1, "unsupported": 3})
        self.assertEqual(report["common_original_baseline_inputs"]["case_count"], 1)
        self.assertEqual(report["summaries"]["direct_llm"]["review_cases"], 4)
        for row in report["cases"]:
            hashes = {engine["source_digest_before"] for engine in row["engines"].values()}
            self.assertEqual(len(hashes), 1)
            self.assertTrue(all(engine["source_digest_before"] == engine["source_digest_after"] for engine in row["engines"].values()))
        for context in provider.contexts:
            serialized = json.dumps(context)
            for field in ("observable_valid_allocations", "latent_expected_allocation", "automatic_link_permitted", "expected_status"):
                self.assertNotIn(field, serialized)

    @unittest.skipUnless(importlib.util.find_spec("ortools"), "Install the solver extra for actual OR-Tools evaluation")
    def test_frozen_complete_corpus_has_expected_control_behavior_without_model_calls(self):
        corpus = self.corpus()
        with patch("recon.reconstruction.evaluate.create_provider", side_effect=AssertionError("model requested")):
            report = evaluate(corpus, split="all", limit=None, model_runs=False)
        self.assertEqual(report["case_count_per_engine"], 30)
        self.assertEqual(report["engines"], ["baseline", "all_tools"])
        summary = report["summaries"]["all_tools"]
        self.assertEqual(summary["expected_behavior_met"], 30)
        self.assertEqual(summary["status_counts"], {"matched": 18, "review": 12})
        self.assertEqual(summary["wrong_allocations"], 0)
        self.assertEqual(report["summaries"]["baseline"]["unsupported_cases"], 27)


if __name__ == "__main__":
    unittest.main()
