"""Comparison tests use explicit scripts, never claim simulated output is AI."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.ai.compare import DEFAULT_IDS, compare
from recon.ai.provider import Completion
from recon.phase2.contracts import PlannerUnavailable


class ScriptedProvider:
    """A transparent test double driven by controller observations, not labels."""
    def __init__(self):
        self.contexts = []

    def complete(self, instructions, context, schema):
        self.contexts.append(deepcopy(context))
        available = context["available_operations"]
        observation = context["observation"]
        if not observation["source_loaded"]:
            action = "lookup_provided_references" if "lookup_provided_references" in available else "enumerate_retailer_records"
        elif observation.get("candidate_count", 0) > 1 and "compare_exact_catalog_description" in available:
            action = "compare_exact_catalog_description"
        elif "check_reported_quantity_amount" in available:
            action = "check_reported_quantity_amount"
        elif "derive_quantity_from_amount" in available:
            action = "derive_quantity_from_amount"
        elif "finish" in available:
            action = "finish"
        else:
            action = "request_review"
        return Completion(value={"operation": action}, audit={"provider": "scripted_test", "live": False})


class AIComparisonTests(unittest.TestCase):
    def test_same_records_compare_baseline_offline_and_scripted_controller(self):
        provider = ScriptedProvider()
        report = compare(provider=provider)
        self.assertEqual(report["deduction_ids"], list(DEFAULT_IDS))
        self.assertFalse(report["live_ai_evaluated"])
        self.assertFalse(report["all_ai_cases_fully_live"])
        self.assertEqual(report["live_model_completions"], 0)
        ai = report["summaries"]["ai"]
        self.assertEqual(ai["status_counts"], {"matched": 3, "review": 1})
        self.assertEqual(ai["identity_correct_automatic_links"], 3)
        self.assertEqual(ai["identity_wrong_automatic_links"], 0)
        self.assertEqual(ai["inappropriate_automatic_links"], 0)
        self.assertGreaterEqual(ai["distinct_procedure_count"], 3)
        self.assertEqual(ai["recorded_model_completions"], len(provider.contexts))
        self.assertEqual(ai["injected_model_completions"], len(provider.contexts))
        for row in report["cases"]:
            before = {record["source_hash_before"] for record in row["engines"].values()}
            self.assertEqual(before, {report["source_hash"]})
            for record in row["engines"].values():
                self.assertEqual(record["source_hash_before"], record["source_hash_after"])
        self.assertEqual(report["summaries"]["baseline"]["unsupported_input_cases"], 1)
        self.assertEqual(report["summaries"]["baseline"]["status_counts"], {"matched": 1, "review": 2, "unsupported": 1})
        common = report["common_baseline_input_cases"]
        self.assertEqual(common["case_count"], 3)
        self.assertEqual(common["summaries"]["baseline"]["automatic_links"], 1)
        self.assertEqual(common["summaries"]["ai"]["automatic_links"], 2)

    def test_contexts_never_receive_labels_or_match_identifiers(self):
        provider = ScriptedProvider()
        compare(provider=provider)
        serialized = json.dumps(provider.contexts)
        for forbidden in ("true_invoice_line_id", "true_shipment_id", "expected_links", "automatic_link_permitted",
                          "LINE-ABC-A", "SHP-ABC-A", "D-DEMO-PO", "evaluation_label"):
            self.assertNotIn(forbidden, serialized)
        self.assertTrue(all(not context["observation"]["source_loaded"]
                            for context in provider.contexts if not context["history"]))

    def test_bad_model_action_is_review_and_is_not_repaired_by_offline_control(self):
        class BadProvider:
            def complete(self, *args):
                return Completion(value={"operation": "guess_invoice"}, audit={"live": False})
        report = compare(provider=BadProvider(), deduction_ids=["D-DEMO-PO"])
        case = report["cases"][0]["engines"]
        self.assertEqual(case["ai"]["result"]["reason"], "invalid_model_action")
        self.assertEqual(case["ai"]["result"]["status"], "review")
        self.assertEqual(case["phase2_offline"]["result"]["status"], "matched")
        self.assertEqual(case["ai"]["actual_actions"], [])
        self.assertEqual(report["summaries"]["ai"]["model_call_attempts"], 1)
        self.assertEqual(report["summaries"]["ai"]["injected_model_completions"], 0)
        self.assertEqual(report["summaries"]["ai"]["unverified_model_completions"], 1)

    def test_failed_provider_attempt_is_not_a_completed_or_injected_response(self):
        class FailedProvider:
            def complete(self, *args):
                raise PlannerUnavailable("test transport failed")
        report = compare(provider=FailedProvider(), deduction_ids=["D-DEMO-PO"])
        summary = report["summaries"]["ai"]
        self.assertEqual(summary["model_call_attempts"], 1)
        self.assertEqual(summary["failed_model_attempts"], 1)
        self.assertEqual(summary["recorded_model_completions"], 0)
        self.assertEqual(summary["injected_model_completions"], 0)
        self.assertEqual(summary["live_model_completions"], 0)
        self.assertEqual(summary["unverified_model_completions"], 0)
        self.assertFalse(report["live_ai_evaluated"])

    def test_invalid_provider_return_is_an_unverified_attempt_not_injected_completion(self):
        class MalformedProvider:
            def complete(self, *args):
                return object()
        report = compare(provider=MalformedProvider(), deduction_ids=["D-DEMO-PO"])
        summary = report["summaries"]["ai"]
        self.assertEqual(summary["model_call_attempts"], 1)
        self.assertEqual(summary["failed_model_attempts"], 0)
        self.assertEqual(summary["unverified_model_attempts"], 1)
        self.assertEqual(summary["recorded_model_completions"], 0)
        self.assertEqual(summary["injected_model_completions"], 0)
        self.assertEqual(summary["live_model_completions"], 0)

    def test_missing_provider_still_reports_controls_without_simulated_ai(self):
        with patch("recon.ai.compare.create_provider", side_effect=PlannerUnavailable("no provider")):
            report = compare(deduction_ids=["D-DEMO-PO"])
        self.assertEqual(report["provider_initialization_error"], "PlannerUnavailable")
        self.assertEqual(report["summaries"]["ai"]["model_call_attempts"], 0)
        self.assertEqual(report["summaries"]["ai"]["distinct_procedure_count"], 0)
        self.assertFalse(report["live_ai_evaluated"])
        self.assertEqual(report["cases"][0]["engines"]["ai"]["result"]["reason"], "planner_unavailable")
        self.assertEqual(report["cases"][0]["engines"]["baseline"]["result"]["status"], "matched")

    def test_missing_amount_is_review_and_baseline_input_is_unsupported(self):
        report = compare(provider=ScriptedProvider(), deduction_ids=["D-P2-NO-AMOUNT"])
        case = report["cases"][0]["engines"]
        self.assertEqual(case["ai"]["result"]["status"], "review")
        self.assertEqual(case["baseline"]["result"]["status"], "unsupported")
        self.assertEqual(report["common_baseline_input_cases"]["case_count"], 0)
        self.assertIsNone(report["summaries"]["ai"]["automatic_identity_precision"])

    def test_repeated_ids_cannot_inflate_sample_size(self):
        with self.assertRaisesRegex(ValueError, "distinct"):
            compare(provider=ScriptedProvider(), deduction_ids=["D-DEMO-PO", "D-DEMO-PO"])
        with self.assertRaisesRegex(ValueError, "Unknown deduction"):
            compare(provider=ScriptedProvider(), deduction_ids=["DOES-NOT-EXIST"])

    def test_a_lucky_ambiguous_identity_is_still_an_inappropriate_automatic_link(self):
        # Evaluation must not reward a guessed identity when the authored
        # visible evidence cannot authorize an automatic link.
        forged = {"status": "matched", "candidates": [
            {"invoice_line_id": "LINE-ABC-A", "shipment_id": "SHP-ABC-A"}]}
        with patch("recon.ai.compare.ai_reconcile", return_value=forged):
            report = compare(provider=ScriptedProvider(), deduction_ids=["D-DEMO-AMBIG"])
        summary = report["summaries"]["ai"]
        self.assertEqual(summary["identity_correct_automatic_links"], 1)
        self.assertEqual(summary["identity_wrong_automatic_links"], 0)
        self.assertEqual(summary["inappropriate_automatic_links"], 1)

    def test_a_wrong_identity_is_counted_separately_from_review(self):
        forged = {"status": "matched", "candidates": [
            {"invoice_line_id": "WRONG-LINE", "shipment_id": "WRONG-SHIPMENT"}]}
        with patch("recon.ai.compare.ai_reconcile", return_value=forged):
            report = compare(provider=ScriptedProvider(), deduction_ids=["D-DEMO-PO"])
        summary = report["summaries"]["ai"]
        self.assertEqual(summary["identity_wrong_automatic_links"], 1)
        self.assertEqual(summary["inappropriate_automatic_links"], 1)
        self.assertEqual(summary["review_cases"], 0)


if __name__ == "__main__":
    unittest.main()
