"""Separate label-based comparison tests; production planning never sees labels."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.phase2.compare import _summarize, build_challenges, compare
from recon.phase2.storage import load_data


class ComparisonTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = compare(ROOT / "data", ROOT / "evaluation" / "ground_truth.csv")
        cls.challenges = {row["deduction_id"]: row for row in cls.report["synthetic_challenges"]["applicability"]}

    def test_original_35_cases_are_a_fair_unchanged_comparison(self):
        shared = self.report["original_fixture"]
        self.assertEqual(shared["case_count"], 35)
        self.assertEqual(shared["baseline"]["correct_automatic_links"], 24)
        self.assertEqual(shared["baseline"]["incorrect_automatic_links"], 0)
        self.assertEqual(shared["baseline"]["unsupported_cases"], 0)
        self.assertEqual(shared["phase2"]["incorrect_automatic_links"], 0)
        self.assertEqual(shared["phase2"]["unsupported_cases"], 0)
        self.assertAlmostEqual(shared["baseline"]["automatic_link_coverage"], 24 / 35)

    def test_all_synthetic_expectations_hold_without_false_automatic_links(self):
        suite = self.report["synthetic_challenges"]
        self.assertEqual(suite["case_count"], 8)
        self.assertTrue(suite["all_expectations_met"], suite["applicability"])
        self.assertEqual(suite["phase2"]["incorrect_automatic_links"], 0)
        self.assertEqual(suite["baseline"]["incorrect_automatic_links"], 0)

    def test_baseline_missing_required_fields_are_unsupported_not_review(self):
        for key, field in (("D-P2-MISSING-QTY", "short_qty"),
                           ("D-P2-NO-RECEIPT", "short_qty"),
                           ("D-P2-NO-AMOUNT", "amount_cents")):
            with self.subTest(key=key):
                row = self.challenges[key]
                self.assertFalse(row["baseline_supported"])
                self.assertEqual(row["baseline"]["status"], "unsupported")
                self.assertIn(field, row["baseline"]["missing_required_fields"])
        suite = self.report["synthetic_challenges"]
        self.assertEqual(suite["unsupported_baseline"], 3)
        self.assertEqual(suite["baseline"]["supported_cases"], 5)
        self.assertEqual(suite["baseline"]["abstention_count"], 3)

    def test_exact_text_resolves_ambiguity_but_fuzzy_and_generic_text_do_not(self):
        exact = self.challenges["D-P2-EXACT-TEXT"]
        self.assertEqual(exact["baseline"]["status"], "review")
        self.assertEqual(exact["phase2"]["status"], "matched")
        self.assertTrue(exact["phase2"]["automatic_link_correct"])
        for key in ("D-P2-GENERIC", "D-P2-FUZZY"):
            self.assertEqual(self.challenges[key]["phase2"]["status"], "review")

    def test_derived_quantity_has_explicit_independent_expected_value(self):
        result = self.challenges["D-P2-MISSING-QTY"]["phase2"]
        self.assertEqual(result["status"], "matched")
        self.assertEqual(result["candidates"][0]["derived_short_qty"], 15)
        self.assertEqual(result["candidates"][0]["invoice_line_id"], "LINE-P2-MISSING-QTY-A")

    def test_claim_disagreement_does_not_erase_a_known_transaction_link(self):
        row = self.challenges["D-P2-CONFLICT"]
        self.assertEqual(row["phase2"]["status"], "matched")
        self.assertEqual(row["phase2"]["claim_assessment"],
                         "receiving_records_do_not_support_claimed_quantity")

    def test_challenge_labels_are_not_added_to_business_database(self):
        conn = load_data(ROOT / "data")
        try:
            before = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            build_challenges(conn)
            after = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            self.assertEqual(after, before)
            self.assertNotIn("ground_truth", after)
            missing = conn.execute("SELECT short_qty FROM deductions WHERE deduction_id='D-P2-MISSING-QTY'").fetchone()
            self.assertIsNone(missing[0])
        finally:
            conn.close()

    def test_metric_counts_wrong_links_and_unsupported_inputs_separately(self):
        labels = {"D": {"true_invoice_line_id": "LINE-A", "true_shipment_id": "SHIP-A"},
                  "U": {"true_invoice_line_id": "LINE-U", "true_shipment_id": "SHIP-U"}}
        summary = _summarize([
            {"deduction_id": "D", "status": "matched", "candidates": [
                {"invoice_line_id": "WRONG", "shipment_id": "SHIP-A"}]},
            {"deduction_id": "U", "status": "unsupported", "candidates": []},
        ], labels)
        self.assertEqual(summary["incorrect_automatic_links"], 1)
        self.assertEqual(summary["correct_automatic_links"], 0)
        self.assertEqual(summary["automatic_link_precision"], 0)
        self.assertEqual(summary["automatic_link_coverage"], 0.5)
        self.assertEqual(summary["automatic_link_coverage_supported_cases"], 1)
        self.assertEqual(summary["abstention_count"], 0)

    def test_no_automatic_links_means_precision_is_unmeasured(self):
        result = {"deduction_id": "D", "status": "review", "candidates": []}
        labels = {"D": {"true_invoice_line_id": "LINE", "true_shipment_id": "SHIP"}}
        self.assertIsNone(_summarize([result], labels)["automatic_link_precision"])

    def test_report_does_not_describe_an_offline_policy_as_live_ai(self):
        self.assertEqual(self.report["planner"], "offline_policy")
        self.assertFalse(self.report["live_ai_evaluated"])
        self.assertIn("synthetic", self.report["dataset"].lower())

    def test_cli_writes_valid_report(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "comparison.json"
            completed = subprocess.run(
                [sys.executable, "-m", "recon.phase2.compare", "--data", str(ROOT / "data"),
                 "--truth", str(ROOT / "evaluation" / "ground_truth.csv"), "--output", str(target)],
                cwd=ROOT, capture_output=True, text=True,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            report = json.loads(target.read_text(encoding="utf-8"))
            self.assertEqual(report["original_fixture"]["case_count"], 35)
            self.assertTrue(report["synthetic_challenges"]["all_expectations_met"])


if __name__ == "__main__":
    unittest.main()
