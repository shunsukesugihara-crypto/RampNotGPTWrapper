from pathlib import Path
import tempfile
import unittest

from recon.workspace.environment import load_environment


class WorkspaceEnvironmentTests(unittest.TestCase):
    def test_missing_file_needs_no_credentials_and_changes_nothing(self):
        env = {}
        result = load_environment("/not/a/real/env/file", env)
        self.assertFalse(result["loaded"])
        self.assertEqual(env, {})

    def test_loads_only_known_server_settings_without_overwriting_process_environment(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / ".env"
            path.write_text('# local only\nRECON_PROVIDER=openai\nOPENAI_MODEL="explicit-model"\nOPENAI_API_KEY=example-local-only # do not publish\n')
            env = {"OPENAI_MODEL": "process-model"}
            result = load_environment(path, env)
            self.assertEqual(env["OPENAI_MODEL"], "process-model")
            self.assertEqual(env["OPENAI_API_KEY"], "example-local-only")
            self.assertNotIn("example-local-only", str(result))

    def test_does_not_execute_shell_expansion(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / ".env"
            path.write_text('OPENAI_API_KEY="$(nothing-is-executed)"\n')
            env = {}
            load_environment(path, env)
            self.assertEqual(env["OPENAI_API_KEY"], "$(nothing-is-executed)")

    def test_invalid_lines_cannot_override_unrelated_system_settings_or_leak_values(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / ".env"
            for text in ('HOME=secret-sentinel', 'OPENAI_MODEL="unclosed-secret', 'OPENAI_MODEL=one\nOPENAI_MODEL=two'):
                path.write_text(text)
                with self.subTest(text=text), self.assertRaises(ValueError) as error:
                    load_environment(path, {})
                self.assertNotIn("secret", str(error.exception))
