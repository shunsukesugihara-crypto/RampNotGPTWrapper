"""Imported user records, persistent batch execution and cancellation boundaries.

These sources are authored independently of the demonstration catalog. Tests
exercise the actual CSV importer, mapping builder, financial engines and store.
Every model response is explicitly injected; no live model calls are made.
"""
from copy import deepcopy
import base64
import csv
from datetime import datetime, timezone
import io
import json
from pathlib import Path
from threading import Event
import tempfile
import time
import unittest
import uuid

from recon.ai.provider import Completion
from recon.workspace.ingestion import build_pack, inspect_files
from recon.workspace.jobs import JobManager, results_csv
from recon.workspace.store import Store


def source_tables():
    tables = {
        "notice": [
            {"deduction_id": "ADJ-C104", "retailer": "Harbor Foods", "notice_date": "2026-09-18", "amount": "$150.00", "currency": "USD", "short_qty": "4", "uom": "CS", "scope": "single_line", "basis": "whole_receipt_shortfalls", "invoice_hint": "BILL-X7", "po_hint": "", "sku_hint": "", "description": "Warehouse shortage"},
            {"deduction_id": "ADJ-C205", "retailer": "Harbor Foods", "notice_date": "2026-09-18", "amount": "$62.50", "currency": "USD", "short_qty": "5", "uom": "CS", "scope": "single_line", "basis": "whole_receipt_shortfalls", "invoice_hint": "BILL-Y8", "po_hint": "", "sku_hint": "", "description": "Second shipment discrepancy"}],
        "products": [
            {"sku": "P-ALMOND", "description": "Almond snack carton", "case_pack": "6", "source_ref": "vendor-catalog#almond"},
            {"sku": "P-PASTA", "description": "Pasta carton", "case_pack": "8", "source_ref": "vendor-catalog#pasta"}],
        "purchase_orders": [
            {"po_id": "ORD-701", "retailer": "Harbor Foods", "order_date": "2026-09-01"},
            {"po_id": "ORD-702", "retailer": "Harbor Foods", "order_date": "2026-09-01"}],
        "invoices": [
            {"invoice_id": "BILL-X7", "po_id": "ORD-701", "invoice_date": "2026-09-03", "currency": "USD"},
            {"invoice_id": "BILL-Y8", "po_id": "ORD-702", "invoice_date": "2026-09-03", "currency": "USD"}],
        "invoice_lines": [
            {"invoice_line_id": "ITEM-X71", "invoice_id": "BILL-X7", "sku": "P-ALMOND", "quantity": "20", "uom": "CS", "unit_price": "37.50", "price_uom": "CS", "currency": "USD"},
            {"invoice_line_id": "ITEM-Y81", "invoice_id": "BILL-Y8", "sku": "P-PASTA", "quantity": "50", "uom": "CS", "unit_price": "12.50", "price_uom": "CS", "currency": "USD"}],
        "shipments": [
            {"shipment_id": "DELIV-701", "po_id": "ORD-701", "ship_date": "2026-09-04"},
            {"shipment_id": "DELIV-702", "po_id": "ORD-702", "ship_date": "2026-09-04"}],
        "shipment_lines": [
            {"shipment_id": "DELIV-701", "sku": "P-ALMOND", "quantity": "20", "uom": "CS"},
            {"shipment_id": "DELIV-702", "sku": "P-PASTA", "quantity": "50", "uom": "CS"}],
        "receipts": [
            {"receipt_id": "WH-701", "shipment_id": "DELIV-701", "sku": "P-ALMOND", "quantity": "16", "uom": "CS", "receipt_date": "2026-09-06"},
            {"receipt_id": "WH-702", "shipment_id": "DELIV-702", "sku": "P-PASTA", "quantity": "45", "uom": "CS", "receipt_date": "2026-09-06"}],
    }
    return tables


def import_workspace(tables=None):
    files = []
    tables = source_tables() if tables is None else tables
    for role, rows in tables.items():
        if not rows:
            continue
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
        files.append({"name": role + ".csv", "content_base64": base64.b64encode(stream.getvalue().encode()).decode()})
    inspected = inspect_files(files)
    documents = inspected["documents"]
    mappings = [{"document_id": d["id"], "role": Path(d["name"]).stem,
                 "columns": {column: column for column in d["columns"]}, "defaults": {}} for d in documents]
    built = build_pack(documents, mappings)
    return {"id": str(uuid.uuid4()), "name": "Harbor September adjustments", "created_at": datetime.now(timezone.utc).isoformat(),
            "documents": documents, "mappings": mappings, "built": built}


class ScriptedProvider:
    def __init__(self, *, blocked=False):
        self.model = "explicit-fixture-model"
        self.requests = []
        self.entered, self.release = Event(), Event()
        if not blocked:
            self.release.set()

    def complete(self, instructions, context, schema):
        self.requests.append(deepcopy(context))
        self.entered.set()
        if not self.release.wait(5):
            raise RuntimeError("Test model gate timed out")
        if "available_actions" in context:
            choices = context["available_actions"]
            selected = next((a for a in choices if a.get("relation") == "notice_references"),
                            next(a for a in choices if a["operation"] != "request_review"))
        else:
            choices = context["available_operations"]
            operation = next(op for op in ("normalize_source_records", "join_financial_records", "solve_receipt_shortfall_allocation", "check_single_line_constraints", "verify_reconstruction") if op in choices)
            selected = {"operation": operation}
        return Completion(deepcopy(selected), {"provider": "injected_workspace_test", "model": self.model, "live": False})


class FakeModels:
    def __init__(self, provider=None):
        self.fake = provider or ScriptedProvider()
        self.provider_requests = 0
        self.selection_requests = 0

    def view(self):
        return {"provider": "codex", "model": self.fake.model, "available": True,
                "model_identity_verified": False, "connection_status": "untested"}

    def provider(self):
        self.provider_requests += 1
        return self.fake

    def selection(self):
        self.selection_requests += 1
        return self.provider(), self.view()


class WorkspaceJobTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / "store")
        self.models = FakeModels()
        self.manager = JobManager(self.store, self.models)

    def tearDown(self):
        for event in list(self.manager.cancellations.values()):
            event.set()
        self.models.fake.release.set()
        deadline = time.monotonic() + 3
        while self.manager.active and time.monotonic() < deadline:
            time.sleep(.01)
        self.temp.cleanup()

    def finish(self, job_id, timeout=5):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            job = self.store.get("jobs", job_id)
            if job["status"] in {"complete", "cancelled", "failed", "interrupted"}:
                return job
            time.sleep(.01)
        self.fail("The batch failed to reach a terminal state")

    def workspace(self, tables=None):
        workspace = import_workspace(tables)
        self.assertTrue(workspace["built"]["ready"], workspace["built"]["issues"])
        self.store.save("workspaces", workspace)
        return workspace

    def test_user_csv_batch_matches_distinct_deductions_and_preserves_source_cells(self):
        workspace = self.workspace()
        before = deepcopy(workspace)
        job = self.finish(self.manager.start(workspace, "fixed")["id"])
        self.assertEqual(job["status"], "complete")
        self.assertEqual(job["completed"], 2)
        self.assertEqual([(r["deduction_id"], r["status"]) for r in job["results"]], [("ADJ-C104", "matched"), ("ADJ-C205", "matched")])
        self.assertEqual([r["result"]["candidates"][0]["invoice_line_id"] for r in job["results"]], ["ITEM-X71", "ITEM-Y81"])
        self.assertEqual([r["result"]["candidates"][0]["amount_cents"] for r in job["results"]], [15000, 6250])
        self.assertTrue(all(r["result"]["verification"]["passed"] for r in job["results"]))
        reference = job["results"][0]["import_provenance_ref"]
        self.assertEqual(reference, {"workspace_id": workspace["id"], "section": "built.provenance"})
        preserved = self.store.get("workspaces", reference["workspace_id"])["built"]["provenance"]
        self.assertTrue(any(p["raw"] == "37.50" and p["file"] == "invoice_lines.csv" for p in preserved))
        self.assertEqual(workspace, before)
        self.assertEqual(self.models.provider_requests, 0)
        self.assertEqual(self.models.fake.requests, [])

    def test_uploaded_missing_receipt_is_reviewed_without_losing_other_results(self):
        tables = source_tables()
        tables["receipts"].pop()
        job = self.finish(self.manager.start(self.workspace(tables), "fixed")["id"])
        self.assertEqual([r["status"] for r in job["results"]], ["matched", "review"])
        self.assertEqual(job["results"][1]["result"]["candidates"], [])
        self.assertFalse(job["results"][1]["result"]["verification"]["passed"])

    def test_batch_downgrades_both_deductions_that_reuse_one_whole_receiving_shortfall(self):
        tables = source_tables()
        duplicate = deepcopy(tables["notice"][0])
        duplicate["deduction_id"] = "ADJ-REPEATED-SHORTAGE"
        tables["notice"].append(duplicate)
        job = self.finish(self.manager.start(self.workspace(tables), "fixed")["id"])
        self.assertEqual([r["status"] for r in job["results"]], ["review", "matched", "review"])
        for index in (0, 2):
            result = job["results"][index]["result"]
            self.assertEqual(result["reason"], "shared_shortfall_across_deductions")
            self.assertTrue(result["verification"]["passed"])
            self.assertFalse(result["verification"]["batch_consistency_passed"])
            self.assertEqual(result["candidates"][0]["invoice_line_id"], "ITEM-X71")
        finished = [event for event in job["progress"] if event["type"] == "deduction_finished"]
        self.assertEqual(finished[-1]["status"], "review")
        conflicts = [event for event in job["progress"] if event["type"] == "batch_conflict"]
        self.assertEqual({event["deduction_id"] for event in conflicts}, {"ADJ-C104", "ADJ-REPEATED-SHORTAGE"})
        self.assertTrue(all(event["previous_status"] == "matched" and event["status"] == "review" and event["conflicts"] for event in conflicts))

    def test_execution_log_has_completed_tools_for_each_deduction_and_original_source_rows(self):
        job = self.finish(self.manager.start(self.workspace(), "ai")["id"])
        tools = [event for event in job["progress"] if event["type"] == "tool_observation"]
        self.assertEqual(len(tools), 10)
        for deduction in ("ADJ-C104", "ADJ-C205"):
            selected = [event for event in tools if event["deduction_id"] == deduction]
            self.assertEqual(len(selected), 5)
            self.assertEqual(selected[-1]["operation"], "verify_evidence")
            self.assertTrue(all(event.get("at") and event["status"] == "completed" for event in selected))
        second = job["results"][1]["source_provenance"]
        price = next(cell for cell in second if cell["table"] == "invoice_lines" and cell["field"] == "unit_price")
        self.assertEqual(price["source_row"], 3)
        self.assertEqual(price["raw"], "12.50")

    def test_actual_ai_controller_uses_injected_provider_and_snapshot_is_saved(self):
        job = self.finish(self.manager.start(self.workspace(), "ai")["id"])
        self.assertEqual([r["status"] for r in job["results"]], ["matched", "matched"])
        self.assertEqual(job["provider"], "codex")
        self.assertEqual(job["model"], self.models.fake.model)
        self.assertEqual(job["model_configuration"]["model"], self.models.fake.model)
        self.assertFalse(job["model_configuration"]["model_identity_verified"])
        self.assertTrue(self.models.fake.requests)
        self.assertFalse(any(r["result"]["live_ai"] for r in job["results"]))
        self.assertTrue(any(p["type"] == "model_action" for p in job["progress"]))
        self.assertTrue(all(r["result"]["data_kind"] == "user_uploaded" for r in job["results"]))

    def test_job_configuration_is_captured_atomically_with_selected_provider(self):
        class SwitchingModels(FakeModels):
            def view(self):
                return {"provider": "codex", "model": "stale-before-selection", "available": True}

            def selection(self):
                self.selection_requests += 1
                return self.provider(), {"provider": "codex", "model": self.fake.model, "available": True}

        models = SwitchingModels()
        manager = JobManager(self.store, models)
        job = self.finish(manager.start(self.workspace(), "ai")["id"])
        self.assertEqual(job["model"], models.fake.model)
        self.assertEqual(models.selection_requests, 1)

    def test_cancel_during_model_request_accepts_no_in_progress_financial_result(self):
        self.models.fake.release.clear()
        started = self.manager.start(self.workspace(), "ai")
        self.assertTrue(self.models.fake.entered.wait(2))
        self.manager.cancel(started["id"])
        self.models.fake.release.set()
        job = self.finish(started["id"])
        self.assertEqual(job["status"], "cancelled")
        self.assertEqual(job["completed"], 0)
        self.assertEqual(job["results"], [])
        self.assertEqual(len(self.models.fake.requests), 1)
        self.assertTrue(any(p["type"] == "cancelled_current" for p in job["progress"]))
        self.assertEqual(sum(p["type"] == "deduction_started" for p in job["progress"]), 1)

    def test_a_second_batch_cannot_run_over_an_active_batch(self):
        self.models.fake.release.clear()
        workspace = self.workspace()
        first = self.manager.start(workspace, "ai")
        self.assertTrue(self.models.fake.entered.wait(2))
        with self.assertRaisesRegex(ValueError, "Another batch"):
            self.manager.start(workspace, "fixed")
        self.manager.cancel(first["id"])
        self.models.fake.release.set()
        self.assertEqual(self.finish(first["id"])["status"], "cancelled")

    def test_completed_job_and_workspace_survive_store_and_manager_restart(self):
        workspace = self.workspace()
        complete = self.finish(self.manager.start(workspace, "fixed")["id"])
        reopened = Store(self.store.root)
        JobManager(reopened, FakeModels())
        self.assertEqual(reopened.get("workspaces", workspace["id"])["built"], workspace["built"])
        self.assertEqual(reopened.get("jobs", complete["id"])["results"], complete["results"])
        self.assertEqual(reopened.get("jobs", complete["id"])["status"], "complete")

    def test_interrupted_jobs_are_visible_and_never_silently_resumed(self):
        job_id = str(uuid.uuid4())
        self.store.save("jobs", {"id": job_id, "status": "running", "created_at": "2026-09-19T00:00:00Z", "results": [{"deduction_id": "finished-row", "status": "review"}], "completed": 1})
        models = FakeModels()
        JobManager(Store(self.store.root), models)
        recovered = self.store.get("jobs", job_id)
        self.assertEqual(recovered["status"], "interrupted")
        self.assertEqual(recovered["completed"], 1)
        self.assertEqual(models.provider_requests, 0)
        self.assertIn("restarted", recovered["error"])

    def test_multi_line_uploaded_notice_runs_real_ortools_allocation(self):
        tables = source_tables()
        tables["notice"] = [{**tables["notice"][0], "deduction_id": "ADJ-COMBINE-77", "amount": "112.50", "short_qty": "5", "scope": "multi_line", "invoice_hint": "", "description": "Combined recorded shortages"}]
        tables["purchase_orders"] = [tables["purchase_orders"][0]]
        tables["invoices"] = [tables["invoices"][0]]
        tables["invoice_lines"][1]["invoice_id"] = "BILL-X7"
        tables["shipments"] = [tables["shipments"][0]]
        tables["shipment_lines"][1]["shipment_id"] = "DELIV-701"
        tables["receipts"][0]["quantity"] = "18"
        tables["receipts"][1].update(shipment_id="DELIV-701", quantity="47")
        job = self.finish(self.manager.start(self.workspace(tables), "fixed")["id"])
        result = job["results"][0]["result"]
        self.assertEqual(result["status"], "matched", result)
        self.assertEqual(result["engine"], "all_tools_control")
        search = next(x for x in result["trace"] if x["operation"] == "solve_receipt_shortfall_allocation")
        self.assertEqual(search["tool"], "ortools_cp_sat")
        self.assertTrue(search["complete"])
        lines = result["candidates"][0]["lines"]
        self.assertEqual({r["invoice_line_id"] for r in lines}, {"ITEM-X71", "ITEM-Y81"})
        self.assertEqual(sum(r["amount_cents"] for r in lines), 11250)
        self.assertEqual(sum(r["quantity"] for r in lines), 5)
        self.assertTrue(result["verification"]["passed"])
        self.assertEqual(self.models.provider_requests, 0)

    def test_unconfirmed_or_overlarge_batches_do_not_start(self):
        workspace = self.workspace()
        workspace["built"]["ready"] = False
        with self.assertRaisesRegex(ValueError, "mapping"):
            self.manager.start(workspace, "fixed")
        workspace["built"]["ready"] = True
        workspace["built"]["notices"] *= 51
        with self.assertRaisesRegex(ValueError, "100"):
            self.manager.start(workspace, "fixed")
        self.assertEqual(self.store.list("jobs"), [])

    def test_csv_export_escapes_formula_cells_and_keeps_plain_values(self):
        job = {"provider": "+provider", "model": "@model", "results": [
            {"deduction_id": "=1+1", "status": "matched", "amount": "150.00", "currency": "USD", "reason": "@SUM(1)",
             "result": {"candidates": [{"invoice_line_id": "-line"}], "verification": {"passed": True}}}]}
        rows = list(csv.DictReader(io.StringIO(results_csv(job).decode("utf-8-sig"))))
        self.assertEqual(rows[0]["deduction_id"], "'=1+1")
        self.assertEqual(rows[0]["reason"], "'@SUM(1)")
        self.assertEqual(rows[0]["invoice_lines"], "'-line")
        self.assertEqual(rows[0]["provider"], "'+provider")
        self.assertEqual(rows[0]["model"], "'@model")
        self.assertEqual(rows[0]["amount"], "150.00")

    def test_saved_identifiers_cannot_escape_workspace_directories(self):
        for item_id in ("../secret", "/tmp/other", "not-a-uuid", 1):
            with self.subTest(item_id=item_id), self.assertRaises(ValueError):
                self.store.get("jobs", item_id)


if __name__ == "__main__":
    unittest.main()
