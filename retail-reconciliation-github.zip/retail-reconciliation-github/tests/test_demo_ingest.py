"""CSV adapter/audit checks; the committed demo remains derived synthetic data."""
from copy import deepcopy
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from recon.demo.fixtures import build_demo_corpus
from recon.demo.ingest import ALIASES, FILES, audit_bundle, import_bundle
from recon.reconstruction.evaluate import load_corpus


class DemoIngestTests(unittest.TestCase):
    def setUp(self):
        self.corpus = ROOT / "evaluation/demo_messy"
        self.manifest, self.index, _, _ = load_corpus(self.corpus)
        self.metadata = next(row for row in self.index.values() if row["family"] == "mixed_units")
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.bundle = Path(self.directory.name) / "bundle"
        shutil.copytree(self.corpus / self.metadata["source_bundle_path"], self.bundle)

    def read_csv(self, table):
        with (self.bundle / FILES[table]).open(newline="", encoding="utf-8-sig") as stream:
            return list(csv.reader(stream))

    def write_csv(self, table, rows):
        with (self.bundle / FILES[table]).open("w", newline="", encoding="utf-8-sig") as stream:
            csv.writer(stream).writerows(rows)

    def test_import_maps_only_storage_format_and_preserves_dirty_financial_text(self):
        result = import_bundle(self.bundle)
        expected = json.loads((self.corpus / self.metadata["raw_path"]).read_text())
        self.assertEqual(result["data"], expected)
        self.assertEqual(result["issues"], [])
        self.assertEqual(type(result["data"]["products"][0]["case_pack"]), int)
        self.assertIsNone(result["data"]["notice"]["invoice_hint"])
        self.assertTrue(any("," in row["quantity"] for row in result["data"]["receipts"]))
        self.assertTrue(any(row["uom"] == "EA" for row in result["data"]["receipts"]))
        self.assertIn("/", result["data"]["notice"]["notice_date"])
        self.assertIsInstance(result["data"]["notice"]["amount"], str)
        self.assertNotIn("amount_cents", result["data"]["notice"])

    def test_mapping_covers_all_cells_with_file_hash_and_source_locator(self):
        result = import_bundle(self.bundle)
        self.assertEqual(len(result["sources"]), 8)
        for item in result["mapping"]:
            source = self.bundle / item["file"]
            self.assertEqual(item["sha256"], hashlib.sha256(source.read_bytes()).hexdigest())
            self.assertGreaterEqual(item["row"], 2)
            self.assertLessEqual(item["physical_line_start"], item["physical_line_end"])
            self.assertIn(item["column"], (item["field"], *ALIASES[item["table"]][item["field"]]))
            self.assertTrue(item["json_path"].startswith("$."))
            self.assertTrue(item["record_key"])
        expected_cells = sum(len(self.read_csv(table)[0]) * (len(self.read_csv(table)) - 1) for table in FILES)
        self.assertEqual(len(result["mapping"]), expected_cells)
        self.assertTrue(all(result["importer_checks"].values()))

    def test_independent_audit_never_calls_importer_or_import_header_helper(self):
        data = import_bundle(self.bundle)["data"]
        with patch("recon.demo.ingest.import_bundle", side_effect=AssertionError("Audit cannot reimport")), \
                patch("recon.demo.ingest._headers", side_effect=AssertionError("Independent column check required")):
            audit = audit_bundle(self.bundle, data)
        self.assertTrue(audit["passed"])
        self.assertEqual(audit["method"], "independent_csv_cell_iteration_and_inverse_serialization")

    def test_audit_detects_changed_value_type_lost_rows_and_extra_fields(self):
        original = import_bundle(self.bundle)["data"]
        variants = []
        changed = deepcopy(original); changed["invoice_lines"][0]["unit_price"] = "1.00"; variants.append(changed)
        changed = deepcopy(original); changed["products"][0]["case_pack"] = 12.0; variants.append(changed)
        changed = deepcopy(original); changed["invoice_lines"].pop(); variants.append(changed)
        changed = deepcopy(original); changed["notice"]["guessed_amount_cents"] = 100; variants.append(changed)
        for data in variants:
            with self.subTest(data=data):
                self.assertFalse(audit_bundle(self.bundle, data)["passed"])

    def test_unknown_duplicate_and_missing_columns_are_rejected(self):
        original = self.read_csv("notice")
        variants = []
        rows = deepcopy(original); rows[0][0] = "Unmodeled Fee"; variants.append(rows)
        rows = deepcopy(original); rows[0][0] = rows[0][1]; variants.append(rows)
        rows = deepcopy(original); rows[0].pop(); rows[1].pop(); variants.append(rows)
        for rows in variants:
            with self.subTest(header=rows[0]):
                self.write_csv("notice", rows)
                with self.assertRaises(ValueError):
                    import_bundle(self.bundle)

    def test_two_known_aliases_for_same_field_are_not_silently_merged(self):
        rows = self.read_csv("notice")
        rows[0].append("deduction_id")
        rows[1].append("D-another")
        self.write_csv("notice", rows)
        with self.assertRaises(ValueError):
            import_bundle(self.bundle)

    def test_duplicate_record_id_and_wrong_row_width_are_rejected(self):
        rows = self.read_csv("invoice_lines")
        rows.append(list(rows[1]))
        self.write_csv("invoice_lines", rows)
        with self.assertRaises(ValueError):
            import_bundle(self.bundle)
        rows.pop(); rows[1].append("extra")
        self.write_csv("invoice_lines", rows)
        with self.assertRaises(ValueError):
            import_bundle(self.bundle)

    def test_unknown_files_and_symlink_escape_are_rejected(self):
        extra = self.bundle / "labels.csv"
        extra.write_text("hidden_truth\n", encoding="utf-8")
        with self.assertRaises(ValueError):
            import_bundle(self.bundle)
        extra.unlink()
        source = self.bundle / FILES["notice"]
        outside = self.bundle.parent / "outside.csv"
        outside.write_bytes(source.read_bytes())
        source.unlink()
        source.symlink_to(outside)
        with self.assertRaises(ValueError):
            import_bundle(self.bundle)

    def test_required_blank_and_noncanonical_case_pack_are_rejected(self):
        rows = self.read_csv("products")
        header = rows[0]
        case_pack = next(i for i, name in enumerate(header) if name in ("case_pack", *ALIASES["products"]["case_pack"]))
        for value in ("12.0", "012", " 12 ", "True"):
            rows[1][case_pack] = value
            self.write_csv("products", rows)
            with self.subTest(value=value), self.assertRaises(ValueError):
                import_bundle(self.bundle)
        rows[1][case_pack] = "12"
        sku = next(i for i, name in enumerate(header) if name in ("sku", *ALIASES["products"]["sku"]))
        rows[1][sku] = ""
        self.write_csv("products", rows)
        with self.assertRaises(ValueError):
            import_bundle(self.bundle)

    def test_quoted_commas_and_multiline_text_keep_original_cells_and_physical_lines(self):
        rows = self.read_csv("notice")
        description = next(i for i, name in enumerate(rows[0]) if name in ("description", *ALIASES["notice"]["description"]))
        rows[1][description] = 'Original memo, with "quotes"\nand a second line'
        self.write_csv("notice", rows)
        result = import_bundle(self.bundle)
        self.assertEqual(result["data"]["notice"]["description"], rows[1][description])
        item = next(cell for cell in result["mapping"] if cell["table"] == "notice" and cell["field"] == "description")
        self.assertGreater(item["physical_line_end"], item["physical_line_start"])
        self.assertTrue(audit_bundle(self.bundle, result["data"])["passed"])

    def test_import_and_audit_leave_csv_bytes_unchanged(self):
        before = {path.name: path.read_bytes() for path in self.bundle.iterdir()}
        data = import_bundle(self.bundle)["data"]
        audit_bundle(self.bundle, data)
        self.assertEqual(before, {path.name: path.read_bytes() for path in self.bundle.iterdir()})

    def test_all_frozen_demo_audits_and_original_labels_remain_intact(self):
        original = ROOT / "evaluation/reconstruction"
        _, original_index, _, original_freeze = load_corpus(original)
        self.assertEqual(len(self.index), 30)
        self.assertEqual(self.manifest["split_counts"], {"development": 18, "heldout": 12})
        self.assertEqual((self.corpus / "labels.jsonl").read_bytes(), (original / "labels.jsonl").read_bytes())
        self.assertEqual(self.manifest["original_frozen_corpus"], original_freeze)
        for case_id, row in self.index.items():
            data = import_bundle(self.corpus / row["source_bundle_path"])["data"]
            self.assertTrue(audit_bundle(self.corpus / row["source_bundle_path"], data)["passed"])
            self.assertEqual(data, json.loads((self.corpus / row["raw_path"]).read_text()))
            original_data = json.loads((original / original_index[case_id]["raw_path"]).read_text())
            self.assertEqual(data["notice"], original_data["notice"])
            for table in FILES:
                if table != "notice":
                    expected = sorted(json.dumps(record, sort_keys=True) for record in original_data[table])
                    actual = sorted(json.dumps(record, sort_keys=True) for record in data[table])
                    self.assertEqual(actual, expected)

    def test_frozen_destination_cannot_be_overwritten(self):
        with self.assertRaises(ValueError):
            build_demo_corpus(ROOT / "evaluation/reconstruction", self.corpus)


if __name__ == "__main__":
    unittest.main()
