"""Release only reviewed application paths; never include local private state."""
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

from scripts.package_release import package_release, selected_files


class ReleasePackagingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "developer-checkout"
        self.source.mkdir()
        files = {"src/recon/__init__.py": "", "src/recon/web.py": 'print("local app")\n',
                 "web/workspace.html": "<!doctype html><title>Workspace</title>",
                 "pyproject.toml": '[project]\nname="release-fixture"\nversion="1.0"\n',
                 ".env.example": "RECON_PROVIDER=openai\nOPENAI_MODEL=\nOPENAI_API_KEY=\n",
                 ".gitignore": ".env\n.env.*\n!.env.example\noutput/\n",
                 "start.sh": "#!/bin/sh\nexec python -m recon.web\n",
                 "data/products.csv": "sku,description\nP-1,Authored item\n",
                 "evaluation/ground_truth.csv": "deduction_id,status\nD-1,review\n",
                 "evaluation/reconstruction/cases/authored.json": '{"authored":true}\n',
                 "evaluation/investigation/example.json": '{"authored":true}\n',
                 "evaluation/demo_messy/example.csv": "id,amount\nA,37.50\n",
                 "examples/retail_reconciliation/input/ledger.csv": "claim,amount\nA,37.50\n",
                 "tests/test_engine.py": "import unittest\n",
                 "tests/test_workspace_jobs.py": "import unittest\n",
                 "tests/web_client.test.cjs": "console.log('test');\n",
                 "tests/test_experiment_methods.py": "DO NOT INCLUDE\n",
                 "tests/test_ceap_data.py": "DO NOT INCLUDE\n",
                 "tests/test_cord_data.py": "DO NOT INCLUDE\n",
                 "tests/test_stress_runner.py": "DO NOT INCLUDE\n",
                 "tests/test_real_data_audit.py": "DO NOT INCLUDE\n",
                 "src/recon/__pycache__/compiled.pyc": "DO NOT INCLUDE\n",
                 "scripts/build_example_dataset.py": "# Authored input generator\n"}
        for name, value in files.items():
            self.write(name, value)
        self.output, self.archive = self.root / "retail-reconciliation", self.root / "retail-reconciliation.zip"

    def tearDown(self):
        self.temp.cleanup()

    def write(self, name, value):
        path = self.source / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value)
        return path

    def build(self):
        return package_release(self.source, self.output, self.archive)

    def test_runtime_environment_uploads_and_research_are_not_packaged(self):
        sentinel = "PRIVATE-RUNTIME-SENTINEL"
        for name in (".env", ".env.local", "output/workspace/model_settings.json", "output/jobs/job.json",
                     "uploads/invoice.csv", ".codex/auth.json", ".venv/credentials.txt", "evaluation/public/government.csv"):
            self.write(name, sentinel)
        result = self.build()
        self.assertEqual(result["credential_and_private_path_scan"], "passed")
        self.assertFalse((self.output / ".env").exists())
        self.assertTrue((self.output / ".env.example").is_file())
        with zipfile.ZipFile(self.archive) as bundle:
            names = bundle.namelist()
            self.assertTrue(all(name.startswith("retail-reconciliation/") for name in names))
            self.assertFalse(any("output/" in name or "uploads/" in name or "evaluation/public/" in name for name in names))
            self.assertTrue(all(sentinel.encode() not in bundle.read(name) for name in names))
            self.assertFalse(any("__pycache__" in name or "test_experiment" in name or "test_stress" in name or "test_ceap" in name or "test_cord" in name for name in names))
            self.assertIn("retail-reconciliation/tests/test_workspace_jobs.py", names)
            self.assertIn("retail-reconciliation/evaluation/ground_truth.csv", names)
            self.assertIn("retail-reconciliation/examples/retail_reconciliation/input/ledger.csv", names)

    def test_manifest_is_relative_and_every_shipped_file_matches_its_hash(self):
        self.build()
        manifest = json.loads((self.output / "release_manifest.json").read_text())
        self.assertNotIn(str(self.source), json.dumps(manifest))
        for relative, item in manifest["files"].items():
            self.assertFalse(Path(relative).is_absolute())
            self.assertNotIn("..", Path(relative).parts)
            data = (self.output / relative).read_bytes()
            self.assertEqual(hashlib.sha256(data).hexdigest(), item["sha256"])
            self.assertEqual(len(data), item["bytes"])

    def test_existing_folder_or_archive_is_never_overwritten(self):
        self.output.mkdir()
        (self.output / "user-file.txt").write_text("preserve")
        with self.assertRaisesRegex(ValueError, "overwrite"):
            self.build()
        self.assertEqual((self.output / "user-file.txt").read_text(), "preserve")
        other = self.root / "new-release"
        self.archive.write_text("preserve archive")
        with self.assertRaisesRegex(ValueError, "overwrite"):
            package_release(self.source, other, self.archive)
        self.assertEqual(self.archive.read_text(), "preserve archive")

    def test_suspected_source_key_fails_without_echoing_the_credential(self):
        secret = "sk-" + "K9m2P" * 10
        self.write("src/recon/accidental_key.py", 'API_KEY = "' + secret + '"\n')
        with self.assertRaises(ValueError) as error:
            self.build()
        self.assertIn("Potential credential", str(error.exception))
        self.assertNotIn(secret, str(error.exception))
        self.assertFalse(self.output.exists())
        self.assertFalse(self.archive.exists())

    def test_private_user_path_in_selected_source_fails_without_path_content(self):
        private_path = "/" + "Users" + "/private-person/records.csv"
        self.write("src/recon/private_path.py", 'SOURCE = "' + private_path + '"\n')
        with self.assertRaises(ValueError) as error:
            self.build()
        self.assertIn("Private machine path", str(error.exception))
        self.assertNotIn("private-person", str(error.exception))

    def test_source_symlink_is_refused_without_reading_its_target(self):
        target = self.root / "private-auth.txt"
        target.write_text("PRIVATE-TARGET")
        link = self.source / "src/recon/leaked.py"
        link.symlink_to(target)
        with self.assertRaisesRegex(ValueError, "Symlink"):
            self.build()
        self.assertFalse(self.output.exists())

    def test_credentials_hidden_inside_example_workbook_are_detected(self):
        secret = "sk-" + "B8d2F" * 10
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as workbook:
            workbook.writestr("xl/sharedStrings.xml", "<text>" + secret + "</text>")
        path = self.source / "examples/retail_reconciliation/input/leak.xlsx"
        path.write_bytes(buffer.getvalue())
        with self.assertRaisesRegex(ValueError, "credential"):
            self.build()

    def test_source_readme_is_replaced_with_portable_app_setup_without_editing_it(self):
        original = "Internal development history should not become the public quickstart."
        self.write("README.md", original)
        self.build()
        readme = (self.output / "README.md").read_text()
        self.assertEqual((self.source / "README.md").read_text(), original)
        self.assertIn(".[solver,text,workspace]", readme)
        self.assertIn("API key", readme)
        self.assertIn("historical public-data research", readme)
        self.assertNotIn(original, readme)

    def test_archive_cannot_be_created_inside_its_own_release_folder(self):
        with self.assertRaisesRegex(ValueError, "outside"):
            package_release(self.source, self.output, self.output / "recursive.zip")
        self.assertFalse(self.output.exists())

    def test_release_cannot_be_written_inside_selected_source_tree(self):
        with self.assertRaisesRegex(ValueError, "outside"):
            package_release(self.source, self.source / "src/generated-release", self.archive)

    def test_documented_fake_test_key_is_allowed_only_in_its_exact_test_file(self):
        fake = "sk-" + "unit-test-memory-only-credential"
        self.write("tests/test_workspace_model.py", 'DUMMY = "' + fake + '"\n')
        self.assertIn("tests/test_workspace_model.py", selected_files(self.source))
        self.write("src/recon/wrong.py", 'NOT_A_TEST = "' + fake + '"\n')
        with self.assertRaisesRegex(ValueError, "credential"):
            selected_files(self.source)


if __name__ == "__main__":
    unittest.main()
