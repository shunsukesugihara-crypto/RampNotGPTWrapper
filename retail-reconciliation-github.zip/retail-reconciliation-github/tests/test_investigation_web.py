"""HTTP boundaries and saved reports, with explicit injected execution."""
import http.client
import json
from pathlib import Path
import tempfile
from threading import Thread
import unittest
from unittest.mock import patch

from recon.web import create_server


class InvestigationWebTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        (self.root / "web").mkdir()
        (self.root / "web/workspace.html").write_text("<title>Reconciliation workspace</title>")
        self.root_patch = patch("recon.web.ROOT", self.root)
        self.root_patch.start()
        self.provider = object()
        self.server = create_server(port=0, planner_mode="offline", provider=self.provider)
        self.thread = Thread(target=self.server.serve_forever, kwargs={"poll_interval": .01}, daemon=True)
        self.thread.start()
        self.catalog_patch = patch("recon.investigation.fixtures.catalog", return_value=[{"id": "example", "title": "Injected HTTP case"}])
        self.catalog_patch.start()
        self.pack_patch = patch("recon.investigation.fixtures.load_case", return_value="injected-source")
        self.pack = self.pack_patch.start()
        self.run_patch = patch("recon.investigation.service.run_case", return_value={"status": "review", "reason": "injected_http_check", "live_ai": False, "model_calls": 0})
        self.run = self.run_patch.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.run_patch.stop()
        self.pack_patch.stop()
        self.catalog_patch.stop()
        self.root_patch.stop()
        self.temporary.cleanup()

    def request(self, method, path, value=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
        try:
            connection.request(method, path, body=json.dumps(value) if value is not None else None,
                               headers={"Content-Type": "application/json", **(headers or {})})
            response = connection.getresponse()
            return response.status, response.read()
        finally:
            connection.close()

    def test_page_and_catalog_reads_never_start_execution(self):
        self.assertEqual(self.request("GET", "/investigate/")[0], 200)
        status, body = self.request("GET", "/api/investigation/cases")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["data_kind"], "authored_synthetic")
        self.run.assert_not_called()
        self.pack.assert_not_called()

    def test_each_post_executes_requested_method_and_saves_exact_response(self):
        responses = []
        for mode in ("ai", "fixed", "direct"):
            status, body = self.request("POST", "/api/investigation/run", {"case_id": "example", "mode": mode})
            self.assertEqual(status, 200)
            response = json.loads(body)
            self.run.assert_called_with("injected-source", provider=self.provider, mode=mode)
            saved = json.loads((self.root / "output/investigation_runs" / (response["run_id"] + ".json")).read_text())
            self.assertEqual(saved, response)
            self.assertFalse(response["result"]["live_ai"])
            responses.append(response)
        self.assertEqual(len({r["run_id"] for r in responses}), 3)

    def test_invalid_fields_modes_and_cross_origin_cannot_run(self):
        for value in ({"case_id": "../../secret", "mode": "ai"}, {"case_id": "example", "mode": []},
                      {"case_id": "example", "mode": "python"}, {"case_id": "example", "mode": "ai", "answer": 900}):
            self.assertEqual(self.request("POST", "/api/investigation/run", value)[0], 400)
        self.assertEqual(self.request("POST", "/api/investigation/run", {"case_id": "example", "mode": "ai"},
                                      {"Origin": "https://example.com"})[0], 403)
        self.run.assert_not_called()

    def test_missing_provider_never_silently_runs_fixed_policy(self):
        self.server.provider = None
        for mode in ("ai", "direct"):
            self.assertEqual(self.request("POST", "/api/investigation/run", {"case_id": "example", "mode": mode})[0], 503)
        self.run.assert_not_called()
        self.assertEqual(self.request("POST", "/api/investigation/run", {"case_id": "example", "mode": "fixed"})[0], 200)
        self.run.assert_called_once_with("injected-source", provider=None, mode="fixed")


if __name__ == "__main__":
    unittest.main()
