from copy import deepcopy
import unittest

from test_workspace_jobs import source_tables, import_workspace
from recon.workspace.scoping import scope_pack


class WorkspaceScopingTests(unittest.TestCase):
    def test_explicit_invoice_keeps_all_its_lines_and_original_row_coordinates(self):
        pack = import_workspace()["built"]["pack"]
        pack["notice"]["invoice_hint"] = "BILL-Y8"
        before = deepcopy(pack)
        selection = scope_pack(pack)
        self.assertEqual(selection["source_rows"]["invoice_lines"], [1])
        self.assertEqual(selection["source_rows"]["receipts"], [1])
        self.assertEqual(selection["pack"]["invoices"][0]["invoice_id"], "BILL-Y8")
        self.assertEqual(pack, before)

    def test_without_recorded_references_no_financial_rows_are_silently_removed(self):
        pack = import_workspace()["built"]["pack"]
        pack["notice"]["invoice_hint"] = None
        self.assertEqual(scope_pack(pack)["pack"], pack)

    def test_unrelated_missing_conversion_is_outside_explicit_invoice_scope(self):
        pack = import_workspace()["built"]["pack"]
        pack["receipts"][1]["uom"] = "EA"
        pack["products"][1].update(case_pack=None, source_ref=None)
        selected = scope_pack(pack)["pack"]
        self.assertEqual(len(selected["receipts"]), 1)
        self.assertEqual(selected["receipts"][0]["uom"], "CS")
        self.assertEqual(selected["products"][0]["sku"], "P-ALMOND")

    def test_all_same_reference_alternatives_survive(self):
        tables = source_tables()
        tables["invoices"][1]["po_id"] = "ORD-701"
        tables["shipments"][1]["po_id"] = "ORD-701"
        tables["notice"][0].update(invoice_hint=None, po_hint="ORD-701")
        pack = import_workspace(tables)["built"]["pack"]
        selected = scope_pack(pack)["pack"]
        self.assertEqual(len(selected["invoice_lines"]), 2)
        self.assertEqual(len(selected["receipts"]), 2)

    def test_orphan_invoice_lines_are_not_hidden_by_an_order_filter(self):
        tables = source_tables()
        tables["invoice_lines"][1]["invoice_id"] = "MISSING-HEADER"
        tables["notice"][0].update(invoice_hint=None, po_hint="ORD-701")
        selected = scope_pack(import_workspace(tables)["built"]["pack"])["pack"]
        self.assertTrue(any(r["invoice_id"] == "MISSING-HEADER" for r in selected["invoice_lines"]))
