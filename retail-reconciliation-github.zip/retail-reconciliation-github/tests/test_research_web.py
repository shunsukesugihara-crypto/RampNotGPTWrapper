"""Read-only study routes never launch a model or expose arbitrary files."""
import http.client
import json
from pathlib import Path
import tempfile
from threading import Thread
import unittest
from unittest.mock import patch

from recon.web import create_server


class ResearchWebTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.patch = patch("recon.web.ROOT", self.root)
        self.patch.start()
        with patch("recon.web.create_provider", side_effect=AssertionError("No inference for reports")):
            self.server = create_server(port=0, planner_mode="offline")
        self.thread = Thread(target=self.server.serve_forever, kwargs={"poll_interval": .01}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.patch.stop()
        self.temporary.cleanup()

    def request(self, path):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
        try:
            connection.request("GET", path)
            response = connection.getresponse()
            return response.status, response.getheader("Content-Type"), response.read()
        finally:
            connection.close()

    def publish(self, run_id="00000000-0000-0000-0000-000000000001"):
        experiments = self.root / "output/experiments"
        experiments.mkdir(parents=True, exist_ok=True)
        (experiments / "latest_run.json").write_text(json.dumps({"run_id": run_id}))
        return experiments / run_id

    def test_completed_allowlisted_reports_are_read_only_html(self):
        folder = self.publish()
        folder.mkdir()
        names = ("overview.html", "report.html", "cord.html", "ceap.html", "cord_extra_redaction.html")
        for name in names:
            (folder / name).write_text(f"<!doctype html><title>{name}</title>")
        with patch("recon.web.create_provider", side_effect=AssertionError("Report reads cannot launch inference")):
            for name in names:
                with self.subTest(name=name):
                    status, content_type, body = self.request(f"/research/{name}")
                    self.assertEqual(status, 200)
                    self.assertEqual(content_type, "text/html; charset=utf-8")
                    self.assertIn(name.encode(), body)
            self.assertEqual(self.request("/research/")[2], self.request("/research/overview.html")[2])
            for name in ("report.json", "protocol.json", "study_history.json"):
                (folder / name).write_text('{"saved_evidence":true}')
                status, content_type, body = self.request(f"/research/{name}")
                self.assertEqual(status, 200)
                self.assertEqual(content_type, "application/json; charset=utf-8")
                self.assertTrue(json.loads(body)["saved_evidence"])

    def test_absent_or_invalid_saved_pointer_is_visible_as_unavailable(self):
        self.assertEqual(self.request("/research/")[0], 503)
        self.publish("../../private")
        self.assertEqual(self.request("/research/")[0], 503)
        (self.root / "output/experiments/latest_run.json").write_text("broken json")
        self.assertEqual(self.request("/research/")[0], 503)

    def test_arbitrary_artifacts_and_query_paths_are_not_served(self):
        folder = self.publish()
        folder.mkdir()
        (folder / "checkpoint.json").write_text('{"private":true}')
        for path in ("/research/checkpoint.json", "/research/../latest_run.json", "/research/report.html?file=checkpoint.json"):
            with self.subTest(path=path):
                self.assertEqual(self.request(path)[0], 404)

    def test_symlink_cannot_escape_saved_run_directory(self):
        folder = self.publish()
        folder.mkdir()
        outside = self.root / "outside.html"
        outside.write_text("not a report")
        (folder / "overview.html").symlink_to(outside)
        self.assertEqual(self.request("/research/")[0], 503)


if __name__ == "__main__":
    unittest.main()
