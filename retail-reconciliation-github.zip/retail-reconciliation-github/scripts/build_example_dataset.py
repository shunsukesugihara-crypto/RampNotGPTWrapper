"""Build an uploadable, authored retail ledger with separate expected results.

The expected outcomes below are authored from the event specification, never
obtained by running the matching engine. This is an engineering dataset, not
genuine retailer data or a representative external accuracy benchmark.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import csv
from datetime import datetime
import hashlib
import io
import json
from pathlib import Path
import re
import zipfile


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "examples/retail_reconciliation"
FIXED_TIME = datetime(2026, 1, 1)

HEADERS = {
    "notice": {"deduction_id": "Claim Number", "retailer": "Customer Name", "notice_date": "Claim Date",
               "amount": "Deduction Amount", "currency": "Currency Code", "short_qty": "Missing Qty",
               "uom": "Quantity UOM", "scope": "Claim Scope", "basis": "Financial Basis",
               "po_hint": "PO Reference", "invoice_hint": "Invoice Reference", "sku_hint": "Item Ref",
               "description": "Deduction Memo"},
    "products": {"sku": "Item Code", "description": "Item Name", "case_pack": "Units Per Case", "source_ref": "Pack Evidence Ref"},
    "purchase_orders": {"po_id": "PO Number", "retailer": "Customer Name", "order_date": "PO Date"},
    "invoices": {"invoice_id": "Invoice Number", "po_id": "PO Number", "invoice_date": "Billing Date", "currency": "Currency Code"},
    "invoice_lines": {"invoice_line_id": "Line Reference", "invoice_id": "Invoice Number", "sku": "Item Code",
                      "quantity": "Billed Quantity", "uom": "Qty UOM", "unit_price": "Price Per Unit",
                      "price_uom": "Price UOM", "currency": "Currency Code"},
    "shipments": {"shipment_id": "Dispatch Reference", "po_id": "PO Number", "ship_date": "Dispatch Date"},
    "shipment_lines": {"shipment_id": "Dispatch Reference", "sku": "Item Code", "quantity": "Dispatched Quantity", "uom": "Qty UOM"},
    "receipts": {"receipt_id": "Receiving Reference", "shipment_id": "Dispatch Reference", "sku": "Item Code",
                 "quantity": "Receiving Quantity", "uom": "Quantity Unit", "receipt_date": "Received Date"},
}
FILE_ROLES = {
    "01_deductions.csv": ("notice",),
    "02_product_master.tsv": ("products",),
    "03_purchase_orders.csv": ("purchase_orders",),
    "04_billing_export.xlsx": ("invoices", "invoice_lines"),
    "05_dispatch_export.csv": ("shipments", "shipment_lines"),
    "06_warehouse_receiving.tsv": ("receipts",),
}


def authored_sources():
    """Independent business events; no matching-library imports or decisions."""
    tables = {role: [] for role in HEADERS}
    retailer = "Harbor & Field Markets"

    def order(po_id):
        if not any(row["po_id"] == po_id for row in tables["purchase_orders"]):
            tables["purchase_orders"].append({"po_id": po_id, "retailer": retailer, "order_date": "10/01/2026"})

    def transaction(number, po_id, currency, lines):
        order(po_id)
        invoice_id, shipment_id = "000" + number, "ASN-" + number
        tables["invoices"].append({"invoice_id": invoice_id, "po_id": po_id, "invoice_date": "2026-10-03", "currency": currency})
        tables["shipments"].append({"shipment_id": shipment_id, "po_id": po_id, "ship_date": "10/04/2026"})
        for item in lines:
            sku, description, price, shipped, received, factor = item[:6]
            receiving_unit = item[6] if len(item) > 6 else "CS"
            tables["products"].append({"sku": sku, "description": description, "case_pack": factor,
                                       "source_ref": "catalog-2026-10#" + sku if factor is not None else ""})
            tables["invoice_lines"].append({"invoice_line_id": "BILL-" + number + "-" + sku, "invoice_id": invoice_id,
                                            "sku": sku, "quantity": str(shipped), "uom": "CS", "unit_price": price,
                                            "price_uom": "CS", "currency": currency})
            tables["shipment_lines"].append({"shipment_id": shipment_id, "sku": sku, "quantity": str(shipped), "uom": "CS"})
            if received is not None:
                tables["receipts"].append({"receipt_id": "GR-" + number + "-" + sku, "shipment_id": shipment_id, "sku": sku,
                                           "quantity": received, "uom": receiving_unit, "receipt_date": "2026-10-07"})
        return invoice_id

    transaction("401", "000941", "USD", [("000101", "Single-origin coffee, 6 × 5kg", "1,275.00", 40, "37", 6)])
    transaction("402", "000942", "USD", [("000102", "Roasted coffee, 8 × 250g", "46.50", 60, "55", 8)])
    transaction("403", "000943", "EUR", [("000103", "Tomato passata, 8 × 700g", "31.80", 25, "21", 8)])
    # Same price and short quantity as EUR403, but explicitly USD. It remains a
    # real source candidate under the PO until currency is checked.
    transaction("493", "000943", "USD", [("000303", "Tomato passata US-market pack", "31.80", 30, "26", 8)])
    transaction("404", "000944", "USD", [("000104", "Sparkling water, 12 × 330ml", "16.25", 50, "540", 12, "EA")])
    transaction("405", "000945", "USD", [("000105", "Sesame crackers, 10 × 150g", "27.95", 100, "93", 10)])
    transaction("450", "000950", "USD", [("000201", "Chickpeas, 6 × 400g", "22.50", 40, "38", 6),
                                            ("000202", "Kidney beans, 12 × 400g", "14.25", 30, "26", 12)])
    transaction("460", "000960", "USD", [("000106", "Brown rice, 5 × 1kg", "45.00", 80, None, 5)])
    transaction("461", "000961", "USD", [("000107", "Lemon tea, 10 × 20 bags", "24.40", 45, "40", 10),
                                            ("000108", "Mint tea, 10 × 20 bags", "24.40", 45, "40", 10)])
    transaction("462", "000962", "USD", [("000109", "Seasonal assortment, supplier pack", "33.33", 100, "1,170", None, "EA")])
    transaction("470", "000970", "USD", [("000110", "Sea salt, 12 × 500g", "18.75", 70, "62", 12)])
    transaction("480", "000980", "GBP", [("000111", "Digestive biscuits, 12 × 250g", "12.80", 80, "71", 12)])

    notices = [
        ("CLM-2026-0041", "$3,825.00", "USD", "3", "single_line", "", "000401"),
        ("CLM-2026-0042", "232.50", "USD", "5", "single_line", "000942", ""),
        ("CLM-2026-0043", "€127.20", "EUR", "4", "single_line", "000943", ""),
        ("CLM-2026-0044", "$81.25", "USD", "5", "single_line", "", "000404"),
        ("CLM-2026-0045", "195.65", "USD", "", "single_line", "", "000405"),
        ("CLM-2026-0050", "$102.00", "USD", "6", "multi_line", "", "000450"),
        ("CLM-2026-0060", "135.00", "USD", "3", "single_line", "", "000460"),
        ("CLM-2026-0061", "$122.00", "USD", "5", "single_line", "000961", ""),
        ("CLM-2026-0062", "333.30", "USD", "10", "single_line", "", "000462"),
        ("CLM-2026-0070", "$150.00", "USD", "8", "single_line", "", "000470"),
        ("CLM-2026-0071", "150.00", "USD", "8", "single_line", "", "000470"),
        ("CLM-2026-0080", "115.20", "GBP", "9", "single_line", "", "000480"),
    ]
    for identity, amount, currency, quantity, scope, po_hint, invoice_hint in notices:
        tables["notice"].append({"deduction_id": identity, "retailer": retailer, "notice_date": "10/18/2026", "amount": amount,
                                 "currency": currency, "short_qty": quantity, "uom": "CS", "scope": scope,
                                 "basis": "whole_receipt_shortfalls", "po_hint": po_hint, "invoice_hint": invoice_hint,
                                 "sku_hint": "", "description": "Distribution-center discrepancy; October settlement"})
    return tables


def expected_results():
    """Authored expectations; these never become application input records."""
    def supported(claim, invoice, sku, shipment, quantity, amount, reason):
        return {"deduction_id": claim, "status": "matched", "invoice_lines": ["BILL-" + invoice + "-" + sku],
                "shipments": [shipment], "quantity_cases": quantity, "amount_cents": amount, "explanation": reason}
    values = [
        supported("CLM-2026-0041", "401", "000101", "ASN-401", 3, 382500, "40 shipped minus 37 received = 3 cases; 3 × $1,275.00 = $3,825.00."),
        supported("CLM-2026-0042", "402", "000102", "ASN-402", 5, 23250, "PO reference connects 60 shipped and 55 received; 5 × $46.50 = $232.50."),
        supported("CLM-2026-0043", "403", "000103", "ASN-403", 4, 12720, "The EUR invoice and receiving evidence support 4 × €31.80. The USD invoice under the same PO cannot contribute."),
        supported("CLM-2026-0044", "404", "000104", "ASN-404", 5, 8125, "The product source establishes 12 units/case: 540 units = 45 cases; 50 minus 45 = 5; 5 × $16.25 = $81.25."),
        supported("CLM-2026-0045", "405", "000105", "ASN-405", 7, 19565, "The notice lacks quantity. Independent records give 100 minus 93 = 7 cases; 7 × $27.95 = $195.65."),
        {"deduction_id": "CLM-2026-0050", "status": "matched", "invoice_lines": ["BILL-450-000201", "BILL-450-000202"],
         "shipments": ["ASN-450"], "quantity_cases": 6, "amount_cents": 10200,
         "explanation": "Whole shortages contribute 2 × $22.50 + 4 × $14.25 = $102.00, across six cases. Neither line alone explains the deduction."},
        {"deduction_id": "CLM-2026-0060", "status": "review", "invoice_lines": [], "shipments": [],
         "explanation": "The relevant shipment exists, but its warehouse receiving record is absent. No missing quantity can be assumed."},
        {"deduction_id": "CLM-2026-0061", "status": "review", "invoice_lines": [], "shipments": [],
         "supported_alternatives": ["BILL-461-000107", "BILL-461-000108"],
         "explanation": "Two different products each have a recorded five-case shortage at $24.40. Both satisfy $122.00; neither can be selected uniquely."},
        {"deduction_id": "CLM-2026-0062", "status": "review", "invoice_lines": [], "shipments": [],
         "explanation": "Receiving uses individual units, but the source product record does not establish units per case. The missing conversion cannot be guessed."},
        {"deduction_id": "CLM-2026-0070", "status": "review", "invoice_lines": [], "shipments": [],
         "conflicting_deductions": ["CLM-2026-0071"], "arithmetic_supported_line": "BILL-470-000110",
         "explanation": "This and CLM-2026-0071 both claim the same entire ASN-470/000110 receiving shortage. The batch must flag both for joint review."},
        {"deduction_id": "CLM-2026-0071", "status": "review", "invoice_lines": [], "shipments": [],
         "conflicting_deductions": ["CLM-2026-0070"], "arithmetic_supported_line": "BILL-470-000110",
         "explanation": "This and CLM-2026-0070 both claim the same entire ASN-470/000110 receiving shortage. There is no automatic first-claim winner."},
        supported("CLM-2026-0080", "480", "000111", "ASN-480", 9, 11520, "80 shipped minus 71 received = 9 cases; 9 × 12.80 = 115.20 in declared GBP. No foreign-exchange conversion is used."),
    ]
    return {"data_kind": "authored_synthetic", "ground_truth_authoring": "Written from the business-event specification before running any reconciliation engine.",
            "scope": "Controlled engineering input, not genuine retailer evidence or an external accuracy benchmark.",
            "expected_completed_batch": {"deductions": 12, "matched": 7, "review": 5, "failed": 0}, "results": values}


def _delimited(path, rows, headers, *, delimiter=","):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(headers.values()), delimiter=delimiter, quoting=csv.QUOTE_MINIMAL)
    writer.writeheader()
    writer.writerows({label: row.get(field, "") if row.get(field) is not None else "" for field, label in headers.items()} for row in rows)
    path.write_bytes(stream.getvalue().encode("utf-8-sig" if delimiter == "," else "utf-8"))


def _workbook(path, rows, headers):
    # Explicitly requested Excel input fixture, rather than a formatted report.
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    workbook = Workbook()
    workbook.properties.creator = "Synthetic reconciliation dataset generator"
    workbook.properties.lastModifiedBy = "Synthetic reconciliation dataset generator"
    workbook.properties.created = FIXED_TIME
    workbook.properties.modified = FIXED_TIME
    sheet = workbook.active
    sheet.title = "Billing rows"
    sheet.append(["Harbor & Field Markets — billing export, October 2026"])
    sheet.append(list(headers.values()))
    for row in rows:
        values = []
        for field in headers:
            value = row.get(field, "")
            if field == "invoice_date":
                value = datetime.fromisoformat(value)
            values.append(value)
        sheet.append(values)
    for cell in sheet[2]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="244C5A")
    date_index = list(headers).index("invoice_date") + 1
    for row in sheet.iter_rows(min_row=3):
        row[date_index - 1].number_format = "yyyy-mm-dd"
    sheet.freeze_panes = "A3"
    sheet.auto_filter.ref = f"A2:J{sheet.max_row}"
    workbook.save(path)
    # Normalize container timestamps and core XML modification time so the
    # generated source hashes are reproducible across separate invocations.
    source = io.BytesIO(path.read_bytes())
    output = io.BytesIO()
    with zipfile.ZipFile(source) as original, zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for item in sorted(original.infolist(), key=lambda value: value.filename):
            content = original.read(item.filename)
            if item.filename == "docProps/core.xml":
                content = re.sub(rb"(<dcterms:(?:created|modified)[^>]*>)[^<]+", rb"\g<1>2026-01-01T00:00:00Z", content)
            info = zipfile.ZipInfo(item.filename, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            target.writestr(info, content)
    path.write_bytes(output.getvalue())


def build_dataset(output=DEFAULT_OUTPUT):
    output = Path(output)
    input_folder = output / "input"
    input_folder.mkdir(parents=True, exist_ok=True)
    tables = authored_sources()
    _delimited(input_folder / "01_deductions.csv", tables["notice"], HEADERS["notice"])
    _delimited(input_folder / "02_product_master.tsv", tables["products"], HEADERS["products"], delimiter="\t")
    _delimited(input_folder / "03_purchase_orders.csv", tables["purchase_orders"], HEADERS["purchase_orders"])
    invoices = {row["invoice_id"]: row for row in tables["invoices"]}
    billing = [{**invoices[row["invoice_id"]], **row} for row in tables["invoice_lines"]]
    billing_headers = {**HEADERS["invoices"], **HEADERS["invoice_lines"]}
    _workbook(input_folder / "04_billing_export.xlsx", billing, billing_headers)
    shipments = {row["shipment_id"]: row for row in tables["shipments"]}
    dispatch = [{**shipments[row["shipment_id"]], **row} for row in tables["shipment_lines"]]
    _delimited(input_folder / "05_dispatch_export.csv", dispatch, {**HEADERS["shipments"], **HEADERS["shipment_lines"]})
    _delimited(input_folder / "06_warehouse_receiving.tsv", tables["receipts"], HEADERS["receipts"], delimiter="\t")
    guide = {"data_kind": "authored_synthetic", "upload_only": "input/", "settings": {}, "table_mappings": [
        {"file": name, "role": role, "columns": HEADERS[role], "defaults": {}}
        for name, roles in FILE_ROLES.items() for role in roles],
        "notes": ["Map the Billing rows worksheet twice: invoices and invoice_lines.",
                  "Map the dispatch CSV twice: shipments and shipment_lines.",
                  "Identical repeated header projections collapse with provenance; financial lines do not.",
                  "All currency, units, scope and basis declarations are recorded in the input; no defaults are needed."]}
    expected = expected_results()
    for name, value in (("expected_results.json", expected), ("mapping_guide.json", guide), ("authored_ledger.json", tables)):
        (output / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    instructions = """RETAIL RECONCILIATION — UPLOADABLE ENGINEERING DATASET

These are authored synthetic records, not a real retailer's transactions.
The original event ledger and expected outcomes are separate from the upload
inputs. No answer labels, chosen matches, or model instructions appear there.

1. Open http://127.0.0.1:8765/ and check the visible provider/model settings.
   Choose Fixed tools for an immediate run without model calls, or configure
   an explicit AI model and test its connection before using AI planning.
2. Upload ALL SIX files inside input/. Do not upload this text file,
   mapping_guide.json, authored_ledger.json, or expected_results.json.
3. Review or request AI-suggested column mappings. Map the billing worksheet
   to BOTH invoices and invoice_lines; map dispatch to BOTH shipments and
   shipment_lines. The other four files each supply one table. The mapping
   guide lists the exact source headers. Do not add currency/unit defaults:
   every required declaration is already a recorded source column.
4. Confirm the mappings. Check that 12 deduction rows are ready. Expected
   source counts: 14 products; 11 purchase orders; 12 invoice headers;
   14 invoice lines; 12 shipment headers; 14 shipment lines; 13 receipts.
   Leading-zero identifiers and the billing worksheet's title row are real
   format tests. A missing receiving record and missing pack conversion are
   intentional missing evidence; do not repair them by guessing.
5. Run the complete batch and watch the actual execution log. Wait for the
   entire run: the two claims sharing one whole shortage must BOTH change
   to review when the second claim is processed.
6. Export results and evidence. Compare them with expected_results.json:
   7 supported matches, 5 reviews, 0 failures. Reviews cover a missing
   receipt, two equally valid products, an unsupported unit conversion,
   and two claims reusing one entire receiving shortage. A match identifies
   a supported relationship; it does not establish deduction liability.

Mixed input formats: CSV, tab-separated exports, and XLSX. Money and dates
use their recorded formats; the application must preserve the source cells.
One EUR notice has a same-price USD distractor under the same purchase order.
A multi-line notice combines two whole shortages. One notice omits quantity
but remains solvable from amount, price, shipment and receiving evidence.

This dataset checks software behavior on known constructed events. It does
not prove accuracy on genuine business data or that AI outperforms rules.
Regenerate with: .venv/bin/python scripts/build_example_dataset.py
"""
    (output / "START_HERE.txt").write_text(instructions)
    manifest = {"data_kind": "authored_synthetic", "description": "Uploadable mixed-format retail deduction ledger with independently authored expected outcomes.",
                "input_files": {path.name: {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                                            "mapped_roles": FILE_ROLES[path.name]}
                                for path in sorted(input_folder.iterdir()) if path.is_file()},
                "source_counts": {role: len(rows) for role, rows in tables.items()},
                "expected_completed_batch": expected["expected_completed_batch"],
                "ground_truth_file": "expected_results.json", "expected_labels_are_not_upload_inputs": True}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args(argv)
    print(json.dumps(build_dataset(args.output), indent=2))


if __name__ == "__main__":
    main()
