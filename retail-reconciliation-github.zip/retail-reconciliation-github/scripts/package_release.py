"""Create a source-only GitHub release without credentials or runtime records.

The source checkout is never changed. Only explicit application/source paths
are copied; downloaded research data, uploads, jobs and environment files are
not traversed. Suspected credentials and private home paths fail closed without
printing their contents.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import fnmatch
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import zipfile


ROOT = Path(__file__).resolve().parents[1]
TREES = ("src", "web", "data", "examples/retail_reconciliation", "evaluation/reconstruction",
         "evaluation/demo_messy", "evaluation/investigation")
FILES = ("pyproject.toml", ".gitignore", ".env.example", "start.sh", "scripts/package_release.py",
         "scripts/build_example_dataset.py", "evaluation/ground_truth.csv", "evaluation/engine_snapshot.json")
EXCLUDED_TESTS = ("test_experiment*.py", "test_ceap_data.py", "test_cord_data.py", "test_stress_*.py", "test_real_data_audit.py")
ESSENTIAL = ("src/recon/web.py", "web/workspace.html", "pyproject.toml", ".env.example", ".gitignore", "start.sh")
DENIED_COMPONENTS = {"__pycache__", ".venv", "node_modules", "output", "uploads", "jobs", "workspaces", ".git", ".codex", ".openai"}
TEXT_EXTENSIONS = {".py", ".html", ".css", ".js", ".cjs", ".mjs", ".json", ".jsonl", ".csv", ".tsv", ".txt", ".toml", ".md", ".sh", ".svg"}
ALLOWED_EXTENSIONS = TEXT_EXTENSIONS | {".xlsx", ".pdf", ".png", ".jpg", ".jpeg", ".woff", ".woff2"}
SECRET_PATTERNS = (
    re.compile(rb"(?<![A-Za-z0-9_-])sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}"),
    re.compile(rb"gh[pousr]_[A-Za-z0-9]{30,}"),
    re.compile(rb"AKIA[0-9A-Z]{16}"),
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
)
PRIVATE_PATH = re.compile(rb"(?:/(?:Users|home)/[^/\s\"'<>]+|/private/var/" rb"folders/|[A-Za-z]:\\Users\\[^\\\s\"'<>]+)")
# Exact, visibly fictional credentials used by the credential-isolation tests.
# No wildcard exception is granted to tests or to strings containing 'test'.
FAKE_TEST_KEYS = {value.encode() for value in (
    "sk-api-key-not-for-cli", "sk-env-key-only-test", "sk-environment-key-for-test",
    "sk-injected-http-only-test", "sk-key-is-not-a-model-name", "sk-memory-key-for-test",
    "sk-new-key-only-test", "sk-new-session-test-only", "sk-old-session-test-only",
    "sk-private-session-only-test", "sk-session-key-only-test", "sk-unit-test-memory-only-credential")}

README = """# Retail deduction reconciliation

A local workspace for importing retail deduction records, confirming column mappings,
running bounded AI-selected computations, and reviewing source-backed results.

## Start locally

Python 3.10 or newer is required. From this folder:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[solver,text,workspace]'
.venv/bin/python -m recon.web
```

Open `http://127.0.0.1:8765/workspace/`. Upload your CSV, TSV, XLSX or JSON tables,
inspect the source previews, assign their financial roles and confirm the column
mappings. PDF support is limited to extractable text; it does not promise scanned
document recognition or automatic financial-table extraction.

In **Model settings**, choose **OpenAI API**, enter an explicit model identifier
supported by your account, enter your API key and test the connection. The session
key is held in server memory only and must be entered again after a server restart.
The API key is sent only from the local Python server to the model service. No key
is included in this repository or returned in result exports.

Alternatively, copy `.env.example` to `.env` and fill in `OPENAI_MODEL` and
`OPENAI_API_KEY` on the server. `.env` is ignored by Git. A configured, authenticated
Codex CLI is optional; it is not required for the OpenAI API path. The displayed
model is the explicitly requested model; backend identity verification is reported
separately rather than assumed.

On Windows, create/activate a virtual environment using your Python installation,
then run `python -m pip install -e ".[solver,text,workspace]"` and
`python -m recon.web`. `start.sh` is an optional macOS/Linux convenience after setup.

## Try the supplied files

`examples/retail_reconciliation/input/` contains an authored mixed-format batch.
Upload only those input files. `mapping_guide.json` documents their roles and
columns; `expected_results.json` contains separate human-authored assertions for
testing and is not an input to the reconciler. These are synthetic examples,
not genuine retailer records or evidence of real-world accuracy.

AI proposes column mappings for review and selects approved computations. Ordinary
code calculates exact amounts, checks document relationships and verifies the
evidence. Missing or contradictory evidence remains unresolved. Reusing the same
recorded receiving shortage across deductions requires review together. Matching a
transaction does not establish deduction liability or recovered money.

Runs and imported records are stored locally under `output/`, which is ignored by
Git. Download results as CSV or JSON from the app. Exported CSV text is protected
against spreadsheet formula execution. This local prototype has bounded supported
financial formats and is not an internet-facing multi-user deployment.

## Tests

```sh
PYTHONPATH=src .venv/bin/python -m unittest discover -s tests -v
node tests/web_client.test.cjs
```

The included tests use injected model responses and do not make live model calls.
Some tests open temporary localhost sockets. Node.js is optional for the JavaScript
client test. The original rules-only baseline remains in `recon.engine`; the
independent financial reconstruction engines and workspace are included separately.

This application distribution intentionally excludes historical public-data research
archives, research accuracy reports and their dataset-dependent tests. It includes
only authored example data and the tests needed for the shipped application. No
claim of AI superiority follows from the supplied examples.

## Share this repository

Review `release_manifest.json` for file hashes. The release excludes real API keys,
`.env`, authentication files, saved model settings, uploads, runs, user records,
virtual environments and downloaded research datasets. Keep these exclusions when
adding files. No license is asserted by this packaging script; the repository owner
must choose any public license separately.
"""


def _safe_relative(relative):
    path = PurePosixPath(relative)
    return not path.is_absolute() and ".." not in path.parts and "\\" not in relative


def _excluded(relative):
    path = PurePosixPath(relative)
    if any(part in DENIED_COMPONENTS or part.endswith(".egg-info") for part in path.parts):
        return True
    if any(part.startswith(".") for part in path.parts) and relative not in {".gitignore", ".env.example"}:
        return True
    if path.name in {"auth.json", "credentials.json", "model_settings.json"} or path.suffix in {".pyc", ".pyo", ".key", ".pem"}:
        return True
    return False


def _scan_bytes(relative, data):
    if PRIVATE_PATH.search(data):
        raise ValueError(f"Private machine path detected in selected release file: {relative}")
    for pattern in SECRET_PATTERNS:
        for match in pattern.finditer(data):
            if relative in {"tests/test_workspace_model.py", "scripts/package_release.py"} and match.group() in FAKE_TEST_KEYS:
                continue
            raise ValueError(f"Potential credential detected in selected release file: {relative}; contents withheld")


def _scan(relative, data):
    _scan_bytes(relative, data)
    if PurePosixPath(relative).suffix == ".xlsx":
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as workbook:
                if sum(item.file_size for item in workbook.infolist()) > 20_000_000:
                    raise ValueError("Workbook is too large to inspect for this application release")
                for item in workbook.infolist():
                    if item.filename.endswith((".xml", ".rels")):
                        _scan_bytes(relative + " (workbook content)", workbook.read(item))
        except zipfile.BadZipFile:
            raise ValueError(f"Malformed workbook in selected release files: {relative}") from None


def selected_files(source):
    """Allowlist selection; no runtime/authentication directories are opened."""
    source = Path(source).resolve()
    selected = {}

    def add(path):
        relative = path.relative_to(source).as_posix()
        if path.is_symlink():
            raise ValueError(f"Symlink is not permitted in release inputs: {relative}")
        if _excluded(relative) or not path.is_file():
            return
        if not _safe_relative(relative):
            raise ValueError("Unsafe release member path")
        if path.suffix not in ALLOWED_EXTENSIONS and relative not in {".gitignore", ".env.example"}:
            return
        payload = path.read_bytes()
        _scan(relative, payload)
        selected[relative] = (payload, path.stat().st_mode & 0o777)

    for relative in FILES:
        path = source / relative
        if path.exists() or path.is_symlink():
            add(path)
    for relative in TREES:
        path = source / relative
        if path.is_symlink():
            raise ValueError(f"Symlink is not permitted in release inputs: {relative}")
        if path.is_dir():
            for item in sorted(path.rglob("*")):
                add(item)
    tests = source / "tests"
    if tests.is_symlink():
        raise ValueError("Symlink is not permitted in release inputs: tests")
    if tests.is_dir():
        for path in sorted(tests.iterdir()):
            if path.name.startswith("test_") and path.suffix == ".py" and not any(fnmatch.fnmatchcase(path.name, pattern) for pattern in EXCLUDED_TESTS):
                add(path)
            elif path.name == "web_client.test.cjs":
                add(path)
    for essential in ESSENTIAL:
        if essential not in selected:
            raise ValueError(f"Required application release file is missing: {essential}")
    selected["README.md"] = (README.encode(), 0o644)
    _scan("README.md", selected["README.md"][0])
    return selected


def package_release(source, output, archive):
    original_output, original_archive = Path(output), Path(archive)
    if original_output.is_symlink() or original_archive.is_symlink():
        raise ValueError("Release output and archive cannot be symlinks")
    source, output, archive = Path(source).resolve(), original_output.resolve(), original_archive.resolve()
    if output.exists() or output.is_symlink() or archive.exists() or archive.is_symlink():
        raise ValueError("Release output and archive must be new paths; refusing to overwrite")
    if archive.is_relative_to(output) or output == source or any(output.is_relative_to(source / tree) for tree in (*TREES, "tests", "scripts")):
        raise ValueError("Place the archive outside the release folder and the release outside selected source trees")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", output.name):
        raise ValueError("Use a simple application folder name for the release")
    selected = selected_files(source)
    manifest = {"version": 1, "created_at": datetime.now(timezone.utc).isoformat(),
                "scope": "Application source and authored example data only; no credentials or runtime user data",
                "excluded": [".env", "API keys", "authentication files", "saved model settings", "output/", "uploads/", "jobs/", "virtual environments", "public research datasets", "dataset-dependent research tests"],
                "files": {name: {"sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload)} for name, (payload, _) in sorted(selected.items())}}
    output.mkdir(parents=True)
    for relative, (payload, mode) in sorted(selected.items()):
        target = output / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        target.chmod(mode)
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    _scan("release_manifest.json", manifest_bytes)
    (output / "release_manifest.json").write_bytes(manifest_bytes)
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for path in sorted(output.rglob("*")):
            if path.is_file():
                bundle.write(path, (PurePosixPath(output.name) / path.relative_to(output).as_posix()).as_posix())
    with zipfile.ZipFile(archive) as bundle:
        if bundle.testzip() is not None or any(not _safe_relative(name) for name in bundle.namelist()):
            raise ValueError("The release archive failed its integrity check")
    return {"output": str(output), "archive": str(archive), "files": len(selected) + 1,
            "archive_bytes": archive.stat().st_size, "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
            "credential_and_private_path_scan": "passed", "manifest": str(output / "release_manifest.json")}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args(argv)
    print(json.dumps(package_release(ROOT, args.output, args.archive), indent=2))


if __name__ == "__main__":
    main()
