# Retail deduction reconciliation

A local workspace for importing retail deduction records, confirming column mappings,
running bounded AI-selected computations, and reviewing source-backed results.

## Start locally

Python 3.10 or newer is required. From this folder:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[solver,text,workspace]'
.venv/bin/python -m recon.web
```

Open `http://127.0.0.1:8765/workspace/`. Upload your CSV, TSV, XLSX or JSON tables,
inspect the source previews, assign their financial roles and confirm the column
mappings. PDF support is limited to extractable text; it does not promise scanned
document recognition or automatic financial-table extraction.

In **Model settings**, choose **OpenAI API**, enter an explicit model identifier
supported by your account, enter your API key and test the connection. The session
key is held in server memory only and must be entered again after a server restart.
The API key is sent only from the local Python server to the model service. No key
is included in this repository or returned in result exports.

Alternatively, copy `.env.example` to `.env` and fill in `OPENAI_MODEL` and
`OPENAI_API_KEY` on the server. `.env` is ignored by Git. A configured, authenticated
Codex CLI is optional; it is not required for the OpenAI API path. The displayed
model is the explicitly requested model; backend identity verification is reported
separately rather than assumed.

On Windows, create/activate a virtual environment using your Python installation,
then run `python -m pip install -e ".[solver,text,workspace]"` and
`python -m recon.web`. `start.sh` is an optional macOS/Linux convenience after setup.

## Try the supplied files

`examples/retail_reconciliation/input/` contains an authored mixed-format batch.
Upload only those input files. `mapping_guide.json` documents their roles and
columns; `expected_results.json` contains separate human-authored assertions for
testing and is not an input to the reconciler. These are synthetic examples,
not genuine retailer records or evidence of real-world accuracy.

AI proposes column mappings for review and selects approved computations. Ordinary
code calculates exact amounts, checks document relationships and verifies the
evidence. Missing or contradictory evidence remains unresolved. Reusing the same
recorded receiving shortage across deductions requires review together. Matching a
transaction does not establish deduction liability or recovered money.

Runs and imported records are stored locally under `output/`, which is ignored by
Git. Download results as CSV or JSON from the app. Exported CSV text is protected
against spreadsheet formula execution. This local prototype has bounded supported
financial formats and is not an internet-facing multi-user deployment.

## Tests

```sh
PYTHONPATH=src .venv/bin/python -m unittest discover -s tests -v
node tests/web_client.test.cjs
```

The included tests use injected model responses and do not make live model calls.
Some tests open temporary localhost sockets. Node.js is optional for the JavaScript
client test. The original rules-only baseline remains in `recon.engine`; the
independent financial reconstruction engines and workspace are included separately.

This application distribution intentionally excludes historical public-data research
archives, research accuracy reports and their dataset-dependent tests. It includes
only authored example data and the tests needed for the shipped application. No
claim of AI superiority follows from the supplied examples.

## Share this repository

Review `release_manifest.json` for file hashes. The release excludes real API keys,
`.env`, authentication files, saved model settings, uploads, runs, user records,
virtual environments and downloaded research datasets. Keep these exclusions when
adding files. No license is asserted by this packaging script; the repository owner
must choose any public license separately.
