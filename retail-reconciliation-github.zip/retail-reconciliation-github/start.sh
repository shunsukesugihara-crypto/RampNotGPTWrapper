#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ ! -x .venv/bin/python ]; then
  printf '%s\n' 'Create .venv and install the project first; see README.md.' >&2
  exit 1
fi
exec .venv/bin/python -m recon.web "$@"
